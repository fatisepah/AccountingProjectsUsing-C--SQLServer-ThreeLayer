﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class SanadeHesabdariManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView SanadeHesabdariShow2()
        {
            string str = "Select * from ViewSanadeHesabdari";
            return Show3(str);
        }
        protected DataTable  SanadeHesabdariReportShow2()
        {
            string str = "Select * from ViewSanadeHesabdari";
            return find_row1_2(str);
        }
        protected void SanadeHesabdariDelete2(int IDSanad)
        {
            obj.SanadeHesabdariDelete(IDSanad);
        }
        protected void SanadeHesabdariInsert2(SanadeHesabdariDB db)
        {
            obj.SanadeHesabdariInsert(db.IDSanad,db.FKHesabeBedehkar ,db.FKHesabeBestankar ,db.FKNoeSanad, db.NameKarbar, db.TarikheSanad, db.SharheSanad, db.MablagheBedehkari , db.MablagheBestanKari);
        }
        protected void SanadeHesabdariUpdate2(SanadeHesabdariDB db)
        {
            obj.SanadeHesabdariUpdate(db.IDSanad, db.FKHesabeBedehkar, db.FKHesabeBestankar, db.FKNoeSanad, db.NameKarbar, db.TarikheSanad, db.SharheSanad, db.MablagheBedehkari, db.MablagheBestanKari);

        }
        protected Boolean SanadeHesabdariSearch2(int IDSanad)
        {
            string str = string.Format("select * from TblSanadeHesabdari Where IDSanad = '{0}'", IDSanad);
            return find_row(str);
        }
        protected DataTable SanadeHesabdariSearchID2()
        {
            string str = string.Format("select * from TblSanadeHesabdari");
            return find_row1_2(str);
        }
        protected DataRow SanadeHesabdariFind2(int IDSanad)
        {
            string strsql = string.Format("SELECT * FROM TblSanadeHesabdari Where IDSanad = '{0}'", IDSanad);
            return find_row1(strsql);
        }
       //
       //
       //
        protected string FilterSharheSanad2(string SharheSanad)
        {
            return string.Format("SharheSanad like '%{0}%'", SharheSanad);
        }
        protected string FilterTarikh2(DateTime TarikheSanad)
        {
            return string.Format("TarikheSanad like '%{0}%'", TarikheSanad);
        }
        protected string FilterHBedehkar2(int FKHesabeBedehkar)
        {
            return string.Format("FKHesabeBedehkar like '%{0}%'", FKHesabeBedehkar);
        }
        protected string FilterHBestankar2(int FKHesabeBestankar )
        {
            return string.Format("FKHesabeBestankar like '%{0}%'", FKHesabeBestankar);
        }
    }
}

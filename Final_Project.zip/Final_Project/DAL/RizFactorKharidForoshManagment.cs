﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class RizFactorKharidForoshManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable RizFactorKharidForoshComboShow2()
        {
            string str = "select * from TblRizFactorKharidForosh";
            return ShowCombo3(str);
        }

        protected DataView RizFactorKharidForoshShow2()
        {
            string str = "SELECT * FROM ViewFactorKharidForosh";
            return Show3(str);
        }
        protected void RizFactorKharidForoshDelete2(int IDFactorKHF)
        {
            obj.RizFactorKharidForoshDelete(IDFactorKHF);
        }
        protected void RizFactorKharidForoshInsert2(RizFactorKharidForoshDB db)
        {
            obj.RizFactorKharidForoshInsert(db.IDFactorKHF, db.NameKalayeKharidForosh1, db.Tedade1, db.NameKalayeKharidForosh2, db.Tedade2, db.NameKalayeKharidForosh3, db.Tedade3, db.NameKalayeKharidForosh4, db.Tedade4, db.NameKalayeKharidForosh5, db.Tedade5, db.NameKalayeKharidForosh6, db.Tedade6, db.FKFactor, db.GheimateKol);
        }
        protected void RizFactorKharidForoshUpdate2(RizFactorKharidForoshDB db)
        {
            obj.RizFactorKharidForoshUpdate(db.IDFactorKHF, db.NameKalayeKharidForosh1, db.Tedade1, db.NameKalayeKharidForosh2, db.Tedade2, db.NameKalayeKharidForosh3, db.Tedade3, db.NameKalayeKharidForosh4, db.Tedade4, db.NameKalayeKharidForosh5, db.Tedade5, db.NameKalayeKharidForosh6, db.Tedade6, db.FKFactor, db.GheimateKol);
        }
        protected Boolean RizFactorKharidForoshSearch2(int IDFactorKHF)
        {
            string str = string.Format("SELECT * FROM TblRizFactorKharidForosh Where IDFactorKHF= '{0}'", IDFactorKHF);
            return find_row(str);
        }
        protected DataTable RizFactorKharidForoshSearchID2()
        {
            string str = "SELECT * FROM TblRizFactorKharidForosh";
            return find_row1_2(str);
        }
        protected DataRow RizFactorKharidForoshFind2(int IDFactorKHF)
        {
            string strsql = string.Format("SELECT * FROM TblRizFactorKharidForosh Where IDFactorKHF = '{0}'", IDFactorKHF);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterNameKalayeKharidForosh12(string NameKalayeKharidForosh1)
        {
            return string.Format("NameKalayeKharidForosh1 Like '%{0}%'", NameKalayeKharidForosh1);
        }
        protected string FilterNameKalayeKharidForosh22(string NameKalayeKharidForosh2)
        {
            return string.Format("NameKalayeKharidForosh2 Like '%{0}%'", NameKalayeKharidForosh2);
        }
        protected string FilterNameKalayeKharidForosh32(string NameKalayeKharidForosh3)
        {
            return string.Format("NameKalayeKharidForosh3 Like '%{0}%'", NameKalayeKharidForosh3);
        }
        protected string FilterNameKalayeKharidForosh42(string NameKalayeKharidForosh4)
        {
            return string.Format("NameKalayeKharidForosh4 Like '%{0}%'", NameKalayeKharidForosh4);
        }

    }
}

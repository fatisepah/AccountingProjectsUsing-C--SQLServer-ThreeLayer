﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace DAL
{
   public  class GroupKalaManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView GroupKalaShow2()
        {
            string str = "Select * from TblGroupKala";
            return Show3(str);
        }
        protected DataTable GroupKalaComboShow2()
        {
            string str = "Select * from TblGroupKala";
            return ShowCombo3(str);
        }
        protected void GroupKalaDelete2(int IDGroupKala)
        {
            obj.GroupKalaDelete(IDGroupKala);
        }
        protected void GroupKalaInsert2(GroupKalaDB db)
        {
            obj.GroupKalaInsert(db.IDGroupKala, db.NameGroup);
        }
        protected void GroupKalaUpdate2(GroupKalaDB db)
        {
            obj.GroupKalaUpdate(db.IDGroupKala, db.NameGroup);

        }
        protected Boolean GroupKalaSearch2(int IDGroupKala)
        {
            string str = string.Format("select * from TblGroupKala Where IDGroupKala = '{0}'", IDGroupKala);
            return find_row(str);
        }
        protected Boolean GroupKalaSearchName2(string NameGroup)
        {
            string str = string.Format("SELECT * FROM TblGroupKala Where NameGroup = '{0}'", NameGroup);
            return find_row(str);
        }
        protected DataTable GroupKalaSearchID2()
        {
            string str = string.Format("select * from TblGroupKala");
            return find_row1_2(str);
        }
        protected DataRow GroupKalaFind2(int IDGroupKala)
        {
            string strsql = string.Format("SELECT * FROM TblGroupKala Where IDGroupKala = '{0}'", IDGroupKala);
            return find_row1(strsql);
        }
        protected DataRow GroupKalaFindName2(string NameGroup)
        {
            string strsql = string.Format("SELECT * FROM TblGroupKala Where NameGroup = '{0}'", NameGroup);
            return find_row1(strsql);
        }
    }
}

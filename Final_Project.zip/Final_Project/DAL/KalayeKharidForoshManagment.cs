﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public class KalayeKharidForoshManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView KalayeKharidForoshShow2()
        {
            string str = "SELECT * FROM ViewKalayeKharidForosh";
            return Show3(str);
        }
        protected DataTable  KalayeKharidForoshComboShow2()
        {
            string str = "SELECT * FROM TblKalayeKharidForosh";
            return find_row1_2 (str);
        }
        protected void KalayeKharidForoshDelete2(int IDKalaKHF)
        {
            obj.KalayeKharidForoshDelete(IDKalaKHF);
        }
        protected void KalayeKharidForoshInsert2(KalayeKharidForoshDB db)
        {
            obj.KalayeKharidForoshInsert(db.IDKalaKHF, db.FKNoeKala, db.FKGroupKala, db.NameKala, db.VahedeShomaresheAsli, db.VahedeShomaresheFare, db.HadeaghaleTedadeMojod, db.TedadeKala, db.Tozihat, db.TarikheTolid, db.TarikheEngheza, db.GheimateKharid, db.GheimateForosh, db.Garanty, db.ModeleKala, db.BarcodeKala, db.NameSherkatTolidi);
        }
        protected void KalayeKharidForoshUpdate2(KalayeKharidForoshDB db)
        {
            obj.KalayeKharidForoshUpdate(db.IDKalaKHF, db.FKNoeKala, db.FKGroupKala, db.NameKala,db.VahedeShomaresheAsli ,db.VahedeShomaresheFare , db.HadeaghaleTedadeMojod, db.TedadeKala, db.Tozihat, db.TarikheTolid, db.TarikheEngheza, db.GheimateKharid, db.GheimateForosh, db.Garanty, db.ModeleKala, db.BarcodeKala, db.NameSherkatTolidi);

        }
        protected Boolean KalayeKharidForoshSearch2(int IDKalaKHF)
        {
            string str = string.Format("SELECT * FROM TblKalayeKharidForosh Where IDKalaKHF = '{0}'", IDKalaKHF);
            return find_row(str);
        }
        protected DataTable KalayeKharidForoshSearchID2()
        {
            string str = "SELECT * FROM TblKalayeKharidForosh";
            return find_row1_2(str);
        }
        protected DataRow KalayeKharidForoshFind2(int IDKalaKHF)
        {
            string strsql = string.Format("SELECT * FROM TblKalayeKharidForosh Where IDKalaKHF = '{0}'", IDKalaKHF);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterFKGroupKala2(int FKGroupKala)
        {
            return string.Format("FKGroupKala Like '%{0}%'", FKGroupKala);
        }
        protected string FilterNameKala2(string NameKala)
        {
            return string.Format("NameKala Like '%{0}%'", NameKala);
        }
        protected string FilterNSherkat2(string NameSherkatTolidi)
        {
            return string.Format("NameSherkatTolidi Like '%{0}%'", NameSherkatTolidi);
        }
        //
        ////////////////////////////
        //
    }
}

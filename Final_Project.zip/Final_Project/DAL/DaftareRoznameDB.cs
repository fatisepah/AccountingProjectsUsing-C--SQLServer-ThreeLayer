﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class DaftareRoznameDB
    {
        public int IDDaftareRozname { set; get; }
        public int FKSanadeHesabdari { set; get; }
    }
}

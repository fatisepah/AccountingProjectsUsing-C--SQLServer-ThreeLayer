﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class RizFactorKerayeDB
    {
       public int IDFactorKeraye { set; get; }
       public string NameKalayeKeraye1 { set; get; }
       public int Tedade1 { set; get; }
       public string NameKalayeKeraye2 { set; get; }
       public int Tedade2 { set; get; }
       public string NameKalayeKeraye3 { set; get; }
       public int Tedade3 { set; get; }
       public string NameKalayeKeraye4 { set; get; }
       public int Tedade4 { set; get; }  
       public string NameKalayeKeraye5 { set; get; }
       public int Tedade5 { set; get; }     
       public string NameKalayeKeraye6 { set; get; }
       public int Tedade6 { set; get; }
       public int FKFactor { set; get; }
       public DateTime  TarikheBargashteKala { set; get; }
       public long  GheimateKoleKalaha { set; get; }
       
    }
}

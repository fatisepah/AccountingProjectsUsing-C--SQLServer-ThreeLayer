﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class GhestyManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable GhestyComboShow2()
        {
            string str = "select * from TblGhesty";
            return ShowCombo3(str);
        }

        protected DataView GhestyShow2()
        {
            string str = "SELECT * FROM TblGhesty";
            return Show3(str);
        }
        protected void GhestyDelete2(int IDGhesty)
        {
            obj.GhestyDelete(IDGhesty);
        }
        protected void GhestyInsert2(GhestyDB db)
        {
            obj.GhestyInsert(db.IDGhesty, db.FKNoeTaraconesh,db.FKFactor , db.TarikheSabteGhesti , db.NameDahandeGhest, db.TedadeAghsat , db.TarikhePardakhteAghsat , db.TedadeAghsateMande , db.MablagheGhest, db.DarsadeSodeGhest);
        }
        protected void GhestyUpdate2(GhestyDB db)
        {
            obj.GhestyUpdate(db.IDGhesty, db.FKNoeTaraconesh,db.FKFactor, db.TarikheSabteGhesti, db.NameDahandeGhest, db.TedadeAghsat, db.TarikhePardakhteAghsat, db.TedadeAghsateMande, db.MablagheGhest, db.DarsadeSodeGhest);

        }
        protected Boolean GhestySearch2(int IDGhesty)
        {
            string str = string.Format("SELECT * FROM TblGhesty Where IDGhesty = '{0}'", IDGhesty);
            return find_row(str);
        }
        protected DataTable GhestySearchID2()
        {
            string str = "SELECT * FROM TblGhesty";
            return find_row1_2(str);
        }
        protected DataRow GhestyFind2(int IDGhesty)
        {
            string strsql = string.Format("SELECT * FROM TblGhesty Where IDGhesty = '{0}'", IDGhesty);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterTarikheSabteGhesti2(DateTime TarikheSabteGhesti)
        {
            return string.Format("TarikheSabteGhesti Like '%{0}%'", TarikheSabteGhesti);
        }
        protected string FilterNameDahandeGhest2(string NameDahandeGhest)
        {
            return string.Format("NameDahandeGhest Like '%{0}%'", NameDahandeGhest);
        }
        protected string FilterTarikhePardakhteAghsat2(DateTime  TarikhePardakhteAghsat)
        {
            return string.Format("TarikhePardakhteAghsat Like '%{0}%'", TarikhePardakhteAghsat);
        }
        protected string FilterFKFactor2(int FKFactor)
        {
            return string.Format("FKFactor Like '%{0}%'", FKFactor);
        }
    }
}

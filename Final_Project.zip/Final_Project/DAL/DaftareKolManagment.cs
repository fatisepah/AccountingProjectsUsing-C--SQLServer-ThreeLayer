﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class DaftareKolManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable DaftareKolComboShow2()
        {
            string str = "select * from ViewTarazeAzmayeshi";
            return ShowCombo3(str);
        }

        protected DataView DaftareKolShow2()
        {
            string str = "SELECT * FROM ViewTarazeAzmayeshi";
            return Show3(str);
        }
        protected void DaftareKolDelete2(int IDDaftareKol)
        {
            obj.DaftareKolDelete(IDDaftareKol);
        }
        protected void DaftareKolInsert2(DaftareKolDB db)
        {
            obj.DaftareKolInsert(db.IDDaftareKol, db.FKDaftareRozname,db.FKHesab , db.MandeBedehkar, db.MandeBestankar);
        }
        protected void DaftareKolUpdate2(DaftareKolDB db)
        {
            obj.DaftareKolUpdate(db.IDDaftareKol, db.FKDaftareRozname, db.FKHesab, db.MandeBedehkar, db.MandeBestankar);

        }
        protected Boolean DaftareKolSearch2(int IDDaftareKol)
        {
            string str = string.Format("SELECT * FROM TblDaftareKol Where IDDaftareKol = '{0}'", IDDaftareKol);
            return find_row(str);
        }
        protected Boolean DaftareKolSearchHesab2(int FKHesab)
        {
            string str = string.Format("SELECT * FROM TblDaftareKol Where FKHesab = '{0}'", FKHesab);
            return find_row(str);
        }
        protected DataTable DaftareKolSearchID2()
        {
            string str = "SELECT * FROM TblDaftareKol";
            return find_row1_2(str);
        }
        protected DataRow DaftareKolFind2(int IDDaftareKol)
        {
            string strsql = string.Format("SELECT * FROM TblDaftareKol Where IDDaftareKol = '{0}'", IDDaftareKol);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterIDDaftareKol2(int IDDaftareKol)
        {
            return string.Format("IDDaftareKol Like '%{0}%'", IDDaftareKol);
        }
        protected string FilterMandeBedehkar2(long  MandeBedehkar)
        {
            return string.Format("MandeBedehkar Like '%{0}%'", MandeBedehkar);
        }
        protected string FilterMandeBestankar2(long  MandeBestankar)
        {
            return string.Format("MandeBestankar Like '%{0}%'", MandeBestankar);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class CheckManagment : SqlClass
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable CheckComboShow2()
        {
            string str = "select * from TblCheck";
            return ShowCombo3(str);
        }

        protected DataView CheckShow2()
        {
            string str = "SELECT * FROM TblCheck";
            return Show3(str);
        }
        protected void CheckDelete2(int IDCheck)
        {
            obj.CheckDelete(IDCheck);
        }
        protected void CheckInsert2(CheckDB db)
        {
            obj.CheckInsert(db.IDCheck, db.FKNoeTaraconesh,db.FKFactor , db.TarikheSabteCheck, db.TarikheSarResideCheck, db.NameCheckDahande, db.NameBank, db.ShobeBank, db.VazeiyatePardakhtOrVosol, db.ShomareSerialeCheck, db.MablagheCheck);
        }
        protected void CheckUpdate2(CheckDB db)
        {
            obj.CheckUpdate(db.IDCheck, db.FKNoeTaraconesh,db.FKFactor, db.TarikheSabteCheck, db.TarikheSarResideCheck, db.NameCheckDahande, db.NameBank, db.ShobeBank, db.VazeiyatePardakhtOrVosol, db.ShomareSerialeCheck, db.MablagheCheck);

        }
        protected Boolean CheckSearch2(int IDCheck)
        {
            string str = string.Format("SELECT * FROM TblCheck Where IDCheck = '{0}'", IDCheck);
            return find_row(str);
        }
        protected DataTable CheckSearchID2()
        {
            string str = "SELECT * FROM TblCheck";
            return find_row1_2(str);
        }
        protected DataRow CheckFind2(int IDCheck)
        {
            string strsql = string.Format("SELECT * FROM TblCheck Where IDCheck = '{0}'", IDCheck);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterTarikheSarReside2(DateTime TarikheSarResideCheck)
        {
            return string.Format("TarikheSarResideCheck Like '%{0}%'", TarikheSarResideCheck);
        }
        protected string FilterNameCheckDahande2(string NameCheckDahande)
        {
            return string.Format("NameCheckDahande Like '%{0}%'", NameCheckDahande);
        }
        protected string FilterVazeiyatePardakhtOrVosol2(string VazeiyatePardakhtOrVosol)
        {
            return string.Format("VazeiyatePardakhtOrVosol Like '%{0}%'", VazeiyatePardakhtOrVosol);
        }
        protected string FilterFKFactor2(int FKFactor)
        {
            return string.Format("FKFactor Like '%{0}%'", FKFactor);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class CheckDB
    {
        public int IDCheck { set; get; }
        public int FKNoeTaraconesh { set; get; }
        public int FKFactor { set; get; }
        public DateTime TarikheSabteCheck { set; get; }
        public DateTime TarikheSarResideCheck { set; get; }
        public string NameCheckDahande { set; get; }
        public string NameBank { set; get; }
        public string ShobeBank { set; get; }
        public string VazeiyatePardakhtOrVosol { set; get; }
        public string ShomareSerialeCheck { set; get; }
        public long MablagheCheck { set; get; }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FilterHesabBankiManageMent: SqlClass
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM TblHesabBanki";
            return show_data(strsql);
        }
              
        protected string Filter_kala(string nam_bank)
        {
            return string.Format("NameBank Like '%{0}%'", nam_bank);
        }
        protected string Filter1(string barangh)
        {
            return string.Format("ShomareHesab Like '%{0}%'", barangh);
        }
    }
}

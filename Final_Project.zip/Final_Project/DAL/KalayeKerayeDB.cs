﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class KalayeKerayeDB
    {
        public int IDKalaKeraye { set; get; }
        public int FKNoeKala { set; get; }
        public int FKGroupKala { set; get; }
        public string NameKala { set; get; }
        public string VaziyateKeraye { set; get; }
        public string Tozihat { set; get; }
        public long GheimateKharid { set; get; }
        public long GheimateKeraye { set; get; }
        public int TedadeKalayeMojod { set; get; }
        public int TedadeKerayeDadeShode { set; get; }
        public string Garanty { set; get; }
        public string ModeleKala { set; get; }
        public string BarcodeKala { set; get; }
        public string NameSherkatTolidi { set; get; }
    }
}

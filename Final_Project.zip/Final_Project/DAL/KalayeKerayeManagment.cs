﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class KalayeKerayeManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView KalayeKerayeShow2()
        {
            string str = "SELECT * FROM ViewKalayeKeraye";
            return Show3(str);
        }
        protected DataTable  KalayeKerayeReportShow2()
        {
            string str = "SELECT * FROM ViewKalayeKeraye";
            return find_row1_2(str);
        }
       //
       //
       //
        protected void KalayeKerayeDelete2(int IDKalaKeraye)
        {
            obj.KalayeKerayeDelete(IDKalaKeraye);
        }
        protected void KalayeKerayeInsert2(KalayeKerayeDB db)
        {
            obj.KalayeKerayeInsert(db.IDKalaKeraye , db.FKNoeKala , db.FKGroupKala , db.NameKala , db.VaziyateKeraye, db.Tozihat , db.GheimateKharid , db.GheimateKeraye , db.TedadeKalayeMojod,db.TedadeKerayeDadeShode, db.Garanty, db.ModeleKala, db.BarcodeKala, db.NameSherkatTolidi);
        }
        protected void KalayeKerayeUpdate2(KalayeKerayeDB db)
        {
            obj.KalayeKerayeUpdate(db.IDKalaKeraye, db.FKNoeKala, db.FKGroupKala, db.NameKala, db.VaziyateKeraye, db.Tozihat, db.GheimateKharid, db.GheimateKeraye, db.TedadeKalayeMojod,db.TedadeKerayeDadeShode, db.Garanty, db.ModeleKala, db.BarcodeKala, db.NameSherkatTolidi);

        }
        protected Boolean KalayeKerayeSearch2(int IDKalaKeraye)
        {
            string str = string.Format("SELECT * FROM TblKalayeKeraye Where IDKalaKeraye = '{0}'", IDKalaKeraye);
            return find_row(str);
        }
        protected DataTable KalayeKerayeSearchID2()
        {
            string str = "SELECT * FROM TblKalayeKeraye";
            return find_row1_2(str);
        }
        protected DataRow KalayeKerayeFind2(int IDKalaKeraye)
        {
            string strsql = string.Format("SELECT * FROM TblKalayeKeraye Where IDKalaKeraye = '{0}'", IDKalaKeraye);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterFKGroupKala2(int FKGroupKala)
        {
            return string.Format("FKGroupKala Like '%{0}%'", FKGroupKala);
        }
        protected string FilterNameKala2(string  NameKala)
        {
            return string.Format("NameKala Like '%{0}%'", NameKala);
        }
        protected string FilterVaziyateKeraye2(string VaziyateKeraye)
        {
            return string.Format("VaziyateKeraye Like '%{0}%'", VaziyateKeraye);
        }
        protected string FilterNSherkat2(string  NameSherkatTolidi)
        {
            return string.Format("NameSherkatTolidi Like '%{0}%'", NameSherkatTolidi);
        }
       //
       ////////////////////////////
       //
       //
    }
}

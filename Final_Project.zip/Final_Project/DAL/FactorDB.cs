﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class FactorDB
    {
       public int IDFactor { set; get; }
       public int FKNoeFactor { set; get; }
       public int FKNoeMoshtari { set; get; }
       public int FKMoshtari { set; get; }
        public string  NameMoshtari { set; get; }
        public int FKSanadeHesabdari { set; get; }
        public int FKNaghdy { set; get; }
        public int FKGhesty { set; get; }
        public int FKCheck { set; get; }
        public int FKHavale { set; get; }
        public string  NameKarbar { set; get; }
        public DateTime  TarikheFactor { set; get; }
        public string  DarsadeTakhfif { set; get; }
        public string NameRanande { set; get; }
        public long  DastMozdeKargareBarbari { set; get; }
        public long  KerayeHaml { set; get; }

    }
}

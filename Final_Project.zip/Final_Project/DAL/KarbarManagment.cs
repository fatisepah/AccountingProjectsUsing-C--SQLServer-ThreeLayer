﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class KarbarManagment:SqlClass 
    {
       LinqDataContext obj = new LinqDataContext();
         protected DataView KarbarShow2()
         {
             string str = "Select * from ViewKarbar";
             return Show3(str);              
         }
         protected void KarbarDelete2(int IDKarbar)
         {
             obj.KarbarDelete(IDKarbar);
         }
         protected void KarbarInsert2(KarbarDB db)
         {
             obj.KarbarInsert(db.IDKarbar, db.FKHesabBanki, db.UserName, db.Password, db.NameKarbar, db.FamilyKarbar, db.Semat, db.Madrak, db.CodeMeli,db.TarikheTavalod , db.Sen , db.Jensiyat, db.Address, db.Mobile, db.Tel, db.Email, db.Aks, db.Tozihat);
         }
         protected void KarbarUpdate2(KarbarDB db)
         {
             obj.KarbarUpdate(db.IDKarbar, db.FKHesabBanki, db.UserName, db.Password, db.NameKarbar, db.FamilyKarbar, db.Semat, db.Madrak, db.CodeMeli,db.TarikheTavalod , db.Sen, db.Jensiyat, db.Address, db.Mobile, db.Tel, db.Email, db.Aks, db.Tozihat);

         }

         protected DataRow KarbarFind2(int IDKarbar)
         {
             string strsql = string.Format("SELECT * FROM TblKarbar Where IDKarbar = '{0}'", IDKarbar);
             return find_row1(strsql);
         }
       //
       //
       //
         protected string FilterUserKarbar2(string UserName)
         {
             return string.Format("UserName like '%{0}%'", UserName);
         }
         protected string FilterNameKarbar2(string NameKarbar)
         {
             return string.Format("NameKarbar like '%{0}%'", NameKarbar);
         }
       //
       //
       //
         protected DataTable KarbarSearchID2()
         {
             string str = string.Format("select * from TblKarbar");
             return find_row1_2(str);
         }
         protected Boolean KarbarSearchUser2(string  UserName)
         {
             string str = string.Format("SELECT * FROM TblKarbar Where UserName = '{0}'", UserName);
             return find_row(str);
         }
         protected Boolean KarbarSearchPass2(string Password)
         {
             string str = string.Format("SELECT * FROM TblKarbar Where Password = '{0}'", Password);
             return find_row(str);
         }

    }
}

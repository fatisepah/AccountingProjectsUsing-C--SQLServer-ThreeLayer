﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public  class HesabhaManagment1 : SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable HesabhaComboShow2()
        {
            string str = "select * from TblHesabha";
            return ShowCombo3(str);
        }

        protected DataView HesabhaShow2()
        {
            string str = "SELECT * FROM TblHesabha";
            return Show3(str);
        }
        protected DataTable HesabhaReportShow2()
        {
            string str = "SELECT * FROM TblHesabha";
            return find_row1_2(str);
        }
        protected void HesabhaDelete2(int IDHesab)
        {
            obj.HesabhaDelete(IDHesab);
        }
        protected void HesabhaInsert2(HesabhaDB db)
        {
            obj.HesabhaInsert(db.IDHesab, db.NoeHesab, db.CodeHesabeKol, db.NameHesabKol, db.CodeHesabeMoien, db.NameHesabMoien, db.CodeHesabeTafzily, db.NameHesabTafzily);
        }
        protected void HesabhaUpdate2(HesabhaDB db)
        {
            obj.HesabhaUpdate(db.IDHesab, db.NoeHesab, db.CodeHesabeKol, db.NameHesabKol, db.CodeHesabeMoien, db.NameHesabMoien, db.CodeHesabeTafzily, db.NameHesabTafzily);

        }
        protected Boolean HesabhaSearch2(int IDHesab)
        {
            string str = string.Format("SELECT * FROM TblHesabha Where IDHesab = '{0}'", IDHesab);
            return find_row(str);
        }
        protected DataTable HesabhaSearchID2()
        {
            string str = "SELECT * FROM TblHesabha";
            return find_row1_2(str);
        }
        protected DataRow HesabhaFind2(int IDHesab)
        {
            string strsql = string.Format("SELECT * FROM TblHesabha Where IDHesab = '{0}'", IDHesab);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterNoeHesab2(string NoeHesab)
        {
            return string.Format("NoeHesab Like '%{0}%'", NoeHesab);
        }
        protected string FilterKol2(string NameHesabKol)
        {
            return string.Format("NameHesabKol Like '%{0}%'", NameHesabKol);
        }
        protected string FilterMoien2(string NameHesabMoien)
        {
            return string.Format("NameHesabMoien Like '%{0}%'", NameHesabMoien);
        }
        protected string FilterTafzily2(string NameHesabTafzily)
        {
            return string.Format("NameHesabTafzily Like '%{0}%'", NameHesabTafzily);
        }
    }
}

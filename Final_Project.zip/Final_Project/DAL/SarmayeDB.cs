﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class SarmayeDB
    {
        public int IDSarmaye { set; get; }
        public long SarmayeAvalDore { set; get; }
        public long SarmayeGozariyeMojadad { set; get; }
        public long SoodeVizhe { set; get; }
        public long Bardasht { set; get; }
        public long ZiyaneVizhe { set; get; }
        public long AfzayeshDarSarmaye { set; get; }
        public long KaheshDarSarmaye { set; get; }
        public long SarmayePayanDore { set; get; }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FilterMoshtariManagment: SqlClass
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM ViewMoshtari";
            return show_data(strsql);
        }
              
        protected string Filter_kala(string nam_bank)
        {
            return string.Format("NameMoshtari Like '%{0}%'", nam_bank);
        }
       
       
    }
}

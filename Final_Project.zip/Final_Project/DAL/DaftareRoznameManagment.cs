﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class DaftareRoznameManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable DaftareRoznameComboShow2()
        {
            string str = "select * from TblDaftareRozname";
            return ShowCombo3(str);
        }

        protected DataView DaftareRoznameShow2()
        {
            string str = "SELECT * FROM ViewDaftareRozname";
            return Show3(str);
        }
        protected void DaftareRoznameDelete2(int IDDaftareRozname)
        {
            obj.DaftareRoznameDelete(IDDaftareRozname);
        }
        protected void DaftareRoznameInsert2(DaftareRoznameDB db)
        {
            obj.DaftareRoznameInsert(db.IDDaftareRozname, db.FKSanadeHesabdari);
        }
        protected void DaftareRoznameUpdate2(DaftareRoznameDB db)
        {
            obj.DaftareRoznameUpdate(db.IDDaftareRozname, db.FKSanadeHesabdari);

        }
        protected Boolean DaftareRoznameSearch2(int IDDaftareRozname)
        {
            string str = string.Format("SELECT * FROM TblDaftareRozname Where IDDaftareRozname = '{0}'", IDDaftareRozname);
            return find_row(str);
        }
        protected DataTable DaftareRoznameSearchID2()
        {
            string str = "SELECT * FROM TblDaftareRozname";
            return find_row1_2(str);
        }
        protected DataRow DaftareRoznameFind2(int IDDaftareRozname)
        {
            string strsql = string.Format("SELECT * FROM TblDaftareRozname Where IDDaftareRozname = '{0}'", IDDaftareRozname);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterIDDaftareRozname2(int IDDaftareRozname)
        {
            return string.Format("IDDaftareRozname Like '%{0}%'", IDDaftareRozname);
        }
    }
}

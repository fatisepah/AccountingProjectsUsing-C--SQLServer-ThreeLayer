﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class SoodZiyaneBazarganiDB
    {
        public int IDSoodZiyaneBazargani { set; get; }
        public long Forosh { set; get; }
        public long BargashtAzForoshVaTakhfifat { set; get; }
        public long TakhfifateNaghdiyeForosh { set; get; }
        public long ForosheKhales { set; get; }
        public long MojodiyeKalayeAvalDore { set; get; }
        public long KharidTeyeDore { set; get; }
        public long BargashtAzKharidVaTakhfifat { set; get; }
        public long TakhfifateNaghdiyeKharid { set; get; }
        public long KharideKhales { set; get; }
        public long HazineHamleKalaKharidi { set; get; }
        public long BahayeTamamShodeKalaKharidi { set; get; }
        public long MojodiyeKalayeAmadeForosh { set; get; }
        public long MojodieKalayePayanDore { set; get; }
        public long BahayeTamamShodeKalaForosh { set; get; }
        public long SoodeNaVizhe { set; get; }
        public long HazineOmomiVaEdari { set; get; }
        public long HazinehayeForosh { set; get; }
        public long SoodeKhales { set; get; }
    }
}

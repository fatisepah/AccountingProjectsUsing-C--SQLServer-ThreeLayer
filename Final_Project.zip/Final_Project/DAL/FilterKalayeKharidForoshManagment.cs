﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FilterKalayeKharidForoshManagment: SqlClass
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM ViewKalayeKharidForosh";
            return show_data(strsql);
        }
              
        protected string Filter_kala(string nam_bank)
        {
            return string.Format("FKGroupKala Like '%{0}%'", nam_bank);
        }
        protected string Filter1(string barangh)
        {
            return string.Format("NameKala Like '%{0}%'", barangh);
        }
	protected string FilterVaziyateKeraye2(string VaziyateKeraye)
        {
            return string.Format("NameSherkatTolidi Like '%{0}%'", VaziyateKeraye);
        }
       
    }
}

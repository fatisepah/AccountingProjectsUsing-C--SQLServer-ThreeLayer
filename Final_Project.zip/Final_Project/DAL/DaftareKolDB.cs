﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class DaftareKolDB
    {
       public int IDDaftareKol { set; get; }
       public int FKDaftareRozname { set; get; }
       public int FKHesab { set; get; }
       public long MandeBedehkar { set; get; }
       public long MandeBestankar { set; get; }
    }
}

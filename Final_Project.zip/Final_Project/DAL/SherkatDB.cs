﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class SherkatDB
    {
        public int IDSherkat { set; get; }
        public int FKHesabBanki { set; get; }
        public int FKNoeMoshtari { set; get; }
        public string NameKarbar { set; get; }
        public string NameSherkat { set; get; }
        public string AddressSherkat { set; get; }
        public string TelSherkat { set; get; }
        public string Email { set; get; }
        public string Fax { set; get; }

    }
}

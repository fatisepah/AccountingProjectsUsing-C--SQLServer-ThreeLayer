﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class HavaleDB
    {
        public int IDHavale { set; get; }
        public int FKNoeTaraconesh { set; get; }
        public int FKFactor { set; get; }
        public DateTime TarikheSabteHavale { set; get; }
        public string NameHavaleDahande { set; get; }
        public DateTime TarikheSarResideHavale { set; get; }
        public string NameBank { set; get; }
        public string ShobeBank { set; get; }
        public string VazeiyatePardakhtOrVosol { set; get; }
        public string ShomareSerialeHavale { set; get; }
        public long MablagheHavale { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class NaghdManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable NaghdComboShow2()
        {
            string str = "select * from TblNaghd";
            return ShowCombo3(str);
        }

        protected DataView NaghdShow2()
        {
            string str = "SELECT * FROM TblNaghd";
            return Show3(str);
        }
        protected void NaghdDelete2(int IDNaghdy)
        {
            obj.NaghdDelete(IDNaghdy);
        }
        protected void NaghdInsert2(NaghdDB db)
        {
            obj.NaghdInsert(db.IDNaghdy, db.FKNoeTaraconesh, db.FKFactor, db.TarikheSabteNaghdy, db.NamePardakhtKonande, db.MablagheNaghdy);
        }
        protected void NaghdUpdate2(NaghdDB db)
        {
            obj.NaghdUpdate(db.IDNaghdy, db.FKNoeTaraconesh, db.FKFactor, db.TarikheSabteNaghdy, db.NamePardakhtKonande, db.MablagheNaghdy);

        }
        protected Boolean NaghdSearch2(int IDNaghdy)
        {
            string str = string.Format("SELECT * FROM TblNaghd Where IDNaghdy = '{0}'", IDNaghdy);
            return find_row(str);
        }
        protected DataTable NaghdSearchID2()
        {
            string str = "SELECT * FROM TblNaghd";
            return find_row1_2(str);
        }
        protected DataRow NaghdFind2(int IDNaghdy)
        {
            string strsql = string.Format("SELECT * FROM TblNaghd Where IDNaghdy = '{0}'", IDNaghdy);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterTarikheSabt2(DateTime TarikheSabteNaghdy)
        {
            return string.Format("TarikheSabteNaghdy Like '%{0}%'", TarikheSabteNaghdy);
        }
        protected string FilterNamePardakhtKonande2(string NamePardakhtKonande)
        {
            return string.Format("NamePardakhtKonande Like '%{0}%'", NamePardakhtKonande);
        }
        protected string FilterFKFactor2(int FKFactor)
        {
            return string.Format("FKFactor Like '%{0}%'", FKFactor);
        }
    }
}

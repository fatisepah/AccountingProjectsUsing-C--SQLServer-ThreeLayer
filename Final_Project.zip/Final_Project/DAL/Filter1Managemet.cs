﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class BankManagement : sqlclass1
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM TblHesabha";
            return show_data(strsql);
        }

        protected string Filter_kala(string NameHesabKol)
        {
            return string.Format("NameHesabKol Like '%{0}%'", NameHesabKol);
        }
        protected string FilterNoeHesab2(string NoeHesab)
        {
            return string.Format("NoeHesab Like '%{0}%'", NoeHesab);
        }
        protected string FilterMoien2(string NameHesabMoien)
        {
            return string.Format("NameHesabMoien Like '%{0}%'", NameHesabMoien);
        }
        protected string FilterTafzily2(string NameHesabTafzily)
        {
            return string.Format("NameHesabTafzily Like '%{0}%'", NameHesabTafzily);
        }
       
    }
}

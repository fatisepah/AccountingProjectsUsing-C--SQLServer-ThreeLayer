﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class TaraznameDB
    {
        public int IDTarazname { set; get; }
        public long VajheNaghd { set; get; }
        public long HesabhayeDaryaftani { set; get; }
        public long AsnadeDaryaftaniyeKotahModat { set; get; }
        public long PishPardakhteBime_Hazine { set; get; }
        public long SUMDaraeehayeJari { set; get; }
        public long Zamin { set; get; }
        public long Sakhteman { set; get; }
        public long EstehlakeSakhteman { set; get; }
        public long ArzesheDaftariyeSakhteman { set; get; }
        public long VasayeleNaghliye { set; get; }
        public long EstehlakeVasayeleNaghliye { set; get; }
        public long ArzesheDaftariyeVasayeleNaghliye { set; get; }
        public long SarGhofli { set; get; }
        public long SUMDaraeehayeSabet { set; get; }
        public long SUMDaraeeha { set; get; }
        public long HesabhayePardakhtani { set; get; }
        public long AsnadePardakhtaniyeKotahModat { set; get; }
        public long PishDaryafteDaramad { set; get; }
        public long MaliyatePardakhtani { set; get; }
        public long EzafeBardashteBanki { set; get; }
        public long SUMBedehihayeJari { set; get; }
        public long AsnadePardakhtaniyeBolandModat { set; get; }
        public long OragheGharzePardakhtani { set; get; }
        public long SUMBedehihayeBolandModat { set; get; }
        public long SUMBedehiha { set; get; }
        public int FKSarmaye { set; get; }
        public long SUMBedehihaVaSarmaye { set; get; }
    }
}

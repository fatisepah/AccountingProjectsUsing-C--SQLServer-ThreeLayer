﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class SanadeHesabdariDB
    {
        public int IDSanad { set; get; }
        public int FKHesabeBedehkar { set; get; }
        public int FKHesabeBestankar { set; get; }
        public int FKNoeSanad { set; get; }
        public string NameKarbar { set; get; }
        public DateTime TarikheSanad { set; get; }
        public string SharheSanad { set; get; }
        public long MablagheBedehkari { set; get; }
        public long MablagheBestanKari { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public  class RoidadeGheireMaliManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView RoidadeGheireMaliShow2()
        {
            string str = "SELECT * FROM TblRoidadeGheireMali";
            return Show3(str);
        }
        protected void RoidadeGheireMaliInsert2(RoidadeGheireMaliDB db)
        {
            obj.RoidadeGheireMaliInsert(db.IDRoidad, db.FKNoeSanad, db.NameKarbar, db.TarikheRoidad, db.SharheRoidad);
        }
        protected string Filter2(string SharheRoidad)
        {
            return string.Format("SharheRoidad like '%{0}%'",SharheRoidad);
        }
        protected Boolean RoidadeGheireMaliSearch2(int IDRoidad)
        {
            string str = string.Format("select * from TblRoidadeGheireMali Where IDRoidad = '{0}'", IDRoidad);
            return find_row(str);
        }

        protected DataTable  RoidadeGheireMaliSearchTarikh2()
        {
            string str = "select * from TblRoidadeGheireMali";
            return find_row1_2(str);
        }
        protected DataTable RoidadeGheireMaliSearchID2()
        {
            string str = string.Format("select * from TblRoidadeGheireMali");
            return find_row1_2(str);
        }
    }
}

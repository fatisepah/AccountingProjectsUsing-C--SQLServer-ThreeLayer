﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class NaghdDB
    {
       public int IDNaghdy { set; get; }
       public int FKNoeTaraconesh { set; get; }
       public int FKFactor { set; get; }
       public DateTime  TarikheSabteNaghdy { set; get; }
       public string  NamePardakhtKonande { set; get; }
       public long  MablagheNaghdy { set; get; }

    }
}

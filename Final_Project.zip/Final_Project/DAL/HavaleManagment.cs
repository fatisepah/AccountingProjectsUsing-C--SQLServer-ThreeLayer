﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public  class HavaleManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable HavaleComboShow2()
        {
            string str = "select * from TblHavale";
            return ShowCombo3(str);
        }

        protected DataView HavaleShow2()
        {
            string str = "SELECT * FROM TblHavale";
            return Show3(str);
        }
        protected void HavaleDelete2(int IDHavale)
        {
            obj.HavaleDelete(IDHavale);
        }
        protected void HavaleInsert2(HavaleDB db)
        {
            obj.HavaleInsert(db.IDHavale, db.FKNoeTaraconesh,db.FKFactor , db.TarikheSabteHavale, db.NameHavaleDahande, db.TarikheSarResideHavale, db.NameBank, db.ShobeBank, db.VazeiyatePardakhtOrVosol, db.ShomareSerialeHavale, db.MablagheHavale);
        }
        protected void HavaleUpdate2(HavaleDB db)
        {
            obj.HavaleUpdate(db.IDHavale, db.FKNoeTaraconesh,db.FKFactor , db.TarikheSabteHavale, db.NameHavaleDahande, db.TarikheSarResideHavale, db.NameBank, db.ShobeBank, db.VazeiyatePardakhtOrVosol, db.ShomareSerialeHavale, db.MablagheHavale);

        }
        protected Boolean HavaleSearch2(int IDHavale)
        {
            string str = string.Format("SELECT * FROM TblHavale Where IDHavale = '{0}'", IDHavale);
            return find_row(str);
        }
        protected DataTable HavaleSearchID2()
        {
            string str = "SELECT * FROM TblHavale";
            return find_row1_2(str);
        }
        protected DataRow HavaleFind2(int IDHavale)
        {
            string strsql = string.Format("SELECT * FROM TblHavale Where IDHavale = '{0}'", IDHavale);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterTarikheSarReside2(DateTime TarikheSarResideHavale)
        {
            return string.Format("TarikheSarResideHavale Like '%{0}%'", TarikheSarResideHavale);
        }
        protected string FilterNameHavaleDahande2(string NameHavaleDahande)
        {
            return string.Format("NameHavaleDahande Like '%{0}%'", NameHavaleDahande);
        }
        protected string FilterVazeiyatePardakhtOrVosol2(string VazeiyatePardakhtOrVosol)
        {
            return string.Format("VazeiyatePardakhtOrVosol Like '%{0}%'", VazeiyatePardakhtOrVosol);
        }
        protected string FilterFKFactor2(int FKFactor)
        {
            return string.Format("FKFactor Like '%{0}%'", FKFactor);
        }
    }
}

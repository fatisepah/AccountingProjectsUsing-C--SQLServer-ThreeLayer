﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class SoodZiyaneKhadamatiDB
    {
        public int IDSoodZiyaneKhadamati { set; get; }
        public long DaramadeKhadamat { set; get; }
        public long HazineEjare { set; get; }
        public long HazineHoghogh { set; get; }
        public long HazineAbBarghTel { set; get; }
        public long HazineMotefareghe { set; get; }
        public long SUMHazineha { set; get; }
        public long SoodVaZiyanGhableKasreMaliyat { set; get; }
        public long Maliyat25 { set; get; }
        public long SoodYaZiyaneVizhe { set; get; }
    }
}

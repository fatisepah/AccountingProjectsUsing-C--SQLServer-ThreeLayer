﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class GhestyDB
    {
        public int IDGhesty { set; get; }
        public int FKNoeTaraconesh { set; get; }
        public int FKFactor { set; get; }
        public DateTime  TarikheSabteGhesti { set; get; }
        public string  NameDahandeGhest { set; get; }
        public int TedadeAghsat { set; get; }
        public DateTime  TarikhePardakhteAghsat { set; get; }
        public int TedadeAghsateMande { set; get; }
        public long MablagheGhest { set; get; }
        public string  DarsadeSodeGhest { set; get; }
    }
}

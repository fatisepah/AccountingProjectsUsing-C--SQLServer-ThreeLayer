﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FilterSanadeHesabdariManagment: SqlClass
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM ViewSanadeHesabdari";
            return show_data(strsql);
        }
              
        protected string Filter_kala(string nam_bank)
        {
            return string.Format("SharheSanad Like '%{0}%'", nam_bank);
        }
        protected string FilterTarikh2(DateTime TarikheSanad)
        {
            return string.Format("TarikheSanad like '%{0}%'", TarikheSanad);
        }
        protected string FilterHBedehkar2(int FKHesabeBedehkar)
        {
            return string.Format("FKHesabeBedehkar like '%{0}%'", FKHesabeBedehkar);
        }
        protected string FilterHBestankar2(int FKHesabeBestankar )
        {
            return string.Format("FKHesabeBestankar like '%{0}%'", FKHesabeBestankar);
        }
       
    }
}

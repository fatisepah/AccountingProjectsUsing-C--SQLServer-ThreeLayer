﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class HesabBankiDB
    {
        public int IDHesabBanki { set; get; }
        public string  NameBank { set; get; }
        public string  ShobeBank { set; get; }
        public string ShomareHesab { set; get; }
        public string ShomareKart { set; get; }
        public long MablagheMojodi { set; get; }
    }
}

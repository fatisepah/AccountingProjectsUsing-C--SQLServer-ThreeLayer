﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class SoodZiyaneBazarganiManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView SoodZiyaneBazarganiShow2()
        {
            string str = "Select * from TblSoodZiyaneBazargani";
            return Show3(str);
        }

        protected void SoodZiyaneBazarganiInsert2(SoodZiyaneBazarganiDB db)
        {
            obj.SoodZiyaneBazarganiInsert(db.IDSoodZiyaneBazargani, db.Forosh , db.BargashtAzForoshVaTakhfifat , db.TakhfifateNaghdiyeForosh , db.ForosheKhales , db.MojodiyeKalayeAvalDore , db.KharidTeyeDore , db.BargashtAzKharidVaTakhfifat , db.TakhfifateNaghdiyeKharid , db.KharideKhales , db.HazineHamleKalaKharidi , db.BahayeTamamShodeKalaKharidi , db.MojodiyeKalayeAmadeForosh , db.MojodieKalayePayanDore , db.BahayeTamamShodeKalaForosh , db.SoodeNaVizhe , db.HazineOmomiVaEdari , db.HazinehayeForosh , db.SoodeKhales );
        }
        protected void SoodZiyaneBazarganiUpdate2(SoodZiyaneBazarganiDB db)
        {
            obj.SoodZiyaneBazarganiUpdate(db.IDSoodZiyaneBazargani, db.Forosh, db.BargashtAzForoshVaTakhfifat, db.TakhfifateNaghdiyeForosh, db.ForosheKhales, db.MojodiyeKalayeAvalDore, db.KharidTeyeDore, db.BargashtAzKharidVaTakhfifat, db.TakhfifateNaghdiyeKharid, db.KharideKhales, db.HazineHamleKalaKharidi, db.BahayeTamamShodeKalaKharidi, db.MojodiyeKalayeAmadeForosh, db.MojodieKalayePayanDore, db.BahayeTamamShodeKalaForosh, db.SoodeNaVizhe, db.HazineOmomiVaEdari, db.HazinehayeForosh, db.SoodeKhales);

        }
        protected Boolean SoodZiyaneBazarganiSearch2(int IDSoodZiyaneBazargani)
        {
            string str = string.Format("select * from TblSoodZiyaneBazargani Where IDSoodZiyaneBazargani = '{0}'", IDSoodZiyaneBazargani);
            return find_row(str);
        }
        protected DataRow SoodZiyaneBazarganiFind2(int IDSoodZiyaneBazargani)
        {
            string strsql = string.Format("select * from TblSoodZiyaneBazargani Where IDSoodZiyaneBazargani = '{0}'", IDSoodZiyaneBazargani);
            return find_row1(strsql);
        }
        protected DataTable SoodZiyaneBazarganiSearchID2()
        {
            string str = string.Format("select * from TblSoodZiyaneBazargani");
            return find_row1_2(str);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public class RizFactorKerayeManagment:SqlClass
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataTable RizFactorKerayeComboShow2()
        {
            string str = "select * from TblRizFactorKeraye";
            return ShowCombo3(str);
        }

        protected DataView RizFactorKerayeShow2()
        {
            string str = "SELECT * FROM ViewFactorKeraye";
            return Show3(str);
        }
        protected void RizFactorKerayeDelete2(int IDRizFactorKeraye)
        {
            obj.RizFactorKerayeDelete(IDRizFactorKeraye);
        }
        protected void RizFactorKerayeInsert2(RizFactorKerayeDB db)
        {
            obj.RizFactorKerayeInsert(db.IDFactorKeraye, db.NameKalayeKeraye1, db.Tedade1, db.NameKalayeKeraye2, db.Tedade2, db.NameKalayeKeraye3, db.Tedade3, db.NameKalayeKeraye4, db.Tedade4, db.NameKalayeKeraye5, db.Tedade5, db.NameKalayeKeraye6, db.Tedade6, db.FKFactor, db.TarikheBargashteKala, db.GheimateKoleKalaha);
        }
        protected void RizFactorKerayeUpdate2(RizFactorKerayeDB db)
        {
            obj.RizFactorKerayeUpdate(db.IDFactorKeraye, db.NameKalayeKeraye1, db.Tedade1, db.NameKalayeKeraye2, db.Tedade2, db.NameKalayeKeraye3, db.Tedade3, db.NameKalayeKeraye4, db.Tedade4, db.NameKalayeKeraye5, db.Tedade5, db.NameKalayeKeraye6, db.Tedade6, db.FKFactor, db.TarikheBargashteKala, db.GheimateKoleKalaha);

        }
        protected Boolean RizFactorKerayeSearch2(int IDFactorKeraye)
        {
            string str = string.Format("SELECT * FROM TblRizFactorKeraye Where IDFactorKeraye= '{0}'", IDFactorKeraye);
            return find_row(str);
        }
        protected DataTable RizFactorKerayeSearchID2()
        {
            string str = "SELECT * FROM TblRizFactorKeraye";
            return find_row1_2(str);
        }
        protected DataRow RizFactorKerayeFind2(int IDFactorKeraye)
        {
            string strsql = string.Format("SELECT * FROM TblRizFactorKeraye Where IDFactorKeraye = '{0}'", IDFactorKeraye);
            return find_row1(strsql);
        }
        ///////
        /////////////////////////فیلترها
        //

        protected string FilterNameKalayeKeraye12(string NameKalayeKeraye1)
        {
            return string.Format("NameKalayeKeraye1 Like '%{0}%'", NameKalayeKeraye1);
        }
        protected string FilterNameKalayeKeraye22(string NameKalayeKeraye2)
        {
            return string.Format("NameKalayeKeraye2 Like '%{0}%'", NameKalayeKeraye2);
        }
        protected string FilterNameKalayeKeraye32(string NameKalayeKeraye3)
        {
            return string.Format("NameKalayeKeraye3 Like '%{0}%'", NameKalayeKeraye3);
        }
        protected string FilterNameKalayeKeraye42(string NameKalayeKeraye4)
        {
            return string.Format("NameKalayeKeraye4 Like '%{0}%'", NameKalayeKeraye4);
        }

        protected string FilterTarikheBargashteKala2(DateTime TarikheBargashteKala)
        {
            return string.Format("TarikheBargashteKala Like '%{0}%'", TarikheBargashteKala);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
  public class HesabhaDB
    {
        public int IDHesab { set; get; }
        public string NoeHesab { set; get; }
        public int CodeHesabeKol { set; get; }
        public string NameHesabKol { set; get; }
        public int CodeHesabeMoien { set; get; }
        public string NameHesabMoien { set; get; }
        public int CodeHesabeTafzily { set; get; }
        public string NameHesabTafzily { set; get; }

    }
}

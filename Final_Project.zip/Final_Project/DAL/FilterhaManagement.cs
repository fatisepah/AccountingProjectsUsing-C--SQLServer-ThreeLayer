﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FilterhaManagement : SqlClass 
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM TblHesabha";
            return show_data(strsql);
        }
        
        protected string Filter_kala(string nam_bank)
        {
            return string.Format("NameHesabKol Like '%{0}%'", nam_bank);
        }
        protected string Filter39(string str39)
        {
            return string.Format("NameHesabMoein Like '%{0}%'", str39);
        }
        protected string Filter30_39(string str30_39)
        {
            return string.Format("NameHesabTafzily Like '%{0}%'", str30_39);
        }
        protected string FilterNoeHesab2(string NoeHesab)
        {
            return string.Format("NoeHesab Like '%{0}%'", NoeHesab);
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
   public  class FilterManagment1 : SqlClass 
    {
        protected DataView RoidadeGheireMaliShow2()
        {
            string str = "SELECT * FROM TblRoidadeGheireMali";
            return Show3(str);
        }
        protected DataView HesabhaShow2()
        {
            string str = "SELECT * FROM TblHesabha";
            return Show3(str);
        }
        protected string FilterSharheRoidad2(string SharheRoidad)
        {
            return string.Format("SharheRoidad like '%{0}%'", SharheRoidad);
        }
        protected string FilterNameHesabKol2(string NameHesabKol)
        {
            return string.Format("NameHesabKol like '%{0}%'", NameHesabKol);
        }


        //فیلترها رو به این صورت تغییر دادم که اینبار به امید خدا اجرا بشن
        protected string Filter30(string str30)
        {
            return string.Format("NameHesabKol Like '%{0}%'", str30);
        }
        protected string Filter39(string str39)
        {
            return string.Format("NameHesabMoein Like '%{0}%'", str39);
        }
        protected string Filter30_39(string str30_39)
        {
            return string.Format("NameHesabTafzily Like '%{0}%'", str30_39);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class SarmayeManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView SarmayeShow2()
        {
            string str = "Select * from TblSarmaye";
            return Show3(str);
        }

        protected void SarmayeInsert2(SarmayeDB db)
        {
            obj.SarmayeInsert(db.IDSarmaye, db.SarmayeAvalDore , db.SarmayeGozariyeMojadad , db.SoodeVizhe, db.Bardasht, db.ZiyaneVizhe, db.AfzayeshDarSarmaye, db.KaheshDarSarmaye, db.SarmayePayanDore );
        }
        protected void SarmayeUpdate2(SarmayeDB db)
        {
            obj.SarmayeUpdate(db.IDSarmaye, db.SarmayeAvalDore, db.SarmayeGozariyeMojadad, db.SoodeVizhe, db.Bardasht, db.ZiyaneVizhe, db.AfzayeshDarSarmaye, db.KaheshDarSarmaye, db.SarmayePayanDore);

        }
        protected Boolean SarmayeSearch2(int IDSarmaye)
        {
            string str = string.Format("select * from TblSarmaye Where IDSarmaye = '{0}'", IDSarmaye);
            return find_row(str);
        }
        protected DataRow SarmayeFind2(int IDSarmaye)
        {
            string strsql = string.Format("select * from TblSarmaye Where IDSarmaye = '{0}'", IDSarmaye);
            return find_row1(strsql);
        }
        protected DataTable SarmayeSearchID2()
        {
            string str = string.Format("select * from TblSarmaye");
            return find_row1_2(str);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class SqlClass
    {
        static string strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\LSakhteman.mdf;Integrated Security=True;Connect Timeout=100;User Instance=True";
        SqlConnection cn = new SqlConnection(strcon);
        private void Connect()
        {
            if (cn == null)
                cn = new SqlConnection(strcon);
            if (cn.State == ConnectionState.Closed)
                cn.Open();
        }
        private void disconnect()
        {
            cn.Close();
        }

        //  برای پیدا کردن سطر استفاده می شود و مقداری بولین را میفرستدfind_row
        protected Boolean find_row(string str)
        {
            DataSet ds = new DataSet();
            Connect();
            SqlDataAdapter sda = new SqlDataAdapter(str, cn);
            sda.Fill(ds);
            disconnect();
            if (ds.Tables[0].Rows.Count == 0)
                return false;
            else
                return true;
        }

        //sql برای اجرای دستورات 
        protected Boolean ExecuteQuery(string strsql)
        {
            try
            {
                Connect();
                SqlCommand objcommand = new SqlCommand(strsql, cn);
                objcommand.ExecuteNonQuery();
                disconnect();
                return true;
            }
            catch
            {
                disconnect();
                return false;
            }
        }

        //سطر موردنظر را پیدا کرده و میفرستدfind_row1
        protected DataRow find_row1(string str)
        {
            DataSet ds = new DataSet();
            Connect();
            SqlDataAdapter sda = new SqlDataAdapter(str, cn);
            sda.Fill(ds);
            disconnect();
            return ds.Tables[0].Rows[0];
        }
        protected DataTable find_row1_2(string str)
        {
            DataSet ds = new DataSet();
            Connect();
            SqlDataAdapter sda = new SqlDataAdapter(str, cn);
            sda.Fill(ds);
            disconnect();
            return ds.Tables[0];
        }

        protected DataView Show3(string str)
        {
            Connect();
            SqlDataAdapter sda = new SqlDataAdapter(str, cn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            disconnect();
            DataView dv = new DataView();
            dv.Table = ds.Tables[0];
            return dv;
        }
        protected DataTable ShowCombo3(string str)
        {
            Connect();
            SqlDataAdapter ADAP = new SqlDataAdapter(str, cn);
            DataSet DS = new DataSet();
            ADAP.Fill(DS);
            disconnect();
            return DS.Tables[0];
        }
        protected DataView show_data(string str)
        {
            DataSet ds = new DataSet();
            Connect();
            SqlDataAdapter sda = new SqlDataAdapter(str, cn);
            sda.Fill(ds);
            disconnect();
            DataView dv = new DataView();
            dv.Table = ds.Tables[0];
            return dv;
        }
    }
}
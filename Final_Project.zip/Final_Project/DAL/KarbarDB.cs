﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class KarbarDB
    {
        public int IDKarbar {set; get;}
        public int FKHesabBanki {set; get;}
        public string UserName {set; get;}
        public string Password {set; get;}
        public string NameKarbar {set; get;}
        public string FamilyKarbar {set; get;}
        public string Semat {set; get;}
        public string Madrak {set; get;}
        public string CodeMeli { set; get; }
        public string TarikheTavalod { set; get; }
        public int Sen {set; get;}
        public string Jensiyat{set; get;}
        public string Address {set; get;}
        public string Mobile {set; get;}
        public string Tel {set; get;}
        public string Email {set; get;}
        public byte[] Aks{set; get;}
        public string Tozihat{set; get;}


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class MoshtariManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView MoshtariShow2()
        {
            string str = "Select * from  ViewMoshtari";
            return Show3(str);
        }
        protected DataTable MoshtariComboShow2()
        {
            string str = "Select * from  ViewMoshtari";
            return find_row1_2(str);
        }
        protected void MoshtariDelete2(int IDMoshtari)
        {
            obj.MoshtariDelete(IDMoshtari);
        }
        protected void MoshtariInsert2(MoshtariDB db)
        {
            obj.MoshtariInsert(db.IDMoshtari ,db.FKHesabBanki ,db.FKNoeMoshtari,db.NameKarbar ,db.NameMoshtari ,db.Mobile ,db.AddressKhane ,db.AddressKar ,db.Email);
        }
        protected void MoshtariUpdate2(MoshtariDB db)
        {
            obj.MoshtariUpdate(db.IDMoshtari, db.FKHesabBanki, db.FKNoeMoshtari,db.NameKarbar, db.NameMoshtari, db.Mobile, db.AddressKhane, db.AddressKar, db.Email);

        }
        protected Boolean MoshtariSearch2(int IDMoshtari)
        {
            string str = string.Format("select * from TblMoshtari Where IDMoshtari = '{0}'", IDMoshtari);
            return find_row(str);
        }
        protected DataRow  MoshtariFind2(int IDMoshtari)
        {
            string strsql = string.Format("SELECT * FROM TblMoshtari Where IDMoshtari = '{0}'", IDMoshtari);
            return find_row1(strsql);
        }
        protected DataTable MoshtariSearchID2()
        {
            string str = string.Format("select * from TblMoshtari");
            return find_row1_2(str);
        }
        protected string FilterNMoshtari2(string NameMoshtari)
        {
            return string.Format("NameMoshtari like '%{0}%'", NameMoshtari);
        }
    }
}

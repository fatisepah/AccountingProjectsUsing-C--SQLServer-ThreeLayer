﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public  class RoidadeGheireMaliDB
    {
       public int IDRoidad { set; get; }
       public int FKNoeSanad{set; get;}
       public string NameKarbar{set; get;}
       public DateTime TarikheRoidad{set; get;}
       public string SharheRoidad{set; get;}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class SoodZiyaneKhadamatiManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView SoodZiyaneKhadamatiShow2()
        {
            string str = "Select * from TblSoodZiyaneKhadamati";
            return Show3(str);
        }

        protected void SoodZiyaneKhadamatiInsert2(SoodZiyaneKhadamatiDB  db)
        {
            obj.SoodZiyaneKhadamatiInsert(db.IDSoodZiyaneKhadamati, db.DaramadeKhadamat, db.HazineEjare , db.HazineHoghogh , db.HazineAbBarghTel , db.HazineMotefareghe , db.SUMHazineha, db.SoodVaZiyanGhableKasreMaliyat , db.Maliyat25, db.SoodYaZiyaneVizhe);
        }
        protected void SoodZiyaneKhadamatiUpdate2(SoodZiyaneKhadamatiDB db)
        {
            obj.SoodZiyaneKhadamatiUpdate(db.IDSoodZiyaneKhadamati, db.DaramadeKhadamat, db.HazineEjare, db.HazineHoghogh, db.HazineAbBarghTel, db.HazineMotefareghe, db.SUMHazineha, db.SoodVaZiyanGhableKasreMaliyat, db.Maliyat25, db.SoodYaZiyaneVizhe);

        }
        protected Boolean SoodZiyaneKhadamatiSearch2(int IDSoodZiyaneKhadamati)
        {
            string str = string.Format("select * from TblSoodZiyaneKhadamati Where IDSoodZiyaneKhadamati = '{0}'", IDSoodZiyaneKhadamati);
            return find_row(str);
        }
        protected DataRow SoodZiyaneKhadamatiFind2(int IDSoodZiyaneKhadamati)
        {
            string strsql = string.Format("select * from TblSoodZiyaneKhadamati Where IDSoodZiyaneKhadamati = '{0}'", IDSoodZiyaneKhadamati);
            return find_row1(strsql);
        }
        protected DataTable SoodZiyaneKhadamatiSearchID2()
        {
            string str = string.Format("select * from TblSoodZiyaneKhadamati");
            return find_row1_2(str);
        }
    }
}

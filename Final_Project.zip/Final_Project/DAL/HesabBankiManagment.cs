﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class HesabBankiManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView  HesabBankiShow2()
        {
            string str = "Select * from TblHesabBanki";
            return Show3(str);
        }
        protected DataTable  HesabBankiReportShow2()
        {
            string str = "Select * from TblHesabBanki";
            return find_row1_2(str);
        }
       //
       //
       //
        protected void HesabBankiDelete2(int IDHesabBanki)
        {
            obj.HesabBankiDelete(IDHesabBanki);
        }
        protected void HesabBankiInsert2(HesabBankiDB db)
        {
            obj.HesabBankiInsert(db.IDHesabBanki, db.NameBank, db.ShobeBank,db.ShomareHesab ,db.ShomareKart ,db.MablagheMojodi);
        }
        protected void HesabBankiUpdate2(HesabBankiDB db)
        {
            obj.HesabBankiUpdate(db.IDHesabBanki, db.NameBank, db.ShobeBank, db.ShomareHesab,db.ShomareKart,db.MablagheMojodi );

        }
        protected Boolean HesabBankiSearch2(int IDHesabBanki)
        {
            string str = string.Format("select * from TblHesabBanki Where IDHesabBanki = '{0}'", IDHesabBanki);
            return find_row(str);
        }
        protected DataTable  HesabBankiSearchID2()
        {
            string str = string.Format("select * from TblHesabBanki");
            return find_row1_2(str);
        }
        protected DataRow HesabBankiFind2(int IDHesabBanki)
        {
            string strsql = string.Format("SELECT * FROM TblHesabBanki Where IDHesabBanki = '{0}'", IDHesabBanki);
            return find_row1(strsql);
        }
        protected string FilterNBank2(string NameBank)
        {
            return string.Format("NameBank like '%{0}%'", NameBank);
        }
        protected string FilterSHHesab2(string ShomareHesab)
        {
            return string.Format("ShomareHesab like '%{0}%'", ShomareHesab);
        }
    }
}

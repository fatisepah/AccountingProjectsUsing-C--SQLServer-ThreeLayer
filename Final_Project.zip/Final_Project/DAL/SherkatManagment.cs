﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class SherkatManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView SherkatShow2()
        {
            string str = "Select * from ViewSherkat";
            return Show3(str);
        }
        protected DataTable SherkatComboShow2()
        {
            string str = "Select * from ViewSherkat";
            return find_row1_2(str);
        }
        protected void SherkatDelete2(int IDSherkat)
        {
            obj.SherkatDelete(IDSherkat);
        }
        protected void SherkatInsert2(SherkatDB db)
        {
            obj.SherkatInsert(db.IDSherkat, db.FKHesabBanki, db.FKNoeMoshtari,db.NameKarbar, db.NameSherkat, db.AddressSherkat, db.TelSherkat,db.Email,db.Fax);
        }
        protected void SherkatUpdate2(SherkatDB db)
        {
            obj.SherkatUpdate(db.IDSherkat, db.FKHesabBanki, db.FKNoeMoshtari,db.NameKarbar, db.NameSherkat, db.AddressSherkat, db.TelSherkat, db.Email, db.Fax);

        }
        protected Boolean SherkatSearch2(int IDSherkat)
        {
            string str = string.Format("select * from TblSherkat Where IDSherkat = '{0}'", IDSherkat);
            return find_row(str);
        }
        protected DataRow  SherkatFind2(int IDSherkat)
        {
            string strsql = string.Format("select * from TblSherkat Where IDSherkat = '{0}'", IDSherkat);
            return find_row1(strsql);
        }
        protected DataTable SherkatSearchID2()
        {
            string str = string.Format("select * from TblSherkat");
            return find_row1_2(str);
        }
        protected string FilterNSherkat2(string NameSherkat)
        {
            return string.Format("NameSherkat like '%{0}%'", NameSherkat);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
   public class KalayeKharidForoshDB
    {
        public int IDKalaKHF { set; get; }
        public int FKNoeKala { set; get; }
        public int FKGroupKala { set; get; }
        public string NameKala { set; get; }
        public string VahedeShomaresheAsli { set; get; }
        public string VahedeShomaresheFare { set; get; }
        public int HadeaghaleTedadeMojod { set; get; }
        public int TedadeKala { set; get; }
        public string Tozihat { set; get; }
        public DateTime TarikheTolid { set; get; }
        public DateTime TarikheEngheza { set; get; }
        public long GheimateKharid { set; get; }
        public long GheimateForosh { set; get; }
        public string Garanty { set; get; }
        public string ModeleKala { set; get; }
        public string BarcodeKala { set; get; }
        public string NameSherkatTolidi { set; get; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
   public  class TaraznameManagment:SqlClass 
    {
        LinqDataContext obj = new LinqDataContext();
        protected DataView TaraznameShow2()
        {
            string str = "Select * from TblTarazname";
            return Show3(str);
        }

        protected void TaraznameInsert2(TaraznameDB db)
        {
            obj.TaraznameInsert(db.IDTarazname, db.VajheNaghd, db.HesabhayeDaryaftani, db.AsnadeDaryaftaniyeKotahModat, db.PishPardakhteBime_Hazine, db.SUMDaraeehayeJari, db.Zamin, db.Sakhteman, db.EstehlakeSakhteman, db.ArzesheDaftariyeSakhteman, db.VasayeleNaghliye, db.EstehlakeVasayeleNaghliye, db.ArzesheDaftariyeVasayeleNaghliye, db.SarGhofli, db.SUMDaraeehayeSabet, db.SUMDaraeeha, db.HesabhayePardakhtani, db.AsnadePardakhtaniyeKotahModat, db.PishDaryafteDaramad, db.MaliyatePardakhtani, db.EzafeBardashteBanki, db.SUMBedehihayeJari, db.AsnadePardakhtaniyeBolandModat, db.OragheGharzePardakhtani, db.SUMBedehihayeBolandModat, db.SUMBedehiha, db.FKSarmaye, db.SUMBedehihaVaSarmaye);
        }
        protected void TaraznameUpdate2(TaraznameDB db)
        {
            obj.TaraznameUpdate(db.IDTarazname, db.VajheNaghd, db.HesabhayeDaryaftani, db.AsnadeDaryaftaniyeKotahModat, db.PishPardakhteBime_Hazine, db.SUMDaraeehayeJari, db.Zamin, db.Sakhteman, db.EstehlakeSakhteman, db.ArzesheDaftariyeSakhteman, db.VasayeleNaghliye, db.EstehlakeVasayeleNaghliye, db.ArzesheDaftariyeVasayeleNaghliye, db.SarGhofli, db.SUMDaraeehayeSabet, db.SUMDaraeeha, db.HesabhayePardakhtani, db.AsnadePardakhtaniyeKotahModat, db.PishDaryafteDaramad, db.MaliyatePardakhtani, db.EzafeBardashteBanki, db.SUMBedehihayeJari, db.AsnadePardakhtaniyeBolandModat, db.OragheGharzePardakhtani, db.SUMBedehihayeBolandModat, db.SUMBedehiha, db.FKSarmaye, db.SUMBedehihaVaSarmaye);

        }
        protected Boolean TaraznameSearch2(int IDTarazname)
        {
            string str = string.Format("select * from TblTarazname Where IDTarazname = '{0}'", IDTarazname);
            return find_row(str);
        }
        protected DataRow TaraznameFind2(int IDTarazname)
        {
            string strsql = string.Format("select * from TblTarazname Where IDTarazname = '{0}'", IDTarazname);
            return find_row1(strsql);
        }
        protected DataTable TaraznameSearchID2()
        {
            string str = string.Format("select * from TblTarazname");
            return find_row1_2(str);
        }
    }
}

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class FilterNaghdManagment: SqlClass
    {
        protected DataView show_data()
        {
            string strsql = "SELECT * FROM TblNaghd";
            return show_data(strsql);
        }
              
        protected string Filter_kala(string nam_bank)
        {
            return string.Format("TarikheSabteNaghdy Like '%{0}%'", nam_bank);
        }
        protected string FilterTarikh2(DateTime TarikheSanad)
        {
            return string.Format("NamePardakhtKonande like '%{0}%'", TarikheSanad);
        }
        protected string FilterHBedehkar2(int FKHesabeBedehkar)
        {
            return string.Format("FKFactor like '%{0}%'", FKHesabeBedehkar);
        }
        
       
    }
}

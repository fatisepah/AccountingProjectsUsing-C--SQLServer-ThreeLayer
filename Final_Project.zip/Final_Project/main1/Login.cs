﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using DAL;
using BLL;
namespace main1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        DataTable dt = new DataTable();
        KarbarData KData = new KarbarData();
        private void taeed_Click(object sender, EventArgs e)
        {
            if(usertxt .Text =="" && passtxt .Text =="")
            {
                MessageBox.Show("نام کاربری و کلمه عبور را وارد نمایید", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                usertxt.Focus();
            }
            else if(usertxt .Text =="")
            {
                MessageBox.Show("نام کاربری را وارد نمایید", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                usertxt.Focus();
            }
           else if(passtxt .Text =="")
            {
                MessageBox.Show("کلمه عبور را وارد نمایید", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                passtxt.Focus();
            }
            else if (KData.KarbarSearchUser1(usertxt.Text) && KData.KarbarSearchPass1(passtxt.Text))
            {
                this.Close();

            }
            else
            {
                MessageBox.Show("نام کاربری یا رمز عبور اشتباه است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                usertxt.Focus();
            }
            dt = KData.KarbarSearchID1();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][2].ToString()== usertxt .Text  && dt.Rows[i][3].ToString() ==passtxt .Text )
                {
                    Class1.NameFamilyKarbar = dt.Rows[i][4].ToString() +" "+ dt.Rows[i][5].ToString();
                    Class1.SemateKarbar=dt.Rows[i][6].ToString();
                    break;
                }
            }

           
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Login_Load(object sender, EventArgs e)
        {
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
           // Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.System) + Path.DirectorySeparatorChar + "osk.exe");
        }

        private void usertxt_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.System) + Path.DirectorySeparatorChar + "osk.exe");
        }

    }
}

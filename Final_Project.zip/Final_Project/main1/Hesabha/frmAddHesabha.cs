﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Hesabha
{
    public partial class frmAddHesabha : Form
    {
        public frmAddHesabha()
        {
            InitializeComponent();
        }
        HesabhaDB DBhesab = new HesabhaDB(); 
        HesabhaData  objhesab=new HesabhaData ();
        //
        //
        int k = 0;
        private void idkoltxt_TextChanged(object sender, EventArgs e)
        {
            if (idkoltxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                idkoltxt.Text = Class1.convert_number(idkoltxt.Text.Replace(",", ""));
                idkoltxt.Select(idkoltxt.Text.Length, 0);
            }
        }

        private void idkoltxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        //
        //
        //
        int k1 = 0;
        private void idmoientxt_TextChanged(object sender, EventArgs e)
        {
            if (idmoientxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idmoientxt.Text = Class1.convert_number(idmoientxt.Text.Replace(",", ""));
                idmoientxt.Select(idmoientxt.Text.Length, 0);
            }
        }

        private void idmoientxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        //
        //
        //
        int k2 = 0;
        private void idtafzilytxt_TextChanged(object sender, EventArgs e)
        {
            if (idtafzilytxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                idtafzilytxt.Text = Class1.convert_number(idtafzilytxt.Text.Replace(",", ""));
                idtafzilytxt.Select(idtafzilytxt.Text.Length, 0);
            }
        }

        private void idtafzilytxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        //
        //
        //
        private void sabtbtn_Click(object sender, EventArgs e)
        {

            if (idhesabtxt.Text != "" && idkoltxt.Text != "" && noehesabcmb.Text != "" && namekoltxt.Text != "" && idmoientxt.Text != "" && namemoientxt.Text != "" && idtafzilytxt.Text != "" && nametafzilytxt.Text != "")
            {
                DBhesab.IDHesab = Convert.ToInt32(idhesabtxt.Text);
                DBhesab.NoeHesab = noehesabcmb.Text;
                DBhesab.CodeHesabeKol = Convert.ToInt32(idkoltxt.Text);
                DBhesab.NameHesabKol = namekoltxt.Text;
                DBhesab.CodeHesabeMoien = Convert.ToInt32(idmoientxt.Text);
                DBhesab.NameHesabMoien = namemoientxt.Text;
                DBhesab.CodeHesabeTafzily = Convert.ToInt32(idtafzilytxt.Text);
                DBhesab.NameHesabTafzily = nametafzilytxt.Text;
                if (Class1.virayesh != 0)
                {
                    if (objhesab.HesabhaSearch1(DBhesab.IDHesab) && Class1.virayesh != DBhesab.IDHesab)
                    {
                        MessageBox.Show(" کد حساب تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        objhesab.HesabhaUpdate1(DBhesab);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                  if (!objhesab.HesabhaSearch1(DBhesab.IDHesab))
                   {
                     objhesab.HesabhaInsert1(DBhesab);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                    }
                    Close();
                   }
                  else
                  {
                      MessageBox.Show("کد حساب تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                  }
                }
                 
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Hide();
            frmHesabha Hb = new frmHesabha();
            Hb.ShowDialog();
            
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            

            idhesabtxt.Text = "";
            noehesabcmb.Text = "";
            idkoltxt.Text = "";
            namekoltxt.Text = "";
            idmoientxt.Text = "";
            namemoientxt.Text = "";
            idtafzilytxt.Text = "";
            nametafzilytxt.Text = "";
            this.Close();
        }



        private void set_color()
        {
            idhesabtxt.BackColor = Color.White;
            noehesabcmb.BackColor = Color.White;
            idkoltxt .BackColor = Color.White;
            namekoltxt .BackColor = Color.White;
            idmoientxt .BackColor = Color.White;
            namemoientxt .BackColor = Color.White;
            idtafzilytxt.BackColor = Color.White;
            nametafzilytxt.BackColor = Color.White;
        }

        private void idhesabtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idhesabtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idkoltxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idkoltxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namekoltxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namekoltxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idmoientxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idmoientxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namemoientxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namemoientxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idtafzilytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idtafzilytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void nametafzilytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            nametafzilytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void frmHesabha_Load(object sender, EventArgs e)
        {

           if (Class1.virayesh != 0)
           {
               DBhesab = objhesab.HesabhaFind1(Class1 .virayesh);
               idhesabtxt.Text = DBhesab.IDHesab.ToString();
               noehesabcmb.Text = DBhesab.NoeHesab;
               idkoltxt.Text = DBhesab.CodeHesabeKol.ToString();
               namekoltxt.Text = DBhesab.NameHesabKol;
               idmoientxt.Text = DBhesab.CodeHesabeMoien.ToString();
               namemoientxt.Text = DBhesab.NameHesabMoien;
               idtafzilytxt.Text = DBhesab.CodeHesabeTafzily.ToString();
               nametafzilytxt.Text = DBhesab.NameHesabTafzily;
           }
           else
           {
               int i1 = 0;
               int i2 = 1;
               DataTable dt = objhesab.HesabhaSearchID1();
               for (int i = 0; i < dt.Rows.Count; i++)
               {
                   i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                   if (i2 < i1)
                   {
                       i2 = i1;
                   }
               }
               if (dt.Rows.Count == 0)
               {
                   idhesabtxt.Text = "1";
               }
               else
               {
                   idhesabtxt.Text = Convert.ToString(i2 + 1);
               }

           }
           
        }
        private void frmAddHesabha_FormClosing(object sender, FormClosingEventArgs e)
        {
            idhesabtxt.Text = "";
            noehesabcmb.Text = "";
            idkoltxt.Text = "";
            namekoltxt.Text = "";
            idmoientxt.Text = "";
            namemoientxt.Text = "";
            idtafzilytxt.Text = "";
            nametafzilytxt.Text = "";
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
           this . Close();
        }
        //
        //
        //


        private void noehesabcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            noehesabcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Hesabha
{
    public partial class frmHesabha : Form
    {
        public frmHesabha()
        {
            InitializeComponent();
        }
        HesabhaData HData=new HesabhaData ();
        FilterData1 FData = new FilterData1();
        FilterhaData bd = new FilterhaData();
        private void virayeshbtn_Click(object sender, EventArgs e)
        {  
           Hesabha.frmAddHesabha obj = new frmAddHesabha();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                if (obj.ShowDialog() == DialogResult.OK) { }

                dataGridView1.DataSource = true;
                dataGridView1.DataSource = FData.HesabhaShow1();
                set_datagrid();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد حساب ";
            dataGridView1.Columns[1].HeaderText = "نوع حساب ";
            dataGridView1.Columns[2].HeaderText = "کد حساب کل";
            dataGridView1.Columns[3].HeaderText = "نام حساب کل";
            dataGridView1.Columns[4].HeaderText = "کد حساب معین";
            dataGridView1.Columns[5].HeaderText = "نام حساب معین";
            dataGridView1.Columns[6].HeaderText = "کد حساب تفضیلی";
            dataGridView1.Columns[7].HeaderText = "نام حساب تفضیلی";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 100;
            dataGridView1.Columns[2].Width = 50;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 50;
            dataGridView1.Columns[5].Width = 100;
            dataGridView1.Columns[6].Width = 50;
            dataGridView1.Columns[7].Width = 100;
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void چاپToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }

        private void frmHesabha_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = bd.get_data();
            set_datagrid();
            kolrbtn.Checked = true;
            noehesabtxt.Enabled = false;
            dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
            searchtxt.Focus();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDHesab = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    HData.HesabhaDelete1(IDHesab);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        dataGridView1.DataSource = HData.HesabhaShow1();
                        this.dataGridView1.Refresh();
                    }
                }
                dataGridView1.DataSource = HData.HesabhaShow1();
                this.dataGridView1.Refresh();
            }
        }
 

      public int virayesh { get; set; }

        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddHesabha obj = new frmAddHesabha();
            obj.ShowDialog();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = FData.HesabhaShow1();
            set_datagrid();
        }

        private void kolrbtn_CheckedChanged(object sender, EventArgs e)
        {
            //چون زمانی که هیچ سطری در دیتا گرید نیست نباید ستون موردنظر انتخاب شود
            if (dataGridView1 .RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                searchtxt .Focus();
                label4.Text = "جستجو براساس نام حساب کل:";
            }
            if (kolrbtn.Checked == true)
                searchtxt.Enabled = true;
            else
                searchtxt.Enabled = false;
        }

        private void moeinrbtn_CheckedChanged(object sender, EventArgs e)
        {
            //چون زمانی که هیچ سطری در دیتا گرید نیست نباید ستون موردنظر انتخاب شود
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
                searchtxt.Focus();
                label4.Text = "جستجو براساس نام حساب معین:";
                if (moeinrbtn .Checked == true)
                    searchtxt.Enabled = true;
                else
                    searchtxt.Enabled = false;
            }
        }

        private void tafzilyrbtn_CheckedChanged(object sender, EventArgs e)
        {
            //چون زمانی که هیچ سطری در دیتا گرید نیست نباید ستون موردنظر انتخاب شود
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                searchtxt.Focus();
                label4.Text = "جستجو براساس نام حساب تفضیلی:";
            }
            if (tafzilyrbtn .Checked == true)
                searchtxt.Enabled = true;
            else
                searchtxt.Enabled = false;
        }

        private void searchtxt_Enter(object sender, EventArgs e)
        {
            searchtxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void searchtxt_Leave(object sender, EventArgs e)
        {
            searchtxt.BackColor = Color.White;
        }

        private void searchtxt_TextChanged_1(object sender, EventArgs e)
        {
            if (searchtxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = bd.get_data();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (kolrbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                if (moeinrbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
                if (tafzilyrbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (kolrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                    string str1 = searchtxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        //this filter for NameHesabKol filter
                        dataGridView1.DataSource = bd.Filter(str1);
                        set_datagrid();
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (kolrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        searchtxt.Text = "";
                        searchtxt.Focus();
                        searchtxt.SelectAll();

                    }
                }
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (moeinrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
                    string str2 = searchtxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = bd.Filter2_NameHesabMoein(str2);
                        set_datagrid();
                        //انتخاب سطر اول سلول چهارم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (moeinrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;
                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        searchtxt.Text = "";
                        searchtxt.Focus();
                        searchtxt.SelectAll();

                    }
                }
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tafzilyrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                    //بدون انجام این عملیات جایگزین کردن هم فیلترینگ کار می کند
                    string str3 = searchtxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = bd.Filter2_NameHesabTafzily(str3);
                        set_datagrid();
                        //انتخاب سطر اول سلول ششم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tafzilyrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;
                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        searchtxt.Text = "";
                        searchtxt.Focus();
                        searchtxt.SelectAll();

                    }
                }
            }
        }

        private void noehesabtxt_TextChanged(object sender, EventArgs e)
        {
            if (noehesabrbtn .Checked == true && dataGridView1.RowCount.ToString() != "0")
            {
                if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                string str4 = noehesabtxt.Text;  //.Replace("ی", "ي");

                try
                {
                    dataGridView1.DataSource = true;
                    dataGridView1.DataSource = bd.FilterNoeHesab1(str4);
                    set_datagrid();
                    //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                    if (noehesabrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                    if (dataGridView1.RowCount.ToString() == "0")
                    {
                        virayeshbtn.Enabled = false;
                        printbtn.Enabled = false;

                    }
                    else
                    {
                        virayeshbtn.Enabled = true;
                        printbtn.Enabled = true;

                    }
                }

                catch
                {
                    MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                    noehesabtxt.Text = "";
                    noehesabtxt.Focus();
                    noehesabtxt.SelectAll();

                }
            }
        }

        private void noehesabrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                noehesabtxt.Focus();
            }
            if (noehesabrbtn.Checked == true)
            {
                noehesabtxt.Enabled = true;
                searchtxt.Enabled = false;
                noehesabtxt.Focus();
            }
            else
                noehesabtxt.Enabled = false;
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            Hesabha.frmHesabhaReport obj = new frmHesabhaReport();
            obj.ShowDialog();
        }

       
    }
}

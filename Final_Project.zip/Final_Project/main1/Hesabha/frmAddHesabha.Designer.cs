﻿namespace main1.Hesabha
{
    partial class frmAddHesabha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.noehesabcmb = new System.Windows.Forms.ComboBox();
            this.nametafzilytxt = new System.Windows.Forms.TextBox();
            this.namemoientxt = new System.Windows.Forms.TextBox();
            this.namekoltxt = new System.Windows.Forms.TextBox();
            this.idtafzilytxt = new System.Windows.Forms.TextBox();
            this.idmoientxt = new System.Windows.Forms.TextBox();
            this.idkoltxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.idhesabtxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // noehesabcmb
            // 
            this.noehesabcmb.FormattingEnabled = true;
            this.noehesabcmb.Items.AddRange(new object[] {
            "دارایی",
            "بدهی",
            "سرمایه"});
            this.noehesabcmb.Location = new System.Drawing.Point(658, 142);
            this.noehesabcmb.Name = "noehesabcmb";
            this.noehesabcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.noehesabcmb.Size = new System.Drawing.Size(95, 21);
            this.noehesabcmb.TabIndex = 4;
            this.noehesabcmb.Enter += new System.EventHandler(this.noehesabcmb_Enter);
            // 
            // nametafzilytxt
            // 
            this.nametafzilytxt.Location = new System.Drawing.Point(20, 142);
            this.nametafzilytxt.Name = "nametafzilytxt";
            this.nametafzilytxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.nametafzilytxt.Size = new System.Drawing.Size(127, 20);
            this.nametafzilytxt.TabIndex = 10;
            this.nametafzilytxt.Enter += new System.EventHandler(this.nametafzilytxt_Enter);
            // 
            // namemoientxt
            // 
            this.namemoientxt.Location = new System.Drawing.Point(233, 142);
            this.namemoientxt.Name = "namemoientxt";
            this.namemoientxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namemoientxt.Size = new System.Drawing.Size(127, 20);
            this.namemoientxt.TabIndex = 8;
            this.namemoientxt.Enter += new System.EventHandler(this.namemoientxt_Enter);
            // 
            // namekoltxt
            // 
            this.namekoltxt.Location = new System.Drawing.Point(446, 142);
            this.namekoltxt.Name = "namekoltxt";
            this.namekoltxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekoltxt.Size = new System.Drawing.Size(126, 20);
            this.namekoltxt.TabIndex = 6;
            this.namekoltxt.Enter += new System.EventHandler(this.namekoltxt_Enter);
            // 
            // idtafzilytxt
            // 
            this.idtafzilytxt.Location = new System.Drawing.Point(148, 142);
            this.idtafzilytxt.Name = "idtafzilytxt";
            this.idtafzilytxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idtafzilytxt.Size = new System.Drawing.Size(84, 20);
            this.idtafzilytxt.TabIndex = 9;
            this.idtafzilytxt.TextChanged += new System.EventHandler(this.idtafzilytxt_TextChanged);
            this.idtafzilytxt.Enter += new System.EventHandler(this.idtafzilytxt_Enter);
            this.idtafzilytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idtafzilytxt_KeyDown);
            // 
            // idmoientxt
            // 
            this.idmoientxt.Location = new System.Drawing.Point(361, 142);
            this.idmoientxt.Name = "idmoientxt";
            this.idmoientxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idmoientxt.Size = new System.Drawing.Size(84, 20);
            this.idmoientxt.TabIndex = 7;
            this.idmoientxt.TextChanged += new System.EventHandler(this.idmoientxt_TextChanged);
            this.idmoientxt.Enter += new System.EventHandler(this.idmoientxt_Enter);
            this.idmoientxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idmoientxt_KeyDown);
            // 
            // idkoltxt
            // 
            this.idkoltxt.Location = new System.Drawing.Point(573, 142);
            this.idkoltxt.Name = "idkoltxt";
            this.idkoltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idkoltxt.Size = new System.Drawing.Size(84, 20);
            this.idkoltxt.TabIndex = 5;
            this.idkoltxt.TextChanged += new System.EventHandler(this.idkoltxt_TextChanged);
            this.idkoltxt.Enter += new System.EventHandler(this.idkoltxt_Enter);
            this.idkoltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idkoltxt_KeyDown);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(522, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 15);
            this.label5.TabIndex = 78;
            this.label5.Text = "*";
            // 
            // idhesabtxt
            // 
            this.idhesabtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhesabtxt.Location = new System.Drawing.Point(540, 52);
            this.idhesabtxt.Name = "idhesabtxt";
            this.idhesabtxt.ReadOnly = true;
            this.idhesabtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabtxt.Size = new System.Drawing.Size(117, 20);
            this.idhesabtxt.TabIndex = 3;
            this.idhesabtxt.Enter += new System.EventHandler(this.idhesabtxt_Enter);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(662, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 23);
            this.label6.TabIndex = 77;
            this.label6.Text = ":کد حساب";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(769, 24);
            this.menuStrip1.TabIndex = 79;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(19, 48);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 2;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(114, 48);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 1;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 20;
            this.lineShape1.X2 = 753;
            this.lineShape1.Y1 = 140;
            this.lineShape1.Y2 = 140;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 655;
            this.lineShape5.X2 = 655;
            this.lineShape5.Y1 = 107;
            this.lineShape5.Y2 = 162;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.Location = new System.Drawing.Point(19, 106);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(734, 57);
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 572;
            this.lineShape6.X2 = 572;
            this.lineShape6.Y1 = 107;
            this.lineShape6.Y2 = 162;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 445;
            this.lineShape7.X2 = 445;
            this.lineShape7.Y1 = 107;
            this.lineShape7.Y2 = 162;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 360;
            this.lineShape4.X2 = 360;
            this.lineShape4.Y1 = 106;
            this.lineShape4.Y2 = 161;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 232;
            this.lineShape3.X2 = 232;
            this.lineShape3.Y1 = 107;
            this.lineShape3.Y2 = 162;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 147;
            this.lineShape2.X2 = 147;
            this.lineShape2.Y1 = 107;
            this.lineShape2.Y2 = 162;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape9,
            this.lineShape8,
            this.lineShape2,
            this.lineShape3,
            this.lineShape4,
            this.lineShape7,
            this.lineShape6,
            this.rectangleShape1,
            this.lineShape5,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(769, 199);
            this.shapeContainer1.TabIndex = 80;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 657;
            this.lineShape9.X2 = 657;
            this.lineShape9.Y1 = 107;
            this.lineShape9.Y2 = 162;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 19;
            this.lineShape8.X2 = 752;
            this.lineShape8.Y1 = 140;
            this.lineShape8.Y2 = 140;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(28, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 10);
            this.label7.TabIndex = 115;
            this.label7.Text = "*";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(587, 119);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 10);
            this.label13.TabIndex = 114;
            this.label13.Text = "*";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(464, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 10);
            this.label12.TabIndex = 113;
            this.label12.Text = "*";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(371, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 10);
            this.label9.TabIndex = 112;
            this.label9.Text = "*";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(245, 119);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 10);
            this.label8.TabIndex = 111;
            this.label8.Text = "*";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(151, 119);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 10);
            this.label14.TabIndex = 110;
            this.label14.Text = "*";
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(662, 119);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 10);
            this.label15.TabIndex = 109;
            this.label15.Text = "*";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label16.Location = new System.Drawing.Point(600, 116);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 15);
            this.label16.TabIndex = 102;
            this.label16.Text = "کد کل";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label17.Location = new System.Drawing.Point(676, 116);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 15);
            this.label17.TabIndex = 108;
            this.label17.Text = "نوع حساب";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label18.Location = new System.Drawing.Point(477, 116);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 15);
            this.label18.TabIndex = 103;
            this.label18.Text = "نام حساب کل";
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label19.Location = new System.Drawing.Point(384, 116);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 15);
            this.label19.TabIndex = 104;
            this.label19.Text = "کد معین";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label20.Location = new System.Drawing.Point(257, 116);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 15);
            this.label20.TabIndex = 105;
            this.label20.Text = "نام حساب معین";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label21.Location = new System.Drawing.Point(40, 116);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(99, 15);
            this.label21.TabIndex = 107;
            this.label21.Text = "نام حساب تفضیلی";
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label22.Location = new System.Drawing.Point(163, 116);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(63, 15);
            this.label22.TabIndex = 106;
            this.label22.Text = "کد تفضیلی";
            // 
            // frmAddHesabha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(769, 199);
            this.Controls.Add(this.namekoltxt);
            this.Controls.Add(this.namemoientxt);
            this.Controls.Add(this.nametafzilytxt);
            this.Controls.Add(this.noehesabcmb);
            this.Controls.Add(this.idkoltxt);
            this.Controls.Add(this.idmoientxt);
            this.Controls.Add(this.idtafzilytxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.idhesabtxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmAddHesabha";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم ثبت حسابها";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAddHesabha_FormClosing);
            this.Load += new System.EventHandler(this.frmHesabha_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nametafzilytxt;
        private System.Windows.Forms.TextBox namemoientxt;
        private System.Windows.Forms.TextBox namekoltxt;
        private System.Windows.Forms.TextBox idtafzilytxt;
        private System.Windows.Forms.TextBox idmoientxt;
        private System.Windows.Forms.TextBox idkoltxt;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox idhesabtxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.ComboBox noehesabcmb;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
    }
}
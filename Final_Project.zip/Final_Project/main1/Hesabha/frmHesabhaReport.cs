﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using DAL;
using BLL;

namespace main1.Hesabha
{
    public partial class frmHesabhaReport : Form
    {
        public frmHesabhaReport()
        {
            InitializeComponent();
        }

        private void frmHesabhaReport_Load(object sender, EventArgs e)
        {
            ReportDocument RD = new ReportDocument();
            RD.FileName = "HesabhaReport.rpt";
            HesabhaData HData = new HesabhaData();
            RD.SetDataSource(HData.HesabhaReportShow1());
            crystalReportViewer1.ReportSource = RD;
            crystalReportViewer1.Show();
        }
    }
}

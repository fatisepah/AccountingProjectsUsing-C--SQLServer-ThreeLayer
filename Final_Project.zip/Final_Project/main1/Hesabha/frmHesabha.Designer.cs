﻿namespace main1.Hesabha
{
    partial class frmHesabha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHesabha));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.noehesabrbtn = new System.Windows.Forms.RadioButton();
            this.noehesabtxt = new System.Windows.Forms.TextBox();
            this.searchtxt = new System.Windows.Forms.TextBox();
            this.tafzilyrbtn = new System.Windows.Forms.RadioButton();
            this.moeinrbtn = new System.Windows.Forms.RadioButton();
            this.kolrbtn = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پایینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.printbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.virayeshbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.darjbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.noehesabrbtn);
            this.groupBox1.Controls.Add(this.noehesabtxt);
            this.groupBox1.Controls.Add(this.searchtxt);
            this.groupBox1.Controls.Add(this.tafzilyrbtn);
            this.groupBox1.Controls.Add(this.moeinrbtn);
            this.groupBox1.Controls.Add(this.kolrbtn);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(11, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(491, 124);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "جستجو";
            // 
            // noehesabrbtn
            // 
            this.noehesabrbtn.AutoSize = true;
            this.noehesabrbtn.Location = new System.Drawing.Point(326, 89);
            this.noehesabrbtn.Name = "noehesabrbtn";
            this.noehesabrbtn.Size = new System.Drawing.Size(113, 17);
            this.noehesabrbtn.TabIndex = 5;
            this.noehesabrbtn.TabStop = true;
            this.noehesabrbtn.Text = "براساس نوع حساب:";
            this.noehesabrbtn.UseVisualStyleBackColor = true;
            this.noehesabrbtn.CheckedChanged += new System.EventHandler(this.noehesabrbtn_CheckedChanged);
            // 
            // noehesabtxt
            // 
            this.noehesabtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.noehesabtxt.Location = new System.Drawing.Point(126, 89);
            this.noehesabtxt.Name = "noehesabtxt";
            this.noehesabtxt.Size = new System.Drawing.Size(168, 20);
            this.noehesabtxt.TabIndex = 6;
            this.noehesabtxt.TextChanged += new System.EventHandler(this.noehesabtxt_TextChanged);
            // 
            // searchtxt
            // 
            this.searchtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchtxt.Location = new System.Drawing.Point(126, 60);
            this.searchtxt.Name = "searchtxt";
            this.searchtxt.Size = new System.Drawing.Size(168, 20);
            this.searchtxt.TabIndex = 4;
            this.searchtxt.TextChanged += new System.EventHandler(this.searchtxt_TextChanged_1);
            // 
            // tafzilyrbtn
            // 
            this.tafzilyrbtn.AutoSize = true;
            this.tafzilyrbtn.Location = new System.Drawing.Point(165, 30);
            this.tafzilyrbtn.Name = "tafzilyrbtn";
            this.tafzilyrbtn.Size = new System.Drawing.Size(91, 17);
            this.tafzilyrbtn.TabIndex = 3;
            this.tafzilyrbtn.TabStop = true;
            this.tafzilyrbtn.Text = "حساب تفضیلی";
            this.tafzilyrbtn.UseVisualStyleBackColor = true;
            this.tafzilyrbtn.CheckedChanged += new System.EventHandler(this.tafzilyrbtn_CheckedChanged);
            // 
            // moeinrbtn
            // 
            this.moeinrbtn.AutoSize = true;
            this.moeinrbtn.Location = new System.Drawing.Point(272, 30);
            this.moeinrbtn.Name = "moeinrbtn";
            this.moeinrbtn.Size = new System.Drawing.Size(78, 17);
            this.moeinrbtn.TabIndex = 2;
            this.moeinrbtn.TabStop = true;
            this.moeinrbtn.Text = "حساب معین";
            this.moeinrbtn.UseVisualStyleBackColor = true;
            this.moeinrbtn.CheckedChanged += new System.EventHandler(this.moeinrbtn_CheckedChanged);
            // 
            // kolrbtn
            // 
            this.kolrbtn.AutoSize = true;
            this.kolrbtn.Location = new System.Drawing.Point(372, 30);
            this.kolrbtn.Name = "kolrbtn";
            this.kolrbtn.Size = new System.Drawing.Size(70, 17);
            this.kolrbtn.TabIndex = 1;
            this.kolrbtn.TabStop = true;
            this.kolrbtn.Text = "حساب کل";
            this.kolrbtn.UseVisualStyleBackColor = true;
            this.kolrbtn.CheckedChanged += new System.EventHandler(this.kolrbtn_CheckedChanged);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(293, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 23);
            this.label4.TabIndex = 73;
            this.label4.Text = "براساس نام حساب کل:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.انصرافToolStripMenuItem,
            this.بالاToolStripMenuItem,
            this.پایینToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 58;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.چاپToolStripMenuItem.Text = "چاپ";
            this.چاپToolStripMenuItem.Click += new System.EventHandler(this.چاپToolStripMenuItem_Click);
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // بالاToolStripMenuItem
            // 
            this.بالاToolStripMenuItem.Name = "بالاToolStripMenuItem";
            this.بالاToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.Tab)));
            this.بالاToolStripMenuItem.Size = new System.Drawing.Size(32, 20);
            this.بالاToolStripMenuItem.Text = "بالا";
            this.بالاToolStripMenuItem.Click += new System.EventHandler(this.بالاToolStripMenuItem_Click);
            // 
            // پایینToolStripMenuItem
            // 
            this.پایینToolStripMenuItem.Name = "پایینToolStripMenuItem";
            this.پایینToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.پایینToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.پایینToolStripMenuItem.Text = "پایین";
            this.پایینToolStripMenuItem.Click += new System.EventHandler(this.پایینToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(11, 152);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(491, 243);
            this.dataGridView1.TabIndex = 7;
            // 
            // printbtn
            // 
            this.printbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printbtn.Image = ((System.Drawing.Image)(resources.GetObject("printbtn.Image")));
            this.printbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printbtn.Location = new System.Drawing.Point(126, 410);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(85, 28);
            this.printbtn.TabIndex = 10;
            this.printbtn.Text = "F7  چاپ";
            this.printbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.printbtn.UseVisualStyleBackColor = true;
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebtn.Image = global::main1.Properties.Resources.cross_script;
            this.deletebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deletebtn.Location = new System.Drawing.Point(215, 410);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(85, 28);
            this.deletebtn.TabIndex = 9;
            this.deletebtn.Text = "Del  حذف";
            this.deletebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // virayeshbtn
            // 
            this.virayeshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.virayeshbtn.Image = ((System.Drawing.Image)(resources.GetObject("virayeshbtn.Image")));
            this.virayeshbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.virayeshbtn.Location = new System.Drawing.Point(304, 410);
            this.virayeshbtn.Name = "virayeshbtn";
            this.virayeshbtn.Size = new System.Drawing.Size(85, 28);
            this.virayeshbtn.TabIndex = 8;
            this.virayeshbtn.Text = "F3  ویرایش";
            this.virayeshbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.virayeshbtn.UseVisualStyleBackColor = true;
            this.virayeshbtn.Click += new System.EventHandler(this.virayeshbtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(32, 410);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 11;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // darjbtn
            // 
            this.darjbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darjbtn.Image = global::main1.Properties.Resources.ButtonNew;
            this.darjbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.darjbtn.Location = new System.Drawing.Point(393, 410);
            this.darjbtn.Name = "darjbtn";
            this.darjbtn.Size = new System.Drawing.Size(83, 28);
            this.darjbtn.TabIndex = 7;
            this.darjbtn.Text = "F2  درج ";
            this.darjbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.darjbtn.UseVisualStyleBackColor = true;
            this.darjbtn.Click += new System.EventHandler(this.darjbtn_Click);
            // 
            // frmHesabha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 455);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.printbtn);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.virayeshbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.darjbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmHesabha";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم حسابها";
            this.Load += new System.EventHandler(this.frmHesabha_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button virayeshbtn;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button darjbtn;
        private System.Windows.Forms.Button printbtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پایینToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.RadioButton tafzilyrbtn;
        private System.Windows.Forms.RadioButton moeinrbtn;
        private System.Windows.Forms.RadioButton kolrbtn;
        private System.Windows.Forms.TextBox searchtxt;
        private System.Windows.Forms.RadioButton noehesabrbtn;
        private System.Windows.Forms.TextBox noehesabtxt;
    }
}
﻿namespace main1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.shobetxt = new System.Windows.Forms.TextBox();
            this.mablaghemojoditxt = new System.Windows.Forms.TextBox();
            this.shhesabmtxt = new System.Windows.Forms.MaskedTextBox();
            this.namebankcmb = new System.Windows.Forms.ComboBox();
            this.shkartmtxt = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape7,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(684, 188);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 542;
            this.lineShape7.X2 = 542;
            this.lineShape7.Y1 = 101;
            this.lineShape7.Y2 = 156;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 423;
            this.lineShape4.X2 = 423;
            this.lineShape4.Y1 = 101;
            this.lineShape4.Y2 = 156;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 288;
            this.lineShape3.X2 = 288;
            this.lineShape3.Y1 = 101;
            this.lineShape3.Y2 = 156;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 151;
            this.lineShape2.X2 = 151;
            this.lineShape2.Y1 = 101;
            this.lineShape2.Y2 = 156;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 16;
            this.lineShape1.X2 = 661;
            this.lineShape1.Y1 = 134;
            this.lineShape1.Y2 = 134;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.Location = new System.Drawing.Point(15, 100);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(646, 57);
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label33.Location = new System.Drawing.Point(51, 109);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(69, 15);
            this.label33.TabIndex = 89;
            this.label33.Text = "مبلغ موجودی";
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label34.Location = new System.Drawing.Point(185, 110);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(62, 15);
            this.label34.TabIndex = 88;
            this.label34.Text = "شماره کارت";
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label27.Location = new System.Drawing.Point(324, 109);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(72, 15);
            this.label27.TabIndex = 83;
            this.label27.Text = "شماره حساب";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label28.Location = new System.Drawing.Point(467, 109);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 15);
            this.label28.TabIndex = 82;
            this.label28.Text = "شعبه بانک";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(585, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 15);
            this.label3.TabIndex = 72;
            this.label3.Text = "نام بانک";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(170, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 10);
            this.label7.TabIndex = 96;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(312, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 10);
            this.label8.TabIndex = 97;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(453, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 10);
            this.label9.TabIndex = 98;
            this.label9.Text = "*";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(572, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 10);
            this.label1.TabIndex = 101;
            this.label1.Text = "*";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(17, 43);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 103;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(112, 43);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 102;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            // 
            // shobetxt
            // 
            this.shobetxt.Location = new System.Drawing.Point(425, 136);
            this.shobetxt.Name = "shobetxt";
            this.shobetxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.shobetxt.Size = new System.Drawing.Size(116, 20);
            this.shobetxt.TabIndex = 105;
            // 
            // mablaghemojoditxt
            // 
            this.mablaghemojoditxt.Location = new System.Drawing.Point(16, 136);
            this.mablaghemojoditxt.Name = "mablaghemojoditxt";
            this.mablaghemojoditxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghemojoditxt.Size = new System.Drawing.Size(135, 20);
            this.mablaghemojoditxt.TabIndex = 108;
            // 
            // shhesabmtxt
            // 
            this.shhesabmtxt.Location = new System.Drawing.Point(289, 136);
            this.shhesabmtxt.Name = "shhesabmtxt";
            this.shhesabmtxt.Size = new System.Drawing.Size(134, 20);
            this.shhesabmtxt.TabIndex = 106;
            // 
            // namebankcmb
            // 
            this.namebankcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namebankcmb.FormattingEnabled = true;
            this.namebankcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namebankcmb.Items.AddRange(new object[] {
            "بانک ملی",
            "بانک سپه",
            "بانک تجارت",
            "بانک کشاورزی",
            "بانک صادرات",
            "بانک ملت",
            "بانک قوامین"});
            this.namebankcmb.Location = new System.Drawing.Point(544, 136);
            this.namebankcmb.Name = "namebankcmb";
            this.namebankcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namebankcmb.Size = new System.Drawing.Size(116, 21);
            this.namebankcmb.TabIndex = 104;
            this.namebankcmb.Text = "... انتخاب کنید ...";
            // 
            // shkartmtxt
            // 
            this.shkartmtxt.Location = new System.Drawing.Point(153, 136);
            this.shkartmtxt.Mask = "9999-9999-9999-9999";
            this.shkartmtxt.Name = "shkartmtxt";
            this.shkartmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.shkartmtxt.Size = new System.Drawing.Size(134, 20);
            this.shkartmtxt.TabIndex = 107;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(684, 188);
            this.Controls.Add(this.shobetxt);
            this.Controls.Add(this.mablaghemojoditxt);
            this.Controls.Add(this.shhesabmtxt);
            this.Controls.Add(this.namebankcmb);
            this.Controls.Add(this.shkartmtxt);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.TextBox shobetxt;
        private System.Windows.Forms.TextBox mablaghemojoditxt;
        private System.Windows.Forms.MaskedTextBox shhesabmtxt;
        private System.Windows.Forms.ComboBox namebankcmb;
        private System.Windows.Forms.MaskedTextBox shkartmtxt;
    }
}
﻿namespace main1.HesabBanki
{
    partial class frmAddHesabBanki
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namebankcmb = new System.Windows.Forms.ComboBox();
            this.idhesabtxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.shobetxt = new System.Windows.Forms.TextBox();
            this.mablaghemojoditxt = new System.Windows.Forms.TextBox();
            this.shhesabmtxt = new System.Windows.Forms.MaskedTextBox();
            this.shkartmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // namebankcmb
            // 
            this.namebankcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namebankcmb.FormattingEnabled = true;
            this.namebankcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namebankcmb.Items.AddRange(new object[] {
            "بانک ملی",
            "بانک سپه",
            "بانک تجارت",
            "بانک کشاورزی",
            "بانک صادرات",
            "بانک ملت",
            "بانک قوامین"});
            this.namebankcmb.Location = new System.Drawing.Point(553, 158);
            this.namebankcmb.Name = "namebankcmb";
            this.namebankcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namebankcmb.Size = new System.Drawing.Size(119, 21);
            this.namebankcmb.TabIndex = 4;
            this.namebankcmb.Text = "... انتخاب کنید ...";
            this.namebankcmb.Enter += new System.EventHandler(this.namebankcmb_Enter_1);
            // 
            // idhesabtxt
            // 
            this.idhesabtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhesabtxt.Location = new System.Drawing.Point(471, 61);
            this.idhesabtxt.Name = "idhesabtxt";
            this.idhesabtxt.ReadOnly = true;
            this.idhesabtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabtxt.Size = new System.Drawing.Size(116, 20);
            this.idhesabtxt.TabIndex = 3;
            this.idhesabtxt.Enter += new System.EventHandler(this.idhesabtxt_Enter_1);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(592, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 23);
            this.label1.TabIndex = 36;
            this.label1.Text = "کد حساب:";
            // 
            // shobetxt
            // 
            this.shobetxt.Location = new System.Drawing.Point(434, 158);
            this.shobetxt.Name = "shobetxt";
            this.shobetxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.shobetxt.Size = new System.Drawing.Size(118, 20);
            this.shobetxt.TabIndex = 5;
            this.shobetxt.Enter += new System.EventHandler(this.shobetxt_Enter);
            // 
            // mablaghemojoditxt
            // 
            this.mablaghemojoditxt.Location = new System.Drawing.Point(27, 158);
            this.mablaghemojoditxt.Name = "mablaghemojoditxt";
            this.mablaghemojoditxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghemojoditxt.Size = new System.Drawing.Size(134, 20);
            this.mablaghemojoditxt.TabIndex = 8;
            this.mablaghemojoditxt.TextChanged += new System.EventHandler(this.mablaghemojoditxt_TextChanged);
            this.mablaghemojoditxt.Enter += new System.EventHandler(this.mablaghemojoditxt_Enter);
            this.mablaghemojoditxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghemojoditxt_KeyDown);
            // 
            // shhesabmtxt
            // 
            this.shhesabmtxt.Location = new System.Drawing.Point(299, 158);
            this.shhesabmtxt.Name = "shhesabmtxt";
            this.shhesabmtxt.Size = new System.Drawing.Size(134, 20);
            this.shhesabmtxt.TabIndex = 6;
            this.shhesabmtxt.TextChanged += new System.EventHandler(this.shhesabmtxt_TextChanged);
            this.shhesabmtxt.Enter += new System.EventHandler(this.shhesabmtxt_Enter);
            this.shhesabmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.shhesabmtxt_KeyDown);
            // 
            // shkartmtxt
            // 
            this.shkartmtxt.Location = new System.Drawing.Point(162, 158);
            this.shkartmtxt.Mask = "9999-9999-9999-9999";
            this.shkartmtxt.Name = "shkartmtxt";
            this.shkartmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.shkartmtxt.Size = new System.Drawing.Size(136, 20);
            this.shkartmtxt.TabIndex = 7;
            this.shkartmtxt.Enter += new System.EventHandler(this.shkartmtxt_Enter_1);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(455, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 18);
            this.label8.TabIndex = 31;
            this.label8.Text = "*";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(27, 59);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 2;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(126, 59);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 1;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click_1);
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.Location = new System.Drawing.Point(26, 122);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(646, 57);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape7,
            this.lineShape4,
            this.lineShape3,
            this.lineShape1,
            this.lineShape2,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(699, 217);
            this.shapeContainer1.TabIndex = 37;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 552;
            this.lineShape7.X2 = 552;
            this.lineShape7.Y1 = 123;
            this.lineShape7.Y2 = 178;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 433;
            this.lineShape4.X2 = 433;
            this.lineShape4.Y1 = 123;
            this.lineShape4.Y2 = 178;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 298;
            this.lineShape3.X2 = 298;
            this.lineShape3.Y1 = 123;
            this.lineShape3.Y2 = 178;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 26;
            this.lineShape1.X2 = 671;
            this.lineShape1.Y1 = 156;
            this.lineShape1.Y2 = 156;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 161;
            this.lineShape2.X2 = 161;
            this.lineShape2.Y1 = 123;
            this.lineShape2.Y2 = 178;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(582, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 10);
            this.label7.TabIndex = 110;
            this.label7.Text = "*";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(463, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 10);
            this.label12.TabIndex = 109;
            this.label12.Text = "*";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(322, 136);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 10);
            this.label13.TabIndex = 108;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(186, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 10);
            this.label14.TabIndex = 107;
            this.label14.Text = "*";
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Location = new System.Drawing.Point(595, 133);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 15);
            this.label15.TabIndex = 102;
            this.label15.Text = "نام بانک";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label28.Location = new System.Drawing.Point(477, 133);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 15);
            this.label28.TabIndex = 103;
            this.label28.Text = "شعبه بانک";
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label27.Location = new System.Drawing.Point(334, 133);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(72, 15);
            this.label27.TabIndex = 104;
            this.label27.Text = "شماره حساب";
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label33.Location = new System.Drawing.Point(61, 133);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(69, 15);
            this.label33.TabIndex = 106;
            this.label33.Text = "مبلغ موجودی";
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label34.Location = new System.Drawing.Point(201, 134);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(62, 15);
            this.label34.TabIndex = 105;
            this.label34.Text = "شماره کارت";
            // 
            // frmAddHesabBanki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(699, 217);
            this.Controls.Add(this.shobetxt);
            this.Controls.Add(this.shkartmtxt);
            this.Controls.Add(this.mablaghemojoditxt);
            this.Controls.Add(this.namebankcmb);
            this.Controls.Add(this.shhesabmtxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.idhesabtxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddHesabBanki";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن حساب بانکی";
            this.Load += new System.EventHandler(this.frmAddHesabBanki_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox namebankcmb;
        private System.Windows.Forms.TextBox idhesabtxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox shkartmtxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.MaskedTextBox shhesabmtxt;
        private System.Windows.Forms.TextBox mablaghemojoditxt;
        private System.Windows.Forms.TextBox shobetxt;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.HesabBanki
{
    public partial class frmAddHesabBanki : Form
    {
        public frmAddHesabBanki()
        {
            InitializeComponent();
        }
        HesabBankiData objHesabBanki = new HesabBankiData();
        HesabBankiDB DBHesabBanki = new HesabBankiDB();

        int k = 0;
        private void shhesabmtxt_TextChanged(object sender, EventArgs e)
        {
            if (shhesabmtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                shhesabmtxt.Text = Class1.convert_number(shhesabmtxt.Text.Replace(",", ""));
                shhesabmtxt.Select(shhesabmtxt.Text.Length, 0);
            }

        }
        private void shhesabmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            idhesabtxt.Text = "";
            namebankcmb.Text = "";
            shobetxt.Text = "";
            shhesabmtxt.Text = "";
            shkartmtxt.Text = "";
            mablaghemojoditxt.Text = "";
            this.Close();
        }

        private void mablaghemojoditxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mablaghemojoditxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void shobetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            shobetxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        int k1 = 0;
        private void mablaghemojoditxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghemojoditxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                mablaghemojoditxt.Text = Class1.convert_str(mablaghemojoditxt.Text.Replace(",", ""));
                mablaghemojoditxt.Select(mablaghemojoditxt.Text.Length, 0);
            }
        }

        private void mablaghemojoditxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }

        private void set_color()
        {
            idhesabtxt.BackColor = Color.White;
            mablaghemojoditxt.BackColor = Color.White;
            namebankcmb.BackColor = Color.White;
            shobetxt.BackColor = Color.White;
            shhesabmtxt.BackColor = Color.White;
            shkartmtxt.BackColor = Color.White;

        }
        private void frmAddHesabBanki_Load(object sender, EventArgs e)
        {
            int i1 = 0;
            int i2 = 1;
            if (Class1.virayesh != 0)
            {
                DBHesabBanki = objHesabBanki.HesabBankiFind1(Class1.virayesh);
                idhesabtxt.Text = DBHesabBanki.IDHesabBanki .ToString();
                namebankcmb.Text = DBHesabBanki.NameBank;
                shobetxt .Text = DBHesabBanki.ShobeBank;
                shhesabmtxt.Text = DBHesabBanki.ShomareHesab;
                shkartmtxt.Text = DBHesabBanki.ShomareKart ;
                mablaghemojoditxt.Text = Class1 .convert_str (DBHesabBanki.MablagheMojodi.ToString());
            }
            else
            {
                DataTable dt = objHesabBanki.HesabBankiSearchID1();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idhesabtxt.Text = "1";
                }
                else
                {
                    idhesabtxt.Text = Convert.ToString(i2 + 1);
                }

            }

        }

        private void sabtbtn_Click_1(object sender, EventArgs e)
        {

            if (idhesabtxt.Text != "" && namebankcmb.Text != "" && shobetxt.Text != "" && shhesabmtxt.Text != "" && shkartmtxt.Text != "")
            {
                DBHesabBanki.IDHesabBanki = Convert.ToInt32(idhesabtxt.Text);
                DBHesabBanki.NameBank = namebankcmb.Text;
                DBHesabBanki.ShobeBank = shobetxt.Text;
                DBHesabBanki.ShomareHesab = shhesabmtxt.Text;
                DBHesabBanki.ShomareKart = shkartmtxt.Text;
                DBHesabBanki.MablagheMojodi = Convert.ToInt64(mablaghemojoditxt.Text.Replace(",", ""));
                if (Class1.virayesh != 0)
                {
                    if (objHesabBanki.HesabBankiSearch1(DBHesabBanki.IDHesabBanki) && Class1.virayesh != DBHesabBanki.IDHesabBanki)
                    {
                        MessageBox.Show(" کد حساب بانکی تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        objHesabBanki.HesabBankiUpdate1(DBHesabBanki);
                        MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        Class1.virayesh = 0;
                        Class1.IDHesab = Convert.ToInt32(idhesabtxt.Text);
                        idhesabtxt.Text = "";
                        namebankcmb.Text = "";
                        shobetxt.Text = "";
                        shhesabmtxt.Text = "";
                        shkartmtxt.Text = "";
                        mablaghemojoditxt.Text = "";
                        Close();
                    }
                    
                }
                else
                {
                    if (!objHesabBanki.HesabBankiSearch1(DBHesabBanki.IDHesabBanki))
                    {
                        objHesabBanki.HesabBankiInsert1(DBHesabBanki);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1 .IDHesab =Convert .ToInt32(idhesabtxt .Text );
                            idhesabtxt.Text = "";
                            namebankcmb.Text = "";
                            shobetxt.Text = "";
                            shhesabmtxt.Text = "";
                            shkartmtxt.Text = "";
                            mablaghemojoditxt.Text = "";
                        }
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("شماره حساب بانکی تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Hide();
            frmHesabBanki Hb = new frmHesabBanki();
            Hb.ShowDialog();
        }


        private void idhesabtxt_Enter_1(object sender, EventArgs e)
        {
            set_color();
            idhesabtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namebankcmb_Enter_1(object sender, EventArgs e)
        {
            set_color();
            namebankcmb.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void shhesabmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            shhesabmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void shkartmtxt_Enter_1(object sender, EventArgs e)
        {
            set_color();
            shkartmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }




  
    }
        
    }


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.HesabBanki
{
    public partial class frmHesabBanki : Form
    {
        public frmHesabBanki()
        {
            InitializeComponent();
        }
        FilterHesabBankiData HBData1 = new FilterHesabBankiData();
        HesabBankiData HBData = new HesabBankiData();
        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchnbankrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                searchnbanktxt.Focus();
            }
            if (searchnbankrbtn.Checked == true)
            {
                searchnbanktxt.Enabled = true;
                searchnbanktxt.Focus();
            }
            else
                searchnbanktxt.Enabled = false;

        }

        private void searchshhesabrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                searchshhesabtxt.Focus();
            }
            if (searchshhesabrbtn.Checked == true)
            {
                searchshhesabtxt.Enabled = true;
                searchshhesabtxt.Focus();
            }
            else
                searchshhesabtxt .Enabled = false;
            
        }

        private void searchnbanktxt_Enter(object sender, EventArgs e)
        {
            set_color();
            searchnbanktxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void searchshhesabtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            searchshhesabtxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void searchnbanktxt_TextChanged(object sender, EventArgs e)
        {
            string NameBank = searchnbanktxt.Text.Replace("ی", "ي");
            try
            {
                dataGridView1.DataSource = HBData1.FilterNBank1(NameBank);
                if (dataGridView1.RowCount.ToString() == "0")
                {
                    virayeshbtn.Enabled = false;
                    printbtn.Enabled = false;
                }
                else
                {
                    virayeshbtn.Enabled = true;
                    printbtn.Enabled = true;
                }

            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                searchnbanktxt.Text = "";
                searchnbanktxt.Focus();
                searchnbanktxt.SelectAll();
            }
        }
        int k = 0;
        private void searchshhesabtxt_TextChanged(object sender, EventArgs e)
        {
            if(searchshhesabtxt .Text .Length !=0 && k==1)
            {
                k = 0;
                searchshhesabtxt.Text = Class1.convert_str(searchshhesabtxt .Text .Replace (",",""));
                searchshhesabtxt.Select(searchshhesabtxt.Text.Length, 0);

            }
            string ShomareHesab = searchshhesabtxt.Text.Replace("ی", "ي");
            try
            {
                dataGridView1.DataSource = HBData1.FilterSHHesab1(ShomareHesab);
                if (dataGridView1.RowCount.ToString() == "0")
                {
                    virayeshbtn.Enabled = false;
                    printbtn .Enabled = false;
                }
                else
                {
                    virayeshbtn.Enabled = true;
                    printbtn.Enabled = true;
                }

            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                searchshhesabtxt.Text = "";
                searchshhesabtxt.Focus();
                searchshhesabtxt.SelectAll();
            }
        }

        private void frmHesabBanki_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = HBData1.HesabBankiShow1();
            set_datagrid();
            this.dataGridView1.Refresh();
            searchshhesabrbtn.Checked = false;
            searchnbankrbtn.Checked = false;
            searchnbanktxt.Enabled = false;
            searchshhesabtxt.Enabled = false;

        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = "کد حساب بانکی";
            dataGridView1.Columns[1].HeaderText = "نام بانک";
            dataGridView1.Columns[2].HeaderText = "شعبه بانک";
            dataGridView1.Columns[3].HeaderText = "شماره حساب";
            dataGridView1.Columns[4].HeaderText = "شماره کارت";
            dataGridView1.Columns[5].HeaderText = "مبلغ موجودی";
            dataGridView1.Columns[5].DefaultCellStyle.Format = "0,0";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 70;
            dataGridView1.Columns[2].Width = 70;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 120;
            dataGridView1.Columns[5].Width = 120;
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddHesabBanki obj = new frmAddHesabBanki();
            obj.Show();
            dataGridView1.DataSource = HBData.HesabBankiShow1();
            set_datagrid();
            this.dataGridView1.Refresh();
        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            frmAddHesabBanki obj = new frmAddHesabBanki();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("سطری انتخاب نشده است!", "", MessageBoxButtons.OK);
            }
            else
            {
                int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                if (obj.ShowDialog() == DialogResult.OK) { }

                dataGridView1.DataSource = true;
                dataGridView1.DataSource = HBData.HesabBankiShow1();
                set_datagrid();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }

        }
        private void set_color()
        {
            searchshhesabtxt .BackColor = Color.White;
            searchnbanktxt .BackColor = Color.White;
        }

        private void searchnbanktxt_Leave(object sender, EventArgs e)
        {
            set_color();
        }

        private void searchshhesabtxt_Leave(object sender, EventArgs e)
        {
            set_color();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDHesab = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    HBData.HesabBankiDelete1(IDHesab);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        dataGridView1.DataSource = HBData.HesabBankiShow1();
                        set_datagrid();
                    }
                }
                dataGridView1.DataSource = HBData.HesabBankiShow1();
                this.dataGridView1.EndEdit();
                this.dataGridView1.Refresh();
            }
        }

        private void searchshhesabtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            HesabBanki.frmHesabBankiReport obj = new frmHesabBankiReport();
            obj.ShowDialog();
        }
      }
}

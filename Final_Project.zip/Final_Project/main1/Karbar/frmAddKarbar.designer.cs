﻿namespace main1.Karbar
{
    partial class frmAddKarbar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.passtxt = new System.Windows.Forms.TextBox();
            this.usertxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tarikhetavalodmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.codemelimtxt = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.jenseiatcmb = new System.Windows.Forms.ComboBox();
            this.madrakcmb = new System.Windows.Forms.ComboBox();
            this.sematcmb = new System.Windows.Forms.ComboBox();
            this.mobilemtxt = new System.Windows.Forms.MaskedTextBox();
            this.telmtxt = new System.Windows.Forms.MaskedTextBox();
            this.senmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tozihattxt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.addresstxt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.familytxt = new System.Windows.Forms.TextBox();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.searchbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.pic = new System.Windows.Forms.PictureBox();
            this.label36 = new System.Windows.Forms.Label();
            this.idkarbartxt = new System.Windows.Forms.TextBox();
            this.delbtn = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.hesabbtn = new System.Windows.Forms.Button();
            this.idhesabtxt = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(22, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 6;
            this.label5.Text = "*";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(91, 671);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 3;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.passtxt);
            this.groupBox1.Controls.Add(this.usertxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(23, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(465, 64);
            this.groupBox1.TabIndex = 47;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "اطلاعات کاربری";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(237, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 23);
            this.label4.TabIndex = 5;
            this.label4.Text = "*";
            // 
            // passtxt
            // 
            this.passtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.passtxt.Location = new System.Drawing.Point(39, 28);
            this.passtxt.Name = "passtxt";
            this.passtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.passtxt.Size = new System.Drawing.Size(116, 20);
            this.passtxt.TabIndex = 7;
            this.passtxt.Enter += new System.EventHandler(this.passtxt_Enter);
            // 
            // usertxt
            // 
            this.usertxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.usertxt.Location = new System.Drawing.Point(260, 28);
            this.usertxt.Name = "usertxt";
            this.usertxt.Size = new System.Drawing.Size(116, 20);
            this.usertxt.TabIndex = 6;
            this.usertxt.Enter += new System.EventHandler(this.usertxt_Enter);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(148, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "پسورد:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(371, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "کد کاربری:";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(404, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 23);
            this.label1.TabIndex = 46;
            this.label1.Text = ":کد کاربر";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.tarikhetavalodmtxt);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.codemelimtxt);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.jenseiatcmb);
            this.groupBox2.Controls.Add(this.madrakcmb);
            this.groupBox2.Controls.Add(this.sematcmb);
            this.groupBox2.Controls.Add(this.mobilemtxt);
            this.groupBox2.Controls.Add(this.telmtxt);
            this.groupBox2.Controls.Add(this.senmtxt);
            this.groupBox2.Controls.Add(this.tozihattxt);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.emailtxt);
            this.groupBox2.Controls.Add(this.addresstxt);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.nametxt);
            this.groupBox2.Controls.Add(this.familytxt);
            this.groupBox2.Location = new System.Drawing.Point(23, 117);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(465, 339);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "مشخصات کاربر";
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(22, 136);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(16, 19);
            this.label28.TabIndex = 51;
            this.label28.Text = "*";
            // 
            // tarikhetavalodmtxt
            // 
            this.tarikhetavalodmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhetavalodmtxt.Location = new System.Drawing.Point(39, 132);
            this.tarikhetavalodmtxt.Mask = "9999/99/99";
            this.tarikhetavalodmtxt.Name = "tarikhetavalodmtxt";
            this.tarikhetavalodmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhetavalodmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhetavalodmtxt.TabIndex = 49;
            this.tarikhetavalodmtxt.Enter += new System.EventHandler(this.tarikhetavalodmtxt_Enter);
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(162, 134);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 23);
            this.label27.TabIndex = 50;
            this.label27.Text = "تاریخ تولد:";
            // 
            // codemelimtxt
            // 
            this.codemelimtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.codemelimtxt.Location = new System.Drawing.Point(255, 133);
            this.codemelimtxt.Mask = "999-999999-9";
            this.codemelimtxt.Name = "codemelimtxt";
            this.codemelimtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.codemelimtxt.Size = new System.Drawing.Size(116, 20);
            this.codemelimtxt.TabIndex = 14;
            this.codemelimtxt.Enter += new System.EventHandler(this.codemelimtxt_Enter);
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(237, 136);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(16, 23);
            this.label38.TabIndex = 39;
            this.label38.Text = "*";
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(380, 134);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(48, 23);
            this.label39.TabIndex = 38;
            this.label39.Text = "کد ملی:";
            // 
            // jenseiatcmb
            // 
            this.jenseiatcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.jenseiatcmb.FormattingEnabled = true;
            this.jenseiatcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.jenseiatcmb.Items.AddRange(new object[] {
            "زن",
            "مرد"});
            this.jenseiatcmb.Location = new System.Drawing.Point(39, 98);
            this.jenseiatcmb.Name = "jenseiatcmb";
            this.jenseiatcmb.Size = new System.Drawing.Size(116, 21);
            this.jenseiatcmb.TabIndex = 13;
            this.jenseiatcmb.Text = "... انتخاب کنید ...";
            this.jenseiatcmb.Enter += new System.EventHandler(this.jenseiatcmb_Enter);
            // 
            // madrakcmb
            // 
            this.madrakcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.madrakcmb.FormattingEnabled = true;
            this.madrakcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.madrakcmb.Items.AddRange(new object[] {
            "زیر دیپلم",
            "دیپلم",
            "کاردانی",
            "کارشناسی",
            "ارشد",
            "دکترا"});
            this.madrakcmb.Location = new System.Drawing.Point(39, 64);
            this.madrakcmb.Name = "madrakcmb";
            this.madrakcmb.Size = new System.Drawing.Size(116, 21);
            this.madrakcmb.TabIndex = 11;
            this.madrakcmb.Text = "... انتخاب کنید ...";
            this.madrakcmb.Enter += new System.EventHandler(this.madrakcmb_Enter);
            // 
            // sematcmb
            // 
            this.sematcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.sematcmb.FormattingEnabled = true;
            this.sematcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sematcmb.Items.AddRange(new object[] {
            "مدیر",
            "کارمند",
            "حسابدار",
            "انباردار",
            "معاون"});
            this.sematcmb.Location = new System.Drawing.Point(255, 64);
            this.sematcmb.Name = "sematcmb";
            this.sematcmb.Size = new System.Drawing.Size(116, 21);
            this.sematcmb.TabIndex = 10;
            this.sematcmb.Text = "... انتخاب کنید ...";
            this.sematcmb.Enter += new System.EventHandler(this.sematcmb_Enter);
            // 
            // mobilemtxt
            // 
            this.mobilemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mobilemtxt.Location = new System.Drawing.Point(40, 202);
            this.mobilemtxt.Mask = "99999999999";
            this.mobilemtxt.Name = "mobilemtxt";
            this.mobilemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mobilemtxt.Size = new System.Drawing.Size(116, 20);
            this.mobilemtxt.TabIndex = 17;
            this.mobilemtxt.Enter += new System.EventHandler(this.mobilemtxt_Enter);
            // 
            // telmtxt
            // 
            this.telmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.telmtxt.Location = new System.Drawing.Point(255, 202);
            this.telmtxt.Mask = "9999-99999999";
            this.telmtxt.Name = "telmtxt";
            this.telmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.telmtxt.Size = new System.Drawing.Size(116, 20);
            this.telmtxt.TabIndex = 16;
            this.telmtxt.Enter += new System.EventHandler(this.telmtxt_Enter);
            // 
            // senmtxt
            // 
            this.senmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.senmtxt.Location = new System.Drawing.Point(255, 99);
            this.senmtxt.Name = "senmtxt";
            this.senmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.senmtxt.Size = new System.Drawing.Size(116, 20);
            this.senmtxt.TabIndex = 12;
            this.senmtxt.TextChanged += new System.EventHandler(this.senmtxt_TextChanged);
            this.senmtxt.Enter += new System.EventHandler(this.senmtxt_Enter);
            this.senmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.senmtxt_KeyDown);
            // 
            // tozihattxt
            // 
            this.tozihattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tozihattxt.Location = new System.Drawing.Point(39, 275);
            this.tozihattxt.Multiline = true;
            this.tozihattxt.Name = "tozihattxt";
            this.tozihattxt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tozihattxt.Size = new System.Drawing.Size(332, 51);
            this.tozihattxt.TabIndex = 19;
            this.tozihattxt.Enter += new System.EventHandler(this.tozihattxt_Enter);
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(378, 277);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 23);
            this.label25.TabIndex = 36;
            this.label25.Text = "توضیحات:";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(23, 204);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(16, 23);
            this.label24.TabIndex = 35;
            this.label24.Text = "*";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(237, 204);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(16, 23);
            this.label23.TabIndex = 34;
            this.label23.Text = "*";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(22, 169);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(16, 23);
            this.label22.TabIndex = 33;
            this.label22.Text = "*";
            // 
            // emailtxt
            // 
            this.emailtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emailtxt.Location = new System.Drawing.Point(39, 238);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(332, 20);
            this.emailtxt.TabIndex = 18;
            this.emailtxt.Enter += new System.EventHandler(this.emailtxt_Enter);
            // 
            // addresstxt
            // 
            this.addresstxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addresstxt.Location = new System.Drawing.Point(39, 167);
            this.addresstxt.Name = "addresstxt";
            this.addresstxt.Size = new System.Drawing.Size(332, 20);
            this.addresstxt.TabIndex = 15;
            this.addresstxt.Enter += new System.EventHandler(this.addresstxt_Enter);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(379, 239);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 23);
            this.label21.TabIndex = 28;
            this.label21.Text = "ایمیل:";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(162, 204);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 23);
            this.label20.TabIndex = 27;
            this.label20.Text = "موبایل:";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(377, 204);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 23);
            this.label19.TabIndex = 26;
            this.label19.Text = "تلفن منزل:";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(381, 167);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 23);
            this.label18.TabIndex = 25;
            this.label18.Text = "آدرس:";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(22, 103);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(16, 19);
            this.label17.TabIndex = 24;
            this.label17.Text = "*";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(237, 101);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 23);
            this.label16.TabIndex = 23;
            this.label16.Text = "*";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(22, 63);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 23);
            this.label15.TabIndex = 22;
            this.label15.Text = "*";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(22, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 23);
            this.label14.TabIndex = 21;
            this.label14.Text = "*";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(236, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 23);
            this.label13.TabIndex = 20;
            this.label13.Text = "*";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(237, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 23);
            this.label12.TabIndex = 19;
            this.label12.Text = "*";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(159, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 23);
            this.label11.TabIndex = 17;
            this.label11.Text = "جنسیت:";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(379, 100);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 23);
            this.label10.TabIndex = 16;
            this.label10.Text = "سن:";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(158, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 23);
            this.label9.TabIndex = 15;
            this.label9.Text = "مدرک تحصیلی:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(375, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 23);
            this.label8.TabIndex = 14;
            this.label8.Text = "سمت:";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(157, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 23);
            this.label7.TabIndex = 13;
            this.label7.Text = "نام خانوادگی:";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(377, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 23);
            this.label6.TabIndex = 12;
            this.label6.Text = "نام:";
            // 
            // nametxt
            // 
            this.nametxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nametxt.Location = new System.Drawing.Point(255, 30);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(116, 20);
            this.nametxt.TabIndex = 8;
            this.nametxt.Enter += new System.EventHandler(this.nametxt_Enter);
            // 
            // familytxt
            // 
            this.familytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.familytxt.Location = new System.Drawing.Point(39, 30);
            this.familytxt.Name = "familytxt";
            this.familytxt.Size = new System.Drawing.Size(116, 20);
            this.familytxt.TabIndex = 9;
            this.familytxt.Enter += new System.EventHandler(this.familytxt_Enter);
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 52;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // searchbtn
            // 
            this.searchbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.searchbtn.Location = new System.Drawing.Point(307, 48);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(91, 23);
            this.searchbtn.TabIndex = 20;
            this.searchbtn.Text = "جستجو...";
            this.searchbtn.UseVisualStyleBackColor = true;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(333, 671);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 1;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // pic
            // 
            this.pic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic.ErrorImage = global::main1.Properties.Resources.error11;
            this.pic.Image = global::main1.Properties.Resources.error11;
            this.pic.Location = new System.Drawing.Point(55, 20);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(140, 155);
            this.pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic.TabIndex = 2;
            this.pic.TabStop = false;
            // 
            // label36
            // 
            this.label36.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.Red;
            this.label36.Location = new System.Drawing.Point(264, 23);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(11, 23);
            this.label36.TabIndex = 51;
            this.label36.Text = "*";
            // 
            // idkarbartxt
            // 
            this.idkarbartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idkarbartxt.Location = new System.Drawing.Point(278, 19);
            this.idkarbartxt.Name = "idkarbartxt";
            this.idkarbartxt.ReadOnly = true;
            this.idkarbartxt.Size = new System.Drawing.Size(116, 20);
            this.idkarbartxt.TabIndex = 4;
            this.idkarbartxt.Enter += new System.EventHandler(this.idkarbartxt_Enter);
            // 
            // delbtn
            // 
            this.delbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.delbtn.Location = new System.Drawing.Point(307, 86);
            this.delbtn.Name = "delbtn";
            this.delbtn.Size = new System.Drawing.Size(91, 23);
            this.delbtn.TabIndex = 21;
            this.delbtn.Text = "حذف";
            this.delbtn.UseVisualStyleBackColor = true;
            this.delbtn.Click += new System.EventHandler(this.delbtn_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pic);
            this.groupBox4.Controls.Add(this.delbtn);
            this.groupBox4.Controls.Add(this.searchbtn);
            this.groupBox4.Location = new System.Drawing.Point(23, 460);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox4.Size = new System.Drawing.Size(465, 188);
            this.groupBox4.TabIndex = 49;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "عکس";
            // 
            // hesabbtn
            // 
            this.hesabbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hesabbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hesabbtn.Location = new System.Drawing.Point(189, 671);
            this.hesabbtn.Name = "hesabbtn";
            this.hesabbtn.Size = new System.Drawing.Size(137, 28);
            this.hesabbtn.TabIndex = 2;
            this.hesabbtn.Text = "اضافه کردن حساب بانکی ";
            this.hesabbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.hesabbtn.UseVisualStyleBackColor = true;
            this.hesabbtn.Click += new System.EventHandler(this.hesabbtn_Click);
            // 
            // idhesabtxt
            // 
            this.idhesabtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhesabtxt.Location = new System.Drawing.Point(63, 19);
            this.idhesabtxt.Name = "idhesabtxt";
            this.idhesabtxt.ReadOnly = true;
            this.idhesabtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabtxt.Size = new System.Drawing.Size(116, 20);
            this.idhesabtxt.TabIndex = 5;
            this.idhesabtxt.Text = "0";
            this.idhesabtxt.Enter += new System.EventHandler(this.idhesabtxt_Enter_1);
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(180, 21);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(86, 23);
            this.label26.TabIndex = 55;
            this.label26.Text = ":کد حساب بانکی";
            // 
            // frmAddKarbar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 712);
            this.Controls.Add(this.idhesabtxt);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.hesabbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.idkarbartxt);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddKarbar";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن کاربر";
            this.Load += new System.EventHandler(this.frmAddKarbar_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox passtxt;
        private System.Windows.Forms.TextBox usertxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox codemelimtxt;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox jenseiatcmb;
        private System.Windows.Forms.ComboBox madrakcmb;
        private System.Windows.Forms.ComboBox sematcmb;
        private System.Windows.Forms.MaskedTextBox mobilemtxt;
        private System.Windows.Forms.MaskedTextBox telmtxt;
        private System.Windows.Forms.MaskedTextBox senmtxt;
        private System.Windows.Forms.TextBox tozihattxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.TextBox addresstxt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.TextBox familytxt;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.PictureBox pic;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox idkarbartxt;
        private System.Windows.Forms.Button delbtn;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button hesabbtn;
        private System.Windows.Forms.TextBox idhesabtxt;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.MaskedTextBox tarikhetavalodmtxt;
        private System.Windows.Forms.Label label27;

    }
}
﻿namespace main1.Karbar
{
    partial class frmKarbar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKarbar));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.searchuserkarbartxt = new System.Windows.Forms.TextBox();
            this.searchuserkarbarrbtn = new System.Windows.Forms.RadioButton();
            this.searchnkarbarrbtn = new System.Windows.Forms.RadioButton();
            this.searchnkarbartxt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.printbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.virayeshbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.darjbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پایینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.searchuserkarbartxt);
            this.groupBox1.Controls.Add(this.searchuserkarbarrbtn);
            this.groupBox1.Controls.Add(this.searchnkarbarrbtn);
            this.groupBox1.Controls.Add(this.searchnkarbartxt);
            this.groupBox1.Location = new System.Drawing.Point(12, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(489, 94);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "جستجو";
            // 
            // searchuserkarbartxt
            // 
            this.searchuserkarbartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchuserkarbartxt.Location = new System.Drawing.Point(120, 54);
            this.searchuserkarbartxt.Name = "searchuserkarbartxt";
            this.searchuserkarbartxt.Size = new System.Drawing.Size(151, 20);
            this.searchuserkarbartxt.TabIndex = 4;
            this.searchuserkarbartxt.TextChanged += new System.EventHandler(this.searchuserkarbartxt_TextChanged);
            this.searchuserkarbartxt.Enter += new System.EventHandler(this.searchuserkarbartxt_Enter);
            this.searchuserkarbartxt.Leave += new System.EventHandler(this.searchuserkarbartxt_Leave);
            // 
            // searchuserkarbarrbtn
            // 
            this.searchuserkarbarrbtn.AutoSize = true;
            this.searchuserkarbarrbtn.Location = new System.Drawing.Point(295, 54);
            this.searchuserkarbarrbtn.Name = "searchuserkarbarrbtn";
            this.searchuserkarbarrbtn.Size = new System.Drawing.Size(154, 17);
            this.searchuserkarbarrbtn.TabIndex = 3;
            this.searchuserkarbarrbtn.TabStop = true;
            this.searchuserkarbarrbtn.Text = "جستجو براساس نام کاربری:";
            this.searchuserkarbarrbtn.UseVisualStyleBackColor = true;
            this.searchuserkarbarrbtn.CheckedChanged += new System.EventHandler(this.searchuserkarbarrbtn_CheckedChanged);
            // 
            // searchnkarbarrbtn
            // 
            this.searchnkarbarrbtn.AutoSize = true;
            this.searchnkarbarrbtn.Location = new System.Drawing.Point(305, 25);
            this.searchnkarbarrbtn.Name = "searchnkarbarrbtn";
            this.searchnkarbarrbtn.Size = new System.Drawing.Size(144, 17);
            this.searchnkarbarrbtn.TabIndex = 1;
            this.searchnkarbarrbtn.TabStop = true;
            this.searchnkarbarrbtn.Text = "جستجو براساس نام کاربر:";
            this.searchnkarbarrbtn.UseVisualStyleBackColor = true;
            this.searchnkarbarrbtn.CheckedChanged += new System.EventHandler(this.searchnkarbarrbtn_CheckedChanged);
            // 
            // searchnkarbartxt
            // 
            this.searchnkarbartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchnkarbartxt.Location = new System.Drawing.Point(120, 25);
            this.searchnkarbartxt.Name = "searchnkarbartxt";
            this.searchnkarbartxt.Size = new System.Drawing.Size(151, 20);
            this.searchnkarbartxt.TabIndex = 2;
            this.searchnkarbartxt.TextChanged += new System.EventHandler(this.searchnkarbartxt_TextChanged);
            this.searchnkarbartxt.Enter += new System.EventHandler(this.searchnkarbartxt_Enter);
            this.searchnkarbartxt.Leave += new System.EventHandler(this.searchnkarbartxt_Leave);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 116);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(489, 243);
            this.dataGridView1.TabIndex = 21;
            // 
            // printbtn
            // 
            this.printbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printbtn.Image = ((System.Drawing.Image)(resources.GetObject("printbtn.Image")));
            this.printbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printbtn.Location = new System.Drawing.Point(127, 374);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(85, 28);
            this.printbtn.TabIndex = 19;
            this.printbtn.Text = "F7  چاپ";
            this.printbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.printbtn.UseVisualStyleBackColor = true;
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebtn.Image = global::main1.Properties.Resources.cross_script;
            this.deletebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deletebtn.Location = new System.Drawing.Point(216, 374);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(85, 28);
            this.deletebtn.TabIndex = 18;
            this.deletebtn.Text = "Del  حذف";
            this.deletebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // virayeshbtn
            // 
            this.virayeshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.virayeshbtn.Image = ((System.Drawing.Image)(resources.GetObject("virayeshbtn.Image")));
            this.virayeshbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.virayeshbtn.Location = new System.Drawing.Point(305, 374);
            this.virayeshbtn.Name = "virayeshbtn";
            this.virayeshbtn.Size = new System.Drawing.Size(85, 28);
            this.virayeshbtn.TabIndex = 17;
            this.virayeshbtn.Text = "F3  ویرایش";
            this.virayeshbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.virayeshbtn.UseVisualStyleBackColor = true;
            this.virayeshbtn.Click += new System.EventHandler(this.virayeshbtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(33, 374);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 20;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // darjbtn
            // 
            this.darjbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darjbtn.Image = global::main1.Properties.Resources.ButtonNew;
            this.darjbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.darjbtn.Location = new System.Drawing.Point(394, 374);
            this.darjbtn.Name = "darjbtn";
            this.darjbtn.Size = new System.Drawing.Size(83, 28);
            this.darjbtn.TabIndex = 16;
            this.darjbtn.Text = "F2  درج ";
            this.darjbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.darjbtn.UseVisualStyleBackColor = true;
            this.darjbtn.Click += new System.EventHandler(this.darjbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.انصرافToolStripMenuItem,
            this.بالاToolStripMenuItem,
            this.پایینToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 60;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.چاپToolStripMenuItem.Text = "چاپ";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // بالاToolStripMenuItem
            // 
            this.بالاToolStripMenuItem.Name = "بالاToolStripMenuItem";
            this.بالاToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.Tab)));
            this.بالاToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
            this.بالاToolStripMenuItem.Text = "بالا";
            this.بالاToolStripMenuItem.Click += new System.EventHandler(this.بالاToolStripMenuItem_Click);
            // 
            // پایینToolStripMenuItem
            // 
            this.پایینToolStripMenuItem.Name = "پایینToolStripMenuItem";
            this.پایینToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.پایینToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.پایینToolStripMenuItem.Text = "پایین";
            this.پایینToolStripMenuItem.Click += new System.EventHandler(this.پایینToolStripMenuItem_Click);
            // 
            // frmKarbar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 420);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.printbtn);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.virayeshbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.darjbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmKarbar";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم کاربر";
            this.Load += new System.EventHandler(this.frmKarbar_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button printbtn;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button virayeshbtn;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button darjbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox searchuserkarbartxt;
        private System.Windows.Forms.RadioButton searchuserkarbarrbtn;
        private System.Windows.Forms.RadioButton searchnkarbarrbtn;
        private System.Windows.Forms.TextBox searchnkarbartxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پایینToolStripMenuItem;


    }
}
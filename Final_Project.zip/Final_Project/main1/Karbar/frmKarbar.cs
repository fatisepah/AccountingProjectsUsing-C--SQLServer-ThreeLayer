﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;


namespace main1.Karbar
{
    public partial class frmKarbar : Form
    {
        public frmKarbar()
        {
            InitializeComponent();
        }
        FilterKarbarData KData1 = new FilterKarbarData();
        KarbarData KData = new KarbarData();
        HesabBankiData HBData = new HesabBankiData();
        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddKarbar obj = new frmAddKarbar();
            obj.Show();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = KData.KarbarShow1();
            set_datagrid();
            this.dataGridView1.Refresh();

        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            
            frmAddKarbar obj = new frmAddKarbar();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("سطری انتخاب نشده است!", "", MessageBoxButtons.OK);
            }
            else
            {
                int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayeshG = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value);           
                if (obj.ShowDialog() == DialogResult.OK) { }
                this.dataGridView1.Refresh();
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = KData.KarbarShow1();
                set_datagrid();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchnkarbartxt_TextChanged(object sender, EventArgs e)
        {
            string NameBank = searchnkarbartxt.Text.Replace("ی", "ي");
            try
            {
                dataGridView1.DataSource = KData1.FilterNameKarbar1(NameBank);
                if (dataGridView1.RowCount.ToString() == "0")
                {
                    virayeshbtn.Enabled = false;
                    printbtn.Enabled = false;
                }
                else
                {
                    virayeshbtn.Enabled = true;
                    printbtn.Enabled = true;
                }

            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                searchnkarbartxt.Text = "";
                searchnkarbartxt.Focus();
                searchnkarbartxt.SelectAll();
            }
                
            if(searchnkarbartxt.Text == "")
            {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = KData1.KarbarShow1();
            }
        }

        private void searchuserkarbartxt_TextChanged(object sender, EventArgs e)
        {
            string UserName = searchuserkarbartxt.Text.Replace("ی", "ي");
            try
            {
                dataGridView1.DataSource = KData1.FilterUserKarbar1(UserName);
                if (dataGridView1.RowCount.ToString() == "0")
                {
                    virayeshbtn.Enabled = false;
                    printbtn.Enabled = false;
                }
                else
                {
                    virayeshbtn.Enabled = true;
                    printbtn.Enabled = true;
                }

            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                searchuserkarbartxt.Text = "";
                searchuserkarbartxt.Focus();
                searchuserkarbartxt.SelectAll();
            }
            if (searchuserkarbartxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = KData1.KarbarShow1();
            }
        }

        private void searchnkarbartxt_Enter(object sender, EventArgs e)
        {
            set_color();
            searchnkarbartxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void searchuserkarbartxt_Enter(object sender, EventArgs e)
        {
            set_color();
            searchuserkarbartxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void searchnkarbarrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (searchnkarbarrbtn.Checked == true)
            {
                searchnkarbartxt .Enabled = true;
                searchnkarbartxt.Focus();
            }
            else
                searchnkarbartxt.Enabled = false;

        }

        private void searchuserkarbarrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (searchuserkarbarrbtn.Checked == true)
            {
                searchuserkarbartxt.Enabled = true;
                searchuserkarbartxt.Focus();
            }
            else
                searchuserkarbartxt.Enabled = false;

        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = "کد کاربر";
            dataGridView1.Columns[1].HeaderText = "کد حساب بانکی کاربر";
            dataGridView1.Columns[2].HeaderText = "کد کاربری";
            dataGridView1.Columns[3].HeaderText = "رمز عبور";
            dataGridView1.Columns[4].HeaderText = "نام ";
            dataGridView1.Columns[5].HeaderText = "فامیلی ";
            dataGridView1.Columns[6].HeaderText = "سمت";
            dataGridView1.Columns[7].HeaderText = "مدرک";
            dataGridView1.Columns[8].HeaderText = "کد ملی";
            dataGridView1.Columns[9].HeaderText = "تاریخ تولد ";
            dataGridView1.Columns[10].HeaderText = "سن";
            dataGridView1.Columns[11].HeaderText = "جنسیت";
            dataGridView1.Columns[12].HeaderText = "آدرس";
            dataGridView1.Columns[13].HeaderText = "موبایل";
            dataGridView1.Columns[14].HeaderText = "تلفن";
            dataGridView1.Columns[15].HeaderText = "ایمیل";
            dataGridView1.Columns[16].HeaderText = "عکس";
            dataGridView1.Columns[17].HeaderText = "توضیحات";
            dataGridView1.Columns[18].HeaderText = "نام بانک";
            dataGridView1.Columns[19].HeaderText = "شعبه بانک";
            dataGridView1.Columns[20].HeaderText = "شماره حساب";
            dataGridView1.Columns[21].HeaderText = "شماره کارت";
            dataGridView1.Columns[22].HeaderText = "مبلغ موجودی";
            dataGridView1.Columns[22].DefaultCellStyle.Format = "0,0";

            dataGridView1.Columns[0].Width =50;
            dataGridView1.Columns[1].Width =50;
            dataGridView1.Columns[2].Width =100;
            dataGridView1.Columns[3].Width =80;
            dataGridView1.Columns[4].Width =100;
            dataGridView1.Columns[5].Width =100;
            dataGridView1.Columns[6].Width =100;
            dataGridView1.Columns[7].Width = 100;
            dataGridView1.Columns[8].Width =120;
            dataGridView1.Columns[9].Width =120;
            dataGridView1.Columns[10].Width =50;
            dataGridView1.Columns[11].Width = 100;
            dataGridView1.Columns[12].Width =150;
            dataGridView1.Columns[13].Width =100;
            dataGridView1.Columns[14].Width =100;
            dataGridView1.Columns[15].Width =120;
            dataGridView1.Columns[16].Width =80;
            dataGridView1.Columns[17].Width =120;
            dataGridView1.Columns[18].Width = 100;
            dataGridView1.Columns[19].Width = 100;
            dataGridView1.Columns[20].Width =120;
            dataGridView1.Columns[21].Width =150;
            dataGridView1.Columns[22].Width = 150;
        }

        private void frmKarbar_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = KData1.KarbarShow1();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = KData1.KarbarShow1();
            set_datagrid();
            this.dataGridView1.Refresh();
            searchuserkarbarrbtn.Checked = false;
            searchnkarbarrbtn.Checked = false;
            searchuserkarbartxt.Enabled = false;
            searchnkarbartxt.Enabled = false;
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void set_color()
        {
            searchuserkarbartxt.BackColor = Color.White;
            searchnkarbartxt.BackColor = Color.White;
        }

        private void searchnkarbartxt_Leave(object sender, EventArgs e)
        {
            set_color();
        }

        private void searchuserkarbartxt_Leave(object sender, EventArgs e)
        {
            set_color();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDKarbar = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    int IDHesab = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value);
                    HBData.HesabBankiDelete1(IDHesab);
                    KData.KarbarDelete1(IDKarbar);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        this.dataGridView1.EndEdit();
                        this.dataGridView1.Refresh();
                        dataGridView1.DataSource = HBData.HesabBankiShow1();
                    }
                    dataGridView1.DataSource = HBData.HesabBankiShow1();
                    this.dataGridView1.EndEdit();
                    this.dataGridView1.Refresh();
                }
            }
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            frmKarbarReport obj = new frmKarbarReport();
            obj.ShowDialog();
        }
    }
}

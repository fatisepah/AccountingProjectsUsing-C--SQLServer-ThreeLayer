﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DAL;
using BLL;

namespace main1.Karbar
{
    public partial class frmAddKarbar : Form
    {
        string AksName = "";
        KarbarData objK = new KarbarData();
        KarbarDB DBK = new KarbarDB();
        public frmAddKarbar()
        {
            InitializeComponent();
        }

        private void senmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k = 0;
        private void senmtxt_TextChanged(object sender, EventArgs e)
        {
            if (senmtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                senmtxt.Text = Class1.convert_number(senmtxt.Text.Replace(",", ""));
                senmtxt.Select(senmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private byte[] ReadFile(string spath)
        {
            byte[] data = null;
            if (spath != "")
            {
                FileInfo finfo = new FileInfo(spath);
                long numbytes = finfo.Length;
                FileStream fstream = new FileStream(spath, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fstream);
                data = br.ReadBytes((int)numbytes);
            }
            return data;
        }
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (usertxt .Text  != "" && passtxt .Text  != "" && nametxt .Text  != "" && familytxt .Text  != "" && sematcmb .Text  != "" && madrakcmb .Text  != "" && codemelimtxt .Text  != ""&& tarikhetavalodmtxt .Text!="    /  /" && jenseiatcmb .Text  != "" && addresstxt .Text  != "" && mobilemtxt .Text  != "" && telmtxt .Text  != "")
            {
                DBK.IDKarbar = Convert.ToInt32(idkarbartxt .Text);
                DBK.FKHesabBanki = Convert.ToInt32(idhesabtxt .Text);
                DBK.UserName = usertxt .Text;
                DBK.Password =passtxt  .Text;
                DBK.NameKarbar = nametxt .Text;
                DBK.FamilyKarbar = familytxt .Text;
                DBK.Semat = sematcmb .Text;
                DBK.Madrak = madrakcmb .Text;
                DBK.CodeMeli = codemelimtxt .Text;
                DBK.TarikheTavalod = tarikhetavalodmtxt.Text;
                DBK.Sen = Convert.ToInt32(senmtxt .Text);
                DBK.Jensiyat = jenseiatcmb .Text;
                DBK.Address = addresstxt .Text;
                DBK.Mobile = mobilemtxt .Text;
                DBK.Tel = telmtxt .Text;
                DBK.Email = emailtxt .Text;
                if (AksName == "")
                    DBK.Aks = ReadFile(@"C:\Users\mohandes sepahvand\Documents\Downloads\Compressed\Attachments_2012_12_14_3\main1-2(eslah shode_3039)\main1-2(eslah shode_3039)\main1\aks\error11.png");
                else 
                    DBK.Aks = ReadFile(AksName);
                DBK.Tozihat = tozihattxt .Text;

                if (Class1.virayeshG != 0)
                {

                            objK.KarbarUpdate1(DBK);
                         if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        this.Close();
                        Class1.virayeshG = 0;
                        Class1.virayesh = 0;
                    
                }
                else
                {
                    ///تعریف کاربر جدید
                    objK.KarbarInsert1(DBK);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                    }
                    Close();
                }
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //
            //
            //
            this.Hide();
            frmKarbar fk = new frmKarbar();
            fk.ShowDialog();
        }
        private void searchbtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            DialogResult dlgRes = dlg.ShowDialog();
            if (dlgRes != DialogResult.Cancel)
            {
                pic.ImageLocation = dlg.FileName;
                AksName = dlg.FileName;
            }
            if (delbtn.Visible == false)
                delbtn.Visible = true;
        }
        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void delbtn_Click(object sender, EventArgs e)
        {
            pic.Image = null;
            delbtn.Visible = false;
            AksName = AksName = @"C:\Users\mohandes sepahvand\Documents\Downloads\Compressed\Attachments_2012_12_14_3\main1-2(eslah shode_3039)\main1-2(eslah shode_3039)\main1\aks\error11.png";
            pic.Image = global::main1.Properties.Resources.error11;
        }

        private void set_color()
        {
            idkarbartxt.BackColor = Color.White;
            usertxt.BackColor = Color.White;
            passtxt.BackColor = Color.White;
            nametxt.BackColor = Color.White;
            familytxt.BackColor = Color.White;
            sematcmb.BackColor = Color.White;
            madrakcmb.BackColor = Color.White;
            senmtxt.BackColor = Color.White;
            jenseiatcmb.BackColor = Color.White;
            tarikhetavalodmtxt.BackColor = Color.White;
            codemelimtxt.BackColor = Color.White;
            addresstxt.BackColor = Color.White;
            telmtxt.BackColor = Color.White;
            mobilemtxt.BackColor = Color.White;
            emailtxt.BackColor = Color.White;
            tozihattxt.BackColor = Color.White;
            idhesabtxt.BackColor = Color.White;
        }

        private void idkarbartxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idkarbartxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void usertxt_Enter(object sender, EventArgs e)
        {
            set_color();
            usertxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void passtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            passtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void nametxt_Enter(object sender, EventArgs e)
        {
            set_color();
            nametxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void familytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            familytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void sematcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            sematcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void madrakcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            madrakcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void senmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            senmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void jenseiatcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            jenseiatcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void codemelimtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            codemelimtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void addresstxt_Enter(object sender, EventArgs e)
        {
            set_color();
            addresstxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void telmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            telmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void mobilemtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mobilemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void emailtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            emailtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tozihattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tozihattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void frmAddKarbar_Load(object sender, EventArgs e)
        {
            delbtn.Visible = false;
            int i1 = 0;
            int i2 = 1;
            if (Class1 .virayeshG != 0)
            {
                DBK = objK.KarbarFind1(Class1.virayeshG);
                idkarbartxt.Text = DBK.IDKarbar.ToString();
                idhesabtxt.Text = DBK.FKHesabBanki.ToString();
                usertxt.Text = DBK.UserName.ToString();
                passtxt.Text = DBK.Password;
                nametxt.Text = DBK.NameKarbar;
                familytxt.Text = DBK.FamilyKarbar;
                sematcmb.Text = DBK.Semat;
                madrakcmb.Text = DBK.Madrak;
                codemelimtxt.Text = DBK.CodeMeli;
                tarikhetavalodmtxt.Text = DBK.TarikheTavalod;
                senmtxt.Text = DBK.Sen.ToString();
                jenseiatcmb.Text = DBK.Jensiyat;
                addresstxt.Text = DBK.Address;
                mobilemtxt.Text = DBK.Mobile;
                telmtxt.Text = DBK.Tel;
                emailtxt.Text = DBK.Email;
                tozihattxt.Text = DBK.Tozihat;

                byte[] picarray = DBK.Aks;
                MemoryStream ms = new MemoryStream(picarray );
                this.pic.SizeMode = PictureBoxSizeMode.StretchImage;
                this.pic.Image = Image.FromStream(ms);
                ms.Dispose();
            }
            else
            {
                DataTable dt = objK.KarbarSearchID1();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idhesabtxt.Text = "1";
                }
                else
                {
                    idkarbartxt.Text = Convert.ToString(i2 + 1);
                }
            }
        }

        private void hesabbtn_Click(object sender, EventArgs e)
        {
            HesabBanki.frmAddHesabBanki obj = new HesabBanki.frmAddHesabBanki();
            if (obj.ShowDialog() == DialogResult.OK) { }
            idhesabtxt.Text = Class1.IDHesab.ToString();
        }

        private void idhesabtxt_Enter_1(object sender, EventArgs e)
        {
            set_color();
            idhesabtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhetavalodmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhetavalodmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using DAL;
using BLL;
using System.Data;
namespace main1
{
    public class Class1
    {
        public static int virayesh = 0;
        public static int virayeshG = 0;

        public static int virayeshM = 0;
        public static int virayeshS = 0;
        public static string NameFamilyKarbar = "";
        public static string NameFamilyKarbarVirayesh = "";
        public static string SemateKarbar = "";
        public static int IDHesab = 0;
        public static string TarikheJari = "";
        public static string SaateJari = "";
        //متغیر برای تشخیص نوع حساب در سند حسابداری
        public static int IDSanad = 0;
        //برای چکهای وصولی و پرداختی
        CheckData CData = new CheckData();
        CheckDB CDB = new CheckDB();
        public static string checkdaryafti = "";
        public static string checkpardakhti = "";
        //برای پرداخت هزینه ها در فاکتورها
        public static int IDCheck = 0;
        public static int IDNaghdy = 0;
        public static int IDGhesty = 0;
        public static int IDHavale = 0;
        //برای قرار دادن خودکار نام مشتری در فرم های نقد و چک و حواله و قسطی
        public static string NameMoshtari = "";
        //متغیر برای ویرایش فاکتورها
        public static int virayeshF = 0;
        public static int virayeshRFK = 0;
        public static int virayeshRFKharid = 0;
        public static int virayeshRFForosh = 0;
        //
        public static int id = 0;
        public static int code_kala = 0;
        public static int id_temp = 0;
        public static string name_kala = "";
        public static Int64 money = 0;
        public static double conut = 0;
        public static string name = "";
        public static string pass = "";
        public static int money_kol = 0;
        public static Boolean flag = false;
        public int ID
        {
            set { id = value; }
            get { return id; }
        }
        public int ID_temp
        {
            set { id_temp = value; }
            get { return id_temp; }
        }
        public string NAME
        {
            set { name = value; }
            get { return name; }
        }
        public string PASS
        {
            set { pass = value; }
            get { return pass; }
        }
        public static string convert_str(string str)
        {
            try
            {
                char ch;
                if (str.Length == 1)
                    ch = Convert.ToChar(str);
                else
                    ch = Convert.ToChar(str.Substring(str.Length - 1, 1));
                if (ch < '0' || ch > '9')
                {
                    str = str.Substring(0, str.Length - 1);
                }
                if (str.Length == 0)
                    return str;
                Int64 number = Convert.ToInt64(str);
                str = number.ToString();
                char[] str1 = new char[20];
                int i = str.Length - 1, j = 0;
                for (int l = 0; i >= 0; i--, j++, l++)
                {
                    if (l > 0 && l % 3 == 0)
                    {
                        str1[j++] = ',';
                    }
                    str1[j] = str[i];
                }
                str = "";
                j--;
                for (; j >= 0; j--)
                    str += str1[j];
                return str;
            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات دچار خطا شدید", "تائید", MessageBoxButtons.OK);
                return "";
            }
        }
        public static string convert_number(string str)
        {
            char ch;
            if (str.Length == 1)
                ch = Convert.ToChar(str);
            else
                ch = Convert.ToChar(str.Substring(str.Length - 1, 1));
            if (ch < '0' || ch > '9')
            {
                str = str.Substring(0, str.Length - 1);
            }
            if (str.Length != 0)
            {
                Int64 number = Convert.ToInt64(str);
                str = number.ToString();
            }
            return str;
        }
        public static string convert_float(string str)
        {
            char ch;
            int count = 0;
            for (int i = 0; i < str.Length; i++)
                if (str[i] == '.')
                    count++;
            if (str.Length == 1)
                ch = Convert.ToChar(str);
            else
                ch = Convert.ToChar(str.Substring(str.Length - 1, 1));
            if ((ch < '0' || ch > '9') && count != 1)
            {
                str = str.Substring(0, str.Length - 1);
            }
            else if ((ch < '0' || ch > '9') && count == 1 && ch != '.')
            {
                str = str.Substring(0, str.Length - 1);
            }
            else
            {
                if (str.Length > 1 && str[0] == '0' && str[1] != '.')
                    str = str.Substring(1);
                return str;
            }
            if (str.Length != 0)
            {
                double number = Convert.ToDouble(str);
                str = number.ToString();
            }
            return str;
        }
        public static string convert_date(string str)
        {
            if (str == "    /  /")
                return str;
            str = str.Replace(" ", "0");
            str = str.Replace("/", "");
            if (str.Length < 8)
            {
                if (str.Length == 7)
                    str = str.Substring(0, 6) + "0" + str.Substring(6);
                else if (str.Length == 6)
                {
                    str += "01";
                    if (str[4] == '0' && str[5] == '0')
                    {
                        str = str.Substring(0, 4) + "0101";
                    }
                    if (str[0] == '0')
                    {
                        date1 da = new date1();
                        string s = da.print();
                        str = s.Substring(0, 4) + "/01/01";
                    }
                }
            }
            str = str.Replace("/", "");
            int year = Convert.ToInt32(str.Substring(0, 4));
            int month = Convert.ToInt32(str.Substring(4, 2));
            int day = Convert.ToInt32(str.Substring(6, 2));
            int k = 31;
            if (year > 1500 || year < 1380)
            {
                date1 obj = new date1();
                str = obj.print().Substring(0, 4) + str.Substring(4);
            }
            if (month > 12 || month < 1)
            {
                date1 obj = new date1();
                str = str.Substring(0, 4) + "01" + str.Substring(6, 2);
            }
            month = Convert.ToInt32(str.Substring(4, 2));
            if (month == 12)
                k = 29;
            if ((month > 6 && month < 12) || (month == 12 && year % 4 == 3))
                k = 30;
            if (day > k || day < 1)
            {
                date1 obj = new date1();
                str = str.Substring(0, 6) + "01";
            }
            return str;
        }

        public static string Tarikh(string s)
        {
            string s1="";
            if(s.Length >9)
                 s1 = s.Substring(9, s.Length - 9);
            s = s.Substring(0, 8);
            string sday = s.Substring(0, 2);
            string smonth = s.Substring(3, 2);
            string syear ="13"+ s.Substring(6, 2);
            s = syear +"/"+ smonth + "/"+ sday +" "+ s1;
            return s;
        }
        public void  Check()
        {
            //برای چک کردن تاریخ سر رسید چکهای دریافتی و پرداختی
            DataTable DT = new DataTable();
            DT = CData.CheckSearchID1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                string TarikheSarResid = DT.Rows[i][3].ToString();
                string NameSahebeCheck = DT.Rows[i][4].ToString();
                string VazeiyatePardakht = DT.Rows[i][7].ToString();
                long Mablagh = Convert.ToInt64(DT.Rows[i][9].ToString());
                TarikheSarResid = Class1.Tarikh(TarikheSarResid);
                TarikheSarResid = TarikheSarResid.Substring(0, 10);
                int TarikheSarResid1 = Convert.ToInt32(TarikheSarResid.Replace("/", ""));
                int TarikheJari1 = Convert.ToInt32(Class1.TarikheJari.Replace("/", ""));
                if (TarikheSarResid1 >= TarikheJari1)
                {
                    if (VazeiyatePardakht == "پرداخت نشده")
                    {
                        checkpardakhti += "تاریخ چک آقای/شرکت" + " " + NameSahebeCheck + " " + "به مبلغ" + " " + Mablagh + " " + "سررسیده است\r\n";
                    }
                    if (VazeiyatePardakht == "دریافت نشده")
                    {
                        checkdaryafti+= "تاریخ چک آقای/شرکت" + " " + NameSahebeCheck + " " + "به مبلغ" + " " + Mablagh + " " + "سررسیده است\r\n";
                    }

                }
            }
            //
        }
    }
}

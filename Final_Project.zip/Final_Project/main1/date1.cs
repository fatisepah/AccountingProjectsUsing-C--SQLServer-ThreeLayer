﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace main1
{
   public class date1
    {
        int Start_day = 0;
        int year = 1383;
        string st = "";
        public string print()
        {
            set_date();
            return st;
        }
        private void set_date()
        {
            DateTime century, century1;
            century = new DateTime(2004, 3, 20);
            century1 = DateTime.Now;
            int k, day = 0;
            while (true)
            {
                century = century.AddDays(1);
                day++;
                if (String.Compare(century.ToLongDateString(), century1.ToLongDateString()) == 0)
                    break;
            }
            if (day >= 366)
            {
                k = 0;
                while (day >= 0)
                {
                    if ((k % 4) == 0)
                    {
                        if (day > 366)
                            date_iran(366, 30, Start_day);
                        else
                            date_iran(day, 30, Start_day);
                        day -= 366;
                    }
                    else
                    {
                        if (day > 365)
                            date_iran(365, 29, Start_day);
                        else
                            date_iran(day, 29, Start_day);
                        day -= 365;
                    }
                    k += 1;
                    year += 1;
                }

            }
            else
                date_iran(day, 30, Start_day);
        }

        private void date_iran(int day, int k, int j)
        {
            int[][] number;
            number = new int[12][];
            number[0] = new int[31];
            number[1] = new int[31];
            number[2] = new int[31];
            number[3] = new int[31];
            number[4] = new int[31];
            number[5] = new int[31];
            number[6] = new int[30];
            number[7] = new int[30];
            number[8] = new int[30];
            number[9] = new int[30];
            number[10] = new int[30];
            number[11] = new int[k];
            for (int i = 0; i <= 365; i++)
            {
                if (i <= 185)
                {
                    number[i / 31][i % 31] = (j + 1) % 7;
                    if (i == day)
                    {
                        Month(i / 31, (i % 31) + 1, ((j + 1) % 7));
                        return;
                    }
                }
                else if (i <= 335)
                {
                    number[(i - 6) / 30][(i - 6) % 30] = (j + 1) % 7;
                    if (i == day)
                    {
                        Month((i - 6) / 30, (i - 6) % 30 + 1, ((j + 1) % 7));
                        return;
                    }
                }
                else
                {
                    try
                    {
                        number[11][(i - 6) % 30] = (j + 1) % 7;
                        if (i == day)
                        {
                            Month(11, (i - 6) % 30 + 1, ((j + 1) % 7));
                            return;
                        }
                    }
                    catch
                    {
                    }
                }
                j += 1;

            }
            Start_day = number[11][k - 1];
        }

        private void Month(int Month, int day, int weekday)
        {
            string str = "";
            str += year.ToString() + "/";
            if (Month == 0)
                str += "01";
            else if (Month == 1)
                str += "02";
            else if (Month == 2)
                str += "03";
            else if (Month == 3)
                str += "04";
            else if (Month == 4)
                str += "05";
            else if (Month == 5)
                str += "06";
            else if (Month == 6)
                str += "07";
            else if (Month == 7)
                str += "08";
            else if (Month == 8)
                str += "09";
            else if (Month == 9)
                str += "10";
            else if (Month == 10)
                str += "11";
            else if (Month == 11)
                str += "12";
            if (day < 10)
                str += "/0" + day;
            else
                str += "/" + day;
            st = str;
        }
    }
}

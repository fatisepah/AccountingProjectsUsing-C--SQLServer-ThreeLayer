﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Web.UI.WebControls;

namespace main1.KalayeKharidForosh
{
    public partial class frmKalayeKharidForosh : Form
    {
        public frmKalayeKharidForosh()
        {
            InitializeComponent();
        }
        FilterKalayeKharidForoshData KKFData1 = new FilterKalayeKharidForoshData();
        KalayeKharidForoshData KKFData = new KalayeKharidForoshData();
        GroupKalaData GKData = new GroupKalaData();
        //
        //
        //
        private void idgroupmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k4 = 1;
        }
        int k4 = 0;
        private void idgroupmtxt_TextChanged(object sender, EventArgs e)
        {
            if (idgroupmtxt.Text.Length != 0 && k4 == 1)
            {
                k4 = 0;
                idgroupmtxt.Text = Class1.convert_number(idgroupmtxt.Text.Replace(",", ""));
                idgroupmtxt.Select(idgroupmtxt.Text.Length, 0);
            }
            //
            //
            if (idgroupmtxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = KKFData1.KalayeKharidForoshShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (idgrouprbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
            }
            else
            {
                if (idgrouprbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                    //بدون انجام این عملیات جایگزین کردن هم فیلترینگ کار می کند
                    string NameSherkat = idgroupmtxt.Text.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = KKFData1.FilterNSherkat1(NameSherkat);
                        //انتخاب سطر اول سلول ششم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (idgrouprbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;
                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        idgroupmtxt.Text = "";
                        idgroupmtxt.Focus();
                        idgroupmtxt.SelectAll();

                    }
                }
            }
        }
        //
        //
        //
        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddKalayeKharidForosh obj = new frmAddKalayeKharidForosh();
            obj.ShowDialog();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = KKFData.KalayeKharidForoshShow1();
            set_datagrid();
        }
        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            
            KalayeKharidForosh .frmAddKalayeKharidForosh  obj = new frmAddKalayeKharidForosh();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("سطری انتخاب نشده است!", "", MessageBoxButtons.OK);
            }
            else
            {
               int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                if (obj.ShowDialog() == DialogResult.OK) { }

                dataGridView1.DataSource = true;
                dataGridView1.DataSource = KKFData.KalayeKharidForoshShow1();
                set_datagrid();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDKalaKeraye = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    KKFData.KalayeKharidForoshDelete1(IDKalaKeraye);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        dataGridView1.DataSource = KKFData.KalayeKharidForoshShow1();
                        this.dataGridView1.Refresh();
                    }
                    dataGridView1.DataSource = KKFData.KalayeKharidForoshShow1();
                    this.dataGridView1.Refresh();
                }
            }
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            frmKalayeKharidForoshReport obj = new frmKalayeKharidForoshReport();
            obj.ShowDialog();
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void چاپToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد کالای خرید فروش ";
            dataGridView1.Columns[1].HeaderText = "کد نوع کالا";
            dataGridView1.Columns[2].HeaderText = "کد گروه کالا";
            dataGridView1.Columns[3].HeaderText = "نام کالا";
            dataGridView1.Columns[4].HeaderText = "نام گروه کالا";
            dataGridView1.Columns[5].HeaderText = "واحد شمارش اصلی";
            dataGridView1.Columns[6].HeaderText = "واحد شمارش فرعی";
            dataGridView1.Columns[7].HeaderText = "حداقل تعداد کالای موجود";
            dataGridView1.Columns[8].HeaderText = "تعداد کالا";
            dataGridView1.Columns[9].HeaderText = "توضیحات";
            dataGridView1.Columns[10].HeaderText = "تاریخ تولید";
            dataGridView1.Columns[11].HeaderText = "تاریخ انقضا";
            dataGridView1.Columns[12].HeaderText = "قیمت خرید";
            dataGridView1.Columns[13].HeaderText = "قیمت فروش";
            dataGridView1.Columns[14].HeaderText = "گارانتی";
            dataGridView1.Columns[15].HeaderText = "مدل کالا";
            dataGridView1.Columns[16].HeaderText = "بارکد کالا";
            dataGridView1.Columns[17].HeaderText = "نام شرکت تولید کننده";
            dataGridView1.Columns[12].DefaultCellStyle.Format = "0,0";
            dataGridView1.Columns[13].DefaultCellStyle.Format = "0,0";

            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 50;
            dataGridView1.Columns[2].Width = 50;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 100;
            dataGridView1.Columns[5].Width = 100;
            dataGridView1.Columns[6].Width = 100;
            dataGridView1.Columns[7].Width = 50;
            dataGridView1.Columns[8].Width = 50;
            dataGridView1.Columns[9].Width = 200;
            dataGridView1.Columns[10].Width = 100;
            dataGridView1.Columns[11].Width = 100;
            dataGridView1.Columns[12].Width = 100;
            dataGridView1.Columns[13].Width = 100;
            dataGridView1.Columns[14].Width = 120;
            dataGridView1.Columns[15].Width = 100;
            dataGridView1.Columns[16].Width = 120;
            dataGridView1.Columns[17].Width = 100;
        }

        private void namekalatxt_TextChanged(object sender, EventArgs e)
        {
            if (namekalatxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = KKFData1.KalayeKharidForoshShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (namekalarbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
            }
            else
            {
                if (namekalarbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                    //بدون انجام این عملیات جایگزین کردن هم فیلترینگ کار می کند
                    string NameKala = namekalatxt.Text.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = KKFData1.FilterNameKala1(NameKala);
                        //انتخاب سطر اول سلول ششم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (namekalarbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;
                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        namekalatxt.Text = "";
                        namekalatxt.Focus();
                        namekalatxt.SelectAll();

                    }
                }
            }
        }

        private void sherkattxt_TextChanged(object sender, EventArgs e)
        {
            if (sherkattxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = KKFData1.KalayeKharidForoshShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (sherkatrbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[16];
            }
            else
            {
                if (sherkatrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[16];
                    //بدون انجام این عملیات جایگزین کردن هم فیلترینگ کار می کند
                    string NameSherkat = sherkattxt.Text.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = KKFData1.FilterNSherkat1(NameSherkat);
                        //انتخاب سطر اول سلول ششم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (sherkatrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[16];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;
                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        sherkattxt.Text = "";
                        sherkattxt.Focus();
                        sherkattxt.SelectAll();

                    }
                }
            }
        }
        //
        //
        //


        private void idgroupmtxt_Enter(object sender, EventArgs e)
        {
            idgroupmtxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void namegroupcmb_Enter(object sender, EventArgs e)
        {
            namegroupcmb.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void namekalatxt_Enter(object sender, EventArgs e)
        {
            namekalatxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void sherkattxt_Enter(object sender, EventArgs e)
        {
            sherkattxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void idgroupmtxt_Leave(object sender, EventArgs e)
        {
            idgroupmtxt.BackColor = Color.White;

        }

        private void namegroupcmb_Leave(object sender, EventArgs e)
        {
            namegroupcmb.BackColor = Color.White;

        }

        private void namekalatxt_Leave(object sender, EventArgs e)
        {
            namekalatxt.BackColor = Color.White;

        }

        private void sherkattxt_Leave(object sender, EventArgs e)
        {
            sherkattxt.BackColor = Color.White;

        }

        private void idgrouprbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (idgrouprbtn.Checked == true)
            {
                idgroupmtxt.Enabled = true;
                label1.Enabled = true;
                namegroupcmb.Enabled = true;
                namegroupcmb.Focus();
            }
            else
            {
                idgroupmtxt.Enabled = false;
                label1.Enabled = false;
                namegroupcmb.Enabled = false;
            }
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                namegroupcmb.Focus();
            }
        }

        private void namekalarbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (namekalarbtn.Checked == true)
            {
                namekalatxt.Enabled = true;
                namekalatxt.Focus();
            }
            else
                namekalatxt.Enabled = false;
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                namekalatxt.Focus();
            }
        }

        private void sherkatrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (sherkatrbtn.Checked == true)
            {
                sherkattxt.Enabled = true;
                sherkattxt.Focus();
            }
            else
                sherkattxt.Enabled = false;
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[16];
                sherkattxt.Focus();
            }
        }

        private void frmKalayeKharidForosh_Load(object sender, EventArgs e)
        {
            //برای قرار دادن نام گروه ها در کمبو باکس

            DataTable DT = GKData.GroupKalaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDGroup = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameGroup = DT.Rows[i][1].ToString();

                ListItem item = new ListItem();
                item.Text = NameGroup;
                item.Value = IDGroup.ToString();

                namegroupcmb.Items.Add(item);
            }
            namegroupcmb.SelectedIndex = 0;
            //
            //
            //
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = KKFData1.KalayeKharidForoshShow1();
            set_datagrid();

            idgrouprbtn.Checked = true;
            namekalatxt.Enabled = false;
            sherkattxt.Enabled = false;
            namegroupcmb.Focus();
            dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];

        }

        private void namegroupcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable DT = GKData.GroupKalaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDGroup = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameGroup = DT.Rows[i][1].ToString();

                ListItem item = new ListItem();
                item.Text = NameGroup;
                item.Value = IDGroup.ToString();
                if (item.Text == namegroupcmb.Text)
                {
                    idgroupmtxt.Text = IDGroup.ToString();
                }
            }
        }



    }
}

﻿namespace main1.KalayeKharidForosh
{
    partial class frmKalayeKharidForosh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKalayeKharidForosh));
            this.printbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.virayeshbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پایینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.darjbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idgroupmtxt = new System.Windows.Forms.MaskedTextBox();
            this.sherkattxt = new System.Windows.Forms.TextBox();
            this.namekalatxt = new System.Windows.Forms.TextBox();
            this.sherkatrbtn = new System.Windows.Forms.RadioButton();
            this.namegroupcmb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.namekalarbtn = new System.Windows.Forms.RadioButton();
            this.idgrouprbtn = new System.Windows.Forms.RadioButton();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // printbtn
            // 
            this.printbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printbtn.Image = ((System.Drawing.Image)(resources.GetObject("printbtn.Image")));
            this.printbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printbtn.Location = new System.Drawing.Point(125, 421);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(85, 28);
            this.printbtn.TabIndex = 11;
            this.printbtn.Text = "F7  چاپ";
            this.printbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.printbtn.UseVisualStyleBackColor = true;
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebtn.Image = global::main1.Properties.Resources.cross_script;
            this.deletebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deletebtn.Location = new System.Drawing.Point(214, 421);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(85, 28);
            this.deletebtn.TabIndex = 10;
            this.deletebtn.Text = "Del  حذف";
            this.deletebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // virayeshbtn
            // 
            this.virayeshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.virayeshbtn.Image = ((System.Drawing.Image)(resources.GetObject("virayeshbtn.Image")));
            this.virayeshbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.virayeshbtn.Location = new System.Drawing.Point(303, 421);
            this.virayeshbtn.Name = "virayeshbtn";
            this.virayeshbtn.Size = new System.Drawing.Size(85, 28);
            this.virayeshbtn.TabIndex = 9;
            this.virayeshbtn.Text = "F3  ویرایش";
            this.virayeshbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.virayeshbtn.UseVisualStyleBackColor = true;
            this.virayeshbtn.Click += new System.EventHandler(this.virayeshbtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(31, 421);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 12;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.انصرافToolStripMenuItem,
            this.بالاToolStripMenuItem,
            this.پایینToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 74;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.چاپToolStripMenuItem.Text = "چاپ";
            this.چاپToolStripMenuItem.Click += new System.EventHandler(this.چاپToolStripMenuItem_Click);
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // بالاToolStripMenuItem
            // 
            this.بالاToolStripMenuItem.Name = "بالاToolStripMenuItem";
            this.بالاToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.Tab)));
            this.بالاToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
            this.بالاToolStripMenuItem.Text = "بالا";
            this.بالاToolStripMenuItem.Click += new System.EventHandler(this.بالاToolStripMenuItem_Click);
            // 
            // پایینToolStripMenuItem
            // 
            this.پایینToolStripMenuItem.Name = "پایینToolStripMenuItem";
            this.پایینToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.پایینToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.پایینToolStripMenuItem.Text = "پایین";
            this.پایینToolStripMenuItem.Click += new System.EventHandler(this.پایینToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(11, 163);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(491, 243);
            this.dataGridView1.TabIndex = 73;
            // 
            // darjbtn
            // 
            this.darjbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darjbtn.Image = global::main1.Properties.Resources.ButtonNew;
            this.darjbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.darjbtn.Location = new System.Drawing.Point(392, 421);
            this.darjbtn.Name = "darjbtn";
            this.darjbtn.Size = new System.Drawing.Size(83, 28);
            this.darjbtn.TabIndex = 8;
            this.darjbtn.Text = "F2  درج ";
            this.darjbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.darjbtn.UseVisualStyleBackColor = true;
            this.darjbtn.Click += new System.EventHandler(this.darjbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.idgroupmtxt);
            this.groupBox1.Controls.Add(this.sherkattxt);
            this.groupBox1.Controls.Add(this.namekalatxt);
            this.groupBox1.Controls.Add(this.sherkatrbtn);
            this.groupBox1.Controls.Add(this.namegroupcmb);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.namekalarbtn);
            this.groupBox1.Controls.Add(this.idgrouprbtn);
            this.groupBox1.Location = new System.Drawing.Point(11, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(491, 143);
            this.groupBox1.TabIndex = 75;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "جستجو";
            // 
            // idgroupmtxt
            // 
            this.idgroupmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idgroupmtxt.Location = new System.Drawing.Point(239, 30);
            this.idgroupmtxt.Name = "idgroupmtxt";
            this.idgroupmtxt.Size = new System.Drawing.Size(49, 20);
            this.idgroupmtxt.TabIndex = 2;
            this.idgroupmtxt.TextChanged += new System.EventHandler(this.idgroupmtxt_TextChanged);
            this.idgroupmtxt.Enter += new System.EventHandler(this.idgroupmtxt_Enter);
            this.idgroupmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idgroupmtxt_KeyDown);
            this.idgroupmtxt.Leave += new System.EventHandler(this.idgroupmtxt_Leave);
            // 
            // sherkattxt
            // 
            this.sherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sherkattxt.Location = new System.Drawing.Point(115, 98);
            this.sherkattxt.Name = "sherkattxt";
            this.sherkattxt.Size = new System.Drawing.Size(116, 20);
            this.sherkattxt.TabIndex = 7;
            this.sherkattxt.TextChanged += new System.EventHandler(this.sherkattxt_TextChanged);
            this.sherkattxt.Enter += new System.EventHandler(this.sherkattxt_Enter);
            this.sherkattxt.Leave += new System.EventHandler(this.sherkattxt_Leave);
            // 
            // namekalatxt
            // 
            this.namekalatxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namekalatxt.Location = new System.Drawing.Point(173, 64);
            this.namekalatxt.Name = "namekalatxt";
            this.namekalatxt.Size = new System.Drawing.Size(116, 20);
            this.namekalatxt.TabIndex = 5;
            this.namekalatxt.TextChanged += new System.EventHandler(this.namekalatxt_TextChanged);
            this.namekalatxt.Enter += new System.EventHandler(this.namekalatxt_Enter);
            this.namekalatxt.Leave += new System.EventHandler(this.namekalatxt_Leave);
            // 
            // sherkatrbtn
            // 
            this.sherkatrbtn.AutoSize = true;
            this.sherkatrbtn.Location = new System.Drawing.Point(245, 98);
            this.sherkatrbtn.Name = "sherkatrbtn";
            this.sherkatrbtn.Size = new System.Drawing.Size(206, 17);
            this.sherkatrbtn.TabIndex = 6;
            this.sherkatrbtn.TabStop = true;
            this.sherkatrbtn.Text = "جستجو براساس نام شرکت تولید کننده:";
            this.sherkatrbtn.UseVisualStyleBackColor = true;
            this.sherkatrbtn.CheckedChanged += new System.EventHandler(this.sherkatrbtn_CheckedChanged);
            // 
            // namegroupcmb
            // 
            this.namegroupcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namegroupcmb.FormattingEnabled = true;
            this.namegroupcmb.Location = new System.Drawing.Point(31, 29);
            this.namegroupcmb.Name = "namegroupcmb";
            this.namegroupcmb.Size = new System.Drawing.Size(116, 21);
            this.namegroupcmb.TabIndex = 3;
            this.namegroupcmb.SelectedIndexChanged += new System.EventHandler(this.namegroupcmb_SelectedIndexChanged);
            this.namegroupcmb.Enter += new System.EventHandler(this.namegroupcmb_Enter);
            this.namegroupcmb.Leave += new System.EventHandler(this.namegroupcmb_Leave);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(144, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 23);
            this.label1.TabIndex = 79;
            this.label1.Text = "نام گروه کالا:";
            // 
            // namekalarbtn
            // 
            this.namekalarbtn.AutoSize = true;
            this.namekalarbtn.Location = new System.Drawing.Point(312, 64);
            this.namekalarbtn.Name = "namekalarbtn";
            this.namekalarbtn.Size = new System.Drawing.Size(139, 17);
            this.namekalarbtn.TabIndex = 4;
            this.namekalarbtn.TabStop = true;
            this.namekalarbtn.Text = "جستجو براساس نام کالا:";
            this.namekalarbtn.UseVisualStyleBackColor = true;
            this.namekalarbtn.CheckedChanged += new System.EventHandler(this.namekalarbtn_CheckedChanged);
            // 
            // idgrouprbtn
            // 
            this.idgrouprbtn.AutoSize = true;
            this.idgrouprbtn.Location = new System.Drawing.Point(291, 30);
            this.idgrouprbtn.Name = "idgrouprbtn";
            this.idgrouprbtn.Size = new System.Drawing.Size(160, 17);
            this.idgrouprbtn.TabIndex = 1;
            this.idgrouprbtn.TabStop = true;
            this.idgrouprbtn.Text = "جستجو براساس کد گروه کالا:";
            this.idgrouprbtn.UseVisualStyleBackColor = true;
            this.idgrouprbtn.CheckedChanged += new System.EventHandler(this.idgrouprbtn_CheckedChanged);
            // 
            // frmKalayeKharidForosh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 470);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.printbtn);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.virayeshbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.darjbtn);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmKalayeKharidForosh";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم کالاهای خرید و فروش";
            this.Load += new System.EventHandler(this.frmKalayeKharidForosh_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button printbtn;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button virayeshbtn;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پایینToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button darjbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox sherkattxt;
        private System.Windows.Forms.TextBox namekalatxt;
        private System.Windows.Forms.RadioButton sherkatrbtn;
        private System.Windows.Forms.ComboBox namegroupcmb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton namekalarbtn;
        private System.Windows.Forms.RadioButton idgrouprbtn;
        private System.Windows.Forms.MaskedTextBox idgroupmtxt;

    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Web.UI.WebControls;

namespace main1.KalayeKharidForosh
{
    public partial class frmAddKalayeKharidForosh : Form
    {
        public frmAddKalayeKharidForosh()
        {
            InitializeComponent();
        }
        KalayeKharidForoshData KKFData = new KalayeKharidForoshData();
        KalayeKharidForoshDB KKFDB = new KalayeKharidForoshDB();
        GroupKalaData GKData = new GroupKalaData();
        ToolTip ttip = new ToolTip();
        //
        //
        //

        int k4 = 0;
        private void idgroupmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k4 = 1;
        }

        private void idgroupmtxt_TextChanged(object sender, EventArgs e)
        {
            if (idgroupmtxt.Text.Length != 0 && k4 == 1)
            {
                k4 = 0;
                idgroupmtxt.Text = Class1.convert_number(idgroupmtxt.Text.Replace(",", ""));
                idgroupmtxt.Select(idgroupmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private void tedadekalamtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }
        int k3 = 0;
        private void tedadekalamtxt_TextChanged(object sender, EventArgs e)
        {
            if (tedadekalamtxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                tedadekalamtxt.Text = Class1.convert_str(tedadekalamtxt.Text.Replace(",", ""));
                tedadekalamtxt.Select(tedadekalamtxt.Text.Length, 0);
            }
        }

        //
        //
        //
        private void gheimatekharidmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k = 0;
        private void gheimatekharidmtxt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatekharidmtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                gheimatekharidmtxt.Text = Class1.convert_str(gheimatekharidmtxt.Text.Replace(",", ""));
                gheimatekharidmtxt.Select(gheimatekharidmtxt.Text.Length, 0);
            }
        }

        private void gheimatforoshmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        int k1 = 0;
        private void gheimatforoshmtxt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatforoshmtxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                gheimatforoshmtxt.Text = Class1.convert_str(gheimatforoshmtxt.Text.Replace(",", ""));
                gheimatforoshmtxt.Select(gheimatforoshmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        int k2 = 0;
        private void hadeaghaletedadmojodmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }

        private void hadeaghaletedadmojodmtxt_TextChanged(object sender, EventArgs e)
        {
            if (hadeaghaletedadmojodmtxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                hadeaghaletedadmojodmtxt.Text = Class1.convert_str(hadeaghaletedadmojodmtxt.Text.Replace(",", ""));
                hadeaghaletedadmojodmtxt.Select(hadeaghaletedadmojodmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private void frmAddKalayeKharidForosh_Load(object sender, EventArgs e)
        {
            //برای قرار دادن نام کالاها در کمبو باکس

            DataTable DT = GKData.GroupKalaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDGroup = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameGroup = DT.Rows[i][1].ToString();

                ListItem item = new ListItem();
                item.Text = NameGroup;
                item.Value = IDGroup.ToString();

                namegroupcmb.Items.Add(item);
            }
            namegroupcmb.SelectedIndex = 0;

            //
            //
            //
            if (Class1.virayesh != 0)
            {
                KKFDB = KKFData.KalayeKharidForoshFind1(Class1.virayesh);
                idkalakhfmtxt .Text = KKFDB.IDKalaKHF.ToString();
                idnoekalamtxt .Text = KKFDB.FKNoeKala.ToString();
                idgroupmtxt .Text = KKFDB.FKGroupKala.ToString();
                namegroupcmb .SelectedIndex = KKFDB.FKGroupKala;
                namekalatxt.Text = KKFDB.NameKala;
                vahedaslitxt .Text = KKFDB.VahedeShomaresheAsli ;
                vahedfareetxt.Text = KKFDB.VahedeShomaresheFare;
                hadeaghaletedadmojodmtxt .Text = Class1 .convert_str (KKFDB.HadeaghaleTedadeMojod.ToString ());
                tedadekalamtxt.Text =Class1 .convert_str ( KKFDB.TedadeKala.ToString());
                tozihattxt.Text = KKFDB.Tozihat;
                string s= KKFDB.TarikheTolid .ToString();
                tarikhtolidmtxt .Text =Class1 .Tarikh (s);
                string s1 = KKFDB.TarikheEngheza.ToString();
                tarikhenghezamtxt.Text = Class1.Tarikh(s1);
                gheimatekharidmtxt .Text =Class1 .convert_str ( KKFDB.GheimateKharid .ToString());
                gheimatforoshmtxt .Text =Class1 .convert_str ( KKFDB.GheimateForosh .ToString());
                garantytxt.Text = KKFDB.Garanty;
                modeltxt .Text = KKFDB.ModeleKala;
                barcodemtxt.Text = KKFDB.BarcodeKala;
                namesherkattxt.Text = KKFDB.NameSherkatTolidi;
            }
            else
            {
                int i1 = 0;
                int i2 = 1;
                DataTable dt = KKFData.KalayeKharidForoshSearchID1 ();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idkalakhfmtxt .Text = "1";
                }
                else
                {
                    idkalakhfmtxt.Text = Convert.ToString(i2 + 1);
                }

            }
        }
        private void set_color()
        {
            idkalakhfmtxt .BackColor = Color.White;
            idnoekalamtxt .BackColor = Color.White;
            idgroupmtxt .BackColor = Color.White;
            namegroupcmb .BackColor = Color.White;
            namekalatxt .BackColor = Color.White;
            hadeaghaletedadmojodmtxt .BackColor = Color.White;
            tarikhtolidmtxt .BackColor = Color.White;
            tarikhenghezamtxt .BackColor = Color.White;
            gheimatekharidmtxt .BackColor = Color.White;
            gheimatforoshmtxt .BackColor = Color.White;
            tedadekalamtxt.BackColor = Color.White;
            barcodemtxt .BackColor = Color.White;
            modeltxt.BackColor = Color.White;
            garantytxt.BackColor = Color.White;
            tozihattxt.BackColor = Color.White;
            namesherkattxt .BackColor = Color.White;
            vahedaslitxt .BackColor = Color.White;
            vahedfareetxt.BackColor = Color.White;
        }
        private void enserafbtn_Click(object sender, EventArgs e)
        {
            idkalakhfmtxt.Text ="";
            idnoekalamtxt.Text ="";
            idgroupmtxt.Text = "";
            namekalatxt.Text = "";
            vahedaslitxt.Text = "";
            vahedfareetxt.Text = "";
            hadeaghaletedadmojodmtxt.Text ="";
            tedadekalamtxt.Text = "";
            tozihattxt.Text = "";
            tarikhtolidmtxt.Text ="" ;
            tarikhenghezamtxt.Text = "";
            gheimatekharidmtxt.Text = "";
            gheimatforoshmtxt.Text = "";
            garantytxt.Text ="";
            modeltxt.Text = "";
            barcodemtxt.Text ="" ;
            namesherkattxt.Text = "";

            this.Close();
        }

        private void idnoekalamtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoekalamtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idgroupmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idgroupmtxt.BackColor = Color.FromArgb(255, 255, 192);
            ttip.Show("کد گروه را با انتخاب نام گروه مورد نظر بدست بیاورید", idgroupmtxt);
        }

        private void namegroupcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            namegroupcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idkalakhfmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idkalakhfmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namekalatxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namekalatxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void hadeaghaletedadmojodmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            hadeaghaletedadmojodmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhtolidmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhtolidmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhenghezamtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhenghezamtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void gheimatekharidmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            gheimatekharidmtxt.BackColor = Color.FromArgb(255, 255, 192);
            ttip.Show("قیمت به ریال وارد شود", gheimatekharidmtxt);
        }

        private void gheimatforoshmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            gheimatforoshmtxt.BackColor = Color.FromArgb(255, 255, 192);
            ttip.Show("قیمت به ریال وارد شود", gheimatforoshmtxt);
        }

        private void garantytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            garantytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tedadekalamtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tedadekalamtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void barcodemtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            barcodemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void modeltxt_Enter(object sender, EventArgs e)
        {
            set_color();
            modeltxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesherkattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namesherkattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tozihattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tozihattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void vahedaslitxt_Enter(object sender, EventArgs e)
        {
            set_color();
            vahedaslitxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void vahedfareetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            vahedfareetxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        //
        //
        //
        private void idgroupmtxt_Leave(object sender, EventArgs e)
        {
            ttip.Hide(idgroupmtxt);
        }

        private void idgroupmtxt_MouseEnter(object sender, EventArgs e)
        {
            ttip.Show("کد گروه را با انتخاب نام گروه مورد نظر بدست بیاورید", idgroupmtxt);
        }

        private void idgroupmtxt_MouseLeave(object sender, EventArgs e)
        {
            ttip.Hide(idgroupmtxt);
        }
        //
        //
        //
        private void gheimatekharidmtxt_Leave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatekharidmtxt);
        }

        private void gheimatekharidmtxt_MouseEnter(object sender, EventArgs e)
        {
            ttip.Show("قیمت به ریال وارد شود", gheimatekharidmtxt);
        }

        private void gheimatekharidmtxt_MouseLeave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatekharidmtxt);
        }

        private void gheimatekharidmtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ttip.Hide(gheimatekharidmtxt);
        }
        //
        //
        //
        private void gheimatforoshmtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ttip.Hide(gheimatforoshmtxt);
        }

        private void gheimatforoshmtxt_Leave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatforoshmtxt);
        }

        private void gheimatforoshmtxt_MouseEnter(object sender, EventArgs e)
        {
            ttip.Show("قیمت به ریال وارد شود", gheimatforoshmtxt);
        }

        private void gheimatforoshmtxt_MouseLeave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatforoshmtxt);
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idgroupmtxt.Text != "" && idkalakhfmtxt.Text != "" && namekalatxt.Text != "" && hadeaghaletedadmojodmtxt .Text != "" && tedadekalamtxt .Text != "" && gheimatekharidmtxt .Text != "" && gheimatforoshmtxt .Text != "")
            {
                KKFDB.IDKalaKHF  = Convert.ToInt32(idkalakhfmtxt .Text);
                KKFDB.FKNoeKala = Convert.ToInt32(idnoekalamtxt .Text);
                KKFDB.FKGroupKala = Convert.ToInt32(idgroupmtxt .Text);
                KKFDB.NameKala = namekalatxt.Text;
                KKFDB.VahedeShomaresheAsli  = vahedaslitxt .Text;
                KKFDB.VahedeShomaresheFare  = vahedfareetxt .Text;
                KKFDB.HadeaghaleTedadeMojod = Convert.ToInt32(hadeaghaletedadmojodmtxt .Text);
                KKFDB.TedadeKala = Convert.ToInt32(tedadekalamtxt .Text);
                KKFDB.Tozihat = tozihattxt .Text;
                KKFDB.TarikheTolid = Convert.ToDateTime (tarikhtolidmtxt .Text);
                KKFDB.TarikheEngheza = Convert.ToDateTime(tarikhenghezamtxt.Text);
                KKFDB.GheimateKharid  = Convert.ToInt64(gheimatekharidmtxt .Text.Replace(",", ""));
                KKFDB.GheimateForosh = Convert.ToInt64(gheimatforoshmtxt .Text.Replace(",", ""));
                KKFDB.Garanty = garantytxt .Text;
                KKFDB.ModeleKala = modeltxt .Text;
                KKFDB.BarcodeKala = barcodemtxt .Text;
                KKFDB.NameSherkatTolidi =namesherkattxt.Text;
                if (Class1.virayesh != 0)
                {
                    if (KKFData.KalayeKharidForoshSearch1(KKFDB.IDKalaKHF) && Class1.virayesh != KKFDB.IDKalaKHF)
                    {
                        MessageBox.Show(" کد کالای خرید و فروش تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        KKFData.KalayeKharidForoshUpdate1(KKFDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                    if (!KKFData.KalayeKharidForoshSearch1 (KKFDB.IDKalaKHF))
                    {
                        KKFData.KalayeKharidForoshInsert1 (KKFDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد کالای خرید و فروش تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Hide();
            frmKalayeKharidForosh kkf = new frmKalayeKharidForosh();
            kkf.ShowDialog();
        }

        private void namegroupcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable DT = GKData.GroupKalaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDGroup = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameGroup = DT.Rows[i][1].ToString();

                ListItem item = new ListItem();
                item.Text = NameGroup;
                item.Value = IDGroup.ToString();
                if (item.Text == namegroupcmb.Text)
                {
                    idgroupmtxt.Text = IDGroup.ToString();
                }
            }
        }






    }
}

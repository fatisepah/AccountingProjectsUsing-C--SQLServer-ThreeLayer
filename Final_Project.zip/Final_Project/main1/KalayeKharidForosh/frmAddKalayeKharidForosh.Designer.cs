﻿namespace main1.KalayeKharidForosh
{
    partial class frmAddKalayeKharidForosh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.hadeaghaletedadmojodmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idkalakhfmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tedadekalamtxt = new System.Windows.Forms.MaskedTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.vahedfareetxt = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.vahedaslitxt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.namesherkattxt = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tozihattxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gheimatforoshmtxt = new System.Windows.Forms.MaskedTextBox();
            this.barcodemtxt = new System.Windows.Forms.MaskedTextBox();
            this.gheimatekharidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tarikhenghezamtxt = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.namekalatxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tarikhtolidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.modeltxt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.garantytxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idgroupmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idnoekalamtxt = new System.Windows.Forms.MaskedTextBox();
            this.namegroupcmb = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(338, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 23);
            this.label10.TabIndex = 19;
            this.label10.Text = "کد کالای خرید و فروش:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.hadeaghaletedadmojodmtxt);
            this.groupBox2.Controls.Add(this.idkalakhfmtxt);
            this.groupBox2.Controls.Add(this.tedadekalamtxt);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.namesherkattxt);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.tozihattxt);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.gheimatforoshmtxt);
            this.groupBox2.Controls.Add(this.barcodemtxt);
            this.groupBox2.Controls.Add(this.gheimatekharidmtxt);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.tarikhenghezamtxt);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.namekalatxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tarikhtolidmtxt);
            this.groupBox2.Controls.Add(this.modeltxt);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.garantytxt);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(13, 127);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(487, 433);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "کالای خرید و فروش";
            // 
            // hadeaghaletedadmojodmtxt
            // 
            this.hadeaghaletedadmojodmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hadeaghaletedadmojodmtxt.Location = new System.Drawing.Point(29, 68);
            this.hadeaghaletedadmojodmtxt.Name = "hadeaghaletedadmojodmtxt";
            this.hadeaghaletedadmojodmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hadeaghaletedadmojodmtxt.Size = new System.Drawing.Size(116, 20);
            this.hadeaghaletedadmojodmtxt.TabIndex = 6;
            this.hadeaghaletedadmojodmtxt.TextChanged += new System.EventHandler(this.hadeaghaletedadmojodmtxt_TextChanged);
            this.hadeaghaletedadmojodmtxt.Enter += new System.EventHandler(this.hadeaghaletedadmojodmtxt_Enter);
            this.hadeaghaletedadmojodmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.hadeaghaletedadmojodmtxt_KeyDown);
            // 
            // idkalakhfmtxt
            // 
            this.idkalakhfmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idkalakhfmtxt.Location = new System.Drawing.Point(211, 32);
            this.idkalakhfmtxt.Name = "idkalakhfmtxt";
            this.idkalakhfmtxt.ReadOnly = true;
            this.idkalakhfmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idkalakhfmtxt.Size = new System.Drawing.Size(116, 20);
            this.idkalakhfmtxt.TabIndex = 4;
            this.idkalakhfmtxt.Enter += new System.EventHandler(this.idkalakhfmtxt_Enter);
            // 
            // tedadekalamtxt
            // 
            this.tedadekalamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tedadekalamtxt.Location = new System.Drawing.Point(277, 205);
            this.tedadekalamtxt.Name = "tedadekalamtxt";
            this.tedadekalamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadekalamtxt.Size = new System.Drawing.Size(116, 20);
            this.tedadekalamtxt.TabIndex = 12;
            this.tedadekalamtxt.TextChanged += new System.EventHandler(this.tedadekalamtxt_TextChanged);
            this.tedadekalamtxt.Enter += new System.EventHandler(this.tedadekalamtxt_Enter);
            this.tedadekalamtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedadekalamtxt_KeyDown);
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(197, 37);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 23);
            this.label31.TabIndex = 68;
            this.label31.Text = "*";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.vahedfareetxt);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.vahedaslitxt);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Location = new System.Drawing.Point(15, 338);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(457, 72);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "واحد شمارش کالا";
            // 
            // vahedfareetxt
            // 
            this.vahedfareetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vahedfareetxt.Location = new System.Drawing.Point(14, 28);
            this.vahedfareetxt.Name = "vahedfareetxt";
            this.vahedfareetxt.Size = new System.Drawing.Size(104, 20);
            this.vahedfareetxt.TabIndex = 18;
            this.vahedfareetxt.Enter += new System.EventHandler(this.vahedfareetxt_Enter);
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(117, 31);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(111, 23);
            this.label28.TabIndex = 72;
            this.label28.Text = "واحد شمارش فرعی:";
            // 
            // vahedaslitxt
            // 
            this.vahedaslitxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vahedaslitxt.Location = new System.Drawing.Point(241, 29);
            this.vahedaslitxt.Name = "vahedaslitxt";
            this.vahedaslitxt.Size = new System.Drawing.Size(104, 20);
            this.vahedaslitxt.TabIndex = 17;
            this.vahedaslitxt.Enter += new System.EventHandler(this.vahedaslitxt_Enter);
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(352, 30);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 23);
            this.label25.TabIndex = 70;
            this.label25.Text = "واحد شمارش اصلی:";
            // 
            // namesherkattxt
            // 
            this.namesherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesherkattxt.Location = new System.Drawing.Point(29, 240);
            this.namesherkattxt.Name = "namesherkattxt";
            this.namesherkattxt.Size = new System.Drawing.Size(116, 20);
            this.namesherkattxt.TabIndex = 15;
            this.namesherkattxt.Enter += new System.EventHandler(this.namesherkattxt_Enter);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(153, 241);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 23);
            this.label20.TabIndex = 65;
            this.label20.Text = "نام شرکت تولید کننده:";
            // 
            // tozihattxt
            // 
            this.tozihattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tozihattxt.Location = new System.Drawing.Point(29, 277);
            this.tozihattxt.Multiline = true;
            this.tozihattxt.Name = "tozihattxt";
            this.tozihattxt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tozihattxt.Size = new System.Drawing.Size(364, 46);
            this.tozihattxt.TabIndex = 16;
            this.tozihattxt.Enter += new System.EventHandler(this.tozihattxt_Enter);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(396, 278);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 63;
            this.label1.Text = "توضیحات:";
            // 
            // gheimatforoshmtxt
            // 
            this.gheimatforoshmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatforoshmtxt.Location = new System.Drawing.Point(29, 135);
            this.gheimatforoshmtxt.Name = "gheimatforoshmtxt";
            this.gheimatforoshmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatforoshmtxt.Size = new System.Drawing.Size(116, 20);
            this.gheimatforoshmtxt.TabIndex = 10;
            this.gheimatforoshmtxt.TextChanged += new System.EventHandler(this.gheimatforoshmtxt_TextChanged);
            this.gheimatforoshmtxt.Enter += new System.EventHandler(this.gheimatforoshmtxt_Enter);
            this.gheimatforoshmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatforoshmtxt_KeyDown);
            this.gheimatforoshmtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gheimatforoshmtxt_KeyPress);
            this.gheimatforoshmtxt.Leave += new System.EventHandler(this.gheimatforoshmtxt_Leave);
            this.gheimatforoshmtxt.MouseEnter += new System.EventHandler(this.gheimatforoshmtxt_MouseEnter);
            this.gheimatforoshmtxt.MouseLeave += new System.EventHandler(this.gheimatforoshmtxt_MouseLeave);
            // 
            // barcodemtxt
            // 
            this.barcodemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.barcodemtxt.Location = new System.Drawing.Point(29, 205);
            this.barcodemtxt.Mask = "9999999999999";
            this.barcodemtxt.Name = "barcodemtxt";
            this.barcodemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcodemtxt.Size = new System.Drawing.Size(116, 20);
            this.barcodemtxt.TabIndex = 13;
            this.barcodemtxt.Enter += new System.EventHandler(this.barcodemtxt_Enter);
            // 
            // gheimatekharidmtxt
            // 
            this.gheimatekharidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatekharidmtxt.Location = new System.Drawing.Point(277, 136);
            this.gheimatekharidmtxt.Name = "gheimatekharidmtxt";
            this.gheimatekharidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekharidmtxt.Size = new System.Drawing.Size(116, 20);
            this.gheimatekharidmtxt.TabIndex = 9;
            this.gheimatekharidmtxt.TextChanged += new System.EventHandler(this.gheimatekharidmtxt_TextChanged);
            this.gheimatekharidmtxt.Enter += new System.EventHandler(this.gheimatekharidmtxt_Enter);
            this.gheimatekharidmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatekharidmtxt_KeyDown);
            this.gheimatekharidmtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gheimatekharidmtxt_KeyPress);
            this.gheimatekharidmtxt.Leave += new System.EventHandler(this.gheimatekharidmtxt_Leave);
            this.gheimatekharidmtxt.MouseEnter += new System.EventHandler(this.gheimatekharidmtxt_MouseEnter);
            this.gheimatekharidmtxt.MouseLeave += new System.EventHandler(this.gheimatekharidmtxt_MouseLeave);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(145, 207);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 23);
            this.label18.TabIndex = 56;
            this.label18.Text = "بارکد کالا:";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(12, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 23);
            this.label15.TabIndex = 55;
            this.label15.Text = "*";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(148, 137);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 23);
            this.label16.TabIndex = 53;
            this.label16.Text = "قیمت فروش:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(260, 137);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 23);
            this.label13.TabIndex = 52;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(400, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 23);
            this.label14.TabIndex = 50;
            this.label14.Text = "قیمت خرید:";
            // 
            // tarikhenghezamtxt
            // 
            this.tarikhenghezamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhenghezamtxt.Location = new System.Drawing.Point(29, 101);
            this.tarikhenghezamtxt.Mask = "9999/99/99";
            this.tarikhenghezamtxt.Name = "tarikhenghezamtxt";
            this.tarikhenghezamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhenghezamtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhenghezamtxt.TabIndex = 8;
            this.tarikhenghezamtxt.Enter += new System.EventHandler(this.tarikhenghezamtxt_Enter);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(152, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 23);
            this.label9.TabIndex = 48;
            this.label9.Text = "تاریخ انقضا:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(260, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 23);
            this.label4.TabIndex = 47;
            this.label4.Text = "*";
            // 
            // namekalatxt
            // 
            this.namekalatxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namekalatxt.Location = new System.Drawing.Point(277, 68);
            this.namekalatxt.Name = "namekalatxt";
            this.namekalatxt.Size = new System.Drawing.Size(116, 20);
            this.namekalatxt.TabIndex = 5;
            this.namekalatxt.Enter += new System.EventHandler(this.namekalatxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(12, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 45;
            this.label5.Text = "*";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(149, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 23);
            this.label3.TabIndex = 43;
            this.label3.Text = "حداقل تعداد موجود:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(397, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 23);
            this.label2.TabIndex = 42;
            this.label2.Text = "نام کالا:";
            // 
            // tarikhtolidmtxt
            // 
            this.tarikhtolidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhtolidmtxt.Location = new System.Drawing.Point(277, 101);
            this.tarikhtolidmtxt.Mask = "9999/99/99";
            this.tarikhtolidmtxt.Name = "tarikhtolidmtxt";
            this.tarikhtolidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhtolidmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhtolidmtxt.TabIndex = 7;
            this.tarikhtolidmtxt.Enter += new System.EventHandler(this.tarikhtolidmtxt_Enter);
            // 
            // modeltxt
            // 
            this.modeltxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.modeltxt.Location = new System.Drawing.Point(277, 241);
            this.modeltxt.Name = "modeltxt";
            this.modeltxt.Size = new System.Drawing.Size(116, 20);
            this.modeltxt.TabIndex = 14;
            this.modeltxt.Enter += new System.EventHandler(this.modeltxt_Enter);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(399, 242);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 23);
            this.label21.TabIndex = 33;
            this.label21.Text = "مدل کالا:";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(260, 209);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 23);
            this.label11.TabIndex = 9;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(393, 207);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 23);
            this.label12.TabIndex = 7;
            this.label12.Text = "تعداد کالا:";
            // 
            // garantytxt
            // 
            this.garantytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.garantytxt.Location = new System.Drawing.Point(29, 170);
            this.garantytxt.Name = "garantytxt";
            this.garantytxt.Size = new System.Drawing.Size(364, 20);
            this.garantytxt.TabIndex = 11;
            this.garantytxt.Enter += new System.EventHandler(this.garantytxt_Enter);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(394, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 23);
            this.label7.TabIndex = 2;
            this.label7.Text = "گارانتی:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(398, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 23);
            this.label8.TabIndex = 1;
            this.label8.Text = "تاریخ تولید:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.idgroupmtxt);
            this.groupBox1.Controls.Add(this.idnoekalamtxt);
            this.groupBox1.Controls.Add(this.namegroupcmb);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(13, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(487, 98);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // idgroupmtxt
            // 
            this.idgroupmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idgroupmtxt.Location = new System.Drawing.Point(277, 58);
            this.idgroupmtxt.Name = "idgroupmtxt";
            this.idgroupmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idgroupmtxt.Size = new System.Drawing.Size(116, 20);
            this.idgroupmtxt.TabIndex = 2;
            this.idgroupmtxt.TextChanged += new System.EventHandler(this.idgroupmtxt_TextChanged);
            this.idgroupmtxt.Enter += new System.EventHandler(this.idgroupmtxt_Enter);
            this.idgroupmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idgroupmtxt_KeyDown);
            this.idgroupmtxt.Leave += new System.EventHandler(this.idgroupmtxt_Leave);
            this.idgroupmtxt.MouseEnter += new System.EventHandler(this.idgroupmtxt_MouseEnter);
            this.idgroupmtxt.MouseLeave += new System.EventHandler(this.idgroupmtxt_MouseLeave);
            // 
            // idnoekalamtxt
            // 
            this.idnoekalamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoekalamtxt.Location = new System.Drawing.Point(277, 25);
            this.idnoekalamtxt.Name = "idnoekalamtxt";
            this.idnoekalamtxt.ReadOnly = true;
            this.idnoekalamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoekalamtxt.Size = new System.Drawing.Size(116, 20);
            this.idnoekalamtxt.TabIndex = 1;
            this.idnoekalamtxt.Text = "1";
            this.idnoekalamtxt.Enter += new System.EventHandler(this.idnoekalamtxt_Enter);
            // 
            // namegroupcmb
            // 
            this.namegroupcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namegroupcmb.FormattingEnabled = true;
            this.namegroupcmb.Location = new System.Drawing.Point(29, 57);
            this.namegroupcmb.Name = "namegroupcmb";
            this.namegroupcmb.Size = new System.Drawing.Size(116, 21);
            this.namegroupcmb.TabIndex = 3;
            this.namegroupcmb.SelectedIndexChanged += new System.EventHandler(this.namegroupcmb_SelectedIndexChanged);
            this.namegroupcmb.Enter += new System.EventHandler(this.namegroupcmb_Enter);
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(260, 61);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 23);
            this.label30.TabIndex = 69;
            this.label30.Text = "*";
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(260, 29);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(16, 23);
            this.label29.TabIndex = 68;
            this.label29.Text = "*";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(153, 59);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 23);
            this.label23.TabIndex = 38;
            this.label23.Text = "نام گروه:";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(401, 60);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 23);
            this.label24.TabIndex = 37;
            this.label24.Text = "کد گروه:";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(398, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(64, 23);
            this.label19.TabIndex = 19;
            this.label19.Text = "کد نوع کالا:";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(162, 579);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 20;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(257, 579);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 19;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // frmAddKalayeKharidForosh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 618);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddKalayeKharidForosh";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم کالای خرید و فروش";
            this.Load += new System.EventHandler(this.frmAddKalayeKharidForosh_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tozihattxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox gheimatforoshmtxt;
        private System.Windows.Forms.MaskedTextBox barcodemtxt;
        private System.Windows.Forms.MaskedTextBox gheimatekharidmtxt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox tarikhenghezamtxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox namekalatxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox tarikhtolidmtxt;
        private System.Windows.Forms.TextBox modeltxt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox garantytxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox namesherkattxt;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox vahedfareetxt;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox vahedaslitxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox namegroupcmb;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.MaskedTextBox hadeaghaletedadmojodmtxt;
        private System.Windows.Forms.MaskedTextBox idkalakhfmtxt;
        private System.Windows.Forms.MaskedTextBox tedadekalamtxt;
        private System.Windows.Forms.MaskedTextBox idgroupmtxt;
        private System.Windows.Forms.MaskedTextBox idnoekalamtxt;

    }
}
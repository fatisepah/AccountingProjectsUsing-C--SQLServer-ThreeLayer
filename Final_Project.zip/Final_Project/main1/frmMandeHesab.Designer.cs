﻿namespace main1
{
    partial class frmMandeHesab
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.panel1 = new System.Windows.Forms.Panel();
            this.keshavarzi = new System.Windows.Forms.LinkLabel();
            this.ghavamin = new System.Windows.Forms.LinkLabel();
            this.tejarat = new System.Windows.Forms.LinkLabel();
            this.saderat = new System.Windows.Forms.LinkLabel();
            this.melat = new System.Windows.Forms.LinkLabel();
            this.meli = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Left;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(822, 627);
            this.webBrowser1.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.keshavarzi);
            this.panel1.Controls.Add(this.ghavamin);
            this.panel1.Controls.Add(this.tejarat);
            this.panel1.Controls.Add(this.saderat);
            this.panel1.Controls.Add(this.melat);
            this.panel1.Controls.Add(this.meli);
            this.panel1.Location = new System.Drawing.Point(823, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(156, 627);
            this.panel1.TabIndex = 8;
            // 
            // keshavarzi
            // 
            this.keshavarzi.Font = new System.Drawing.Font("Tahoma", 9F);
            this.keshavarzi.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.keshavarzi.LinkColor = System.Drawing.Color.Blue;
            this.keshavarzi.Location = new System.Drawing.Point(22, 192);
            this.keshavarzi.Name = "keshavarzi";
            this.keshavarzi.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.keshavarzi.Size = new System.Drawing.Size(114, 21);
            this.keshavarzi.TabIndex = 5;
            this.keshavarzi.TabStop = true;
            this.keshavarzi.Text = "سایت بانک کشاورزی";
            this.keshavarzi.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.keshavarzi_LinkClicked);
            // 
            // ghavamin
            // 
            this.ghavamin.Font = new System.Drawing.Font("Tahoma", 9F);
            this.ghavamin.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.ghavamin.LinkColor = System.Drawing.Color.Blue;
            this.ghavamin.Location = new System.Drawing.Point(36, 158);
            this.ghavamin.Name = "ghavamin";
            this.ghavamin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ghavamin.Size = new System.Drawing.Size(100, 21);
            this.ghavamin.TabIndex = 4;
            this.ghavamin.TabStop = true;
            this.ghavamin.Text = "سایت بانک قوامین";
            this.ghavamin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ghavamin_LinkClicked);
            // 
            // tejarat
            // 
            this.tejarat.Font = new System.Drawing.Font("Tahoma", 9F);
            this.tejarat.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.tejarat.LinkColor = System.Drawing.Color.Blue;
            this.tejarat.Location = new System.Drawing.Point(36, 124);
            this.tejarat.Name = "tejarat";
            this.tejarat.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tejarat.Size = new System.Drawing.Size(100, 21);
            this.tejarat.TabIndex = 3;
            this.tejarat.TabStop = true;
            this.tejarat.Text = "سایت بانک تجارت";
            this.tejarat.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.tejarat_LinkClicked);
            // 
            // saderat
            // 
            this.saderat.Font = new System.Drawing.Font("Tahoma", 9F);
            this.saderat.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.saderat.LinkColor = System.Drawing.Color.Blue;
            this.saderat.Location = new System.Drawing.Point(33, 90);
            this.saderat.Name = "saderat";
            this.saderat.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.saderat.Size = new System.Drawing.Size(103, 21);
            this.saderat.TabIndex = 2;
            this.saderat.TabStop = true;
            this.saderat.Text = "سایت بانک صادرات";
            this.saderat.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.saderat_LinkClicked);
            // 
            // melat
            // 
            this.melat.Font = new System.Drawing.Font("Tahoma", 9F);
            this.melat.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.melat.LinkColor = System.Drawing.Color.Blue;
            this.melat.Location = new System.Drawing.Point(47, 56);
            this.melat.Name = "melat";
            this.melat.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.melat.Size = new System.Drawing.Size(89, 21);
            this.melat.TabIndex = 1;
            this.melat.TabStop = true;
            this.melat.Text = "سایت بانک ملت";
            this.melat.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.melat_LinkClicked);
            // 
            // meli
            // 
            this.meli.Font = new System.Drawing.Font("Tahoma", 9F);
            this.meli.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.meli.LinkColor = System.Drawing.Color.Blue;
            this.meli.Location = new System.Drawing.Point(47, 22);
            this.meli.Name = "meli";
            this.meli.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.meli.Size = new System.Drawing.Size(89, 21);
            this.meli.TabIndex = 0;
            this.meli.TabStop = true;
            this.meli.Text = "سایت بانک ملی";
            this.meli.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.meli_LinkClicked);
            // 
            // frmMandeHesab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(980, 627);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.panel1);
            this.Name = "frmMandeHesab";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم نمایش مانده حساب";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel keshavarzi;
        private System.Windows.Forms.LinkLabel ghavamin;
        private System.Windows.Forms.LinkLabel tejarat;
        private System.Windows.Forms.LinkLabel saderat;
        private System.Windows.Forms.LinkLabel melat;
        private System.Windows.Forms.LinkLabel meli;
    }
}
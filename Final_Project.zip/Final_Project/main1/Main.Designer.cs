﻿namespace main1
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.سیستمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ورودسیستمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجازسیستمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجازبرنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.تعریفکاربرانبرنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعاریفپایهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعریفکالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.تعریفمشتریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.تعیینموجودیصندوقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.اسنادپرداختنیاولدورهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اسناددریافتنیاولدورهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ثبترویدادهایغیرمالیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتاسنادحسابداریToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتورToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتورخریدF4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فاکتورفروشF5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.گزارشاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بستانکارانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بدهکارانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.ترازنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ترازآزمایشیToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.صورتتغییراتسرمایهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.صورتحقوقصاحبانسهامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.صورتحسابسودوزیانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.گزارشماندهحسابهاازدفترکلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.گزاشدفترروزنامهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.کاربرگToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.امکاناتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ماشینحسابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نمایشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اطلاعاتکاربرانفعالToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مشاهدهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.راهنماToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.راهنمایاستفادهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.دربارهToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblnamesherkat = new System.Windows.Forms.Label();
            this.lblsalemali = new System.Windows.Forms.Label();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.lbltime = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbldate1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ribbonComboBox1 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonButtonList1 = new System.Windows.Forms.RibbonButtonList();
            this.ribbonButtonList2 = new System.Windows.Forms.RibbonButtonList();
            this.ribbonButtonList3 = new System.Windows.Forms.RibbonButtonList();
            this.ribbonItemGroup1 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbon1 = new System.Windows.Forms.Ribbon();
            this.sistemribtab = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel1 = new System.Windows.Forms.RibbonPanel();
            this.loginkarbarrib = new System.Windows.Forms.RibbonButton();
            this.logoutkarbarrib = new System.Windows.Forms.RibbonButton();
            this.exitrib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel2 = new System.Windows.Forms.RibbonPanel();
            this.shutdownrib = new System.Windows.Forms.RibbonButton();
            this.rebootrib = new System.Windows.Forms.RibbonButton();
            this.logoffrib = new System.Windows.Forms.RibbonButton();
            this.taarifribtab = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel3 = new System.Windows.Forms.RibbonPanel();
            this.kalakerayerib = new System.Windows.Forms.RibbonButton();
            this.kalakharidforoshrib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel4 = new System.Windows.Forms.RibbonPanel();
            this.moshtaririb = new System.Windows.Forms.RibbonButton();
            this.hesabbankirib = new System.Windows.Forms.RibbonButton();
            this.karbarrib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel5 = new System.Windows.Forms.RibbonPanel();
            this.sanadhesabdaririb = new System.Windows.Forms.RibbonButton();
            this.roidadegheiremalirib = new System.Windows.Forms.RibbonButton();
            this.hesabrib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel6 = new System.Windows.Forms.RibbonPanel();
            this.groupkalarib = new System.Windows.Forms.RibbonButton();
            this.taraconeshtabrib = new System.Windows.Forms.RibbonPanel();
            this.checkrib = new System.Windows.Forms.RibbonButton();
            this.havalerib = new System.Windows.Forms.RibbonButton();
            this.ghestyrib = new System.Windows.Forms.RibbonButton();
            this.naghdrib = new System.Windows.Forms.RibbonButton();
            this.gozareshribtab = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel10 = new System.Windows.Forms.RibbonPanel();
            this.taraznamerib = new System.Windows.Forms.RibbonButton();
            this.tarazazmayeshirib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel11 = new System.Windows.Forms.RibbonPanel();
            this.soratsarmayerib = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonList4 = new System.Windows.Forms.RibbonButtonList();
            this.sorathoghoghsahebrib = new System.Windows.Forms.RibbonButton();
            this.soratsodziyanrib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel13 = new System.Windows.Forms.RibbonPanel();
            this.mandekolrib = new System.Windows.Forms.RibbonButton();
            this.dafatreroznamerib = new System.Windows.Forms.RibbonButton();
            this.factorribtab = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel8 = new System.Windows.Forms.RibbonPanel();
            this.factorkharidrib = new System.Windows.Forms.RibbonButton();
            this.factorforoshrib = new System.Windows.Forms.RibbonButton();
            this.factorkerayerib = new System.Windows.Forms.RibbonButton();
            this.emkanatribtab = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel19 = new System.Windows.Forms.RibbonPanel();
            this.mashinhesabrib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel7 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton20 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel9 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton21 = new System.Windows.Forms.RibbonButton();
            this.rahnamaribtab = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel22 = new System.Windows.Forms.RibbonPanel();
            this.rahnamarib = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel23 = new System.Windows.Forms.RibbonPanel();
            this.darbarerib = new System.Windows.Forms.RibbonButton();
            this.ribbonTextBox1 = new System.Windows.Forms.RibbonTextBox();
            this.ribbonComboBox2 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonTab1 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel24 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton1 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel25 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton2 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel26 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton3 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel27 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton8 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel28 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton9 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel29 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton11 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel30 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton13 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel31 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton15 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel32 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton17 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel33 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton18 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton19 = new System.Windows.Forms.RibbonButton();
            this.ribbonTab2 = new System.Windows.Forms.RibbonTab();
            this.ribbonTab3 = new System.Windows.Forms.RibbonTab();
            this.ribbonTab4 = new System.Windows.Forms.RibbonTab();
            this.ribbonTab5 = new System.Windows.Forms.RibbonTab();
            this.checkvosolGB = new System.Windows.Forms.GroupBox();
            this.checkdaryaftilbl = new System.Windows.Forms.Label();
            this.checkpardakhtGB = new System.Windows.Forms.GroupBox();
            this.checkpardakhtilbl = new System.Windows.Forms.Label();
            this.hadeaghalekalaGB = new System.Windows.Forms.GroupBox();
            this.lblkalasefareshi = new System.Windows.Forms.Label();
            this.kalakerayeGB = new System.Windows.Forms.GroupBox();
            this.lblkalakeraye = new System.Windows.Forms.Label();
            this.ribbonButtonList5 = new System.Windows.Forms.RibbonButtonList();
            this.ribbonComboBox3 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonComboBox4 = new System.Windows.Forms.RibbonComboBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.vistaClock1 = new CNPOPSOFT.Controls.VistaClock();
            this.hadeaghalekalachb = new System.Windows.Forms.CheckBox();
            this.kalakerayechb = new System.Windows.Forms.CheckBox();
            this.checkvosolchb = new System.Windows.Forms.CheckBox();
            this.checkpardakhtchb = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ribbonColorChooser1 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonColorChooser2 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonButton4 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton5 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton6 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton7 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton10 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton12 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton14 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton16 = new System.Windows.Forms.RibbonButton();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.checkvosolGB.SuspendLayout();
            this.checkpardakhtGB.SuspendLayout();
            this.hadeaghalekalaGB.SuspendLayout();
            this.kalakerayeGB.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.سیستمToolStripMenuItem,
            this.تعاریفپایهToolStripMenuItem,
            this.فاکتورToolStripMenuItem,
            this.گزارشاتToolStripMenuItem,
            this.امکاناتToolStripMenuItem,
            this.نمایشToolStripMenuItem,
            this.راهنماToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1028, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // سیستمToolStripMenuItem
            // 
            this.سیستمToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.سیستمToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ورودسیستمToolStripMenuItem,
            this.خروجازسیستمToolStripMenuItem,
            this.خروجازبرنامهToolStripMenuItem,
            this.toolStripSeparator12,
            this.تعریفکاربرانبرنامهToolStripMenuItem});
            this.سیستمToolStripMenuItem.Name = "سیستمToolStripMenuItem";
            this.سیستمToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.سیستمToolStripMenuItem.Text = "سیستم";
            // 
            // ورودسیستمToolStripMenuItem
            // 
            this.ورودسیستمToolStripMenuItem.Image = global::main1.Properties.Resources.A_Login;
            this.ورودسیستمToolStripMenuItem.Name = "ورودسیستمToolStripMenuItem";
            this.ورودسیستمToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.ورودسیستمToolStripMenuItem.Text = "ورود  به سیستم";
            // 
            // خروجازسیستمToolStripMenuItem
            // 
            this.خروجازسیستمToolStripMenuItem.Image = global::main1.Properties.Resources.Shutdown;
            this.خروجازسیستمToolStripMenuItem.Name = "خروجازسیستمToolStripMenuItem";
            this.خروجازسیستمToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.خروجازسیستمToolStripMenuItem.Text = "خروج از سیستم";
            // 
            // خروجازبرنامهToolStripMenuItem
            // 
            this.خروجازبرنامهToolStripMenuItem.Image = global::main1.Properties.Resources.Cancel_Min;
            this.خروجازبرنامهToolStripMenuItem.Name = "خروجازبرنامهToolStripMenuItem";
            this.خروجازبرنامهToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.خروجازبرنامهToolStripMenuItem.Text = "خروج از برنامه";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(170, 6);
            // 
            // تعریفکاربرانبرنامهToolStripMenuItem
            // 
            this.تعریفکاربرانبرنامهToolStripMenuItem.Image = global::main1.Properties.Resources.user_add_Min;
            this.تعریفکاربرانبرنامهToolStripMenuItem.Name = "تعریفکاربرانبرنامهToolStripMenuItem";
            this.تعریفکاربرانبرنامهToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.تعریفکاربرانبرنامهToolStripMenuItem.Text = "تعریف کاربران برنامه";
            // 
            // تعاریفپایهToolStripMenuItem
            // 
            this.تعاریفپایهToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تعریفکالاToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripSeparator1,
            this.تعریفمشتریToolStripMenuItem,
            this.toolStripSeparator2,
            this.toolStripMenuItem4,
            this.toolStripSeparator5,
            this.تعیینموجودیصندوقToolStripMenuItem,
            this.toolStripSeparator7,
            this.اسنادپرداختنیاولدورهToolStripMenuItem,
            this.اسناددریافتنیاولدورهToolStripMenuItem,
            this.toolStripSeparator8,
            this.toolStripMenuItem3,
            this.toolStripSeparator6,
            this.ثبترویدادهایغیرمالیToolStripMenuItem,
            this.ثبتاسنادحسابداریToolStripMenuItem});
            this.تعاریفپایهToolStripMenuItem.Name = "تعاریفپایهToolStripMenuItem";
            this.تعاریفپایهToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.تعاریفپایهToolStripMenuItem.Text = "تعاریف پایه";
            // 
            // تعریفکالاToolStripMenuItem
            // 
            this.تعریفکالاToolStripMenuItem.Image = global::main1.Properties.Resources.plus1;
            this.تعریفکالاToolStripMenuItem.Name = "تعریفکالاToolStripMenuItem";
            this.تعریفکالاToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.تعریفکالاToolStripMenuItem.Text = "تعریف کالای کرایه";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(219, 22);
            this.toolStripMenuItem1.Text = "تعریف کالای خرید فروش";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::main1.Properties.Resources.AddGroup;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(219, 22);
            this.toolStripMenuItem2.Text = "تعریف گروه مربوط به کالا";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(216, 6);
            // 
            // تعریفمشتریToolStripMenuItem
            // 
            this.تعریفمشتریToolStripMenuItem.Name = "تعریفمشتریToolStripMenuItem";
            this.تعریفمشتریToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.تعریفمشتریToolStripMenuItem.Text = "تعریف مشتری و فروشندگان";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(216, 6);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(219, 22);
            this.toolStripMenuItem4.Text = "تعریف حساب بانکی";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(216, 6);
            // 
            // تعیینموجودیصندوقToolStripMenuItem
            // 
            this.تعیینموجودیصندوقToolStripMenuItem.Image = global::main1.Properties.Resources._20111006073350971_easyicon_cn_24;
            this.تعیینموجودیصندوقToolStripMenuItem.Name = "تعیینموجودیصندوقToolStripMenuItem";
            this.تعیینموجودیصندوقToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.تعیینموجودیصندوقToolStripMenuItem.Text = "تعیین موجودی صندوق(اول دوره)";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(216, 6);
            // 
            // اسنادپرداختنیاولدورهToolStripMenuItem
            // 
            this.اسنادپرداختنیاولدورهToolStripMenuItem.Name = "اسنادپرداختنیاولدورهToolStripMenuItem";
            this.اسنادپرداختنیاولدورهToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.اسنادپرداختنیاولدورهToolStripMenuItem.Text = "اسناد پرداختنی(اول دوره)";
            // 
            // اسناددریافتنیاولدورهToolStripMenuItem
            // 
            this.اسناددریافتنیاولدورهToolStripMenuItem.Name = "اسناددریافتنیاولدورهToolStripMenuItem";
            this.اسناددریافتنیاولدورهToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.اسناددریافتنیاولدورهToolStripMenuItem.Text = "اسناد دریافتنی(اول دوره)";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(216, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(219, 22);
            this.toolStripMenuItem3.Text = "تعریف حسابها";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(216, 6);
            // 
            // ثبترویدادهایغیرمالیToolStripMenuItem
            // 
            this.ثبترویدادهایغیرمالیToolStripMenuItem.Name = "ثبترویدادهایغیرمالیToolStripMenuItem";
            this.ثبترویدادهایغیرمالیToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ثبترویدادهایغیرمالیToolStripMenuItem.Text = "ثبت رویدادهای غیر مالی";
            // 
            // ثبتاسنادحسابداریToolStripMenuItem
            // 
            this.ثبتاسنادحسابداریToolStripMenuItem.Name = "ثبتاسنادحسابداریToolStripMenuItem";
            this.ثبتاسنادحسابداریToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ثبتاسنادحسابداریToolStripMenuItem.Text = "ثبت اسناد حسابداری";
            // 
            // فاکتورToolStripMenuItem
            // 
            this.فاکتورToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فاکتورخریدF4ToolStripMenuItem,
            this.فاکتورفروشF5ToolStripMenuItem,
            this.toolStripMenuItem5});
            this.فاکتورToolStripMenuItem.Name = "فاکتورToolStripMenuItem";
            this.فاکتورToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.فاکتورToolStripMenuItem.Text = "فاکتور";
            // 
            // فاکتورخریدF4ToolStripMenuItem
            // 
            this.فاکتورخریدF4ToolStripMenuItem.Image = global::main1.Properties.Resources.factorKharid;
            this.فاکتورخریدF4ToolStripMenuItem.Name = "فاکتورخریدF4ToolStripMenuItem";
            this.فاکتورخریدF4ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
            this.فاکتورخریدF4ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.فاکتورخریدF4ToolStripMenuItem.Text = "فاکتور خرید";
            // 
            // فاکتورفروشF5ToolStripMenuItem
            // 
            this.فاکتورفروشF5ToolStripMenuItem.Image = global::main1.Properties.Resources.factorForosh;
            this.فاکتورفروشF5ToolStripMenuItem.Name = "فاکتورفروشF5ToolStripMenuItem";
            this.فاکتورفروشF5ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.فاکتورفروشF5ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.فاکتورفروشF5ToolStripMenuItem.Text = "فاکتور فروش";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.toolStripMenuItem5.Size = new System.Drawing.Size(153, 22);
            this.toolStripMenuItem5.Text = "فاکتور کرایه ";
            // 
            // گزارشاتToolStripMenuItem
            // 
            this.گزارشاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.بستانکارانToolStripMenuItem,
            this.بدهکارانToolStripMenuItem,
            this.toolStripSeparator17,
            this.ترازنامهToolStripMenuItem,
            this.ترازآزمایشیToolStripMenuItem,
            this.toolStripSeparator18,
            this.صورتتغییراتسرمایهToolStripMenuItem,
            this.صورتحقوقصاحبانسهامToolStripMenuItem,
            this.صورتحسابسودوزیانToolStripMenuItem,
            this.toolStripSeparator20,
            this.گزارشماندهحسابهاازدفترکلToolStripMenuItem,
            this.گزاشدفترروزنامهToolStripMenuItem,
            this.toolStripSeparator21,
            this.کاربرگToolStripMenuItem});
            this.گزارشاتToolStripMenuItem.Name = "گزارشاتToolStripMenuItem";
            this.گزارشاتToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.گزارشاتToolStripMenuItem.Text = "گزارشات";
            // 
            // بستانکارانToolStripMenuItem
            // 
            this.بستانکارانToolStripMenuItem.Name = "بستانکارانToolStripMenuItem";
            this.بستانکارانToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.بستانکارانToolStripMenuItem.Text = "بستانکاران";
            // 
            // بدهکارانToolStripMenuItem
            // 
            this.بدهکارانToolStripMenuItem.Name = "بدهکارانToolStripMenuItem";
            this.بدهکارانToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.بدهکارانToolStripMenuItem.Text = "بدهکاران";
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(216, 6);
            // 
            // ترازنامهToolStripMenuItem
            // 
            this.ترازنامهToolStripMenuItem.Name = "ترازنامهToolStripMenuItem";
            this.ترازنامهToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ترازنامهToolStripMenuItem.Text = "ترازنامه";
            // 
            // ترازآزمایشیToolStripMenuItem
            // 
            this.ترازآزمایشیToolStripMenuItem.Name = "ترازآزمایشیToolStripMenuItem";
            this.ترازآزمایشیToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.ترازآزمایشیToolStripMenuItem.Text = "تراز آزمایشی";
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(216, 6);
            // 
            // صورتتغییراتسرمایهToolStripMenuItem
            // 
            this.صورتتغییراتسرمایهToolStripMenuItem.Name = "صورتتغییراتسرمایهToolStripMenuItem";
            this.صورتتغییراتسرمایهToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.صورتتغییراتسرمایهToolStripMenuItem.Text = "صورت تغییرات سرمایه";
            // 
            // صورتحقوقصاحبانسهامToolStripMenuItem
            // 
            this.صورتحقوقصاحبانسهامToolStripMenuItem.Name = "صورتحقوقصاحبانسهامToolStripMenuItem";
            this.صورتحقوقصاحبانسهامToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.صورتحقوقصاحبانسهامToolStripMenuItem.Text = "صورت سود و زیان بازرگانی";
            // 
            // صورتحسابسودوزیانToolStripMenuItem
            // 
            this.صورتحسابسودوزیانToolStripMenuItem.Name = "صورتحسابسودوزیانToolStripMenuItem";
            this.صورتحسابسودوزیانToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.صورتحسابسودوزیانToolStripMenuItem.Text = "صورتحساب سود و زیان خدماتی";
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(216, 6);
            // 
            // گزارشماندهحسابهاازدفترکلToolStripMenuItem
            // 
            this.گزارشماندهحسابهاازدفترکلToolStripMenuItem.Name = "گزارشماندهحسابهاازدفترکلToolStripMenuItem";
            this.گزارشماندهحسابهاازدفترکلToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.گزارشماندهحسابهاازدفترکلToolStripMenuItem.Text = "گزارش مانده حسابها از دفتر کل";
            // 
            // گزاشدفترروزنامهToolStripMenuItem
            // 
            this.گزاشدفترروزنامهToolStripMenuItem.Name = "گزاشدفترروزنامهToolStripMenuItem";
            this.گزاشدفترروزنامهToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.گزاشدفترروزنامهToolStripMenuItem.Text = "گزاش دفتر روزنامه";
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(216, 6);
            // 
            // کاربرگToolStripMenuItem
            // 
            this.کاربرگToolStripMenuItem.Name = "کاربرگToolStripMenuItem";
            this.کاربرگToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.کاربرگToolStripMenuItem.Text = "کاربرگ";
            // 
            // امکاناتToolStripMenuItem
            // 
            this.امکاناتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ماشینحسابToolStripMenuItem});
            this.امکاناتToolStripMenuItem.Name = "امکاناتToolStripMenuItem";
            this.امکاناتToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.امکاناتToolStripMenuItem.Text = "امکانات";
            // 
            // ماشینحسابToolStripMenuItem
            // 
            this.ماشینحسابToolStripMenuItem.Image = global::main1.Properties.Resources.Calculator;
            this.ماشینحسابToolStripMenuItem.Name = "ماشینحسابToolStripMenuItem";
            this.ماشینحسابToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.ماشینحسابToolStripMenuItem.Text = "ماشین حساب";
            // 
            // نمایشToolStripMenuItem
            // 
            this.نمایشToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.اطلاعاتکاربرانفعالToolStripMenuItem,
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem,
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem,
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem,
            this.مشاهدهToolStripMenuItem});
            this.نمایشToolStripMenuItem.Name = "نمایشToolStripMenuItem";
            this.نمایشToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.نمایشToolStripMenuItem.Text = "نمایش";
            // 
            // اطلاعاتکاربرانفعالToolStripMenuItem
            // 
            this.اطلاعاتکاربرانفعالToolStripMenuItem.Checked = true;
            this.اطلاعاتکاربرانفعالToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.اطلاعاتکاربرانفعالToolStripMenuItem.Name = "اطلاعاتکاربرانفعالToolStripMenuItem";
            this.اطلاعاتکاربرانفعالToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.اطلاعاتکاربرانفعالToolStripMenuItem.Text = "مشاهده چک های پرداخت نشده";
            // 
            // اطلاعاتشرکتفروشگاهToolStripMenuItem
            // 
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem.Checked = true;
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem.Name = "اطلاعاتشرکتفروشگاهToolStripMenuItem";
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.اطلاعاتشرکتفروشگاهToolStripMenuItem.Text = "مشاهده چک های وصول نشده";
            // 
            // مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem
            // 
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem.Checked = true;
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem.Name = "مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem";
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem.Text = "مشاهده کالاهای کرایه داده شده ای که برگردانده نشده";
            // 
            // مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem
            // 
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem.Checked = true;
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem.Name = "مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem";
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem.Text = "مشاهده کالاهایی که به حداقل تعداد رسیده اند";
            // 
            // مشاهدهToolStripMenuItem
            // 
            this.مشاهدهToolStripMenuItem.Name = "مشاهدهToolStripMenuItem";
            this.مشاهدهToolStripMenuItem.Size = new System.Drawing.Size(351, 22);
            this.مشاهدهToolStripMenuItem.Text = "مشاهده مشتریانی که اقساط این ماه خود را پرداخت نکرده اند ";
            // 
            // راهنماToolStripMenuItem
            // 
            this.راهنماToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.راهنمایاستفادهToolStripMenuItem,
            this.toolStripSeparator25,
            this.دربارهToolStripMenuItem});
            this.راهنماToolStripMenuItem.Name = "راهنماToolStripMenuItem";
            this.راهنماToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.راهنماToolStripMenuItem.Text = "راهنما";
            // 
            // راهنمایاستفادهToolStripMenuItem
            // 
            this.راهنمایاستفادهToolStripMenuItem.Image = global::main1.Properties.Resources.help_16;
            this.راهنمایاستفادهToolStripMenuItem.Name = "راهنمایاستفادهToolStripMenuItem";
            this.راهنمایاستفادهToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.راهنمایاستفادهToolStripMenuItem.Text = "راهنمای استفاده";
            // 
            // toolStripSeparator25
            // 
            this.toolStripSeparator25.Name = "toolStripSeparator25";
            this.toolStripSeparator25.Size = new System.Drawing.Size(147, 6);
            // 
            // دربارهToolStripMenuItem
            // 
            this.دربارهToolStripMenuItem.Image = global::main1.Properties.Resources.about_32;
            this.دربارهToolStripMenuItem.Name = "دربارهToolStripMenuItem";
            this.دربارهToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.دربارهToolStripMenuItem.Text = "درباره ...";
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 745;
            this.lineShape2.X2 = 745;
            this.lineShape2.Y1 = 136;
            this.lineShape2.Y2 = 825;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(188, 25);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(70, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "شرکت:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(188, 48);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(70, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "سال مالی:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(188, 71);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(70, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "کاربر فعال:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(188, 94);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(70, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "تاریخ:";
            // 
            // lblnamesherkat
            // 
            this.lblnamesherkat.Location = new System.Drawing.Point(26, 25);
            this.lblnamesherkat.Name = "lblnamesherkat";
            this.lblnamesherkat.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblnamesherkat.Size = new System.Drawing.Size(159, 23);
            this.lblnamesherkat.TabIndex = 7;
            this.lblnamesherkat.Text = "شرکت لوازم ساختمانی سپهوند";
            // 
            // lblsalemali
            // 
            this.lblsalemali.Location = new System.Drawing.Point(26, 48);
            this.lblsalemali.Name = "lblsalemali";
            this.lblsalemali.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblsalemali.Size = new System.Drawing.Size(156, 23);
            this.lblsalemali.TabIndex = 8;
            // 
            // lblkarbar
            // 
            this.lblkarbar.Location = new System.Drawing.Point(26, 71);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(156, 23);
            this.lblkarbar.TabIndex = 9;
            // 
            // lbldate
            // 
            this.lbldate.Location = new System.Drawing.Point(26, 94);
            this.lbldate.Name = "lbldate";
            this.lbldate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbldate.Size = new System.Drawing.Size(156, 23);
            this.lbldate.TabIndex = 10;
            // 
            // lbltime
            // 
            this.lbltime.Location = new System.Drawing.Point(26, 139);
            this.lbltime.Name = "lbltime";
            this.lbltime.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbltime.Size = new System.Drawing.Size(156, 23);
            this.lbltime.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(188, 141);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(70, 23);
            this.label10.TabIndex = 11;
            this.label10.Text = "ساعت:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbldate1);
            this.groupBox1.Controls.Add(this.lbltime);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.lbldate);
            this.groupBox1.Controls.Add(this.lblkarbar);
            this.groupBox1.Controls.Add(this.lblsalemali);
            this.groupBox1.Controls.Add(this.lblnamesherkat);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(752, 490);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(274, 173);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "اطلاعات جاری سیستم";
            // 
            // lbldate1
            // 
            this.lbldate1.Location = new System.Drawing.Point(23, 117);
            this.lbldate1.Name = "lbldate1";
            this.lbldate1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbldate1.Size = new System.Drawing.Size(160, 23);
            this.lbldate1.TabIndex = 15;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // ribbonComboBox1
            // 
            this.ribbonComboBox1.AltKey = null;
            this.ribbonComboBox1.Image = null;
            this.ribbonComboBox1.Tag = null;
            this.ribbonComboBox1.Text = "لغغغغغغغغغغ";
            this.ribbonComboBox1.TextBoxText = null;
            this.ribbonComboBox1.ToolTip = null;
            this.ribbonComboBox1.ToolTipImage = null;
            this.ribbonComboBox1.ToolTipTitle = null;
            // 
            // ribbonButtonList1
            // 
            this.ribbonButtonList1.AltKey = null;
            this.ribbonButtonList1.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonList1.FlowToBottom = false;
            this.ribbonButtonList1.Image = null;
            this.ribbonButtonList1.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.ribbonButtonList1.Tag = null;
            this.ribbonButtonList1.Text = null;
            this.ribbonButtonList1.ToolTip = null;
            this.ribbonButtonList1.ToolTipImage = null;
            this.ribbonButtonList1.ToolTipTitle = null;
            // 
            // ribbonButtonList2
            // 
            this.ribbonButtonList2.AltKey = null;
            this.ribbonButtonList2.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonList2.FlowToBottom = false;
            this.ribbonButtonList2.Image = null;
            this.ribbonButtonList2.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.ribbonButtonList2.Tag = null;
            this.ribbonButtonList2.Text = null;
            this.ribbonButtonList2.ToolTip = null;
            this.ribbonButtonList2.ToolTipImage = null;
            this.ribbonButtonList2.ToolTipTitle = null;
            // 
            // ribbonButtonList3
            // 
            this.ribbonButtonList3.AltKey = null;
            this.ribbonButtonList3.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonList3.FlowToBottom = false;
            this.ribbonButtonList3.Image = null;
            this.ribbonButtonList3.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.ribbonButtonList3.Tag = null;
            this.ribbonButtonList3.Text = null;
            this.ribbonButtonList3.ToolTip = null;
            this.ribbonButtonList3.ToolTipImage = null;
            this.ribbonButtonList3.ToolTipTitle = null;
            // 
            // ribbonItemGroup1
            // 
            this.ribbonItemGroup1.AltKey = null;
            this.ribbonItemGroup1.Image = null;
            this.ribbonItemGroup1.Tag = null;
            this.ribbonItemGroup1.Text = null;
            this.ribbonItemGroup1.ToolTip = null;
            this.ribbonItemGroup1.ToolTipImage = null;
            this.ribbonItemGroup1.ToolTipTitle = null;
            // 
            // ribbon1
            // 
            this.ribbon1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbon1.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.Minimized = false;
            this.ribbon1.Name = "ribbon1";
            // 
            // 
            // 
            this.ribbon1.OrbDropDown.BorderRoundness = 8;
            this.ribbon1.OrbDropDown.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.OrbDropDown.Name = "";
            this.ribbon1.OrbDropDown.Size = new System.Drawing.Size(527, 72);
            this.ribbon1.OrbDropDown.TabIndex = 0;
            this.ribbon1.OrbImage = null;
            // 
            // 
            // 
            this.ribbon1.QuickAcessToolbar.AltKey = null;
            this.ribbon1.QuickAcessToolbar.Image = null;
            this.ribbon1.QuickAcessToolbar.Tag = null;
            this.ribbon1.QuickAcessToolbar.Text = null;
            this.ribbon1.QuickAcessToolbar.ToolTip = null;
            this.ribbon1.QuickAcessToolbar.ToolTipImage = null;
            this.ribbon1.QuickAcessToolbar.ToolTipTitle = null;
            this.ribbon1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ribbon1.Size = new System.Drawing.Size(1028, 138);
            this.ribbon1.TabIndex = 0;
            this.ribbon1.Tabs.Add(this.sistemribtab);
            this.ribbon1.Tabs.Add(this.taarifribtab);
            this.ribbon1.Tabs.Add(this.gozareshribtab);
            this.ribbon1.Tabs.Add(this.factorribtab);
            this.ribbon1.Tabs.Add(this.emkanatribtab);
            this.ribbon1.Tabs.Add(this.rahnamaribtab);
            this.ribbon1.TabSpacing = 6;
            this.ribbon1.Text = "ribbon1";
            // 
            // sistemribtab
            // 
            this.sistemribtab.Panels.Add(this.ribbonPanel1);
            this.sistemribtab.Panels.Add(this.ribbonPanel2);
            this.sistemribtab.Tag = null;
            this.sistemribtab.Text = "سیستم";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.Items.Add(this.loginkarbarrib);
            this.ribbonPanel1.Items.Add(this.logoutkarbarrib);
            this.ribbonPanel1.Items.Add(this.exitrib);
            this.ribbonPanel1.Tag = null;
            this.ribbonPanel1.Text = "";
            // 
            // loginkarbarrib
            // 
            this.loginkarbarrib.AltKey = null;
            this.loginkarbarrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.loginkarbarrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.loginkarbarrib.Image = global::main1.Properties.Resources.A_Login;
            this.loginkarbarrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("loginkarbarrib.SmallImage")));
            this.loginkarbarrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.loginkarbarrib.Tag = null;
            this.loginkarbarrib.Text = "ورود-کاربر";
            this.loginkarbarrib.ToolTip = null;
            this.loginkarbarrib.ToolTipImage = null;
            this.loginkarbarrib.ToolTipTitle = null;
            this.loginkarbarrib.Click += new System.EventHandler(this.loginkarbarrib_Click_1);
            // 
            // logoutkarbarrib
            // 
            this.logoutkarbarrib.AltKey = null;
            this.logoutkarbarrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.logoutkarbarrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.logoutkarbarrib.Image = global::main1.Properties.Resources.A_Logout;
            this.logoutkarbarrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("logoutkarbarrib.SmallImage")));
            this.logoutkarbarrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.logoutkarbarrib.Tag = null;
            this.logoutkarbarrib.Text = "خروج-کاربر";
            this.logoutkarbarrib.ToolTip = null;
            this.logoutkarbarrib.ToolTipImage = null;
            this.logoutkarbarrib.ToolTipTitle = null;
            this.logoutkarbarrib.Click += new System.EventHandler(this.logoutkarbarrib_Click);
            // 
            // exitrib
            // 
            this.exitrib.AltKey = null;
            this.exitrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.exitrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.exitrib.Image = global::main1.Properties.Resources.Cancel_Big;
            this.exitrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("exitrib.SmallImage")));
            this.exitrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.exitrib.Tag = null;
            this.exitrib.Text = "خروج";
            this.exitrib.ToolTip = null;
            this.exitrib.ToolTipImage = null;
            this.exitrib.ToolTipTitle = null;
            this.exitrib.Click += new System.EventHandler(this.exitrib_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.Items.Add(this.shutdownrib);
            this.ribbonPanel2.Items.Add(this.rebootrib);
            this.ribbonPanel2.Items.Add(this.logoffrib);
            this.ribbonPanel2.Tag = null;
            this.ribbonPanel2.Text = "";
            // 
            // shutdownrib
            // 
            this.shutdownrib.AltKey = null;
            this.shutdownrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.shutdownrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.shutdownrib.Image = global::main1.Properties.Resources.Shutdown;
            this.shutdownrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("shutdownrib.SmallImage")));
            this.shutdownrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.shutdownrib.Tag = null;
            this.shutdownrib.Text = "ShutDown";
            this.shutdownrib.ToolTip = null;
            this.shutdownrib.ToolTipImage = null;
            this.shutdownrib.ToolTipTitle = null;
            this.shutdownrib.Click += new System.EventHandler(this.shutdownrib_Click);
            // 
            // rebootrib
            // 
            this.rebootrib.AltKey = null;
            this.rebootrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.rebootrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.rebootrib.Image = global::main1.Properties.Resources.Restart;
            this.rebootrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("rebootrib.SmallImage")));
            this.rebootrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.rebootrib.Tag = null;
            this.rebootrib.Text = "Reboot";
            this.rebootrib.ToolTip = null;
            this.rebootrib.ToolTipImage = null;
            this.rebootrib.ToolTipTitle = null;
            this.rebootrib.Click += new System.EventHandler(this.restartrib_Click);
            // 
            // logoffrib
            // 
            this.logoffrib.AltKey = null;
            this.logoffrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.logoffrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.logoffrib.Image = global::main1.Properties.Resources.LogOff;
            this.logoffrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("logoffrib.SmallImage")));
            this.logoffrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.logoffrib.Tag = null;
            this.logoffrib.Text = "LogOff";
            this.logoffrib.ToolTip = null;
            this.logoffrib.ToolTipImage = null;
            this.logoffrib.ToolTipTitle = null;
            this.logoffrib.Click += new System.EventHandler(this.logoffrib_Click);
            // 
            // taarifribtab
            // 
            this.taarifribtab.Panels.Add(this.ribbonPanel3);
            this.taarifribtab.Panels.Add(this.ribbonPanel4);
            this.taarifribtab.Panels.Add(this.ribbonPanel5);
            this.taarifribtab.Panels.Add(this.ribbonPanel6);
            this.taarifribtab.Panels.Add(this.taraconeshtabrib);
            this.taarifribtab.Tag = null;
            this.taarifribtab.Text = "تعاریف پایه";
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.Items.Add(this.kalakerayerib);
            this.ribbonPanel3.Items.Add(this.kalakharidforoshrib);
            this.ribbonPanel3.Tag = null;
            this.ribbonPanel3.Text = "کالاها";
            // 
            // kalakerayerib
            // 
            this.kalakerayerib.AltKey = null;
            this.kalakerayerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.kalakerayerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.kalakerayerib.Image = global::main1.Properties.Resources.installer_box;
            this.kalakerayerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("kalakerayerib.SmallImage")));
            this.kalakerayerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.kalakerayerib.Tag = null;
            this.kalakerayerib.Text = "کالای-کرایه";
            this.kalakerayerib.ToolTip = null;
            this.kalakerayerib.ToolTipImage = null;
            this.kalakerayerib.ToolTipTitle = null;
            this.kalakerayerib.Click += new System.EventHandler(this.kalakerayerib_Click);
            // 
            // kalakharidforoshrib
            // 
            this.kalakharidforoshrib.AltKey = null;
            this.kalakharidforoshrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.kalakharidforoshrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.kalakharidforoshrib.Image = global::main1.Properties.Resources.applications;
            this.kalakharidforoshrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("kalakharidforoshrib.SmallImage")));
            this.kalakharidforoshrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.kalakharidforoshrib.Tag = null;
            this.kalakharidforoshrib.Text = "کالای-خرید-فروش";
            this.kalakharidforoshrib.ToolTip = null;
            this.kalakharidforoshrib.ToolTipImage = null;
            this.kalakharidforoshrib.ToolTipTitle = null;
            this.kalakharidforoshrib.Click += new System.EventHandler(this.kalakharidforoshrib_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.Items.Add(this.moshtaririb);
            this.ribbonPanel4.Items.Add(this.hesabbankirib);
            this.ribbonPanel4.Items.Add(this.karbarrib);
            this.ribbonPanel4.Tag = null;
            this.ribbonPanel4.Text = "";
            // 
            // moshtaririb
            // 
            this.moshtaririb.AltKey = null;
            this.moshtaririb.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.moshtaririb.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.moshtaririb.Image = global::main1.Properties.Resources.image2;
            this.moshtaririb.SmallImage = ((System.Drawing.Image)(resources.GetObject("moshtaririb.SmallImage")));
            this.moshtaririb.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.moshtaririb.Tag = null;
            this.moshtaririb.Text = "مشتری/فروشندگان";
            this.moshtaririb.ToolTip = null;
            this.moshtaririb.ToolTipImage = null;
            this.moshtaririb.ToolTipTitle = null;
            this.moshtaririb.Click += new System.EventHandler(this.moshtaririb_Click);
            // 
            // hesabbankirib
            // 
            this.hesabbankirib.AltKey = null;
            this.hesabbankirib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.hesabbankirib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.hesabbankirib.Image = global::main1.Properties.Resources._20111006074133265_easyicon_cn_32;
            this.hesabbankirib.SmallImage = ((System.Drawing.Image)(resources.GetObject("hesabbankirib.SmallImage")));
            this.hesabbankirib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.hesabbankirib.Tag = null;
            this.hesabbankirib.Text = "حساب-بانکی";
            this.hesabbankirib.ToolTip = null;
            this.hesabbankirib.ToolTipImage = null;
            this.hesabbankirib.ToolTipTitle = null;
            this.hesabbankirib.Click += new System.EventHandler(this.hesabbankirib_Click);
            // 
            // karbarrib
            // 
            this.karbarrib.AltKey = null;
            this.karbarrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.karbarrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.karbarrib.Image = global::main1.Properties.Resources.user1;
            this.karbarrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("karbarrib.SmallImage")));
            this.karbarrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.karbarrib.Tag = null;
            this.karbarrib.Text = "کاربران";
            this.karbarrib.ToolTip = null;
            this.karbarrib.ToolTipImage = null;
            this.karbarrib.ToolTipTitle = null;
            this.karbarrib.Click += new System.EventHandler(this.karbarrib_Click);
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.Items.Add(this.sanadhesabdaririb);
            this.ribbonPanel5.Items.Add(this.roidadegheiremalirib);
            this.ribbonPanel5.Items.Add(this.hesabrib);
            this.ribbonPanel5.Tag = null;
            this.ribbonPanel5.Text = "اسناد حسابداری";
            // 
            // sanadhesabdaririb
            // 
            this.sanadhesabdaririb.AltKey = null;
            this.sanadhesabdaririb.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.sanadhesabdaririb.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.sanadhesabdaririb.Image = global::main1.Properties.Resources.viewstack;
            this.sanadhesabdaririb.SmallImage = ((System.Drawing.Image)(resources.GetObject("sanadhesabdaririb.SmallImage")));
            this.sanadhesabdaririb.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.sanadhesabdaririb.Tag = null;
            this.sanadhesabdaririb.Text = "اسناد-حسابداری-مالی";
            this.sanadhesabdaririb.ToolTip = null;
            this.sanadhesabdaririb.ToolTipImage = null;
            this.sanadhesabdaririb.ToolTipTitle = null;
            this.sanadhesabdaririb.Click += new System.EventHandler(this.sanadhesabdaririb_Click);
            // 
            // roidadegheiremalirib
            // 
            this.roidadegheiremalirib.AltKey = null;
            this.roidadegheiremalirib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.roidadegheiremalirib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.roidadegheiremalirib.Image = global::main1.Properties.Resources.resources;
            this.roidadegheiremalirib.SmallImage = ((System.Drawing.Image)(resources.GetObject("roidadegheiremalirib.SmallImage")));
            this.roidadegheiremalirib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.roidadegheiremalirib.Tag = null;
            this.roidadegheiremalirib.Text = "اسناد-حسابداری-غیر-مالی";
            this.roidadegheiremalirib.ToolTip = null;
            this.roidadegheiremalirib.ToolTipImage = null;
            this.roidadegheiremalirib.ToolTipTitle = null;
            this.roidadegheiremalirib.Click += new System.EventHandler(this.roidadegheiremalirib_Click);
            // 
            // hesabrib
            // 
            this.hesabrib.AltKey = null;
            this.hesabrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.hesabrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.hesabrib.Image = global::main1.Properties.Resources.script;
            this.hesabrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("hesabrib.SmallImage")));
            this.hesabrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.hesabrib.Tag = null;
            this.hesabrib.Text = "حساب";
            this.hesabrib.ToolTip = null;
            this.hesabrib.ToolTipImage = null;
            this.hesabrib.ToolTipTitle = null;
            this.hesabrib.Click += new System.EventHandler(this.hesabrib_Click);
            // 
            // ribbonPanel6
            // 
            this.ribbonPanel6.Items.Add(this.groupkalarib);
            this.ribbonPanel6.Tag = null;
            this.ribbonPanel6.Text = "گروه";
            // 
            // groupkalarib
            // 
            this.groupkalarib.AltKey = null;
            this.groupkalarib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.groupkalarib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.groupkalarib.Image = global::main1.Properties.Resources.installer_box1;
            this.groupkalarib.SmallImage = ((System.Drawing.Image)(resources.GetObject("groupkalarib.SmallImage")));
            this.groupkalarib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.groupkalarib.Tag = null;
            this.groupkalarib.Text = "گروه-کالا";
            this.groupkalarib.ToolTip = null;
            this.groupkalarib.ToolTipImage = null;
            this.groupkalarib.ToolTipTitle = null;
            this.groupkalarib.Click += new System.EventHandler(this.groupkalarib_Click);
            // 
            // taraconeshtabrib
            // 
            this.taraconeshtabrib.Items.Add(this.checkrib);
            this.taraconeshtabrib.Items.Add(this.havalerib);
            this.taraconeshtabrib.Items.Add(this.ghestyrib);
            this.taraconeshtabrib.Items.Add(this.naghdrib);
            this.taraconeshtabrib.Tag = null;
            this.taraconeshtabrib.Text = "تراکنش ها";
            // 
            // checkrib
            // 
            this.checkrib.AltKey = null;
            this.checkrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.checkrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.checkrib.Image = ((System.Drawing.Image)(resources.GetObject("checkrib.Image")));
            this.checkrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("checkrib.SmallImage")));
            this.checkrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.checkrib.Tag = null;
            this.checkrib.Text = "چک";
            this.checkrib.ToolTip = null;
            this.checkrib.ToolTipImage = null;
            this.checkrib.ToolTipTitle = null;
            this.checkrib.Click += new System.EventHandler(this.checkrib_Click);
            // 
            // havalerib
            // 
            this.havalerib.AltKey = null;
            this.havalerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.havalerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.havalerib.Image = ((System.Drawing.Image)(resources.GetObject("havalerib.Image")));
            this.havalerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("havalerib.SmallImage")));
            this.havalerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.havalerib.Tag = null;
            this.havalerib.Text = "حواله";
            this.havalerib.ToolTip = null;
            this.havalerib.ToolTipImage = null;
            this.havalerib.ToolTipTitle = null;
            this.havalerib.Click += new System.EventHandler(this.havalerib_Click);
            // 
            // ghestyrib
            // 
            this.ghestyrib.AltKey = null;
            this.ghestyrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ghestyrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ghestyrib.Image = global::main1.Properties.Resources.coins_in_hand1;
            this.ghestyrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("ghestyrib.SmallImage")));
            this.ghestyrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ghestyrib.Tag = null;
            this.ghestyrib.Text = "قسطی";
            this.ghestyrib.ToolTip = null;
            this.ghestyrib.ToolTipImage = null;
            this.ghestyrib.ToolTipTitle = null;
            this.ghestyrib.Click += new System.EventHandler(this.ghestyrib_Click);
            // 
            // naghdrib
            // 
            this.naghdrib.AltKey = null;
            this.naghdrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.naghdrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.naghdrib.Image = global::main1.Properties.Resources.money1;
            this.naghdrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("naghdrib.SmallImage")));
            this.naghdrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.naghdrib.Tag = null;
            this.naghdrib.Text = "نقد";
            this.naghdrib.ToolTip = null;
            this.naghdrib.ToolTipImage = null;
            this.naghdrib.ToolTipTitle = null;
            this.naghdrib.Click += new System.EventHandler(this.naghdrib_Click);
            // 
            // gozareshribtab
            // 
            this.gozareshribtab.Panels.Add(this.ribbonPanel10);
            this.gozareshribtab.Panels.Add(this.ribbonPanel11);
            this.gozareshribtab.Panels.Add(this.ribbonPanel13);
            this.gozareshribtab.Tag = null;
            this.gozareshribtab.Text = "گزارشات";
            // 
            // ribbonPanel10
            // 
            this.ribbonPanel10.Items.Add(this.taraznamerib);
            this.ribbonPanel10.Items.Add(this.tarazazmayeshirib);
            this.ribbonPanel10.Tag = null;
            this.ribbonPanel10.Text = "تراز های آزمایشی";
            // 
            // taraznamerib
            // 
            this.taraznamerib.AltKey = null;
            this.taraznamerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.taraznamerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.taraznamerib.Image = global::main1.Properties.Resources.document_index;
            this.taraznamerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("taraznamerib.SmallImage")));
            this.taraznamerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.taraznamerib.Tag = null;
            this.taraznamerib.Text = "ترازنامه";
            this.taraznamerib.ToolTip = null;
            this.taraznamerib.ToolTipImage = null;
            this.taraznamerib.ToolTipTitle = null;
            this.taraznamerib.Click += new System.EventHandler(this.taraznamerib_Click);
            // 
            // tarazazmayeshirib
            // 
            this.tarazazmayeshirib.AltKey = null;
            this.tarazazmayeshirib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.tarazazmayeshirib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.tarazazmayeshirib.Image = global::main1.Properties.Resources.report1;
            this.tarazazmayeshirib.SmallImage = ((System.Drawing.Image)(resources.GetObject("tarazazmayeshirib.SmallImage")));
            this.tarazazmayeshirib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.tarazazmayeshirib.Tag = null;
            this.tarazazmayeshirib.Text = "تراز-آزمایشی";
            this.tarazazmayeshirib.ToolTip = null;
            this.tarazazmayeshirib.ToolTipImage = null;
            this.tarazazmayeshirib.ToolTipTitle = null;
            this.tarazazmayeshirib.Click += new System.EventHandler(this.tarazazmayeshirib_Click);
            // 
            // ribbonPanel11
            // 
            this.ribbonPanel11.Items.Add(this.soratsarmayerib);
            this.ribbonPanel11.Items.Add(this.sorathoghoghsahebrib);
            this.ribbonPanel11.Items.Add(this.soratsodziyanrib);
            this.ribbonPanel11.Tag = null;
            this.ribbonPanel11.Text = "صورتحساب ها";
            // 
            // soratsarmayerib
            // 
            this.soratsarmayerib.AltKey = null;
            this.soratsarmayerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.soratsarmayerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.soratsarmayerib.DropDownItems.Add(this.ribbonButtonList4);
            this.soratsarmayerib.Image = global::main1.Properties.Resources.align_right;
            this.soratsarmayerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("soratsarmayerib.SmallImage")));
            this.soratsarmayerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.soratsarmayerib.Tag = null;
            this.soratsarmayerib.Text = "صورت-تغییرات-سرمایه";
            this.soratsarmayerib.ToolTip = null;
            this.soratsarmayerib.ToolTipImage = null;
            this.soratsarmayerib.ToolTipTitle = null;
            this.soratsarmayerib.Click += new System.EventHandler(this.soratsarmayerib_Click);
            // 
            // ribbonButtonList4
            // 
            this.ribbonButtonList4.AltKey = null;
            this.ribbonButtonList4.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonList4.FlowToBottom = false;
            this.ribbonButtonList4.Image = null;
            this.ribbonButtonList4.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.ribbonButtonList4.Tag = null;
            this.ribbonButtonList4.Text = "ribbonButtonList4";
            this.ribbonButtonList4.ToolTip = null;
            this.ribbonButtonList4.ToolTipImage = null;
            this.ribbonButtonList4.ToolTipTitle = null;
            // 
            // sorathoghoghsahebrib
            // 
            this.sorathoghoghsahebrib.AltKey = null;
            this.sorathoghoghsahebrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.sorathoghoghsahebrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.sorathoghoghsahebrib.Image = global::main1.Properties.Resources.text_signature1;
            this.sorathoghoghsahebrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("sorathoghoghsahebrib.SmallImage")));
            this.sorathoghoghsahebrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.sorathoghoghsahebrib.Tag = null;
            this.sorathoghoghsahebrib.Text = "صورتحساب-سود-زیان بازرگانی ";
            this.sorathoghoghsahebrib.ToolTip = null;
            this.sorathoghoghsahebrib.ToolTipImage = null;
            this.sorathoghoghsahebrib.ToolTipTitle = null;
            this.sorathoghoghsahebrib.Click += new System.EventHandler(this.sorathoghoghsahebrib_Click);
            // 
            // soratsodziyanrib
            // 
            this.soratsodziyanrib.AltKey = null;
            this.soratsodziyanrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.soratsodziyanrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.soratsodziyanrib.Image = global::main1.Properties.Resources.text_signature;
            this.soratsodziyanrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("soratsodziyanrib.SmallImage")));
            this.soratsodziyanrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.soratsodziyanrib.Tag = null;
            this.soratsodziyanrib.Text = "صورتحساب-سود-زیان خدماتی";
            this.soratsodziyanrib.ToolTip = null;
            this.soratsodziyanrib.ToolTipImage = null;
            this.soratsodziyanrib.ToolTipTitle = null;
            this.soratsodziyanrib.Click += new System.EventHandler(this.soratsodziyanrib_Click);
            // 
            // ribbonPanel13
            // 
            this.ribbonPanel13.Items.Add(this.mandekolrib);
            this.ribbonPanel13.Items.Add(this.dafatreroznamerib);
            this.ribbonPanel13.Tag = null;
            this.ribbonPanel13.Text = "گزارش";
            // 
            // mandekolrib
            // 
            this.mandekolrib.AltKey = null;
            this.mandekolrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.mandekolrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.mandekolrib.Image = global::main1.Properties.Resources.book_spelling;
            this.mandekolrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("mandekolrib.SmallImage")));
            this.mandekolrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.mandekolrib.Tag = null;
            this.mandekolrib.Text = "مانده-حساب-دفترکل";
            this.mandekolrib.ToolTip = null;
            this.mandekolrib.ToolTipImage = null;
            this.mandekolrib.ToolTipTitle = null;
            this.mandekolrib.Click += new System.EventHandler(this.mandekolrib_Click);
            // 
            // dafatreroznamerib
            // 
            this.dafatreroznamerib.AltKey = null;
            this.dafatreroznamerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.dafatreroznamerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.dafatreroznamerib.Image = global::main1.Properties.Resources.bookmark;
            this.dafatreroznamerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("dafatreroznamerib.SmallImage")));
            this.dafatreroznamerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.dafatreroznamerib.Tag = null;
            this.dafatreroznamerib.Text = "دفتر-روزنامه";
            this.dafatreroznamerib.ToolTip = null;
            this.dafatreroznamerib.ToolTipImage = null;
            this.dafatreroznamerib.ToolTipTitle = null;
            this.dafatreroznamerib.Click += new System.EventHandler(this.dafatreroznamerib_Click);
            // 
            // factorribtab
            // 
            this.factorribtab.Panels.Add(this.ribbonPanel8);
            this.factorribtab.Tag = null;
            this.factorribtab.Text = "فاکتورها";
            // 
            // ribbonPanel8
            // 
            this.ribbonPanel8.Items.Add(this.factorkharidrib);
            this.ribbonPanel8.Items.Add(this.factorforoshrib);
            this.ribbonPanel8.Items.Add(this.factorkerayerib);
            this.ribbonPanel8.Tag = null;
            this.ribbonPanel8.Text = "";
            // 
            // factorkharidrib
            // 
            this.factorkharidrib.AltKey = null;
            this.factorkharidrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.factorkharidrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.factorkharidrib.Image = global::main1.Properties.Resources.factorKharid;
            this.factorkharidrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("factorkharidrib.SmallImage")));
            this.factorkharidrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.factorkharidrib.Tag = null;
            this.factorkharidrib.Text = "فاکتور-خرید";
            this.factorkharidrib.ToolTip = null;
            this.factorkharidrib.ToolTipImage = null;
            this.factorkharidrib.ToolTipTitle = null;
            this.factorkharidrib.Click += new System.EventHandler(this.factorkharidrib_Click);
            // 
            // factorforoshrib
            // 
            this.factorforoshrib.AltKey = null;
            this.factorforoshrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.factorforoshrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.factorforoshrib.Image = global::main1.Properties.Resources.factorForosh;
            this.factorforoshrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("factorforoshrib.SmallImage")));
            this.factorforoshrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.factorforoshrib.Tag = null;
            this.factorforoshrib.Text = "فاکتور-فروش";
            this.factorforoshrib.ToolTip = null;
            this.factorforoshrib.ToolTipImage = null;
            this.factorforoshrib.ToolTipTitle = null;
            this.factorforoshrib.Click += new System.EventHandler(this.factorforoshrib_Click);
            // 
            // factorkerayerib
            // 
            this.factorkerayerib.AltKey = null;
            this.factorkerayerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.factorkerayerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.factorkerayerib.Image = global::main1.Properties.Resources.document_prepare;
            this.factorkerayerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("factorkerayerib.SmallImage")));
            this.factorkerayerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.factorkerayerib.Tag = null;
            this.factorkerayerib.Text = "فاکتور-کرایه";
            this.factorkerayerib.ToolTip = null;
            this.factorkerayerib.ToolTipImage = null;
            this.factorkerayerib.ToolTipTitle = null;
            this.factorkerayerib.Click += new System.EventHandler(this.factorkerayerib_Click);
            // 
            // emkanatribtab
            // 
            this.emkanatribtab.Panels.Add(this.ribbonPanel19);
            this.emkanatribtab.Panels.Add(this.ribbonPanel7);
            this.emkanatribtab.Panels.Add(this.ribbonPanel9);
            this.emkanatribtab.Tag = null;
            this.emkanatribtab.Text = "امکانات";
            // 
            // ribbonPanel19
            // 
            this.ribbonPanel19.Items.Add(this.mashinhesabrib);
            this.ribbonPanel19.Tag = null;
            this.ribbonPanel19.Text = "";
            // 
            // mashinhesabrib
            // 
            this.mashinhesabrib.AltKey = null;
            this.mashinhesabrib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.mashinhesabrib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.mashinhesabrib.Image = global::main1.Properties.Resources.Calculator1;
            this.mashinhesabrib.SmallImage = ((System.Drawing.Image)(resources.GetObject("mashinhesabrib.SmallImage")));
            this.mashinhesabrib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.mashinhesabrib.Tag = null;
            this.mashinhesabrib.Text = "ماشین-حساب";
            this.mashinhesabrib.ToolTip = null;
            this.mashinhesabrib.ToolTipImage = null;
            this.mashinhesabrib.ToolTipTitle = null;
            this.mashinhesabrib.Click += new System.EventHandler(this.mashinhesabrib_Click);
            // 
            // ribbonPanel7
            // 
            this.ribbonPanel7.Items.Add(this.ribbonButton20);
            this.ribbonPanel7.Tag = null;
            this.ribbonPanel7.Text = "";
            // 
            // ribbonButton20
            // 
            this.ribbonButton20.AltKey = null;
            this.ribbonButton20.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton20.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton20.Image = global::main1.Properties.Resources.keyboard1;
            this.ribbonButton20.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton20.SmallImage")));
            this.ribbonButton20.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton20.Tag = null;
            this.ribbonButton20.Text = "صفحه-کلید";
            this.ribbonButton20.ToolTip = null;
            this.ribbonButton20.ToolTipImage = null;
            this.ribbonButton20.ToolTipTitle = null;
            this.ribbonButton20.Click += new System.EventHandler(this.ribbonButton20_Click);
            // 
            // ribbonPanel9
            // 
            this.ribbonPanel9.Items.Add(this.ribbonButton21);
            this.ribbonPanel9.Tag = null;
            this.ribbonPanel9.Text = "";
            // 
            // ribbonButton21
            // 
            this.ribbonButton21.AltKey = null;
            this.ribbonButton21.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton21.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton21.Image = global::main1.Properties.Resources.coins;
            this.ribbonButton21.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton21.SmallImage")));
            this.ribbonButton21.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton21.Tag = null;
            this.ribbonButton21.Text = "مانده-حساب-بانکی";
            this.ribbonButton21.ToolTip = null;
            this.ribbonButton21.ToolTipImage = null;
            this.ribbonButton21.ToolTipTitle = null;
            this.ribbonButton21.Click += new System.EventHandler(this.ribbonButton21_Click);
            // 
            // rahnamaribtab
            // 
            this.rahnamaribtab.Panels.Add(this.ribbonPanel22);
            this.rahnamaribtab.Panels.Add(this.ribbonPanel23);
            this.rahnamaribtab.Tag = null;
            this.rahnamaribtab.Text = "راهنما";
            // 
            // ribbonPanel22
            // 
            this.ribbonPanel22.Items.Add(this.rahnamarib);
            this.ribbonPanel22.Tag = null;
            this.ribbonPanel22.Text = "";
            // 
            // rahnamarib
            // 
            this.rahnamarib.AltKey = null;
            this.rahnamarib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.rahnamarib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.rahnamarib.Image = global::main1.Properties.Resources.help_32;
            this.rahnamarib.SmallImage = ((System.Drawing.Image)(resources.GetObject("rahnamarib.SmallImage")));
            this.rahnamarib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.rahnamarib.Tag = null;
            this.rahnamarib.Text = "راهنمای-برنامه";
            this.rahnamarib.ToolTip = null;
            this.rahnamarib.ToolTipImage = null;
            this.rahnamarib.ToolTipTitle = null;
            // 
            // ribbonPanel23
            // 
            this.ribbonPanel23.Items.Add(this.darbarerib);
            this.ribbonPanel23.Tag = null;
            this.ribbonPanel23.Text = "";
            // 
            // darbarerib
            // 
            this.darbarerib.AltKey = null;
            this.darbarerib.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.darbarerib.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.darbarerib.Image = global::main1.Properties.Resources.about_321;
            this.darbarerib.SmallImage = ((System.Drawing.Image)(resources.GetObject("darbarerib.SmallImage")));
            this.darbarerib.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.darbarerib.Tag = null;
            this.darbarerib.Text = "...درباره";
            this.darbarerib.ToolTip = null;
            this.darbarerib.ToolTipImage = null;
            this.darbarerib.ToolTipTitle = null;
            // 
            // ribbonTextBox1
            // 
            this.ribbonTextBox1.AltKey = null;
            this.ribbonTextBox1.Image = null;
            this.ribbonTextBox1.Tag = null;
            this.ribbonTextBox1.Text = null;
            this.ribbonTextBox1.TextBoxText = null;
            this.ribbonTextBox1.ToolTip = null;
            this.ribbonTextBox1.ToolTipImage = null;
            this.ribbonTextBox1.ToolTipTitle = null;
            // 
            // ribbonComboBox2
            // 
            this.ribbonComboBox2.AltKey = null;
            this.ribbonComboBox2.Image = null;
            this.ribbonComboBox2.Tag = null;
            this.ribbonComboBox2.Text = null;
            this.ribbonComboBox2.TextBoxText = null;
            this.ribbonComboBox2.ToolTip = null;
            this.ribbonComboBox2.ToolTipImage = null;
            this.ribbonComboBox2.ToolTipTitle = null;
            // 
            // ribbonTab1
            // 
            this.ribbonTab1.Panels.Add(this.ribbonPanel24);
            this.ribbonTab1.Panels.Add(this.ribbonPanel25);
            this.ribbonTab1.Panels.Add(this.ribbonPanel26);
            this.ribbonTab1.Panels.Add(this.ribbonPanel27);
            this.ribbonTab1.Panels.Add(this.ribbonPanel28);
            this.ribbonTab1.Panels.Add(this.ribbonPanel29);
            this.ribbonTab1.Panels.Add(this.ribbonPanel30);
            this.ribbonTab1.Panels.Add(this.ribbonPanel31);
            this.ribbonTab1.Panels.Add(this.ribbonPanel32);
            this.ribbonTab1.Panels.Add(this.ribbonPanel33);
            this.ribbonTab1.Tag = null;
            this.ribbonTab1.Text = "ribbonTab1";
            // 
            // ribbonPanel24
            // 
            this.ribbonPanel24.Items.Add(this.ribbonButton1);
            this.ribbonPanel24.Tag = null;
            this.ribbonPanel24.Text = "ribbonPanel24";
            // 
            // ribbonButton1
            // 
            this.ribbonButton1.AltKey = null;
            this.ribbonButton1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton1.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.SmallImage")));
            this.ribbonButton1.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton1.Tag = null;
            this.ribbonButton1.Text = "ribbonButton1";
            this.ribbonButton1.ToolTip = null;
            this.ribbonButton1.ToolTipImage = null;
            this.ribbonButton1.ToolTipTitle = null;
            // 
            // ribbonPanel25
            // 
            this.ribbonPanel25.Items.Add(this.ribbonButton2);
            this.ribbonPanel25.Tag = null;
            this.ribbonPanel25.Text = "ribbonPanel25";
            // 
            // ribbonButton2
            // 
            this.ribbonButton2.AltKey = null;
            this.ribbonButton2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton2.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.SmallImage")));
            this.ribbonButton2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton2.Tag = null;
            this.ribbonButton2.Text = "ribbonButton2";
            this.ribbonButton2.ToolTip = null;
            this.ribbonButton2.ToolTipImage = null;
            this.ribbonButton2.ToolTipTitle = null;
            // 
            // ribbonPanel26
            // 
            this.ribbonPanel26.Items.Add(this.ribbonButton3);
            this.ribbonPanel26.Tag = null;
            this.ribbonPanel26.Text = "ribbonPanel26";
            // 
            // ribbonButton3
            // 
            this.ribbonButton3.AltKey = null;
            this.ribbonButton3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton3.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton3.SmallImage")));
            this.ribbonButton3.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton3.Tag = null;
            this.ribbonButton3.Text = "ribbonButton3";
            this.ribbonButton3.ToolTip = null;
            this.ribbonButton3.ToolTipImage = null;
            this.ribbonButton3.ToolTipTitle = null;
            // 
            // ribbonPanel27
            // 
            this.ribbonPanel27.Items.Add(this.ribbonButton8);
            this.ribbonPanel27.Tag = null;
            this.ribbonPanel27.Text = "ribbonPanel27";
            // 
            // ribbonButton8
            // 
            this.ribbonButton8.AltKey = null;
            this.ribbonButton8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton8.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton8.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton8.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton8.SmallImage")));
            this.ribbonButton8.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton8.Tag = null;
            this.ribbonButton8.Text = "ribbonButton8";
            this.ribbonButton8.ToolTip = null;
            this.ribbonButton8.ToolTipImage = null;
            this.ribbonButton8.ToolTipTitle = null;
            // 
            // ribbonPanel28
            // 
            this.ribbonPanel28.Items.Add(this.ribbonButton9);
            this.ribbonPanel28.Tag = null;
            this.ribbonPanel28.Text = "ribbonPanel28";
            // 
            // ribbonButton9
            // 
            this.ribbonButton9.AltKey = null;
            this.ribbonButton9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton9.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton9.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton9.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton9.SmallImage")));
            this.ribbonButton9.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton9.Tag = null;
            this.ribbonButton9.Text = "ribbonButton9";
            this.ribbonButton9.ToolTip = null;
            this.ribbonButton9.ToolTipImage = null;
            this.ribbonButton9.ToolTipTitle = null;
            // 
            // ribbonPanel29
            // 
            this.ribbonPanel29.Items.Add(this.ribbonButton11);
            this.ribbonPanel29.Tag = null;
            this.ribbonPanel29.Text = "ribbonPanel29";
            // 
            // ribbonButton11
            // 
            this.ribbonButton11.AltKey = null;
            this.ribbonButton11.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton11.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton11.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton11.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton11.SmallImage")));
            this.ribbonButton11.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton11.Tag = null;
            this.ribbonButton11.Text = "ribbonButton11";
            this.ribbonButton11.ToolTip = null;
            this.ribbonButton11.ToolTipImage = null;
            this.ribbonButton11.ToolTipTitle = null;
            // 
            // ribbonPanel30
            // 
            this.ribbonPanel30.Items.Add(this.ribbonButton13);
            this.ribbonPanel30.Tag = null;
            this.ribbonPanel30.Text = "ribbonPanel30";
            // 
            // ribbonButton13
            // 
            this.ribbonButton13.AltKey = null;
            this.ribbonButton13.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton13.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton13.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton13.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton13.SmallImage")));
            this.ribbonButton13.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton13.Tag = null;
            this.ribbonButton13.Text = "ribbonButton13";
            this.ribbonButton13.ToolTip = null;
            this.ribbonButton13.ToolTipImage = null;
            this.ribbonButton13.ToolTipTitle = null;
            // 
            // ribbonPanel31
            // 
            this.ribbonPanel31.Items.Add(this.ribbonButton15);
            this.ribbonPanel31.Tag = null;
            this.ribbonPanel31.Text = "ribbonPanel31";
            // 
            // ribbonButton15
            // 
            this.ribbonButton15.AltKey = null;
            this.ribbonButton15.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton15.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton15.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton15.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton15.SmallImage")));
            this.ribbonButton15.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton15.Tag = null;
            this.ribbonButton15.Text = "ribbonButton15";
            this.ribbonButton15.ToolTip = null;
            this.ribbonButton15.ToolTipImage = null;
            this.ribbonButton15.ToolTipTitle = null;
            // 
            // ribbonPanel32
            // 
            this.ribbonPanel32.Items.Add(this.ribbonButton17);
            this.ribbonPanel32.Tag = null;
            this.ribbonPanel32.Text = "ribbonPanel32";
            // 
            // ribbonButton17
            // 
            this.ribbonButton17.AltKey = null;
            this.ribbonButton17.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton17.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton17.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton17.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton17.SmallImage")));
            this.ribbonButton17.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton17.Tag = null;
            this.ribbonButton17.Text = "ribbonButton17";
            this.ribbonButton17.ToolTip = null;
            this.ribbonButton17.ToolTipImage = null;
            this.ribbonButton17.ToolTipTitle = null;
            // 
            // ribbonPanel33
            // 
            this.ribbonPanel33.Items.Add(this.ribbonButton18);
            this.ribbonPanel33.Items.Add(this.ribbonButton19);
            this.ribbonPanel33.Tag = null;
            this.ribbonPanel33.Text = "ribbonPanel33";
            // 
            // ribbonButton18
            // 
            this.ribbonButton18.AltKey = null;
            this.ribbonButton18.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton18.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton18.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton18.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.SmallImage")));
            this.ribbonButton18.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton18.Tag = null;
            this.ribbonButton18.Text = "ribbonButton18";
            this.ribbonButton18.ToolTip = null;
            this.ribbonButton18.ToolTipImage = null;
            this.ribbonButton18.ToolTipTitle = null;
            // 
            // ribbonButton19
            // 
            this.ribbonButton19.AltKey = null;
            this.ribbonButton19.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton19.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton19.Image = global::main1.Properties.Resources.A_Login;
            this.ribbonButton19.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton19.SmallImage")));
            this.ribbonButton19.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton19.Tag = null;
            this.ribbonButton19.Text = "ribbonButton19";
            this.ribbonButton19.ToolTip = null;
            this.ribbonButton19.ToolTipImage = null;
            this.ribbonButton19.ToolTipTitle = null;
            // 
            // ribbonTab2
            // 
            this.ribbonTab2.Tag = null;
            this.ribbonTab2.Text = "ribbonTab2";
            // 
            // ribbonTab3
            // 
            this.ribbonTab3.Tag = null;
            this.ribbonTab3.Text = "ribbonTab3";
            // 
            // ribbonTab4
            // 
            this.ribbonTab4.Tag = null;
            this.ribbonTab4.Text = "ribbonTab4";
            // 
            // ribbonTab5
            // 
            this.ribbonTab5.Tag = null;
            this.ribbonTab5.Text = "ribbonTab5";
            // 
            // checkvosolGB
            // 
            this.checkvosolGB.Controls.Add(this.checkdaryaftilbl);
            this.checkvosolGB.Location = new System.Drawing.Point(2, 691);
            this.checkvosolGB.Name = "checkvosolGB";
            this.checkvosolGB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkvosolGB.Size = new System.Drawing.Size(389, 129);
            this.checkvosolGB.TabIndex = 14;
            this.checkvosolGB.TabStop = false;
            this.checkvosolGB.Text = "نمایش چکهای وصول نشده";
            this.checkvosolGB.Visible = false;
            // 
            // checkdaryaftilbl
            // 
            this.checkdaryaftilbl.Location = new System.Drawing.Point(6, 23);
            this.checkdaryaftilbl.Name = "checkdaryaftilbl";
            this.checkdaryaftilbl.Size = new System.Drawing.Size(377, 100);
            this.checkdaryaftilbl.TabIndex = 1;
            // 
            // checkpardakhtGB
            // 
            this.checkpardakhtGB.Controls.Add(this.checkpardakhtilbl);
            this.checkpardakhtGB.Location = new System.Drawing.Point(397, 691);
            this.checkpardakhtGB.Name = "checkpardakhtGB";
            this.checkpardakhtGB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkpardakhtGB.Size = new System.Drawing.Size(346, 129);
            this.checkpardakhtGB.TabIndex = 15;
            this.checkpardakhtGB.TabStop = false;
            this.checkpardakhtGB.Text = "نمایش چکهای پرداخت نشده";
            this.checkpardakhtGB.Visible = false;
            // 
            // checkpardakhtilbl
            // 
            this.checkpardakhtilbl.Location = new System.Drawing.Point(5, 23);
            this.checkpardakhtilbl.Name = "checkpardakhtilbl";
            this.checkpardakhtilbl.Size = new System.Drawing.Size(333, 98);
            this.checkpardakhtilbl.TabIndex = 0;
            // 
            // hadeaghalekalaGB
            // 
            this.hadeaghalekalaGB.Controls.Add(this.lblkalasefareshi);
            this.hadeaghalekalaGB.Location = new System.Drawing.Point(397, 551);
            this.hadeaghalekalaGB.Name = "hadeaghalekalaGB";
            this.hadeaghalekalaGB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.hadeaghalekalaGB.Size = new System.Drawing.Size(346, 142);
            this.hadeaghalekalaGB.TabIndex = 16;
            this.hadeaghalekalaGB.TabStop = false;
            this.hadeaghalekalaGB.Text = "نمایش کالاهای سفارشی براساس حداقل موجودی کالاها ";
            this.hadeaghalekalaGB.Visible = false;
            // 
            // lblkalasefareshi
            // 
            this.lblkalasefareshi.Location = new System.Drawing.Point(3, 22);
            this.lblkalasefareshi.Name = "lblkalasefareshi";
            this.lblkalasefareshi.Size = new System.Drawing.Size(336, 109);
            this.lblkalasefareshi.TabIndex = 0;
            // 
            // kalakerayeGB
            // 
            this.kalakerayeGB.Controls.Add(this.lblkalakeraye);
            this.kalakerayeGB.Location = new System.Drawing.Point(3, 551);
            this.kalakerayeGB.Name = "kalakerayeGB";
            this.kalakerayeGB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.kalakerayeGB.Size = new System.Drawing.Size(388, 142);
            this.kalakerayeGB.TabIndex = 17;
            this.kalakerayeGB.TabStop = false;
            this.kalakerayeGB.Text = "نمایش کالاهای کرایه داده شده ای که برگردانده نشده ";
            this.kalakerayeGB.Visible = false;
            // 
            // lblkalakeraye
            // 
            this.lblkalakeraye.Location = new System.Drawing.Point(3, 22);
            this.lblkalakeraye.Name = "lblkalakeraye";
            this.lblkalakeraye.Size = new System.Drawing.Size(378, 109);
            this.lblkalakeraye.TabIndex = 0;
            // 
            // ribbonButtonList5
            // 
            this.ribbonButtonList5.AltKey = null;
            this.ribbonButtonList5.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonList5.FlowToBottom = false;
            this.ribbonButtonList5.Image = null;
            this.ribbonButtonList5.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.ribbonButtonList5.Tag = null;
            this.ribbonButtonList5.Text = null;
            this.ribbonButtonList5.ToolTip = null;
            this.ribbonButtonList5.ToolTipImage = null;
            this.ribbonButtonList5.ToolTipTitle = null;
            // 
            // ribbonComboBox3
            // 
            this.ribbonComboBox3.AltKey = null;
            this.ribbonComboBox3.Image = null;
            this.ribbonComboBox3.Tag = null;
            this.ribbonComboBox3.Text = null;
            this.ribbonComboBox3.TextBoxText = null;
            this.ribbonComboBox3.ToolTip = null;
            this.ribbonComboBox3.ToolTipImage = null;
            this.ribbonComboBox3.ToolTipTitle = null;
            // 
            // ribbonComboBox4
            // 
            this.ribbonComboBox4.AltKey = null;
            this.ribbonComboBox4.Image = null;
            this.ribbonComboBox4.Tag = null;
            this.ribbonComboBox4.Text = null;
            this.ribbonComboBox4.TextBoxText = null;
            this.ribbonComboBox4.ToolTip = null;
            this.ribbonComboBox4.ToolTipImage = null;
            this.ribbonComboBox4.ToolTipTitle = null;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape2});
            this.shapeContainer1.Size = new System.Drawing.Size(1028, 760);
            this.shapeContainer1.TabIndex = 2;
            this.shapeContainer1.TabStop = false;
            // 
            // vistaClock1
            // 
            this.vistaClock1.BackColor = System.Drawing.Color.Transparent;
            this.vistaClock1.Location = new System.Drawing.Point(43, 2);
            this.vistaClock1.Name = "vistaClock1";
            this.vistaClock1.SecondSpring = true;
            this.vistaClock1.ShowSecond = true;
            this.vistaClock1.Size = new System.Drawing.Size(185, 153);
            this.vistaClock1.Style = CNPOPSOFT.Controls.VistaClock.VistaClockStyle.Silver;
            this.vistaClock1.TabIndex = 18;
            // 
            // hadeaghalekalachb
            // 
            this.hadeaghalekalachb.AutoSize = true;
            this.hadeaghalekalachb.Location = new System.Drawing.Point(2, 101);
            this.hadeaghalekalachb.Name = "hadeaghalekalachb";
            this.hadeaghalekalachb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.hadeaghalekalachb.Size = new System.Drawing.Size(260, 17);
            this.hadeaghalekalachb.TabIndex = 19;
            this.hadeaghalekalachb.Text = "نمایش کالاهایی که  تعداد آنها به حداقل رسیده است";
            this.hadeaghalekalachb.UseVisualStyleBackColor = true;
            this.hadeaghalekalachb.CheckedChanged += new System.EventHandler(this.hadeaghalekalachb_CheckedChanged);
            // 
            // kalakerayechb
            // 
            this.kalakerayechb.AutoSize = true;
            this.kalakerayechb.Location = new System.Drawing.Point(33, 74);
            this.kalakerayechb.Name = "kalakerayechb";
            this.kalakerayechb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.kalakerayechb.Size = new System.Drawing.Size(235, 17);
            this.kalakerayechb.TabIndex = 20;
            this.kalakerayechb.Text = "نمایش کالاهای کرایه ای که بگردانده نشده اند";
            this.kalakerayechb.UseVisualStyleBackColor = true;
            this.kalakerayechb.CheckedChanged += new System.EventHandler(this.kalakerayechb_CheckedChanged);
            // 
            // checkvosolchb
            // 
            this.checkvosolchb.AutoSize = true;
            this.checkvosolchb.Location = new System.Drawing.Point(107, 47);
            this.checkvosolchb.Name = "checkvosolchb";
            this.checkvosolchb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkvosolchb.Size = new System.Drawing.Size(151, 17);
            this.checkvosolchb.TabIndex = 21;
            this.checkvosolchb.Text = "نمایش چک های وصول نشده";
            this.checkvosolchb.UseVisualStyleBackColor = true;
            this.checkvosolchb.CheckedChanged += new System.EventHandler(this.checkvosolchb_CheckedChanged);
            // 
            // checkpardakhtchb
            // 
            this.checkpardakhtchb.AutoSize = true;
            this.checkpardakhtchb.Location = new System.Drawing.Point(100, 21);
            this.checkpardakhtchb.Name = "checkpardakhtchb";
            this.checkpardakhtchb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkpardakhtchb.Size = new System.Drawing.Size(155, 17);
            this.checkpardakhtchb.TabIndex = 22;
            this.checkpardakhtchb.Text = "نمایش چک های پرداخت نشده";
            this.checkpardakhtchb.UseVisualStyleBackColor = true;
            this.checkpardakhtchb.CheckedChanged += new System.EventHandler(this.checkpardakhtchb_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkpardakhtchb);
            this.groupBox2.Controls.Add(this.checkvosolchb);
            this.groupBox2.Controls.Add(this.kalakerayechb);
            this.groupBox2.Controls.Add(this.hadeaghalekalachb);
            this.groupBox2.Location = new System.Drawing.Point(751, 356);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(274, 132);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.vistaClock1);
            this.groupBox3.Location = new System.Drawing.Point(753, 666);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(271, 154);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            // 
            // ribbonColorChooser1
            // 
            this.ribbonColorChooser1.AltKey = null;
            this.ribbonColorChooser1.Color = System.Drawing.Color.Transparent;
            this.ribbonColorChooser1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonColorChooser1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser1.Image")));
            this.ribbonColorChooser1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser1.SmallImage")));
            this.ribbonColorChooser1.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonColorChooser1.Tag = null;
            this.ribbonColorChooser1.Text = null;
            this.ribbonColorChooser1.ToolTip = null;
            this.ribbonColorChooser1.ToolTipImage = null;
            this.ribbonColorChooser1.ToolTipTitle = null;
            // 
            // ribbonColorChooser2
            // 
            this.ribbonColorChooser2.AltKey = null;
            this.ribbonColorChooser2.Color = System.Drawing.Color.Transparent;
            this.ribbonColorChooser2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonColorChooser2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser2.Image")));
            this.ribbonColorChooser2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser2.SmallImage")));
            this.ribbonColorChooser2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonColorChooser2.Tag = null;
            this.ribbonColorChooser2.Text = null;
            this.ribbonColorChooser2.ToolTip = null;
            this.ribbonColorChooser2.ToolTipImage = null;
            this.ribbonColorChooser2.ToolTipTitle = null;
            // 
            // ribbonButton4
            // 
            this.ribbonButton4.AltKey = null;
            this.ribbonButton4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton4.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.Image")));
            this.ribbonButton4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.SmallImage")));
            this.ribbonButton4.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton4.Tag = null;
            this.ribbonButton4.Text = null;
            this.ribbonButton4.ToolTip = null;
            this.ribbonButton4.ToolTipImage = null;
            this.ribbonButton4.ToolTipTitle = null;
            // 
            // ribbonButton5
            // 
            this.ribbonButton5.AltKey = null;
            this.ribbonButton5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton5.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.Image")));
            this.ribbonButton5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.SmallImage")));
            this.ribbonButton5.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton5.Tag = null;
            this.ribbonButton5.Text = null;
            this.ribbonButton5.ToolTip = null;
            this.ribbonButton5.ToolTipImage = null;
            this.ribbonButton5.ToolTipTitle = null;
            // 
            // ribbonButton6
            // 
            this.ribbonButton6.AltKey = null;
            this.ribbonButton6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton6.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.Image")));
            this.ribbonButton6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.SmallImage")));
            this.ribbonButton6.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton6.Tag = null;
            this.ribbonButton6.Text = null;
            this.ribbonButton6.ToolTip = null;
            this.ribbonButton6.ToolTipImage = null;
            this.ribbonButton6.ToolTipTitle = null;
            // 
            // ribbonButton7
            // 
            this.ribbonButton7.AltKey = null;
            this.ribbonButton7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton7.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton7.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton7.Image")));
            this.ribbonButton7.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton7.SmallImage")));
            this.ribbonButton7.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton7.Tag = null;
            this.ribbonButton7.Text = null;
            this.ribbonButton7.ToolTip = null;
            this.ribbonButton7.ToolTipImage = null;
            this.ribbonButton7.ToolTipTitle = null;
            // 
            // ribbonButton10
            // 
            this.ribbonButton10.AltKey = null;
            this.ribbonButton10.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton10.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton10.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.Image")));
            this.ribbonButton10.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.SmallImage")));
            this.ribbonButton10.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton10.Tag = null;
            this.ribbonButton10.Text = null;
            this.ribbonButton10.ToolTip = null;
            this.ribbonButton10.ToolTipImage = null;
            this.ribbonButton10.ToolTipTitle = null;
            // 
            // ribbonButton12
            // 
            this.ribbonButton12.AltKey = null;
            this.ribbonButton12.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton12.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton12.Image = global::main1.Properties.Resources.Shutdown1;
            this.ribbonButton12.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton12.SmallImage")));
            this.ribbonButton12.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton12.Tag = null;
            this.ribbonButton12.Text = "خروج-از-سیستم";
            this.ribbonButton12.ToolTip = null;
            this.ribbonButton12.ToolTipImage = null;
            this.ribbonButton12.ToolTipTitle = null;
            // 
            // ribbonButton14
            // 
            this.ribbonButton14.AltKey = null;
            this.ribbonButton14.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton14.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton14.Image = global::main1.Properties.Resources.Shutdown1;
            this.ribbonButton14.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton14.SmallImage")));
            this.ribbonButton14.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton14.Tag = null;
            this.ribbonButton14.Text = "خروج-از-سیستم";
            this.ribbonButton14.ToolTip = null;
            this.ribbonButton14.ToolTipImage = null;
            this.ribbonButton14.ToolTipTitle = null;
            // 
            // ribbonButton16
            // 
            this.ribbonButton16.AltKey = null;
            this.ribbonButton16.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton16.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton16.Image = global::main1.Properties.Resources.Shutdown;
            this.ribbonButton16.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton16.SmallImage")));
            this.ribbonButton16.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton16.Tag = null;
            this.ribbonButton16.Text = "خاموش-کردن-سیستم";
            this.ribbonButton16.ToolTip = null;
            this.ribbonButton16.ToolTipImage = null;
            this.ribbonButton16.ToolTipTitle = null;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 760);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.kalakerayeGB);
            this.Controls.Add(this.hadeaghalekalaGB);
            this.Controls.Add(this.checkpardakhtGB);
            this.Controls.Add(this.checkvosolGB);
            this.Controls.Add(this.ribbon1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اصلی نرم افزار";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.checkvosolGB.ResumeLayout(false);
            this.checkpardakhtGB.ResumeLayout(false);
            this.hadeaghalekalaGB.ResumeLayout(false);
            this.kalakerayeGB.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem سیستمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ورودسیستمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجازسیستمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعریفکاربرانبرنامهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجازبرنامهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعاریفپایهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعریفکالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعریفمشتریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعیینموجودیصندوقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اسنادپرداختنیاولدورهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اسناددریافتنیاولدورهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورخریدF4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فاکتورفروشF5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بستانکارانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بدهکارانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ترازنامهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ترازآزمایشیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem صورتتغییراتسرمایهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کاربرگToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزارشماندهحسابهاازدفترکلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem گزاشدفترروزنامهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem صورتحسابسودوزیانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem نمایشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اطلاعاتکاربرانفعالToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem راهنماToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem راهنمایاستفادهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem دربارهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ثبترویدادهایغیرمالیToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتاسنادحسابداریToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator25;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblnamesherkat;
        private System.Windows.Forms.Label lblsalemali;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbldate1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox1;
        private System.Windows.Forms.RibbonButtonList ribbonButtonList1;
        private System.Windows.Forms.RibbonButtonList ribbonButtonList2;
        private System.Windows.Forms.RibbonButtonList ribbonButtonList3;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup1;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser1;
        private System.Windows.Forms.RibbonButton loginkarbarrib;
        private System.Windows.Forms.RibbonTextBox ribbonTextBox1;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser2;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox2;
        private System.Windows.Forms.RibbonButton ribbonButton4;
        private System.Windows.Forms.RibbonButton ribbonButton5;
        private System.Windows.Forms.RibbonButton ribbonButton6;
        private System.Windows.Forms.RibbonButton ribbonButton7;
        private System.Windows.Forms.RibbonButton ribbonButton10;
        private System.Windows.Forms.RibbonButton logoutkarbarrib;
        private System.Windows.Forms.RibbonButton exitrib;
        private System.Windows.Forms.RibbonButton shutdownrib;
        private System.Windows.Forms.RibbonButton rebootrib;
        private System.Windows.Forms.RibbonButton logoffrib;
        private System.Windows.Forms.RibbonButton ribbonButton12;
        private System.Windows.Forms.RibbonButton ribbonButton14;
        private System.Windows.Forms.RibbonButton ribbonButton16;
        private System.Windows.Forms.RibbonButton kalakerayerib;
        private System.Windows.Forms.RibbonButton kalakharidforoshrib;
        private System.Windows.Forms.RibbonButton moshtaririb;
        private System.Windows.Forms.RibbonButton hesabbankirib;
        private System.Windows.Forms.RibbonButton sanadhesabdaririb;
        private System.Windows.Forms.RibbonButton roidadegheiremalirib;
        private System.Windows.Forms.RibbonButton groupkalarib;
        private System.Windows.Forms.RibbonButton factorkharidrib;
        private System.Windows.Forms.RibbonButton factorforoshrib;
        private System.Windows.Forms.RibbonButton factorkerayerib;
        private System.Windows.Forms.RibbonButton taraznamerib;
        private System.Windows.Forms.RibbonButton tarazazmayeshirib;
        private System.Windows.Forms.RibbonButton soratsarmayerib;
        private System.Windows.Forms.RibbonButtonList ribbonButtonList4;
        private System.Windows.Forms.RibbonButton sorathoghoghsahebrib;
        private System.Windows.Forms.RibbonButton soratsodziyanrib;
        private System.Windows.Forms.RibbonButton mandekolrib;
        private System.Windows.Forms.RibbonButton dafatreroznamerib;
        private System.Windows.Forms.RibbonButton mashinhesabrib;
        private System.Windows.Forms.RibbonButton rahnamarib;
        private System.Windows.Forms.RibbonButton darbarerib;
        private System.Windows.Forms.RibbonButton karbarrib;
        private System.Windows.Forms.RibbonButton hesabrib;
        private System.Windows.Forms.RibbonButton checkrib;
        private System.Windows.Forms.RibbonButton havalerib;
        private System.Windows.Forms.RibbonButton ghestyrib;
        private System.Windows.Forms.RibbonButton naghdrib;
        public System.Windows.Forms.RibbonTab taarifribtab;
        public System.Windows.Forms.RibbonTab gozareshribtab;
        public System.Windows.Forms.Ribbon ribbon1;
        public System.Windows.Forms.RibbonTab sistemribtab;
        public System.Windows.Forms.RibbonPanel ribbonPanel1;
        public System.Windows.Forms.RibbonPanel ribbonPanel2;
        public System.Windows.Forms.RibbonTab factorribtab;
        public System.Windows.Forms.RibbonPanel ribbonPanel3;
        public System.Windows.Forms.RibbonPanel ribbonPanel4;
        public System.Windows.Forms.RibbonPanel ribbonPanel5;
        public System.Windows.Forms.RibbonPanel ribbonPanel6;
        public System.Windows.Forms.RibbonPanel ribbonPanel8;
        public System.Windows.Forms.RibbonPanel ribbonPanel10;
        public System.Windows.Forms.RibbonPanel ribbonPanel11;
        public System.Windows.Forms.RibbonPanel ribbonPanel13;
        public System.Windows.Forms.RibbonTab emkanatribtab;
        public System.Windows.Forms.RibbonTab rahnamaribtab;
        public System.Windows.Forms.RibbonPanel ribbonPanel19;
        public System.Windows.Forms.RibbonPanel ribbonPanel22;
        public System.Windows.Forms.RibbonPanel ribbonPanel23;
        public System.Windows.Forms.RibbonPanel taraconeshtabrib;
        private System.Windows.Forms.RibbonPanel ribbonPanel24;
        private System.Windows.Forms.RibbonPanel ribbonPanel25;
        private System.Windows.Forms.RibbonPanel ribbonPanel26;
        private System.Windows.Forms.RibbonPanel ribbonPanel27;
        private System.Windows.Forms.RibbonPanel ribbonPanel28;
        private System.Windows.Forms.RibbonPanel ribbonPanel29;
        private System.Windows.Forms.RibbonPanel ribbonPanel30;
        private System.Windows.Forms.RibbonPanel ribbonPanel31;
        private System.Windows.Forms.RibbonPanel ribbonPanel32;
        private System.Windows.Forms.RibbonPanel ribbonPanel33;
        private System.Windows.Forms.RibbonTab ribbonTab2;
        private System.Windows.Forms.RibbonTab ribbonTab3;
        private System.Windows.Forms.RibbonTab ribbonTab4;
        private System.Windows.Forms.RibbonTab ribbonTab5;
        public System.Windows.Forms.RibbonButton ribbonButton1;
        public System.Windows.Forms.RibbonButton ribbonButton2;
        public System.Windows.Forms.RibbonButton ribbonButton3;
        public System.Windows.Forms.RibbonButton ribbonButton8;
        public System.Windows.Forms.RibbonButton ribbonButton9;
        public System.Windows.Forms.RibbonButton ribbonButton11;
        public System.Windows.Forms.RibbonButton ribbonButton13;
        public System.Windows.Forms.RibbonButton ribbonButton15;
        public System.Windows.Forms.RibbonTab ribbonTab1;
        private System.Windows.Forms.RibbonButton ribbonButton17;
        private System.Windows.Forms.RibbonButton ribbonButton18;
        private System.Windows.Forms.RibbonButton ribbonButton19;
        private System.Windows.Forms.GroupBox checkvosolGB;
        private System.Windows.Forms.GroupBox checkpardakhtGB;
        private System.Windows.Forms.Label checkdaryaftilbl;
        private System.Windows.Forms.Label checkpardakhtilbl;
        private System.Windows.Forms.GroupBox hadeaghalekalaGB;
        private System.Windows.Forms.Label lblkalasefareshi;
        private System.Windows.Forms.GroupBox kalakerayeGB;
        private System.Windows.Forms.Label lblkalakeraye;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripMenuItem صورتحقوقصاحبانسهامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem امکاناتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ماشینحسابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem اطلاعاتشرکتفروشگاهToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مشاهدهکالاهایکرایهدادهشدهایکهبرگرداندهنشدهToolStripMenuItem;
        private System.Windows.Forms.RibbonButtonList ribbonButtonList5;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox3;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox4;
        private System.Windows.Forms.ToolStripMenuItem مشاهدهکالاهاییکهبهحداقلتعدادرسیدهاندToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مشاهدهToolStripMenuItem;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private CNPOPSOFT.Controls.VistaClock vistaClock1;
        private System.Windows.Forms.CheckBox hadeaghalekalachb;
        private System.Windows.Forms.CheckBox kalakerayechb;
        private System.Windows.Forms.CheckBox checkvosolchb;
        private System.Windows.Forms.CheckBox checkpardakhtchb;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RibbonPanel ribbonPanel7;
        private System.Windows.Forms.RibbonButton ribbonButton20;
        private System.Windows.Forms.RibbonPanel ribbonPanel9;
        private System.Windows.Forms.RibbonButton ribbonButton21;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace main1
{
    public partial class Splashform : Form
    {
        private int maxTime = 0;
        public Splashform()
        {
            InitializeComponent();
        }

        private void Splashform_Load(object sender, EventArgs e)
        {
            this.timer1.Enabled = true;
            progressBar1.Maximum = 100;
            progressBar1.Minimum  = 0;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            if (maxTime >= 100)
            {
                this.timer1.Enabled = false;
                this.DialogResult = DialogResult.OK;
                Main obj = new Main();
                obj.ShowDialog();
                this.Close();
            }
            else
            {
                if (timer1.Interval >= 5)
                    if (maxTime % 4 == 0)
                        timer1.Interval -= 4;
                progressBar1.Value = maxTime;
                this.lblloading.Text = maxTime + "%";
                this.maxTime += 1;

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

    }
}

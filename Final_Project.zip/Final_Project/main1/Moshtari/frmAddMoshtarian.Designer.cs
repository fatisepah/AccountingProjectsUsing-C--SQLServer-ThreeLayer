﻿namespace main1.Moshtari
{
    partial class frmAddMoshtarian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.idhesabtxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.noemoshtaricmb = new System.Windows.Forms.ComboBox();
            this.idnoemoshtaritxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.idmoshtaritxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.namemoshtaritxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.mobilemtxt = new System.Windows.Forms.MaskedTextBox();
            this.emailmoshtaritxt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.addresskartxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.addresskhanetxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.faxsherkatmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.telsharkatmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idsherkattxt = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.namesherkattxt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.emailsherkattxt = new System.Windows.Forms.TextBox();
            this.addresssherkattxt = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.hesabbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.idhesabtxt);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.noemoshtaricmb);
            this.groupBox1.Controls.Add(this.idnoemoshtaritxt);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(21, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(468, 99);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(241, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 46;
            this.label1.Text = "*";
            // 
            // idhesabtxt
            // 
            this.idhesabtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhesabtxt.Location = new System.Drawing.Point(38, 26);
            this.idhesabtxt.Name = "idhesabtxt";
            this.idhesabtxt.ReadOnly = true;
            this.idhesabtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabtxt.Size = new System.Drawing.Size(116, 20);
            this.idhesabtxt.TabIndex = 2;
            this.idhesabtxt.Enter += new System.EventHandler(this.idhesabtxt_Enter);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(158, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 23);
            this.label14.TabIndex = 38;
            this.label14.Text = "کد حساب بانکی:";
            // 
            // noemoshtaricmb
            // 
            this.noemoshtaricmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.noemoshtaricmb.FormattingEnabled = true;
            this.noemoshtaricmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.noemoshtaricmb.Items.AddRange(new object[] {
            "مشتری حقیقی",
            "مشتری حقوقی"});
            this.noemoshtaricmb.Location = new System.Drawing.Point(257, 62);
            this.noemoshtaricmb.Name = "noemoshtaricmb";
            this.noemoshtaricmb.Size = new System.Drawing.Size(116, 21);
            this.noemoshtaricmb.TabIndex = 3;
            this.noemoshtaricmb.SelectedIndexChanged += new System.EventHandler(this.noemoshtaricmb_SelectedIndexChanged);
            this.noemoshtaricmb.Enter += new System.EventHandler(this.noemoshtaricmb_Enter);
            // 
            // idnoemoshtaritxt
            // 
            this.idnoemoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoemoshtaritxt.Location = new System.Drawing.Point(257, 26);
            this.idnoemoshtaritxt.Name = "idnoemoshtaritxt";
            this.idnoemoshtaritxt.ReadOnly = true;
            this.idnoemoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoemoshtaritxt.Size = new System.Drawing.Size(116, 20);
            this.idnoemoshtaritxt.TabIndex = 1;
            this.idnoemoshtaritxt.Enter += new System.EventHandler(this.idnoemoshtaritxt_Enter);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(369, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 23);
            this.label9.TabIndex = 20;
            this.label9.Text = "نام نوع مشتری:";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(379, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 23);
            this.label10.TabIndex = 19;
            this.label10.Text = "کد نوع مشتری:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.idmoshtaritxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.namemoshtaritxt);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.mobilemtxt);
            this.groupBox2.Controls.Add(this.emailmoshtaritxt);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.addresskartxt);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.addresskhanetxt);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(21, 137);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(468, 204);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "اطلاعات مشتریان حقیقی / فروشندگان";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(241, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 23);
            this.label4.TabIndex = 46;
            this.label4.Text = "*";
            // 
            // idmoshtaritxt
            // 
            this.idmoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idmoshtaritxt.Location = new System.Drawing.Point(257, 31);
            this.idmoshtaritxt.Name = "idmoshtaritxt";
            this.idmoshtaritxt.ReadOnly = true;
            this.idmoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idmoshtaritxt.Size = new System.Drawing.Size(116, 20);
            this.idmoshtaritxt.TabIndex = 4;
            this.idmoshtaritxt.Enter += new System.EventHandler(this.idmoshtaritxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(22, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 45;
            this.label5.Text = "*";
            // 
            // namemoshtaritxt
            // 
            this.namemoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namemoshtaritxt.Location = new System.Drawing.Point(39, 31);
            this.namemoshtaritxt.Name = "namemoshtaritxt";
            this.namemoshtaritxt.Size = new System.Drawing.Size(116, 20);
            this.namemoshtaritxt.TabIndex = 5;
            this.namemoshtaritxt.Enter += new System.EventHandler(this.namemoshtaritxt_Enter);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(162, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 23);
            this.label3.TabIndex = 43;
            this.label3.Text = "نام مشتری:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(380, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 23);
            this.label2.TabIndex = 42;
            this.label2.Text = "کد مشتری:";
            // 
            // mobilemtxt
            // 
            this.mobilemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mobilemtxt.Location = new System.Drawing.Point(257, 64);
            this.mobilemtxt.Mask = "99999999999";
            this.mobilemtxt.Name = "mobilemtxt";
            this.mobilemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mobilemtxt.Size = new System.Drawing.Size(116, 20);
            this.mobilemtxt.TabIndex = 6;
            this.mobilemtxt.Enter += new System.EventHandler(this.mobilemtxt_Enter);
            // 
            // emailmoshtaritxt
            // 
            this.emailmoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emailmoshtaritxt.Location = new System.Drawing.Point(38, 167);
            this.emailmoshtaritxt.Name = "emailmoshtaritxt";
            this.emailmoshtaritxt.Size = new System.Drawing.Size(336, 20);
            this.emailmoshtaritxt.TabIndex = 9;
            this.emailmoshtaritxt.Enter += new System.EventHandler(this.emailmoshtaritxt_Enter);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(380, 167);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 23);
            this.label21.TabIndex = 33;
            this.label21.Text = "ایمیل:";
            // 
            // addresskartxt
            // 
            this.addresskartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addresskartxt.Location = new System.Drawing.Point(38, 132);
            this.addresskartxt.Name = "addresskartxt";
            this.addresskartxt.Size = new System.Drawing.Size(336, 20);
            this.addresskartxt.TabIndex = 8;
            this.addresskartxt.Enter += new System.EventHandler(this.addresskartxt_Enter);
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(377, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 23);
            this.label12.TabIndex = 7;
            this.label12.Text = "آدرس محل کار:";
            // 
            // addresskhanetxt
            // 
            this.addresskhanetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addresskhanetxt.Location = new System.Drawing.Point(38, 98);
            this.addresskhanetxt.Name = "addresskhanetxt";
            this.addresskhanetxt.Size = new System.Drawing.Size(336, 20);
            this.addresskhanetxt.TabIndex = 7;
            this.addresskhanetxt.Enter += new System.EventHandler(this.addresskhanetxt_Enter);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(365, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 23);
            this.label7.TabIndex = 2;
            this.label7.Text = "آدرس منزل:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(379, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 23);
            this.label8.TabIndex = 1;
            this.label8.Text = "موبایل:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.faxsherkatmtxt);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.telsharkatmtxt);
            this.groupBox3.Controls.Add(this.idsherkattxt);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.namesherkattxt);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.emailsherkattxt);
            this.groupBox3.Controls.Add(this.addresssherkattxt);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(21, 350);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(468, 182);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "اطلاعات مشتریان حقوقی/ فروشندگان";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(241, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 23);
            this.label6.TabIndex = 54;
            this.label6.Text = "*";
            // 
            // faxsherkatmtxt
            // 
            this.faxsherkatmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.faxsherkatmtxt.Location = new System.Drawing.Point(40, 67);
            this.faxsherkatmtxt.Mask = "9999-99999999";
            this.faxsherkatmtxt.Name = "faxsherkatmtxt";
            this.faxsherkatmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.faxsherkatmtxt.Size = new System.Drawing.Size(116, 20);
            this.faxsherkatmtxt.TabIndex = 13;
            this.faxsherkatmtxt.Enter += new System.EventHandler(this.faxsherkatmtxt_Enter);
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(161, 69);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(39, 23);
            this.label24.TabIndex = 53;
            this.label24.Text = "فکس:";
            // 
            // telsharkatmtxt
            // 
            this.telsharkatmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.telsharkatmtxt.Location = new System.Drawing.Point(257, 67);
            this.telsharkatmtxt.Mask = "9999-99999999";
            this.telsharkatmtxt.Name = "telsharkatmtxt";
            this.telsharkatmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.telsharkatmtxt.Size = new System.Drawing.Size(116, 20);
            this.telsharkatmtxt.TabIndex = 12;
            this.telsharkatmtxt.Enter += new System.EventHandler(this.telsharkatmtxt_Enter);
            // 
            // idsherkattxt
            // 
            this.idsherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idsherkattxt.Location = new System.Drawing.Point(257, 33);
            this.idsherkattxt.Name = "idsherkattxt";
            this.idsherkattxt.ReadOnly = true;
            this.idsherkattxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idsherkattxt.Size = new System.Drawing.Size(116, 20);
            this.idsherkattxt.TabIndex = 10;
            this.idsherkattxt.Enter += new System.EventHandler(this.idsherkattxt_Enter);
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(23, 35);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 23);
            this.label20.TabIndex = 50;
            this.label20.Text = "*";
            // 
            // namesherkattxt
            // 
            this.namesherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesherkattxt.Location = new System.Drawing.Point(40, 33);
            this.namesherkattxt.Name = "namesherkattxt";
            this.namesherkattxt.Size = new System.Drawing.Size(116, 20);
            this.namesherkattxt.TabIndex = 11;
            this.namesherkattxt.Enter += new System.EventHandler(this.namesherkattxt_Enter);
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(155, 35);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 23);
            this.label22.TabIndex = 48;
            this.label22.Text = "نام شرکت:";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(374, 35);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(64, 23);
            this.label23.TabIndex = 47;
            this.label23.Text = "کد شرکت:";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(378, 137);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 23);
            this.label13.TabIndex = 33;
            this.label13.Text = "ایمیل:";
            // 
            // emailsherkattxt
            // 
            this.emailsherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emailsherkattxt.Location = new System.Drawing.Point(38, 135);
            this.emailsherkattxt.Name = "emailsherkattxt";
            this.emailsherkattxt.Size = new System.Drawing.Size(336, 20);
            this.emailsherkattxt.TabIndex = 15;
            this.emailsherkattxt.Enter += new System.EventHandler(this.emailsherkattxt_Enter);
            // 
            // addresssherkattxt
            // 
            this.addresssherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addresssherkattxt.Location = new System.Drawing.Point(38, 101);
            this.addresssherkattxt.Name = "addresssherkattxt";
            this.addresssherkattxt.Size = new System.Drawing.Size(336, 20);
            this.addresssherkattxt.TabIndex = 14;
            this.addresssherkattxt.Enter += new System.EventHandler(this.addresssherkattxt_Enter);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(373, 103);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 23);
            this.label18.TabIndex = 2;
            this.label18.Text = "آدرس شرکت:";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(373, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 23);
            this.label19.TabIndex = 1;
            this.label19.Text = "تلفن شرکت:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 23;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(94, 550);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 18;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(333, 550);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 16;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // lblkarbar
            // 
            this.lblkarbar.Location = new System.Drawing.Point(285, 12);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(124, 23);
            this.lblkarbar.TabIndex = 24;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(408, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 23);
            this.label25.TabIndex = 25;
            this.label25.Text = ":نام کاربر";
            // 
            // hesabbtn
            // 
            this.hesabbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hesabbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hesabbtn.Location = new System.Drawing.Point(190, 550);
            this.hesabbtn.Name = "hesabbtn";
            this.hesabbtn.Size = new System.Drawing.Size(137, 28);
            this.hesabbtn.TabIndex = 17;
            this.hesabbtn.Text = "اضافه کردن حساب بانکی ";
            this.hesabbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.hesabbtn.UseVisualStyleBackColor = true;
            this.hesabbtn.Click += new System.EventHandler(this.hesabbtn_Click);
            // 
            // frmAddMoshtarian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 591);
            this.Controls.Add(this.hesabbtn);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmAddMoshtarian";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن مشتریان و فروشندگان";
            this.Load += new System.EventHandler(this.frmAddMoshtarian_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox addresskhanetxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox idnoemoshtaritxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox addresskartxt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox emailmoshtaritxt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MaskedTextBox mobilemtxt;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox emailsherkattxt;
        private System.Windows.Forms.TextBox addresssherkattxt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox idmoshtaritxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox namemoshtaritxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idsherkattxt;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox namesherkattxt;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.MaskedTextBox telsharkatmtxt;
        private System.Windows.Forms.MaskedTextBox faxsherkatmtxt;
        private System.Windows.Forms.ComboBox noemoshtaricmb;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button hesabbtn;
        private System.Windows.Forms.TextBox idhesabtxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;

    }
}
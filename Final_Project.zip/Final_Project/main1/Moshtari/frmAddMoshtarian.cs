﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Moshtari
{
    public partial class frmAddMoshtarian : Form
    {
        public frmAddMoshtarian()
        {
            InitializeComponent();
        }
        MoshtariDB DBMoshtari = new MoshtariDB();
        MoshtariData objMoshtari = new MoshtariData();
        SherkatData objSherkat = new SherkatData();
        SherkatDB DBSherkat = new SherkatDB();
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if(noemoshtaricmb .Text =="")
            {
                MessageBox.Show("نوع مشتری را انتخاب نکرده اید","خطا",MessageBoxButtons .OK);
                noemoshtaricmb.Focus();
            }
            else
            {
            if (idnoemoshtaritxt.Text == Convert.ToString("1"))
            {

                //در صورتی که نوع مشتری برابر با "1" باشد، مشتری اضافه می شود و اگر "2" باشد، شرکت اضافه می شود. 


                if (idmoshtaritxt.Text != "" && idnoemoshtaritxt.Text != "" && namemoshtaritxt.Text != "")
                {
                    DBMoshtari.IDMoshtari = Convert.ToInt32(idmoshtaritxt.Text);
                    DBMoshtari.FKHesabBanki = Convert.ToInt32(idhesabtxt.Text);
                    DBMoshtari.FKNoeMoshtari = Convert.ToInt32(idnoemoshtaritxt.Text);
                    DBMoshtari.NameKarbar = lblkarbar.Text;
                    DBMoshtari.NameMoshtari = namemoshtaritxt.Text;
                    DBMoshtari.Mobile = mobilemtxt.Text;
                    DBMoshtari.AddressKhane = addresskhanetxt.Text;
                    DBMoshtari.AddressKar = addresskartxt.Text;
                    DBMoshtari.Email = emailmoshtaritxt.Text;
                    if (Class1 .virayeshM != 0)
                    {
                        if ( objMoshtari.MoshtariSearch1(DBMoshtari.IDMoshtari) && Class1.virayeshM != DBMoshtari.IDMoshtari)
                        {
                            MessageBox.Show(" کد مشتری تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            objMoshtari.MoshtariUpdate1(DBMoshtari);
                            MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            Class1.virayeshM = 0;
                            Class1.virayesh = 0;
                            lblkarbar.Text = Class1.NameFamilyKarbar;
                            Close();
                        }
                    }
                    else
                    {

                        //اگر کد مشتری و حساب بانکی که برای آنها وارد شده رو پیدا نکرد درج انجام شود
                        if (!objMoshtari.MoshtariSearch1(DBMoshtari.IDMoshtari))
                        {

                            objMoshtari.MoshtariInsert1(DBMoshtari);
                            if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                            {
                                idmoshtaritxt.Text = "";
                                idhesabtxt.Text = "";
                                idnoemoshtaritxt.Text = "";
                                namemoshtaritxt.Text = "";
                                mobilemtxt.Text = "";
                                addresskhanetxt.Text = "";
                                addresskartxt.Text = "";
                                emailmoshtaritxt.Text = "";
                            }
                            Close();
                        }
                    }
                }

                else
                {
                    MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {


                if (namesherkattxt.Text != "" && idsherkattxt .Text !="")
                {
                    DBSherkat.NameKarbar = lblkarbar.Text;
                    DBSherkat.NameSherkat = namesherkattxt.Text;
                    DBSherkat.AddressSherkat = addresssherkattxt.Text;
                    DBSherkat.TelSherkat = telsharkatmtxt.Text;
                    DBSherkat.Email = emailsherkattxt.Text;
                    DBSherkat.Fax = faxsherkatmtxt.Text;
                    DBSherkat.IDSherkat = Convert.ToInt16(idsherkattxt.Text);
                    DBSherkat.FKHesabBanki = Convert.ToInt16(idhesabtxt.Text);
                    DBSherkat.FKNoeMoshtari = Convert.ToInt16(idnoemoshtaritxt.Text);
                    if (Class1.virayeshS != 0)
                    {
                        if (objSherkat.SherkatSearch1(DBSherkat.IDSherkat) && Class1.virayeshS != DBSherkat.IDSherkat)
                        {
                            MessageBox.Show(" کد شرکت تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            objSherkat.SherkatUpdate1(DBSherkat);
                            MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            Class1.virayeshS = 0;
                            Class1.virayesh = 0;
                            lblkarbar.Text = Class1.NameFamilyKarbar;
                            Close();
                        }
                    }
                    else
                    {
                        if (!objSherkat.SherkatSearch1(DBSherkat.IDSherkat))
                        {
                            objSherkat.SherkatInsert1(DBSherkat);
                            if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                            {
                                idsherkattxt.Text = "";
                                idnoemoshtaritxt.Text = "";
                                namesherkattxt.Text = "";
                                addresssherkattxt.Text = "";
                                telsharkatmtxt.Text = "";
                                emailsherkattxt.Text = "";
                                faxsherkatmtxt.Text = "";
                            }
                            Close();
                        }
                    }
                }
            }
          }
        }
        private void set_color()
        {
            idnoemoshtaritxt.BackColor = Color.White;
            noemoshtaricmb.BackColor = Color.White;
            idmoshtaritxt.BackColor = Color.White;
            namemoshtaritxt.BackColor = Color.White;
            mobilemtxt.BackColor = Color.White;
            addresskhanetxt.BackColor = Color.White;
            addresskartxt.BackColor = Color.White;
            emailmoshtaritxt.BackColor = Color.White;
            idsherkattxt.BackColor = Color.White;
            namesherkattxt.BackColor = Color.White;
            addresskartxt.BackColor = Color.White;
            telsharkatmtxt.BackColor = Color.White;
            emailsherkattxt.BackColor = Color.White;
            faxsherkatmtxt.BackColor = Color.White;
            idhesabtxt.BackColor = Color.White;
            }

        private void idnoemoshtaritxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoemoshtaritxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void noemoshtaricmb_Enter(object sender, EventArgs e)
        {
            set_color();
            noemoshtaricmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idmoshtaritxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idmoshtaritxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namemoshtaritxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namemoshtaritxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void mobilemtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mobilemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void addresskhanetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            addresskhanetxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void addresskartxt_Enter(object sender, EventArgs e)
        {
            set_color();
            addresskartxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void emailmoshtaritxt_Enter(object sender, EventArgs e)
        {
            set_color();
            emailmoshtaritxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idsherkattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idsherkattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesherkattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namesherkattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void telsharkatmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            telsharkatmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void faxsherkatmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            faxsherkatmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void addresssherkattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            addresssherkattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void emailsherkattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            emailsherkattxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void idhesabtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idhesabtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void noemoshtaricmb_SelectedIndexChanged(object sender, EventArgs e)
        {
           int i= Convert .ToInt16(noemoshtaricmb.SelectedIndex );
            if (i == 0)
            {
                idnoemoshtaritxt.Text = "1";
                idmoshtaritxt.Focus();
                groupBox2.Enabled = true;
                groupBox3.Enabled = false;
            }
            else if(i == 1)
            {
                idnoemoshtaritxt.Text = "2";
                idsherkattxt.Focus();
                groupBox3.Enabled = true;
                groupBox2.Enabled = false;

            }
        }

        private void frmAddMoshtarian_Load(object sender, EventArgs e)
        {
            lblkarbar.Text = Class1.NameFamilyKarbar;
            groupBox2.Enabled = false;
            groupBox3.Enabled = false;
            int i1 = 0,i3=0;
            int i2 = 1,i4=0;
            DataTable dt1 = objMoshtari.MoshtariSearchID1();
            DataTable dt2 = objSherkat.SherkatSearchID1();

            if (Class1.virayeshM != 0)
            {
                groupBox2.Enabled = true;
                noemoshtaricmb.SelectedIndex = 0;
                DBMoshtari = objMoshtari .MoshtariFind1(Class1.virayeshM);
                idmoshtaritxt .Text = DBMoshtari.IDMoshtari.ToString();
                idhesabtxt .Text = DBMoshtari.FKHesabBanki.ToString();
                idnoemoshtaritxt.Text = DBMoshtari.FKNoeMoshtari.ToString();
                Class1.NameFamilyKarbarVirayesh = DBMoshtari.NameKarbar;
                lblkarbar.Text = Class1.NameFamilyKarbarVirayesh;
                namemoshtaritxt .Text = DBMoshtari.NameMoshtari ;
                mobilemtxt .Text = DBMoshtari.Mobile;
                addresskhanetxt .Text = DBMoshtari.AddressKhane ;
                addresskartxt .Text = DBMoshtari.AddressKar ;
                emailmoshtaritxt.Text = DBMoshtari.Email;
            }
            else
            {
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt1.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt1.Rows.Count == 0)
                {
                    idmoshtaritxt.Text = "1";
                }
                else
                {
                    idmoshtaritxt.Text = Convert.ToString(i2 + 1);
                }

            }
            if (Class1.virayeshS != 0)
            {
                groupBox3.Enabled = true;
                noemoshtaricmb.SelectedIndex = 1;

                DBSherkat = objSherkat.SherkatFind1(Class1.virayeshS);
                idsherkattxt.Text = DBSherkat.IDSherkat.ToString();
                idhesabtxt.Text = DBSherkat.FKHesabBanki.ToString();
                idnoemoshtaritxt.Text = DBSherkat.FKNoeMoshtari.ToString();
                Class1.NameFamilyKarbarVirayesh = DBSherkat.NameKarbar;
                lblkarbar.Text = Class1.NameFamilyKarbarVirayesh;
                namesherkattxt .Text = DBSherkat.NameSherkat;
                addresssherkattxt .Text = DBSherkat.AddressSherkat;
                telsharkatmtxt .Text = DBSherkat.TelSherkat;
                emailsherkattxt .Text = DBSherkat.Email;
                faxsherkatmtxt.Text = DBSherkat.Fax;

            }
            else
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    i3 = Convert.ToInt32(dt2.Rows[i][0].ToString());
                    if (i4 < i3)
                    {
                        i4 = i3;
                    }
                }
                if (dt2.Rows.Count == 0)
                {
                    idsherkattxt.Text = "1";
                }
                else
                {
                    idsherkattxt.Text = Convert.ToString(i4 + 1);
                }
            }
       }

        private void hesabbtn_Click(object sender, EventArgs e)
        {

            HesabBanki .frmAddHesabBanki  obj = new HesabBanki .frmAddHesabBanki();
            if (obj.ShowDialog() == DialogResult.OK) { }
            idhesabtxt .Text =Class1 .IDHesab.ToString () ;

        }






   }
        

        
 }
 


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Moshtari
{
    public partial class frmMoshtarian : Form
    {
        public frmMoshtarian()
        {
            InitializeComponent();
        }
        FilterMoshtariData MData1 = new FilterMoshtariData();
        MoshtariData MData = new MoshtariData();
        SherkatData SData = new SherkatData();
        HesabBankiData HBData = new HesabBankiData();
        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddMoshtarian obj = new frmAddMoshtarian();
            obj.Show();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = MData.MoshtariShow1();
            set_datagrid();
            this.dataGridView1.Refresh();
        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            if (haghighirbtn.Checked == true)
            {
                frmAddMoshtarian obj = new frmAddMoshtarian();
                if (dataGridView1.RowCount == 0)
                {
                    MessageBox.Show("سطری انتخاب نشده است!", "", MessageBoxButtons.OK);
                }
                else
                {
                    int k = dataGridView1.CurrentCell.RowIndex;
                    Class1.virayeshM = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value);
                    if (obj.ShowDialog() == DialogResult.OK) { }

                    dataGridView1.DataSource = true;
                    dataGridView1.DataSource = MData.MoshtariShow1();
                    set_datagrid();
                    dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
                }

            }
            else
            {
                frmAddMoshtarian obj = new frmAddMoshtarian();
                if (dataGridView1.RowCount == 0)
                {
                    MessageBox.Show("سطری انتخاب نشده است!", "", MessageBoxButtons.OK);
                }
               else
                {
                    int k = dataGridView2.CurrentCell.RowIndex;
                    Class1.virayeshS = Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value);
                    Class1.virayesh = Convert.ToInt32(dataGridView2.CurrentRow.Cells[1].Value);           
                    if (obj.ShowDialog() == DialogResult.OK) { }

                    dataGridView2.DataSource = true;
                    dataGridView2.DataSource = SData.SherkatShow1();
                    set_datagrid1();
                    dataGridView2.CurrentCell = dataGridView2.Rows[k].Cells[1];
                }
            }

            
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchnamemtxt_Enter(object sender, EventArgs e)
        {
            searchnamemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void searchnamemtxt_TextChanged(object sender, EventArgs e)
        {
            string NameMoshtari = searchnamemtxt.Text.Replace("ی", "ي");
            string NameSherkat = searchnamemtxt.Text.Replace("ی", "ي");
            try
            {
                if (haghighirbtn.Checked == true)
                {
                    dataGridView1.DataSource = MData1.FilterNMoshtari1(NameMoshtari);
                }
                else if(hoghoghirbtn .Checked == true)
                {
                    dataGridView2.DataSource = SData.FilterNSherkat1(NameSherkat);
                }
                if (dataGridView1.RowCount.ToString() == "0")
                {
                    virayeshbtn.Enabled = false;
                    printbtn.Enabled = false;
                }
                else
                {
                    virayeshbtn.Enabled = true;
                    printbtn.Enabled = true;
                }

            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                searchnamemtxt.Text = "";
                searchnamemtxt.Focus();
                searchnamemtxt.SelectAll();
            }
        }

        private void frmMoshtarian_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = MData1.MoshtariShow1();
            set_datagrid();
            this.dataGridView1.Refresh();
            dataGridView2.DataSource = true;
            dataGridView2.DataSource = SData.SherkatShow1();
            set_datagrid1();
            searchnamemchb .Checked = false;
            searchnamemtxt.Enabled = false;
            haghighirbtn.Checked = true ;
            hoghoghirbtn.Checked = false;
        }

        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = "کد مشتری";
            dataGridView1.Columns[1].HeaderText = "کد حساب بانکی";
            dataGridView1.Columns[2].HeaderText = "کد نوع مشتری";
            dataGridView1.Columns[3].HeaderText = "نوع مشتری";
            dataGridView1.Columns[4].HeaderText = "نام کاربر";
            dataGridView1.Columns[5].HeaderText = "نام مشتری";
            dataGridView1.Columns[6].HeaderText = "موبایل";
            dataGridView1.Columns[7].HeaderText = "آدرس خانه";
            dataGridView1.Columns[8].HeaderText = "آدرس محل کار";
            dataGridView1.Columns[9].HeaderText = "ایمیل";
            dataGridView1.Columns[10].HeaderText = "نام بانک";
            dataGridView1.Columns[11].HeaderText = "شعبه بانک";
            dataGridView1.Columns[12].HeaderText = "شماره حساب";
            dataGridView1.Columns[13].HeaderText = "شماره کارت";

            dataGridView1.Columns[0].Width=50;
            dataGridView1.Columns[1].Width=50;
            dataGridView1.Columns[2].Width=50;
            dataGridView1.Columns[3].Width=100;
            dataGridView1.Columns[4].Width=100;
            dataGridView1.Columns[5].Width=100;
            dataGridView1.Columns[6].Width=110;
            dataGridView1.Columns[7].Width=200;
            dataGridView1.Columns[8].Width=200;
            dataGridView1.Columns[9].Width=100;
            dataGridView1.Columns[10].Width=100;
            dataGridView1.Columns[11].Width=100;
            dataGridView1.Columns[12].Width=120;
            dataGridView1.Columns[13].Width=120;
        }
        private void set_datagrid1()
        {
            dataGridView2.Columns[0].HeaderText = "کد شرکت";
            dataGridView2.Columns[1].HeaderText = "کد حساب بانکی";
            dataGridView2.Columns[2].HeaderText = "کد نوع مشتری";
            dataGridView2.Columns[3].HeaderText = "نوع مشتری";
            dataGridView2.Columns[4].HeaderText = "نام کاربر";
            dataGridView2.Columns[5].HeaderText = "نام شرکت";
            dataGridView2.Columns[6].HeaderText = "آدرس شرکت";
            dataGridView2.Columns[7].HeaderText = "تلفن شرکت";
            dataGridView2.Columns[8].HeaderText = "ایمیل";
            dataGridView2.Columns[9].HeaderText = "فکس";
            dataGridView2.Columns[10].HeaderText = "نام بانک";
            dataGridView2.Columns[11].HeaderText = "شعبه بانک";
            dataGridView2.Columns[12].HeaderText = "شماره حساب";
            dataGridView2.Columns[13].HeaderText = "شماره کارت";

            dataGridView2.Columns[0].Width = 50;
            dataGridView2.Columns[1].Width = 50;
            dataGridView2.Columns[2].Width = 50;
            dataGridView2.Columns[3].Width = 100;
            dataGridView2.Columns[4].Width = 100;
            dataGridView2.Columns[5].Width = 100;
            dataGridView2.Columns[6].Width = 200;
            dataGridView2.Columns[7].Width = 100;
            dataGridView2.Columns[8].Width = 200;
            dataGridView2.Columns[9].Width = 100;
            dataGridView2.Columns[10].Width = 100;
            dataGridView2.Columns[11].Width = 100;
            dataGridView2.Columns[12].Width = 120;
            dataGridView2.Columns[13].Width = 120;
        }

        private void haghighirbtn_CheckedChanged(object sender, EventArgs e)
        {
            if(haghighirbtn .Checked ==true )
            {
                dataGridView1.Visible = true;
                dataGridView2.Visible = false;
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = MData.MoshtariShow1();
                set_datagrid();
                this.dataGridView1.Refresh();

            }
            else if(hoghoghirbtn .Checked ==true )
            {
                dataGridView1.Visible = false;
                dataGridView2.Visible = true;
                dataGridView2.DataSource = true;
                dataGridView2.DataSource = SData.SherkatShow1();
                set_datagrid1();
                this.dataGridView2.Refresh();
            }
        }

        private void hoghoghirbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (haghighirbtn.Checked == true)
            {
                dataGridView1.Visible = true;
                dataGridView2.Visible = false;
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = MData.MoshtariShow1();
                set_datagrid();
                this.dataGridView1.Refresh();
            }
            else if (hoghoghirbtn.Checked == true)
            {
                dataGridView1.Visible = false;
                dataGridView2.Visible = true;
                dataGridView2.DataSource = true;
                dataGridView2.DataSource = SData.SherkatShow1();
                set_datagrid1();
                this.dataGridView2.Refresh();
            }
        }

        private void searchnamemtxt_Leave(object sender, EventArgs e)
        {
            searchnamemtxt.BackColor = Color.White;

        }

        private void searchnamemchb_CheckedChanged(object sender, EventArgs e)
        {
            if (searchnamemchb.Checked == true)
            {
                searchnamemtxt.Enabled = true;
                searchnamemtxt.Focus();
            }
            else
            {
                searchnamemtxt.Enabled = false;
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {

            if(haghighirbtn .Checked ==true )
            {
                if (dataGridView1.RowCount == 0)
                {
                    MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
                }
                else
                {
                    if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        int IDMoshtari = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                        int IDHesab = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value);
                        HBData.HesabBankiDelete1(IDHesab);
                        MData.MoshtariDelete1(IDMoshtari);
                        if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                        {
                            this.dataGridView1.EndEdit();
                            this.dataGridView1.Refresh();
                            dataGridView1.DataSource = MData.MoshtariShow1();
                        }
                    }
                }
            }
            else if(hoghoghirbtn .Checked == true )
            {
                if (dataGridView2.RowCount == 0)
                {
                    MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
                }
                else
                {
                    if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        int IDSherkat = Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value);
                        int IDHesab = Convert.ToInt32(dataGridView2.CurrentRow.Cells[1].Value);
                        HBData.HesabBankiDelete1(IDHesab);
                        SData.SherkatDelete1(IDSherkat);
                        if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                        {
                            this.dataGridView2.EndEdit();
                            this.dataGridView2.Refresh();
                            dataGridView2.DataSource = SData.SherkatShow1();
                        }
                    }
                }
            }

        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            if (haghighirbtn.Checked == true)
            {
                frmMoshtariReport obj = new frmMoshtariReport();
                obj.ShowDialog();
            }
            else if (hoghoghirbtn.Checked == true)
            {
                frmSherkatReport obj = new frmSherkatReport();
                obj.ShowDialog();
            }
        }


        
        

      



      
    }
}

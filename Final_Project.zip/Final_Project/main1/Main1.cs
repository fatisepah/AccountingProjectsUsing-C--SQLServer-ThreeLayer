﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace main1
{
    public partial class Main1 : Form
    {
        public Main1()
        {
            InitializeComponent();
        }
    }
}

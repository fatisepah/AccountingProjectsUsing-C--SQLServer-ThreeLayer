﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Globalization;
using System.Diagnostics;
using System.IO;

namespace main1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        CheckData CData = new CheckData();
        CheckDB CDB = new CheckDB();
        //
        KalayeKharidForoshData  KKHFData = new KalayeKharidForoshData ();
        KalayeKharidForoshDB  KKHFDB = new KalayeKharidForoshDB ();
        //
        KalayeKerayeData KKData = new KalayeKerayeData();
        KalayeKerayeDB KKDB = new KalayeKerayeDB();
        //
        FactorData FData = new FactorData();
        FactorDB FDB = new FactorDB();
        //
        RizFactorKerayeData RFKData = new RizFactorKerayeData();
        RizFactorKerayeDB RFKDB = new RizFactorKerayeDB();
        //
        public string Miladi2Shasi(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            StringBuilder sb = new StringBuilder();
            sb.Append(pc.GetYear(date).ToString("0000"));
            sb.Append("/");
            sb.Append(pc.GetMonth(date).ToString("00"));
            sb.Append("/");
            sb.Append(pc.GetDayOfMonth(date).ToString("00"));
            return sb.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Class1.TarikheJari = Miladi2Shasi(DateTime.Now);
            //برای چک کردن تاریخ سر رسید چکهای دریافتی و پرداختی
            DataTable DT = new DataTable();
            DT = CData.CheckSearchID1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                string TarikheSarResid = DT.Rows[i][3].ToString();
                string NameSahebeCheck = DT.Rows[i][4].ToString();
                string VazeiyatePardakht = DT.Rows[i][7].ToString();
                string Mablagh = DT.Rows[i][9].ToString();
                Mablagh = Class1.convert_str(Mablagh);
                TarikheSarResid = Class1.Tarikh(TarikheSarResid);
                TarikheSarResid = TarikheSarResid.Substring(0, 10);
               int TarikheSarResid1 = Convert.ToInt32 (TarikheSarResid.Replace("/",""));
               int TarikheJari1 = Convert.ToInt32(Class1.TarikheJari.Replace("/", "")); 
                if (TarikheSarResid1 <= TarikheJari1)
                {
                    if (VazeiyatePardakht == "پرداخت نشده")
                    {
                        checkpardakhtilbl.Text += " تاریخ چک آقای/خانم/شرکت" +" "+ NameSahebeCheck+" " + "به مبلغ" +" "+ Mablagh +" "+ "سررسیده است\r\n";
                    }
                    if (VazeiyatePardakht == "دریافت نشده")
                    {
                        checkdaryaftilbl.Text += " تاریخ چک آقای/خانم/شرکت" + " " + NameSahebeCheck + " " + "به مبلغ" + " " + Mablagh + " " + "سررسیده است\r\n";
                    }

                }
            }
            DataTable DT1 = new DataTable();
            DT1 = KKHFData.KalayeKharidForoshSearchID1 ();
            for (int i = 0; i < DT1.Rows.Count;i++)
            {
                string NameKala = DT1.Rows[i][3].ToString();
                int HadeaghaleTedad =Convert.ToInt32( DT1.Rows[i][6]);
                int TedadKala =Convert.ToInt32( DT1.Rows[i][7]);
                if(TedadKala <= HadeaghaleTedad )
                {
                    label1.Text = " موجودی کالای " + " " + NameKala + ", " + "به حداقل رسیده است\r\n";
                }
            }
            DataTable DT2 = new DataTable();
            DataTable DT3 = new DataTable();
            DT2 = FData.FactorSearchID1();
            DT3 = RFKData.RizFactorKerayeSearchID1();

            for (int i = 0; i < DT2.Rows.Count; i++)
            {
               int IDFactor = Convert.ToInt32(DT2.Rows[i][0]);
               string NameMoshtari = DT2.Rows[i][4].ToString();

                for (int i1 = 0; i1 < DT3.Rows.Count; i1++)
                {
                    int FKFactor = Convert.ToInt32(DT3.Rows[i1][9]);
                    string TarikheBargasht = DT3.Rows[i1][10].ToString();
                    int TarikheBargasht1 = Convert.ToInt32(TarikheBargasht.Replace("/", ""));
                    int TarikheJari1 = Convert.ToInt32(Class1.TarikheJari.Replace("/", ""));
                    if (FKFactor == IDFactor && TarikheBargasht1 <= TarikheJari1)
                    {
                        label2.Text = " زمان برگشت کالاهای کرایه داده شده به آقای/خانم/شرکت " + " " + NameMoshtari + " " + "سر رسیده است\r\n";
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.System) + Path.DirectorySeparatorChar + "osk.exe");
            
        }
    }
}

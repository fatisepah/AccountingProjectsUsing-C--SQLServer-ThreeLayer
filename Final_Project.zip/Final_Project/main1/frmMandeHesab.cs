﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace main1
{
    public partial class frmMandeHesab : Form
    {
        public frmMandeHesab()
        {
            InitializeComponent();
        }

        private void meli_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.webBrowser1.Url = new System.Uri("https://epayment2.bmi.ir/Remain", System.UriKind.Absolute);
        }

        private void melat_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.webBrowser1.Url = new System.Uri("https://epayment2.bmi.ir/Remain", System.UriKind.Absolute);
        }

        private void saderat_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.webBrowser1.Url = new System.Uri("https://epayment2.bmi.ir/Remain", System.UriKind.Absolute);
        }

        private void tejarat_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.webBrowser1.Url = new System.Uri("https://epayment2.bmi.ir/Remain", System.UriKind.Absolute);
        }

        private void ghavamin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.webBrowser1.Url = new System.Uri("https://epayment2.bmi.ir/Remain", System.UriKind.Absolute);
        }

        private void keshavarzi_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.webBrowser1.Url = new System.Uri("https://epayment2.bmi.ir/Remain", System.UriKind.Absolute);
        }




    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.KalayeKeraye
{
    public partial class frmGroupKala : Form
    {
        public frmGroupKala()
        {
            InitializeComponent();
        }
        GroupKalaData GKData = new GroupKalaData();
        GroupKalaDB GKDB = new GroupKalaDB();

        private void idgroup_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k = 0;
        private void idgroup_TextChanged(object sender, EventArgs e)
        {
            if (idgroup.Text.Length != 0 && k == 1)
            {
                k = 0;
                idgroup.Text = Class1.convert_number(idgroup.Text.Replace(",", ""));
                idgroup.Select(idgroup.Text.Length, 0);
            }
        }
        //
        //
        //

        private void frmGroupKala_Load(object sender, EventArgs e)
        {
            int i1 = 0;
            int i2 = 1;
            DataTable dt = GKData.GroupKalaSearchID1();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                if (i2 < i1)
                {
                    i2 = i1;
                }
            }
            if (dt.Rows.Count == 0)
            {
                idgroup .Text = "1";
            }
            else
            {
                idgroup.Text = Convert.ToString(i2 + 1);
            }
        }
        private void set_color()
        {
            idgroup .BackColor = Color.White;
            namegroup .BackColor = Color.White;
        }

        private void idgroup_Enter(object sender, EventArgs e)
        {
            set_color();
            idgroup.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namegroup_Enter(object sender, EventArgs e)
        {
            set_color();
            namegroup.BackColor = Color.FromArgb(255, 255, 192);
        }


        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            if (idgroup .Text != "" && namegroup .Text != "" )
            {
                GKDB.IDGroupKala = Convert.ToInt32(idgroup .Text);
                GKDB.NameGroup = namegroup .Text;
                if (MessageBox.Show("آیا مایل به ویرایش این رکورد هستید؟", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    GKData.GroupKalaUpdate1(GKDB);
                    MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    idgroup.Text = "";
                    namegroup.Text = "";
                }
         
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int IDGroupKala = Convert.ToInt32(idgroup.Text);
                GKData.GroupKalaDelete1(IDGroupKala);
                MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK);
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            
            if (idgroup.Text != "")
            {
                if (GKData.GroupKalaSearch1(Convert .ToInt32 (idgroup.Text)))
                {
                   GKDB = GKData.GroupKalaFind1(Convert.ToInt32(idgroup.Text));
                   namegroup.Text = GKDB.NameGroup;
                }
                else
                    MessageBox.Show("چنین اطلاعاتی وجود ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(namegroup .Text !="")
            {
                if (GKData.GroupKalaSearchName1(namegroup.Text))
                {
                    GKDB = GKData.GroupKalaFindName1(namegroup.Text);
                    idgroup.Text = GKDB.IDGroupKala.ToString();
                }
                else
                    MessageBox.Show("چنین اطلاعاتی وجود ندارد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void darjbtn_Click(object sender, EventArgs e)
        {
            if (idgroup.Text != "" && namegroup.Text != "")
            {
                GKDB.IDGroupKala = Convert.ToInt32(idgroup.Text);
                GKDB.NameGroup = namegroup.Text;

                if (!GKData.GroupKalaSearch1(GKDB.IDGroupKala))
                {
                    GKData.GroupKalaInsert1(GKDB);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                        Class1.IDHesab = Convert.ToInt32(idgroup.Text);
                        idgroup.Text = "";
                        namegroup.Text = "";

                    }
                }
                else
                {
                    MessageBox.Show("کد گروه کالا تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Web.UI.WebControls;
namespace main1.KalayeKeraye
{
    public partial class frmAddKalayeKeraye : Form
    {
        public frmAddKalayeKeraye()
        {
            InitializeComponent();
        }
        KalayeKerayeData KKData = new KalayeKerayeData();
        KalayeKerayeDB KKDB = new KalayeKerayeDB();
        GroupKalaData GKData = new GroupKalaData();
        ToolTip ttip = new ToolTip();
        //
        //
        //
        private void idgroupmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k4 = 1;
        }
        int k4 = 0;
        private void idgroupmtxt_TextChanged(object sender, EventArgs e)
        {
            if (idgroupmtxt.Text.Length != 0 && k4 == 1)
            {
                k4 = 0;
                idgroupmtxt.Text = Class1.convert_number(idgroupmtxt.Text.Replace(",", ""));
                idgroupmtxt.Select(idgroupmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private void tedadekerayedademtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }
        int k3 = 0;
        private void tedadekerayedademtxt_TextChanged(object sender, EventArgs e)
        {
            if (tedadekerayedademtxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                tedadekerayedademtxt.Text = Class1.convert_str(tedadekerayedademtxt.Text.Replace(",", ""));
                tedadekerayedademtxt.Select(tedadekerayedademtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        int k2 = 0;
        private void tedademojodmtxt_TextChanged(object sender, EventArgs e)
        {
            if (tedademojodmtxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                tedademojodmtxt.Text = Class1.convert_str(tedademojodmtxt.Text.Replace(",", ""));
                tedademojodmtxt.Select(tedademojodmtxt.Text.Length, 0);
            }
        }

        private void tedademojodmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        //
        //
        //
        private void gheimatekerayemtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k = 0;
        private void gheimatekerayemtxt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatekerayemtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                gheimatekerayemtxt.Text = Class1.convert_str(gheimatekerayemtxt.Text.Replace(",", ""));
                gheimatekerayemtxt.Select(gheimatekerayemtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private void gheimatekharidmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        int k1 = 0;
        private void gheimatekharidmtxt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatekharidmtxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                gheimatekharidmtxt.Text = Class1.convert_str(gheimatekharidmtxt.Text.Replace(",", ""));
                gheimatekharidmtxt.Select(gheimatekharidmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAddKalayeKeraye_Load(object sender, EventArgs e)
        {

            //برای قرار دادن نام گروه ها در کمبو باکس

            DataTable DT = GKData.GroupKalaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDGroup = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameGroup = DT.Rows[i][1].ToString();

                ListItem item = new ListItem();
                item.Text = NameGroup;
                item.Value = IDGroup.ToString();

                namegroupcmb.Items.Add(item);
            }
            namegroupcmb.SelectedIndex = 0;
            //
            //
            //
            if (Class1.virayesh != 0)
            {
                KKDB = KKData.KalayeKerayeFind1(Class1.virayesh);
                idkalamtxt.Text = KKDB.IDKalaKeraye .ToString();
                idnoekalakerayemtxt .Text = KKDB.FKNoeKala .ToString();
                idgroupmtxt .Text = KKDB.FKGroupKala.ToString() ;
                namegroupcmb.SelectedIndex = KKDB.FKGroupKala;
                namekalatxt .Text = KKDB.NameKala;
                vaziyatekerayecmb .Text = KKDB.VaziyateKeraye;
                tozihattxt .Text = KKDB.Tozihat;
                gheimatekharidmtxt.Text = Class1 .convert_str (KKDB.GheimateKharid.ToString());
                gheimatekerayemtxt .Text = Class1 .convert_str (KKDB.GheimateKeraye.ToString ()) ;
                tedademojodmtxt .Text = Class1 .convert_str (KKDB.TedadeKalayeMojod.ToString () );
                tedadekerayedademtxt .Text =Class1 .convert_str ( KKDB.TedadeKerayeDadeShode.ToString () );
                garantytxt .Text = KKDB.Garanty;
                modeltxt .Text = KKDB.ModeleKala;
                barcodtxt .Text = KKDB.BarcodeKala;
                sherkattxt.Text = KKDB.NameSherkatTolidi;
            }
            else
            {
                int i1 = 0;
                int i2 = 1;
                DataTable dt = KKData.KalayeKerayeSearchID1();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idkalamtxt.Text = "1";
                }
                else
                {
                    idkalamtxt .Text = Convert.ToString(i2 + 1);
                }

            }
        }
        private void set_color()
        {
            idnoekalakerayemtxt.BackColor = Color.White;
            idgroupmtxt.BackColor = Color.White;
            namegroupcmb.BackColor = Color.White;
            idkalamtxt.BackColor = Color.White;
            namekalatxt.BackColor = Color.White;
            vaziyatekerayecmb.BackColor = Color.White;
            tedademojodmtxt.BackColor = Color.White;
            tedadekerayedademtxt.BackColor = Color.White;
            sherkattxt.BackColor = Color.White;
            modeltxt.BackColor = Color.White;
            barcodtxt.BackColor = Color.White;
            gheimatekharidmtxt.BackColor = Color.White;
            gheimatekerayemtxt.BackColor = Color.White;
            garantytxt.BackColor = Color.White;
            tozihattxt.BackColor = Color.White;
        }

        private void namegroupcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            namegroupcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namekalatxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namekalatxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void vaziyatekerayecmb_Enter(object sender, EventArgs e)
        {
            set_color();
            vaziyatekerayecmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void sherkattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            sherkattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void modeltxt_Enter(object sender, EventArgs e)
        {
            set_color();
            modeltxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void barcodtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            barcodtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void garantytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            garantytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tozihattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tozihattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idgroupmtxt.Text != "" && idkalamtxt.Text != "" && namekalatxt.Text != "" && vaziyatekerayecmb.Text != "" && tedademojodmtxt.Text != "" && tedadekerayedademtxt.Text != "" && gheimatekharidmtxt.Text != "" && gheimatekerayemtxt.Text != "")
            {
                KKDB.IDKalaKeraye  = Convert.ToInt32(idkalamtxt .Text);
                KKDB.FKNoeKala  = Convert.ToInt32(idnoekalakerayemtxt .Text);
                KKDB.FKGroupKala  = Convert.ToInt32(idgroupmtxt .Text);
                KKDB.NameKala  = namekalatxt .Text;
                KKDB.VaziyateKeraye = vaziyatekerayecmb .Text;
                KKDB.Tozihat  = tozihattxt .Text;
                KKDB.GheimateKharid = Convert.ToInt64(gheimatekharidmtxt.Text.Replace(",", ""));
                KKDB.GheimateKeraye = Convert.ToInt64(gheimatekerayemtxt.Text.Replace(",", ""));
                KKDB.TedadeKalayeMojod  = Convert.ToInt32( tedademojodmtxt .Text);
                KKDB.TedadeKerayeDadeShode  = Convert.ToInt32(tedadekerayedademtxt .Text);
                KKDB.Garanty  = garantytxt .Text;
                KKDB.ModeleKala = modeltxt .Text;
                KKDB.BarcodeKala = barcodtxt .Text;
                KKDB.NameSherkatTolidi  = sherkattxt.Text;
                if (Class1.virayesh != 0)
                {
                    if (KKData.KalayeKerayeSearch1 (KKDB.IDKalaKeraye) && Class1.virayesh != KKDB.IDKalaKeraye)
                    {
                        MessageBox.Show(" کد کالای کرایه تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        KKData.KalayeKerayeUpdate1(KKDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                    if (!KKData.KalayeKerayeSearch1 (KKDB.IDKalaKeraye))
                    {
                        KKData.KalayeKerayeInsert1(KKDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد کالای کرایه تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Hide();
            frmKalayeKeraye  kk = new frmKalayeKeraye();
            kk.ShowDialog();
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            idkalamtxt.Text="";
            idnoekalakerayemtxt.Text = "";
            idgroupmtxt.Text = "";
            namegroupcmb.Text = "";
            namekalatxt.Text = "";
            vaziyatekerayecmb.Text = "";
            tozihattxt.Text = "";
            gheimatekharidmtxt.Text = "";
            gheimatekerayemtxt.Text = "";
            tedademojodmtxt.Text = "";
            tedadekerayedademtxt.Text = "";
            garantytxt.Text = "";
            modeltxt.Text = "";
            barcodtxt.Text = "";
            sherkattxt.Text = "";

            this.Close();
        }


        //
        //
        //

        private void idgroupmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idgroupmtxt.BackColor = Color.FromArgb(255, 255, 192);
            ttip.Show("کد گروه را با انتخاب نام گروه مورد نظر بدست بیاورید", idgroupmtxt);
        }
        private void idgroupmtxt_Leave(object sender, EventArgs e)
        {
            ttip.Hide(idgroupmtxt);
        }

        private void idgroupmtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ttip.Hide(idgroupmtxt);
        }

        private void idgroupmtxt_MouseEnter(object sender, EventArgs e)
        {
            ttip.Show("کد گروه را با انتخاب نام گروه مورد نظر بدست بیاورید", idgroupmtxt);
        }

        private void idgroupmtxt_MouseLeave(object sender, EventArgs e)
        {
            ttip.Hide(idgroupmtxt);
        }
        //
        //
        //
        private void idnoekalakerayemtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoekalakerayemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void idkalamtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idkalamtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void tedademojodmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tedademojodmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tedadekerayedademtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tedadekerayedademtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        //
        //
        //
        private void gheimatekharidmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            gheimatekharidmtxt.BackColor = Color.FromArgb(255, 255, 192);
            ttip.Show("قیمت به ریال وارد شود", gheimatekharidmtxt);
        }


        private void gheimatekharidmtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ttip.Hide(gheimatekharidmtxt);
        }

        private void gheimatekharidmtxt_MouseEnter(object sender, EventArgs e)
        {
            ttip.Show("قیمت به ریال وارد شود", gheimatekharidmtxt);
        }

        private void gheimatekharidmtxt_MouseLeave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatekharidmtxt);
        }

        private void gheimatekharidmtxt_Leave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatekharidmtxt);
        }


        //
        //
        //

        private void gheimatekerayemtxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            ttip.Hide(gheimatekerayemtxt);
        }

        private void gheimatekerayemtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            gheimatekerayemtxt.BackColor = Color.FromArgb(255, 255, 192);
            ttip.Show("قیمت به ریال وارد شود", gheimatekerayemtxt);
        }

        private void gheimatekerayemtxt_Leave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatekerayemtxt);
        }

        private void gheimatekerayemtxt_MouseEnter(object sender, EventArgs e)
        {
            ttip.Show("قیمت به ریال وارد شود", gheimatekerayemtxt);
        }

        private void gheimatekerayemtxt_MouseLeave(object sender, EventArgs e)
        {
            ttip.Hide(gheimatekerayemtxt);
        }

        private void namegroupcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable DT = GKData.GroupKalaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDGroup = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameGroup = DT.Rows[i][1].ToString();

                ListItem item = new ListItem();
                item.Text = NameGroup;
                item.Value = IDGroup.ToString();
                if (item.Text == namegroupcmb.Text)
                {
                    idgroupmtxt.Text = IDGroup.ToString();
                }
            }
        }






        //
        //
        //




    }
}

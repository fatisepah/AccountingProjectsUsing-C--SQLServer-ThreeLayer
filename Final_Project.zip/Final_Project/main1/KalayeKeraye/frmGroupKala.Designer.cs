﻿namespace main1.KalayeKeraye
{
    partial class frmGroupKala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGroupKala));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.namegroup = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.idgroup = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.حذفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جستجوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.virayeshbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.searchbtn = new System.Windows.Forms.Button();
            this.darjbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.namegroup);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.idgroup);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(340, 128);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            // 
            // namegroup
            // 
            this.namegroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namegroup.Location = new System.Drawing.Point(68, 75);
            this.namegroup.Name = "namegroup";
            this.namegroup.Size = new System.Drawing.Size(116, 20);
            this.namegroup.TabIndex = 5;
            this.namegroup.Enter += new System.EventHandler(this.namegroup_Enter);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(207, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 23);
            this.label2.TabIndex = 83;
            this.label2.Text = ":نام گروه کالا";
            // 
            // idgroup
            // 
            this.idgroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idgroup.Location = new System.Drawing.Point(68, 36);
            this.idgroup.Name = "idgroup";
            this.idgroup.Size = new System.Drawing.Size(116, 20);
            this.idgroup.TabIndex = 4;
            this.idgroup.TextChanged += new System.EventHandler(this.idgroup_TextChanged);
            this.idgroup.Enter += new System.EventHandler(this.idgroup_Enter);
            this.idgroup.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idgroup_KeyDown);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(207, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 23);
            this.label1.TabIndex = 81;
            this.label1.Text = ":کد گروه";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.انصرافToolStripMenuItem,
            this.ثبتToolStripMenuItem,
            this.ویرایشToolStripMenuItem,
            this.حذفToolStripMenuItem,
            this.جستجوToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(364, 24);
            this.menuStrip1.TabIndex = 60;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // ویرایشToolStripMenuItem
            // 
            this.ویرایشToolStripMenuItem.Name = "ویرایشToolStripMenuItem";
            this.ویرایشToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.ویرایشToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.ویرایشToolStripMenuItem.Text = "ویرایش";
            // 
            // حذفToolStripMenuItem
            // 
            this.حذفToolStripMenuItem.Name = "حذفToolStripMenuItem";
            this.حذفToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.حذفToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.حذفToolStripMenuItem.Text = "حذف";
            // 
            // جستجوToolStripMenuItem
            // 
            this.جستجوToolStripMenuItem.Name = "جستجوToolStripMenuItem";
            this.جستجوToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.جستجوToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.جستجوToolStripMenuItem.Text = "جستجو";
            // 
            // virayeshbtn
            // 
            this.virayeshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.virayeshbtn.Image = ((System.Drawing.Image)(resources.GetObject("virayeshbtn.Image")));
            this.virayeshbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.virayeshbtn.Location = new System.Drawing.Point(135, 187);
            this.virayeshbtn.Name = "virayeshbtn";
            this.virayeshbtn.Size = new System.Drawing.Size(90, 28);
            this.virayeshbtn.TabIndex = 2;
            this.virayeshbtn.Text = "F3  ویرایش";
            this.virayeshbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.virayeshbtn.UseVisualStyleBackColor = true;
            this.virayeshbtn.Click += new System.EventHandler(this.virayeshbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebtn.Image = global::main1.Properties.Resources.cross_script;
            this.deletebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deletebtn.Location = new System.Drawing.Point(42, 187);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(90, 28);
            this.deletebtn.TabIndex = 3;
            this.deletebtn.Text = "Del  حذف";
            this.deletebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(87, 219);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 5;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // searchbtn
            // 
            this.searchbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.searchbtn.Image = global::main1.Properties.Resources.ButtonSearch;
            this.searchbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.searchbtn.Location = new System.Drawing.Point(182, 219);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(90, 28);
            this.searchbtn.TabIndex = 4;
            this.searchbtn.Text = "F5 جستجو";
            this.searchbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchbtn.UseVisualStyleBackColor = true;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // darjbtn
            // 
            this.darjbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darjbtn.Image = global::main1.Properties.Resources.ButtonNew;
            this.darjbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.darjbtn.Location = new System.Drawing.Point(231, 187);
            this.darjbtn.Name = "darjbtn";
            this.darjbtn.Size = new System.Drawing.Size(83, 28);
            this.darjbtn.TabIndex = 61;
            this.darjbtn.Text = "F2  درج ";
            this.darjbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.darjbtn.UseVisualStyleBackColor = true;
            this.darjbtn.Click += new System.EventHandler(this.darjbtn_Click);
            // 
            // frmGroupKala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(364, 257);
            this.Controls.Add(this.darjbtn);
            this.Controls.Add(this.searchbtn);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.virayeshbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.enserafbtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmGroupKala";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن گروه کالا";
            this.Load += new System.EventHandler(this.frmGroupKala_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox namegroup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idgroup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button virayeshbtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem حذفToolStripMenuItem;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.ToolStripMenuItem جستجوToolStripMenuItem;
        private System.Windows.Forms.Button darjbtn;
    }
}
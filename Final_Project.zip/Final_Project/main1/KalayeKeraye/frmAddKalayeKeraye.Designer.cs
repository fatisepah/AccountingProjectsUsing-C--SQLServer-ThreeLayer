﻿namespace main1.KalayeKeraye
{
    partial class frmAddKalayeKeraye
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.vaziyatekerayecmb = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idgroupmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idnoekalakerayemtxt = new System.Windows.Forms.MaskedTextBox();
            this.namegroupcmb = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gheimatekerayemtxt = new System.Windows.Forms.MaskedTextBox();
            this.gheimatekharidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tedadekerayedademtxt = new System.Windows.Forms.MaskedTextBox();
            this.tedademojodmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idkalamtxt = new System.Windows.Forms.MaskedTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.sherkattxt = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tozihattxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.barcodtxt = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.namekalatxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.modeltxt = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.garantytxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // vaziyatekerayecmb
            // 
            this.vaziyatekerayecmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.vaziyatekerayecmb.FormattingEnabled = true;
            this.vaziyatekerayecmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.vaziyatekerayecmb.Items.AddRange(new object[] {
            "کرایه داده شده",
            "کرایه داده نشده"});
            this.vaziyatekerayecmb.Location = new System.Drawing.Point(29, 72);
            this.vaziyatekerayecmb.Name = "vaziyatekerayecmb";
            this.vaziyatekerayecmb.Size = new System.Drawing.Size(116, 21);
            this.vaziyatekerayecmb.TabIndex = 6;
            this.vaziyatekerayecmb.Enter += new System.EventHandler(this.vaziyatekerayecmb_Enter);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(12, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 23);
            this.label9.TabIndex = 68;
            this.label9.Text = "*";
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(219, 41);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(16, 23);
            this.label25.TabIndex = 70;
            this.label25.Text = "*";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.idgroupmtxt);
            this.groupBox1.Controls.Add(this.idnoekalakerayemtxt);
            this.groupBox1.Controls.Add(this.namegroupcmb);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(487, 98);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            // 
            // idgroupmtxt
            // 
            this.idgroupmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idgroupmtxt.Location = new System.Drawing.Point(265, 58);
            this.idgroupmtxt.Name = "idgroupmtxt";
            this.idgroupmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idgroupmtxt.Size = new System.Drawing.Size(116, 20);
            this.idgroupmtxt.TabIndex = 2;
            this.idgroupmtxt.TextChanged += new System.EventHandler(this.idgroupmtxt_TextChanged);
            this.idgroupmtxt.Enter += new System.EventHandler(this.idgroupmtxt_Enter);
            this.idgroupmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idgroupmtxt_KeyDown);
            this.idgroupmtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.idgroupmtxt_KeyPress);
            this.idgroupmtxt.Leave += new System.EventHandler(this.idgroupmtxt_Leave);
            this.idgroupmtxt.MouseEnter += new System.EventHandler(this.idgroupmtxt_MouseEnter);
            this.idgroupmtxt.MouseLeave += new System.EventHandler(this.idgroupmtxt_MouseLeave);
            // 
            // idnoekalakerayemtxt
            // 
            this.idnoekalakerayemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoekalakerayemtxt.Location = new System.Drawing.Point(265, 26);
            this.idnoekalakerayemtxt.Name = "idnoekalakerayemtxt";
            this.idnoekalakerayemtxt.ReadOnly = true;
            this.idnoekalakerayemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoekalakerayemtxt.Size = new System.Drawing.Size(116, 20);
            this.idnoekalakerayemtxt.TabIndex = 1;
            this.idnoekalakerayemtxt.Text = "2";
            this.idnoekalakerayemtxt.Enter += new System.EventHandler(this.idnoekalakerayemtxt_Enter);
            // 
            // namegroupcmb
            // 
            this.namegroupcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namegroupcmb.FormattingEnabled = true;
            this.namegroupcmb.Location = new System.Drawing.Point(29, 56);
            this.namegroupcmb.Name = "namegroupcmb";
            this.namegroupcmb.Size = new System.Drawing.Size(116, 21);
            this.namegroupcmb.TabIndex = 3;
            this.namegroupcmb.SelectedIndexChanged += new System.EventHandler(this.namegroupcmb_SelectedIndexChanged);
            this.namegroupcmb.Enter += new System.EventHandler(this.namegroupcmb_Enter);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(248, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 23);
            this.label12.TabIndex = 69;
            this.label12.Text = "*";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(249, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 23);
            this.label11.TabIndex = 68;
            this.label11.Text = "*";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(154, 59);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 23);
            this.label23.TabIndex = 38;
            this.label23.Text = "نام گروه:";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(389, 60);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 23);
            this.label24.TabIndex = 37;
            this.label24.Text = "کد گروه:";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(386, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(64, 23);
            this.label19.TabIndex = 19;
            this.label19.Text = "کد نوع کالا:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gheimatekerayemtxt);
            this.groupBox2.Controls.Add(this.gheimatekharidmtxt);
            this.groupBox2.Controls.Add(this.tedadekerayedademtxt);
            this.groupBox2.Controls.Add(this.tedademojodmtxt);
            this.groupBox2.Controls.Add(this.idkalamtxt);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.vaziyatekerayecmb);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.sherkattxt);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.tozihattxt);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.barcodtxt);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.namekalatxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.modeltxt);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.garantytxt);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(13, 124);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(487, 350);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "کالای کرایه ای";
            // 
            // gheimatekerayemtxt
            // 
            this.gheimatekerayemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatekerayemtxt.Location = new System.Drawing.Point(29, 217);
            this.gheimatekerayemtxt.Name = "gheimatekerayemtxt";
            this.gheimatekerayemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekerayemtxt.Size = new System.Drawing.Size(116, 20);
            this.gheimatekerayemtxt.TabIndex = 13;
            this.gheimatekerayemtxt.TextChanged += new System.EventHandler(this.gheimatekerayemtxt_TextChanged);
            this.gheimatekerayemtxt.Enter += new System.EventHandler(this.gheimatekerayemtxt_Enter);
            this.gheimatekerayemtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatekerayemtxt_KeyDown);
            this.gheimatekerayemtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gheimatekerayemtxt_KeyPress);
            this.gheimatekerayemtxt.Leave += new System.EventHandler(this.gheimatekerayemtxt_Leave);
            this.gheimatekerayemtxt.MouseEnter += new System.EventHandler(this.gheimatekerayemtxt_MouseEnter);
            this.gheimatekerayemtxt.MouseLeave += new System.EventHandler(this.gheimatekerayemtxt_MouseLeave);
            // 
            // gheimatekharidmtxt
            // 
            this.gheimatekharidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatekharidmtxt.Location = new System.Drawing.Point(265, 217);
            this.gheimatekharidmtxt.Name = "gheimatekharidmtxt";
            this.gheimatekharidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekharidmtxt.Size = new System.Drawing.Size(116, 20);
            this.gheimatekharidmtxt.TabIndex = 12;
            this.gheimatekharidmtxt.TextChanged += new System.EventHandler(this.gheimatekharidmtxt_TextChanged);
            this.gheimatekharidmtxt.Enter += new System.EventHandler(this.gheimatekharidmtxt_Enter);
            this.gheimatekharidmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatekharidmtxt_KeyDown);
            this.gheimatekharidmtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gheimatekharidmtxt_KeyPress);
            this.gheimatekharidmtxt.Leave += new System.EventHandler(this.gheimatekharidmtxt_Leave);
            this.gheimatekharidmtxt.MouseEnter += new System.EventHandler(this.gheimatekharidmtxt_MouseEnter);
            this.gheimatekharidmtxt.MouseLeave += new System.EventHandler(this.gheimatekharidmtxt_MouseLeave);
            // 
            // tedadekerayedademtxt
            // 
            this.tedadekerayedademtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tedadekerayedademtxt.Location = new System.Drawing.Point(29, 110);
            this.tedadekerayedademtxt.Name = "tedadekerayedademtxt";
            this.tedadekerayedademtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadekerayedademtxt.Size = new System.Drawing.Size(116, 20);
            this.tedadekerayedademtxt.TabIndex = 8;
            this.tedadekerayedademtxt.TextChanged += new System.EventHandler(this.tedadekerayedademtxt_TextChanged);
            this.tedadekerayedademtxt.Enter += new System.EventHandler(this.tedadekerayedademtxt_Enter);
            this.tedadekerayedademtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedadekerayedademtxt_KeyDown);
            // 
            // tedademojodmtxt
            // 
            this.tedademojodmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tedademojodmtxt.Location = new System.Drawing.Point(265, 110);
            this.tedademojodmtxt.Name = "tedademojodmtxt";
            this.tedademojodmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedademojodmtxt.Size = new System.Drawing.Size(116, 20);
            this.tedademojodmtxt.TabIndex = 7;
            this.tedademojodmtxt.TextChanged += new System.EventHandler(this.tedademojodmtxt_TextChanged);
            this.tedademojodmtxt.Enter += new System.EventHandler(this.tedademojodmtxt_Enter);
            this.tedademojodmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedademojodmtxt_KeyDown);
            // 
            // idkalamtxt
            // 
            this.idkalamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idkalamtxt.Location = new System.Drawing.Point(236, 37);
            this.idkalamtxt.Name = "idkalamtxt";
            this.idkalamtxt.ReadOnly = true;
            this.idkalamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idkalamtxt.Size = new System.Drawing.Size(116, 20);
            this.idkalamtxt.TabIndex = 4;
            this.idkalamtxt.Enter += new System.EventHandler(this.idkalamtxt_Enter);
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(11, 220);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(16, 23);
            this.label26.TabIndex = 76;
            this.label26.Text = "*";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(248, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 23);
            this.label6.TabIndex = 75;
            this.label6.Text = "*";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(382, 112);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 23);
            this.label17.TabIndex = 73;
            this.label17.Text = "تعداد کالای موجود:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(148, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 23);
            this.label8.TabIndex = 68;
            this.label8.Text = "وضعیت کرایه:";
            // 
            // sherkattxt
            // 
            this.sherkattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sherkattxt.Location = new System.Drawing.Point(29, 144);
            this.sherkattxt.Name = "sherkattxt";
            this.sherkattxt.Size = new System.Drawing.Size(352, 20);
            this.sherkattxt.TabIndex = 9;
            this.sherkattxt.Enter += new System.EventHandler(this.sherkattxt_Enter);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(388, 146);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(93, 23);
            this.label20.TabIndex = 65;
            this.label20.Text = "شرکت تولید کننده:";
            // 
            // tozihattxt
            // 
            this.tozihattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tozihattxt.Location = new System.Drawing.Point(29, 290);
            this.tozihattxt.Multiline = true;
            this.tozihattxt.Name = "tozihattxt";
            this.tozihattxt.Size = new System.Drawing.Size(352, 46);
            this.tozihattxt.TabIndex = 15;
            this.tozihattxt.Enter += new System.EventHandler(this.tozihattxt_Enter);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(353, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 23);
            this.label10.TabIndex = 19;
            this.label10.Text = "کد کالای کرایه ای:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(386, 291);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 63;
            this.label1.Text = "توضیحات:";
            // 
            // barcodtxt
            // 
            this.barcodtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.barcodtxt.Location = new System.Drawing.Point(29, 181);
            this.barcodtxt.Mask = "9999999999999";
            this.barcodtxt.Name = "barcodtxt";
            this.barcodtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcodtxt.Size = new System.Drawing.Size(116, 20);
            this.barcodtxt.TabIndex = 11;
            this.barcodtxt.Enter += new System.EventHandler(this.barcodtxt_Enter);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(145, 183);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 23);
            this.label18.TabIndex = 56;
            this.label18.Text = "بارکد کالا:";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(11, 147);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 23);
            this.label15.TabIndex = 55;
            this.label15.Text = "*";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(145, 219);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 23);
            this.label16.TabIndex = 53;
            this.label16.Text = "قیمت کرایه:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(248, 220);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 23);
            this.label13.TabIndex = 52;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(388, 219);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 23);
            this.label14.TabIndex = 50;
            this.label14.Text = "قیمت خرید:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(249, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 23);
            this.label4.TabIndex = 47;
            this.label4.Text = "*";
            // 
            // namekalatxt
            // 
            this.namekalatxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namekalatxt.Location = new System.Drawing.Point(265, 73);
            this.namekalatxt.Name = "namekalatxt";
            this.namekalatxt.Size = new System.Drawing.Size(116, 20);
            this.namekalatxt.TabIndex = 5;
            this.namekalatxt.Enter += new System.EventHandler(this.namekalatxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(11, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 45;
            this.label5.Text = "*";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(137, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 23);
            this.label3.TabIndex = 43;
            this.label3.Text = "تعداد کالای کرایه داده:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(385, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 23);
            this.label2.TabIndex = 42;
            this.label2.Text = "نام کالا:";
            // 
            // modeltxt
            // 
            this.modeltxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.modeltxt.Location = new System.Drawing.Point(265, 181);
            this.modeltxt.Name = "modeltxt";
            this.modeltxt.Size = new System.Drawing.Size(116, 20);
            this.modeltxt.TabIndex = 10;
            this.modeltxt.Enter += new System.EventHandler(this.modeltxt_Enter);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(387, 182);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 23);
            this.label21.TabIndex = 33;
            this.label21.Text = "مدل کالا:";
            // 
            // garantytxt
            // 
            this.garantytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.garantytxt.Location = new System.Drawing.Point(29, 253);
            this.garantytxt.Name = "garantytxt";
            this.garantytxt.Size = new System.Drawing.Size(352, 20);
            this.garantytxt.TabIndex = 14;
            this.garantytxt.Enter += new System.EventHandler(this.garantytxt_Enter);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(382, 255);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 23);
            this.label7.TabIndex = 2;
            this.label7.Text = "گارانتی:";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(158, 496);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 17;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(253, 496);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 16;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 80;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // frmAddKalayeKeraye
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 541);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddKalayeKeraye";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن کالای کرایه";
            this.Load += new System.EventHandler(this.frmAddKalayeKeraye_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox vaziyatekerayecmb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox namegroupcmb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox sherkattxt;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tozihattxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox barcodtxt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox namekalatxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox modeltxt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox garantytxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.MaskedTextBox idgroupmtxt;
        private System.Windows.Forms.MaskedTextBox idnoekalakerayemtxt;
        private System.Windows.Forms.MaskedTextBox gheimatekerayemtxt;
        private System.Windows.Forms.MaskedTextBox gheimatekharidmtxt;
        private System.Windows.Forms.MaskedTextBox tedadekerayedademtxt;
        private System.Windows.Forms.MaskedTextBox tedademojodmtxt;
        private System.Windows.Forms.MaskedTextBox idkalamtxt;
    }
}
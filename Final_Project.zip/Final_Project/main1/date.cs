﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace main1
{
   public  class date
    {
        int Start_day = 0;
        int year = 1383;
        string st = "";

        public  string print()
        {
            set_date();
            return st;
        }
        public  void set_date()
        {
            DateTime century, century1;
            century = new DateTime(2004, 3, 20);
            century1 = DateTime.Now;
            int k, day = 0;
            while (true)
            {
                century = century.AddDays(1);
                day++;
                if (String.Compare(century.ToLongDateString(), century1.ToLongDateString()) == 0)
                    break;
            }
            if (day >= 366)
            {
                k = 0;
                while (day >= 0)
                {
                    if ((k % 4) == 0)
                    {
                        if (day > 366)
                            date_iran(366, 30, Start_day);
                        else
                            date_iran(day, 30, Start_day);
                        day -= 366;
                    }
                    else
                    {
                        if (day > 365)
                            date_iran(365, 29, Start_day);
                        else
                            date_iran(day, 29, Start_day);
                        day -= 365;
                    }
                    k += 1;
                    year += 1;
                }

            }
            else
                date_iran(day, 30, Start_day);
        }

        private void date_iran(int day, int k, int j)
        {
            int[][] number;
            number = new int[12][];
            number[0] = new int[31];
            number[1] = new int[31];
            number[2] = new int[31];
            number[3] = new int[31];
            number[4] = new int[31];
            number[5] = new int[31];
            number[6] = new int[30];
            number[7] = new int[30];
            number[8] = new int[30];
            number[9] = new int[30];
            number[10] = new int[30];
            number[11] = new int[k];
            for (int i = 0; i <= 365; i++)
            {
                if (i <= 185)
                {
                    number[i / 31][i % 31] = (j + 1) % 7;
                    if (i == day)
                    {
                        Month(i / 31, (i % 31) + 1, ((j + 1) % 7));
                        return;
                    }
                }
                else if (i <= 335)
                {
                    number[(i - 6) / 30][(i - 6) % 30] = (j + 1) % 7;
                    if (i == day)
                    {
                        Month((i - 6) / 30, (i - 6) % 30 + 1, ((j + 1) % 7));
                        return;
                    }
                }
                else
                {
                    try
                    {
                        number[11][(i - 6) % 30] = (j + 1) % 7;
                        if (i == day)
                        {
                            Month(11, (i - 6) % 30 + 1, ((j + 1) % 7));
                            return;
                        }
                    }
                    catch
                    {
                    }
                }
                j += 1;

            }
            Start_day = number[11][k - 1];
        }

        private void Month(int Month, int day, int weekday)
        {
            string str = "";
            if (weekday == 1)
                str += "شنبه";
            else if (weekday == 2)
                str += "يك شنبه";
            else if (weekday == 3)
                str += "دوشنبه";
            else if (weekday == 4)
                str += "سه شنبه";
            else if (weekday == 5)
                str += "چهارشنبه";
            else if (weekday == 6)
                str += "پنج شنبه";
            else if (weekday == 0)
                str += "جمعه";

            str += " " + day + " ";

            if (Month == 0)
                str += "فروردين";
            else if (Month == 1)
                str += "ارديبشهت";
            else if (Month == 2)
                str += "خرداد";
            else if (Month == 3)
                str += "تير";
            else if (Month == 4)
                str += "مرداد";
            else if (Month == 5)
                str += "شهريور";
            else if (Month == 6)
                str += "مهر";
            else if (Month == 7)
                str += "آبان";
            else if (Month == 8)
                str += "آذر";
            else if (Month == 9)
                str += "دي";
            else if (Month == 10)
                str += "بهمن";
            else if (Month == 11)
                str += "اسفند";
            str += " " + year.ToString();
            st = str;
        }
    }
}

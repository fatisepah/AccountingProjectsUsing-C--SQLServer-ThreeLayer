﻿namespace main1.Taraconeshha
{
    partial class frmAddCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tarikhsarresidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.nameshobetxt = new System.Windows.Forms.TextBox();
            this.mablaghecheckmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.idchecktxt = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.vaziyatepardakhtcmb = new System.Windows.Forms.ComboBox();
            this.namebankcmb = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.serialechecktxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.namesahebechecktxt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tarikhesabtecheckmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idnoetaraconeshtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tarikhsarresidmtxt);
            this.groupBox2.Controls.Add(this.nameshobetxt);
            this.groupBox2.Controls.Add(this.mablaghecheckmtxt);
            this.groupBox2.Controls.Add(this.label57);
            this.groupBox2.Controls.Add(this.idchecktxt);
            this.groupBox2.Controls.Add(this.label58);
            this.groupBox2.Controls.Add(this.vaziyatepardakhtcmb);
            this.groupBox2.Controls.Add(this.namebankcmb);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.serialechecktxt);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.namesahebechecktxt);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Location = new System.Drawing.Point(9, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(495, 234);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "اطلاعات چک";
            // 
            // tarikhsarresidmtxt
            // 
            this.tarikhsarresidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhsarresidmtxt.Location = new System.Drawing.Point(265, 71);
            this.tarikhsarresidmtxt.Mask = "9999/99/99";
            this.tarikhsarresidmtxt.Name = "tarikhsarresidmtxt";
            this.tarikhsarresidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhsarresidmtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhsarresidmtxt.TabIndex = 5;
            this.tarikhsarresidmtxt.Enter += new System.EventHandler(this.tarikhsarresidmtxt_Enter);
            // 
            // nameshobetxt
            // 
            this.nameshobetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameshobetxt.Location = new System.Drawing.Point(24, 107);
            this.nameshobetxt.Name = "nameshobetxt";
            this.nameshobetxt.Size = new System.Drawing.Size(117, 20);
            this.nameshobetxt.TabIndex = 8;
            this.nameshobetxt.Enter += new System.EventHandler(this.nameshobetxt_Enter);
            // 
            // mablaghecheckmtxt
            // 
            this.mablaghecheckmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mablaghecheckmtxt.Location = new System.Drawing.Point(265, 182);
            this.mablaghecheckmtxt.Name = "mablaghecheckmtxt";
            this.mablaghecheckmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghecheckmtxt.Size = new System.Drawing.Size(117, 20);
            this.mablaghecheckmtxt.TabIndex = 11;
            this.mablaghecheckmtxt.TextChanged += new System.EventHandler(this.mablaghecheckmtxt_TextChanged);
            this.mablaghecheckmtxt.Enter += new System.EventHandler(this.mablaghecheckmtxt_Enter);
            this.mablaghecheckmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghecheckmtxt_KeyDown);
            // 
            // label57
            // 
            this.label57.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label57.ForeColor = System.Drawing.Color.Red;
            this.label57.Location = new System.Drawing.Point(248, 39);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(16, 23);
            this.label57.TabIndex = 184;
            this.label57.Text = "*";
            // 
            // idchecktxt
            // 
            this.idchecktxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idchecktxt.Location = new System.Drawing.Point(265, 35);
            this.idchecktxt.Name = "idchecktxt";
            this.idchecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idchecktxt.Size = new System.Drawing.Size(117, 20);
            this.idchecktxt.TabIndex = 4;
            this.idchecktxt.TextChanged += new System.EventHandler(this.idchecktxt_TextChanged);
            this.idchecktxt.Enter += new System.EventHandler(this.idchecktxt_Enter);
            this.idchecktxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idchecktxt_KeyDown);
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(386, 37);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(46, 23);
            this.label58.TabIndex = 182;
            this.label58.Text = "کد چک:";
            // 
            // vaziyatepardakhtcmb
            // 
            this.vaziyatepardakhtcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.vaziyatepardakhtcmb.FormattingEnabled = true;
            this.vaziyatepardakhtcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.vaziyatepardakhtcmb.Items.AddRange(new object[] {
            "پرداخت شده",
            "پرداخت نشده",
            "وصول شده",
            "وصول نشده"});
            this.vaziyatepardakhtcmb.Location = new System.Drawing.Point(265, 143);
            this.vaziyatepardakhtcmb.Name = "vaziyatepardakhtcmb";
            this.vaziyatepardakhtcmb.Size = new System.Drawing.Size(117, 21);
            this.vaziyatepardakhtcmb.TabIndex = 9;
            this.vaziyatepardakhtcmb.Enter += new System.EventHandler(this.vaziyatepardakhtcmb_Enter);
            // 
            // namebankcmb
            // 
            this.namebankcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namebankcmb.FormattingEnabled = true;
            this.namebankcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namebankcmb.Items.AddRange(new object[] {
            "سپه",
            "ملی",
            "تجارت",
            "کشاورزی",
            "ملت",
            "اقتصاد نوین",
            "پاسارگاد",
            "پارسیان",
            "قوامین",
            "صادرات",
            "رفاه کارگران",
            ""});
            this.namebankcmb.Location = new System.Drawing.Point(265, 106);
            this.namebankcmb.Name = "namebankcmb";
            this.namebankcmb.Size = new System.Drawing.Size(117, 21);
            this.namebankcmb.TabIndex = 7;
            this.namebankcmb.Enter += new System.EventHandler(this.namebankcmb_Enter);
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(248, 187);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(16, 23);
            this.label25.TabIndex = 179;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(378, 184);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 23);
            this.label26.TabIndex = 178;
            this.label26.Text = "مبلغ چک:";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(7, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 23);
            this.label8.TabIndex = 177;
            this.label8.Text = "*";
            // 
            // serialechecktxt
            // 
            this.serialechecktxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.serialechecktxt.Location = new System.Drawing.Point(24, 144);
            this.serialechecktxt.Name = "serialechecktxt";
            this.serialechecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.serialechecktxt.Size = new System.Drawing.Size(117, 20);
            this.serialechecktxt.TabIndex = 10;
            this.serialechecktxt.TextChanged += new System.EventHandler(this.serialechecktxt_TextChanged);
            this.serialechecktxt.Enter += new System.EventHandler(this.serialechecktxt_Enter);
            this.serialechecktxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.serialechecktxt_KeyDown);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(149, 147);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 23);
            this.label9.TabIndex = 175;
            this.label9.Text = "شماره سریال چک:";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(248, 149);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 23);
            this.label10.TabIndex = 174;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(376, 146);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 23);
            this.label11.TabIndex = 173;
            this.label11.Text = "وضعیت پرداخت/وصول:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(7, 111);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 23);
            this.label12.TabIndex = 172;
            this.label12.Text = "*";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(145, 109);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 23);
            this.label13.TabIndex = 171;
            this.label13.Text = "نام شعبه بانک:";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(248, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 23);
            this.label14.TabIndex = 170;
            this.label14.Text = "*";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(248, 76);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 23);
            this.label15.TabIndex = 169;
            this.label15.Text = "*";
            // 
            // namesahebechecktxt
            // 
            this.namesahebechecktxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesahebechecktxt.Location = new System.Drawing.Point(24, 71);
            this.namesahebechecktxt.Name = "namesahebechecktxt";
            this.namesahebechecktxt.Size = new System.Drawing.Size(117, 20);
            this.namesahebechecktxt.TabIndex = 6;
            this.namesahebechecktxt.Enter += new System.EventHandler(this.namesahebechecktxt_Enter);
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(8, 74);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 23);
            this.label16.TabIndex = 167;
            this.label16.Text = "*";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(146, 74);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 23);
            this.label18.TabIndex = 166;
            this.label18.Text = "نام صاحب چک:";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(386, 109);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 23);
            this.label20.TabIndex = 165;
            this.label20.Text = "نام بانک:";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(386, 73);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(78, 23);
            this.label21.TabIndex = 163;
            this.label21.Text = "تاریخ سررسید:";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(162, 354);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 13;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(261, 354);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 12;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tarikhesabtecheckmtxt);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.idnoetaraconeshtxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(9, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(495, 70);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // tarikhesabtecheckmtxt
            // 
            this.tarikhesabtecheckmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhesabtecheckmtxt.Location = new System.Drawing.Point(24, 25);
            this.tarikhesabtecheckmtxt.Name = "tarikhesabtecheckmtxt";
            this.tarikhesabtecheckmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesabtecheckmtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhesabtecheckmtxt.TabIndex = 3;
            this.tarikhesabtecheckmtxt.Enter += new System.EventHandler(this.tarikhesabtecheckmtxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(7, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 193;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(148, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 23);
            this.label6.TabIndex = 192;
            this.label6.Text = ":تاریخ ثبت چک";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(248, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 187;
            this.label1.Text = "*";
            // 
            // idnoetaraconeshtxt
            // 
            this.idnoetaraconeshtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoetaraconeshtxt.Location = new System.Drawing.Point(265, 25);
            this.idnoetaraconeshtxt.Name = "idnoetaraconeshtxt";
            this.idnoetaraconeshtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoetaraconeshtxt.Size = new System.Drawing.Size(117, 20);
            this.idnoetaraconeshtxt.TabIndex = 1;
            this.idnoetaraconeshtxt.Text = "1";
            this.idnoetaraconeshtxt.TextChanged += new System.EventHandler(this.idnoetaraconeshtxt_TextChanged);
            this.idnoetaraconeshtxt.Enter += new System.EventHandler(this.idnoetaraconeshtxt_Enter);
            this.idnoetaraconeshtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnoetaraconeshtxt_KeyDown);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(390, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 23);
            this.label2.TabIndex = 185;
            this.label2.Text = ":کد نوع تراکنش ";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 80;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // frmAddCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 397);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddCheck";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه  کردن چک";
            this.Load += new System.EventHandler(this.frmAddCheck_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox nameshobetxt;
        private System.Windows.Forms.MaskedTextBox mablaghecheckmtxt;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox idchecktxt;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox vaziyatepardakhtcmb;
        private System.Windows.Forms.ComboBox namebankcmb;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox serialechecktxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox namesahebechecktxt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.MaskedTextBox tarikhsarresidmtxt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox idnoetaraconeshtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.MaskedTextBox tarikhesabtecheckmtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Taraconeshha
{
    public partial class frmAddGhesty : Form
    {
        public frmAddGhesty()
        {
            InitializeComponent();
        }
        GhestyData GSData = new GhestyData();
        GhestyDB GSDB = new GhestyDB();
        //
        //
        private void idnoetaraconeshtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k = 0;
        private void idnoetaraconeshtxt_TextChanged(object sender, EventArgs e)
        {
            if (idnoetaraconeshtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                idnoetaraconeshtxt.Text = Class1.convert_number(idnoetaraconeshtxt.Text.Replace(",", ""));
                idnoetaraconeshtxt.Select(idnoetaraconeshtxt.Text.Length, 0);
            }
        }

        private void idghestytxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        int k1 = 0;
        private void idghestytxt_TextChanged(object sender, EventArgs e)
        {
            if (idghestytxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idghestytxt.Text = Class1.convert_number(idghestytxt.Text.Replace(",", ""));
                idghestytxt.Select(idghestytxt.Text.Length, 0);
            }
        }

        private void tedadeaghsatmandetxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        int k2 = 0;
        private void tedadeaghsatmandetxt_TextChanged(object sender, EventArgs e)
        {
            if (tedadeaghsattxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                tedadeaghsattxt.Text = Class1.convert_number(tedadeaghsattxt.Text.Replace(",", ""));
                tedadeaghsattxt.Select(tedadeaghsattxt.Text.Length, 0);
            }
        }

        private void tedadeaghsatepardakhtitxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }
        int k3 = 0;
        private void tedadeaghsatepardakhtitxt_TextChanged(object sender, EventArgs e)
        {
            if (tedadeaghsatemandetxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                tedadeaghsatemandetxt.Text = Class1.convert_number(tedadeaghsatemandetxt.Text.Replace(",", ""));
                tedadeaghsatemandetxt.Select(tedadeaghsatemandetxt.Text.Length, 0);
            }
        }
        int k4 = 0;
        private void mablagheghestmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k4 = 1;
        }

        private void mablagheghestmtxt_TextChanged(object sender, EventArgs e)
        {
            if (mablagheghestmtxt.Text.Length != 0 && k4 == 1)
            {
                k4 = 0;
                mablagheghestmtxt.Text = Class1.convert_str (mablagheghestmtxt.Text.Replace(",", ""));
                mablagheghestmtxt.Select(mablagheghestmtxt.Text.Length, 0);
            }
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idnoetaraconeshtxt.Text != "" && tarikhesabtecheckmtxt.Text != "" && idghestytxt.Text != "" && tarikhepardakhtmtxt.Text != "    /  /" && namesahebeghesttxt.Text != "" && tedadeaghsattxt.Text != "" && tedadeaghsatemandetxt.Text != "" && mablagheghestmtxt.Text != "" && darsadsodtxt.Text != "")
            {
                GSDB.IDGhesty = Convert.ToInt32(idghestytxt.Text);
                GSDB.FKNoeTaraconesh = Convert.ToInt32(idnoetaraconeshtxt.Text);
                GSDB.TarikheSabteGhesti  = Convert.ToDateTime(tarikhesabtecheckmtxt.Text);
                GSDB.NameDahandeGhest = namesahebeghesttxt.Text;
                GSDB.TedadeAghsat  = Convert.ToInt32 (tedadeaghsattxt .Text);
                GSDB.TarikhePardakhteAghsat  = Convert.ToDateTime(tarikhepardakhtmtxt.Text);
                GSDB.TedadeAghsateMande  =Convert.ToInt32 ( tedadeaghsatemandetxt .Text);
                GSDB.MablagheGhest =Convert.ToInt64 ( mablagheghestmtxt .Text.Replace (",",""));
                GSDB.DarsadeSodeGhest = darsadsodtxt.Text;
                if (Class1.virayesh != 0)
                {
                    if (GSData.GhestySearch1 (GSDB.IDGhesty ) && Class1.virayesh != GSDB.IDGhesty )
                    {
                        MessageBox.Show(" کد قسط تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        GSData.GhestyUpdate1 (GSDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDGhesty = Convert.ToInt32(idghestytxt.Text);                            
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                    if (!GSData.GhestySearch1 (GSDB.IDGhesty ))
                    { 
                        GSData.GhestyInsert1 (GSDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDGhesty = Convert.ToInt32(idghestytxt .Text);                            
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد قسط تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            frmGhesty ghs = new frmGhesty();
            ghs.ShowDialog();
        }

        private void frmAddGhesty_Load(object sender, EventArgs e)
        {
            namesahebeghesttxt .Text = Class1.NameMoshtari;
            if (Class1.virayesh != 0)
            {
                GSDB = GSData.GhestyFind1 (Class1.virayesh);
                idghestytxt .Text = GSDB.IDGhesty.ToString();
                idnoetaraconeshtxt.Text = GSDB.FKNoeTaraconesh.ToString();
                string s = GSDB.TarikheSabteGhesti.ToString();
                tarikhesabtecheckmtxt.Text = Class1.Tarikh(s);
                namesahebeghesttxt .Text = GSDB.NameDahandeGhest;
                tedadeaghsattxt .Text = GSDB.TedadeAghsat .ToString();
                string s1 = GSDB.TarikhePardakhteAghsat.ToString();
                tarikhepardakhtmtxt.Text = Class1.Tarikh(s1);
                tedadeaghsatemandetxt .Text = GSDB.TedadeAghsateMande .ToString();
                mablagheghestmtxt .Text =Class1 .convert_str ( GSDB.MablagheGhest.ToString ());
                darsadsodtxt .Text = GSDB.DarsadeSodeGhest;
            }
            else
            {
                int i1 = 0;
                int i2 = 1;
                DataTable dt = GSData.GhestySearchID1 ();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idghestytxt .Text = "1";
                }
                else
                {
                    idghestytxt.Text = Convert.ToString(i2 + 1);
                }

            }
        }
        private void set_color()
        {
            idnoetaraconeshtxt.BackColor = Color.White;
            tarikhesabtecheckmtxt.BackColor = Color.White;
            idghestytxt .BackColor = Color.White;
            tarikhepardakhtmtxt .BackColor = Color.White;
            tedadeaghsatemandetxt .BackColor = Color.White;
            tedadeaghsattxt .BackColor = Color.White;
            mablagheghestmtxt .BackColor = Color.White;
            darsadsodtxt .BackColor = Color.White;
            namesahebeghesttxt .BackColor = Color.White;
        }

        private void idnoetaraconeshtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoetaraconeshtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void tarikhesabtecheckmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhesabtecheckmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idghestytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idghestytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhepardakhtmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhepardakhtmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesahebeghesttxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namesahebeghesttxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tedadeaghsattxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tedadeaghsattxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tedadeaghsatemandetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tedadeaghsatemandetxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void mablagheghestmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mablagheghestmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void darsadsodtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            darsadsodtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
    }
}

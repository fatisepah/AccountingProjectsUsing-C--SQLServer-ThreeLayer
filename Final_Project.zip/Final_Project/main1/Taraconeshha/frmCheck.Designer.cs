﻿namespace main1.Taraconeshha
{
    partial class frmCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCheck));
            this.بالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پایینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tarikhsarresidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.vaziyatepardakhtcmb = new System.Windows.Forms.ComboBox();
            this.namesahebtxt = new System.Windows.Forms.TextBox();
            this.tarikhsarresidrbtn = new System.Windows.Forms.RadioButton();
            this.vaziyatepardakhtrbtn = new System.Windows.Forms.RadioButton();
            this.namesahebrbtn = new System.Windows.Forms.RadioButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.printbtn = new System.Windows.Forms.Button();
            this.deletebtn = new System.Windows.Forms.Button();
            this.virayeshbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.darjbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // بالاToolStripMenuItem
            // 
            this.بالاToolStripMenuItem.Name = "بالاToolStripMenuItem";
            this.بالاToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.Tab)));
            this.بالاToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
            this.بالاToolStripMenuItem.Text = "بالا";
            this.بالاToolStripMenuItem.Click += new System.EventHandler(this.بالاToolStripMenuItem_Click);
            // 
            // پایینToolStripMenuItem
            // 
            this.پایینToolStripMenuItem.Name = "پایینToolStripMenuItem";
            this.پایینToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.پایینToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.پایینToolStripMenuItem.Text = "پایین";
            this.پایینToolStripMenuItem.Click += new System.EventHandler(this.پایینToolStripMenuItem_Click);
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tarikhsarresidmtxt);
            this.groupBox1.Controls.Add(this.vaziyatepardakhtcmb);
            this.groupBox1.Controls.Add(this.namesahebtxt);
            this.groupBox1.Controls.Add(this.tarikhsarresidrbtn);
            this.groupBox1.Controls.Add(this.vaziyatepardakhtrbtn);
            this.groupBox1.Controls.Add(this.namesahebrbtn);
            this.groupBox1.Location = new System.Drawing.Point(11, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(491, 124);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "جستجو";
            // 
            // tarikhsarresidmtxt
            // 
            this.tarikhsarresidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhsarresidmtxt.Location = new System.Drawing.Point(137, 27);
            this.tarikhsarresidmtxt.Mask = "9999/99/99";
            this.tarikhsarresidmtxt.Name = "tarikhsarresidmtxt";
            this.tarikhsarresidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhsarresidmtxt.Size = new System.Drawing.Size(124, 20);
            this.tarikhsarresidmtxt.TabIndex = 188;
            this.tarikhsarresidmtxt.TextChanged += new System.EventHandler(this.tarikhsarresidmtxt_TextChanged);
            // 
            // vaziyatepardakhtcmb
            // 
            this.vaziyatepardakhtcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.vaziyatepardakhtcmb.FormattingEnabled = true;
            this.vaziyatepardakhtcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.vaziyatepardakhtcmb.Items.AddRange(new object[] {
            "پرداخت شده",
            "پرداخت نشده",
            "وصول شده",
            "وصول نشده"});
            this.vaziyatepardakhtcmb.Location = new System.Drawing.Point(137, 87);
            this.vaziyatepardakhtcmb.Name = "vaziyatepardakhtcmb";
            this.vaziyatepardakhtcmb.Size = new System.Drawing.Size(124, 21);
            this.vaziyatepardakhtcmb.TabIndex = 6;
            this.vaziyatepardakhtcmb.TextChanged += new System.EventHandler(this.vaziyatepardakhtcmb_TextChanged);
            this.vaziyatepardakhtcmb.Enter += new System.EventHandler(this.vaziyatepardakhtcmb_Enter);
            this.vaziyatepardakhtcmb.Leave += new System.EventHandler(this.vaziyatepardakhtcmb_Leave);
            // 
            // namesahebtxt
            // 
            this.namesahebtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesahebtxt.Location = new System.Drawing.Point(137, 57);
            this.namesahebtxt.Name = "namesahebtxt";
            this.namesahebtxt.Size = new System.Drawing.Size(124, 20);
            this.namesahebtxt.TabIndex = 4;
            this.namesahebtxt.TextChanged += new System.EventHandler(this.namesahebtxt_TextChanged);
            this.namesahebtxt.Enter += new System.EventHandler(this.namesahebtxt_Enter);
            this.namesahebtxt.Leave += new System.EventHandler(this.namesahebtxt_Leave);
            // 
            // tarikhsarresidrbtn
            // 
            this.tarikhsarresidrbtn.AutoSize = true;
            this.tarikhsarresidrbtn.Location = new System.Drawing.Point(292, 27);
            this.tarikhsarresidrbtn.Name = "tarikhsarresidrbtn";
            this.tarikhsarresidrbtn.Size = new System.Drawing.Size(152, 17);
            this.tarikhsarresidrbtn.TabIndex = 1;
            this.tarikhsarresidrbtn.TabStop = true;
            this.tarikhsarresidrbtn.Text = "براساس تاریخ سررسید چک";
            this.tarikhsarresidrbtn.UseVisualStyleBackColor = true;
            this.tarikhsarresidrbtn.CheckedChanged += new System.EventHandler(this.tarikhsarresidrbtn_CheckedChanged);
            // 
            // vaziyatepardakhtrbtn
            // 
            this.vaziyatepardakhtrbtn.AutoSize = true;
            this.vaziyatepardakhtrbtn.Location = new System.Drawing.Point(287, 88);
            this.vaziyatepardakhtrbtn.Name = "vaziyatepardakhtrbtn";
            this.vaziyatepardakhtrbtn.Size = new System.Drawing.Size(157, 17);
            this.vaziyatepardakhtrbtn.TabIndex = 5;
            this.vaziyatepardakhtrbtn.TabStop = true;
            this.vaziyatepardakhtrbtn.Text = "براساس وضعیت پرداخت چک";
            this.vaziyatepardakhtrbtn.UseVisualStyleBackColor = true;
            this.vaziyatepardakhtrbtn.CheckedChanged += new System.EventHandler(this.vaziyatepardakhtrbtn_CheckedChanged);
            // 
            // namesahebrbtn
            // 
            this.namesahebrbtn.AutoSize = true;
            this.namesahebrbtn.Location = new System.Drawing.Point(312, 57);
            this.namesahebrbtn.Name = "namesahebrbtn";
            this.namesahebrbtn.Size = new System.Drawing.Size(132, 17);
            this.namesahebrbtn.TabIndex = 3;
            this.namesahebrbtn.TabStop = true;
            this.namesahebrbtn.Text = "براساس نام صاحب چک";
            this.namesahebrbtn.UseVisualStyleBackColor = true;
            this.namesahebrbtn.CheckedChanged += new System.EventHandler(this.namesahebrbtn_CheckedChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(11, 151);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(491, 243);
            this.dataGridView1.TabIndex = 65;
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.چاپToolStripMenuItem.Text = "چاپ";
            this.چاپToolStripMenuItem.Click += new System.EventHandler(this.چاپToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.انصرافToolStripMenuItem,
            this.بالاToolStripMenuItem,
            this.پایینToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 66;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // printbtn
            // 
            this.printbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printbtn.Image = ((System.Drawing.Image)(resources.GetObject("printbtn.Image")));
            this.printbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printbtn.Location = new System.Drawing.Point(126, 409);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(85, 28);
            this.printbtn.TabIndex = 10;
            this.printbtn.Text = "F7  چاپ";
            this.printbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.printbtn.UseVisualStyleBackColor = true;
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // deletebtn
            // 
            this.deletebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebtn.Image = global::main1.Properties.Resources.cross_script;
            this.deletebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deletebtn.Location = new System.Drawing.Point(215, 409);
            this.deletebtn.Name = "deletebtn";
            this.deletebtn.Size = new System.Drawing.Size(85, 28);
            this.deletebtn.TabIndex = 9;
            this.deletebtn.Text = "Del  حذف";
            this.deletebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deletebtn.UseVisualStyleBackColor = true;
            this.deletebtn.Click += new System.EventHandler(this.deletebtn_Click);
            // 
            // virayeshbtn
            // 
            this.virayeshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.virayeshbtn.Image = ((System.Drawing.Image)(resources.GetObject("virayeshbtn.Image")));
            this.virayeshbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.virayeshbtn.Location = new System.Drawing.Point(304, 409);
            this.virayeshbtn.Name = "virayeshbtn";
            this.virayeshbtn.Size = new System.Drawing.Size(85, 28);
            this.virayeshbtn.TabIndex = 8;
            this.virayeshbtn.Text = "F3  ویرایش";
            this.virayeshbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.virayeshbtn.UseVisualStyleBackColor = true;
            this.virayeshbtn.Click += new System.EventHandler(this.virayeshbtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(32, 409);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 11;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // darjbtn
            // 
            this.darjbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darjbtn.Image = global::main1.Properties.Resources.ButtonNew;
            this.darjbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.darjbtn.Location = new System.Drawing.Point(393, 409);
            this.darjbtn.Name = "darjbtn";
            this.darjbtn.Size = new System.Drawing.Size(83, 28);
            this.darjbtn.TabIndex = 7;
            this.darjbtn.Text = "F2  درج ";
            this.darjbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.darjbtn.UseVisualStyleBackColor = true;
            this.darjbtn.Click += new System.EventHandler(this.darjbtn_Click);
            // 
            // frmCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 455);
            this.Controls.Add(this.printbtn);
            this.Controls.Add(this.deletebtn);
            this.Controls.Add(this.virayeshbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.darjbtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmCheck";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم چک";
            this.Load += new System.EventHandler(this.frmCheck_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem بالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پایینToolStripMenuItem;
        private System.Windows.Forms.Button printbtn;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.Button deletebtn;
        private System.Windows.Forms.Button virayeshbtn;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox namesahebtxt;
        private System.Windows.Forms.RadioButton tarikhsarresidrbtn;
        private System.Windows.Forms.RadioButton vaziyatepardakhtrbtn;
        private System.Windows.Forms.RadioButton namesahebrbtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button darjbtn;
        private System.Windows.Forms.ComboBox vaziyatepardakhtcmb;
        private System.Windows.Forms.MaskedTextBox tarikhsarresidmtxt;
    }
}
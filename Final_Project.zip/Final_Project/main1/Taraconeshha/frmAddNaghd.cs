﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Taraconeshha
{
    public partial class frmAddNaghd : Form
    {
        public frmAddNaghd()
        {
            InitializeComponent();
        }
        NaghdData NData = new NaghdData();
        NaghdDB NDB = new NaghdDB();
        //
        //

        private void frmAddNaghd_Load(object sender, EventArgs e)
        {
            pardakhtkonandetxt.Text = Class1.NameMoshtari;
            if (Class1.virayesh != 0)
            {
                NDB = NData.NaghdFind1 (Class1.virayesh);
                idnaghdytxt .Text = NDB.IDNaghdy.ToString();
                idnoetaraconeshtxt.Text = NDB.FKNoeTaraconesh.ToString();
                string s = NDB.TarikheSabteNaghdy.ToString();
                tarikhesabtmtxt.Text = Class1.Tarikh(s);
                pardakhtkonandetxt .Text = NDB.NamePardakhtKonande;
                mablaghenaghdmtxt .Text =Class1 .convert_str ( NDB.MablagheNaghdy.ToString());
            }
            else
            {
                tarikhesabtmtxt.Text = Class1.TarikheJari + " " + Class1.SaateJari;
                int i1 = 0;
                int i2 = 1;
                DataTable dt = NData.NaghdSearchID1 ();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idnaghdytxt.Text = "1";
                }
                else
                {
                    idnaghdytxt .Text = Convert.ToString(i2 + 1);
                }

            }
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idnoetaraconeshtxt.Text != "" && idnaghdytxt.Text != "" && tarikhesabtmtxt.Text != "" && pardakhtkonandetxt.Text != "" && mablaghenaghdmtxt.Text != "")
            {
                NDB.IDNaghdy = Convert.ToInt32(idnaghdytxt .Text);
                NDB.FKNoeTaraconesh = Convert.ToInt32(idnoetaraconeshtxt.Text);
                NDB.TarikheSabteNaghdy = Convert.ToDateTime(tarikhesabtmtxt .Text);
                NDB.NamePardakhtKonande  = pardakhtkonandetxt .Text;
                NDB.MablagheNaghdy = Convert.ToInt64(mablaghenaghdmtxt .Text.Replace (",",""));
                if (Class1.virayesh != 0)
                {
                    if (NData.NaghdSearch1 (NDB.IDNaghdy ) && Class1.virayesh != NDB.IDNaghdy )
                    {
                        MessageBox.Show(" کد نقد تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        NData.NaghdUpdate1 (NDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDNaghdy = Convert.ToInt32(idnaghdytxt.Text);
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                    if (!NData.NaghdSearch1 (NDB.IDNaghdy ))
                    {
                        NData.NaghdInsert1 (NDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDNaghdy = Convert.ToInt32(idnaghdytxt.Text);
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد نقد تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            frmNaghd Ngh = new frmNaghd();
            Ngh.ShowDialog();
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        int k = 0;
        private void idnoetaraconeshtxt_TextChanged(object sender, EventArgs e)
        {
            if (idnoetaraconeshtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                idnoetaraconeshtxt.Text = Class1.convert_number(idnoetaraconeshtxt.Text.Replace(",", ""));
                idnoetaraconeshtxt.Select(idnoetaraconeshtxt.Text.Length, 0);
            }
        }
        private void idnoetaraconeshtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k1 = 0;
        private void idnaghdytxt_TextChanged(object sender, EventArgs e)
        {
            if (idnaghdytxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idnaghdytxt.Text = Class1.convert_number(idnaghdytxt.Text.Replace(",", ""));
                idnaghdytxt.Select(idnaghdytxt.Text.Length, 0);
            }
        }
        private void idnaghdytxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }


        int k2 = 0;
        private void mablaghenaghdmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }

        private void mablaghenaghdmtxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghenaghdmtxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                mablaghenaghdmtxt.Text = Class1.convert_str(mablaghenaghdmtxt.Text.Replace(",", ""));
                mablaghenaghdmtxt.Select(mablaghenaghdmtxt.Text.Length, 0);
            }
        }

        private void idnoetaraconeshtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoetaraconeshtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void tarikhesabtmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhesabtmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idnaghdytxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnaghdytxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void mablaghenaghdmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mablaghenaghdmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void pardakhtkonandetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            pardakhtkonandetxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void set_color()
        {
            idnoetaraconeshtxt.BackColor = Color.White;
            tarikhesabtmtxt .BackColor = Color.White;
            idnaghdytxt .BackColor = Color.White;
            mablaghenaghdmtxt .BackColor = Color.White;
            pardakhtkonandetxt .BackColor = Color.White;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Taraconeshha
{
    public partial class frmAddHavale : Form
    {
        public frmAddHavale()
        {
            InitializeComponent();
        }
        HavaleData HVData = new HavaleData();
        HavaleDB HVDB = new HavaleDB();

        int k = 0;
        private void idnoetaraconeshtxt_TextChanged(object sender, EventArgs e)
        {
            if (idnoetaraconeshtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                idnoetaraconeshtxt.Text = Class1.convert_number(idnoetaraconeshtxt.Text.Replace(",", ""));
                idnoetaraconeshtxt.Select(idnoetaraconeshtxt.Text.Length, 0);
            }
        }

        private void idnoetaraconeshtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        //
        //
        int k1 = 0;
        private void idhavaletxt_TextChanged(object sender, EventArgs e)
        {
            if (idhavaletxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idhavaletxt.Text = Class1.convert_number(idhavaletxt.Text.Replace(",", ""));
                idhavaletxt.Select(idhavaletxt.Text.Length, 0);
            }
        }

        private void idhavaletxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        //
        //
        int k2 = 0;
        private void serialhavaletxt_TextChanged(object sender, EventArgs e)
        {
            if (serialhavaletxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                serialhavaletxt.Text = Class1.convert_number(serialhavaletxt.Text.Replace(",", ""));
                serialhavaletxt.Select(serialhavaletxt.Text.Length, 0);
            }
        }

        private void serialhavaletxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        //
        //
        int k3 = 0;
        private void mablaghehavalemtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }

        private void mablaghehavalemtxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghehavalemtxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                mablaghehavalemtxt.Text = Class1.convert_str(mablaghehavalemtxt.Text.Replace(",", ""));
                mablaghehavalemtxt.Select(mablaghehavalemtxt.Text.Length, 0);
            }
        }
        //
        //
        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void idnoetaraconeshtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoetaraconeshtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void tarikhesabtecheckmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhesabtehavalemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idhavaletxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idhavaletxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhsarresidmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhsarresidmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesahebtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namesahebtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namebankcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            namebankcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void shobetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            shobetxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void vaziyatepardakhtcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            vaziyatepardakhtcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void serialhavaletxt_Enter(object sender, EventArgs e)
        {
            set_color();
            serialhavaletxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void mablaghehavalemtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mablaghehavalemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void set_color()
        {
            idnoetaraconeshtxt.BackColor = Color.White;
            tarikhesabtehavalemtxt.BackColor = Color.White;
            idhavaletxt .BackColor = Color.White;
            tarikhsarresidmtxt.BackColor = Color.White;
            namesahebtxt .BackColor = Color.White;
            namebankcmb.BackColor = Color.White;
            shobetxt.BackColor = Color.White;
            vaziyatepardakhtcmb.BackColor = Color.White;
            serialhavaletxt .BackColor = Color.White;
            mablaghehavalemtxt .BackColor = Color.White;
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idhavaletxt.Text != "" && idnoetaraconeshtxt.Text != "" && tarikhesabtehavalemtxt.Text != "" && tarikhsarresidmtxt.Text != "    /  /" && namesahebtxt.Text != "" && namebankcmb.Text != "" && shobetxt.Text != "" && vaziyatepardakhtcmb.Text != "" && serialhavaletxt.Text != "" && mablaghehavalemtxt.Text != "")
            {
                HVDB.IDHavale = Convert.ToInt32(idhavaletxt .Text);
                HVDB.FKNoeTaraconesh = Convert.ToInt32(idnoetaraconeshtxt.Text);
                HVDB.TarikheSabteHavale  = Convert.ToDateTime(tarikhesabtehavalemtxt.Text);
                HVDB.NameHavaleDahande  = namesahebtxt.Text;
                HVDB.TarikheSarResideHavale  = Convert.ToDateTime(tarikhsarresidmtxt.Text);
                HVDB.NameBank = namebankcmb.Text;
                HVDB.ShobeBank =shobetxt  .Text;
                HVDB.VazeiyatePardakhtOrVosol = vaziyatepardakhtcmb.Text;
                HVDB.ShomareSerialeHavale  = serialhavaletxt .Text;
                HVDB.MablagheHavale = Convert.ToInt64(mablaghehavalemtxt .Text.Replace(",", ""));
                if (Class1.virayesh != 0)
                {
                    if (HVData.HavaleSearch1 (HVDB.IDHavale ) && Class1.virayesh != HVDB.IDHavale)
                    {
                        MessageBox.Show(" کد حواله تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        HVData.HavaleUpdate1 (HVDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDHavale = Convert.ToInt32(idhavaletxt.Text);                            
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                    if (!HVData.HavaleSearch1 (HVDB.IDHavale ))
                    {
                        HVData.HavaleInsert1 (HVDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDHavale = Convert.ToInt32(idhavaletxt.Text);                            
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد حواله تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            frmHavale Hvl = new frmHavale();
            Hvl.ShowDialog();
        }

        private void frmAddHavale_Load(object sender, EventArgs e)
        {
            namesahebtxt.Text = Class1.NameMoshtari;
            if (Class1.virayesh != 0)
            {
                HVDB = HVData.HavaleFind1(Class1.virayesh);
                idhavaletxt.Text = HVDB.IDHavale.ToString();
                idnoetaraconeshtxt.Text = HVDB.FKNoeTaraconesh.ToString();
                string s = HVDB.TarikheSabteHavale.ToString();
                tarikhesabtehavalemtxt.Text = Class1.Tarikh(s);
                namesahebtxt.Text = HVDB.NameHavaleDahande.ToString();
                string s1 = HVDB.TarikheSarResideHavale.ToString();
                tarikhsarresidmtxt.Text = Class1.Tarikh(s1);
                namebankcmb.Text = HVDB.NameBank;
                shobetxt.Text = HVDB.ShobeBank.ToString();
                vaziyatepardakhtcmb.Text = HVDB.VazeiyatePardakhtOrVosol;
                serialhavaletxt.Text = HVDB.ShomareSerialeHavale;
                mablaghehavalemtxt.Text =Class1 .convert_str ( HVDB.MablagheHavale.ToString());
            }
            else
            {
                tarikhesabtehavalemtxt .Text = Class1.TarikheJari + " " + Class1.SaateJari;
                int i1 = 0;
                int i2 = 1;
                DataTable dt = HVData.HavaleSearchID1();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idhavaletxt.Text = "1";
                }
                else
                {
                    idhavaletxt.Text = Convert.ToString(i2 + 1);
                }

            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        //
        //

    }
}

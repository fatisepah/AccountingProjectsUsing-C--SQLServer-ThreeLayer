﻿namespace main1.Taraconeshha
{
    partial class frmAddGhesty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mablagheghestmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tarikhepardakhtmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tedadeaghsatemandetxt = new System.Windows.Forms.TextBox();
            this.tedadeaghsattxt = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.idghestytxt = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.darsadsodtxt = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.namesahebeghesttxt = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tarikhesabtecheckmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idnoetaraconeshtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mablagheghestmtxt);
            this.groupBox1.Controls.Add(this.tarikhepardakhtmtxt);
            this.groupBox1.Controls.Add(this.tedadeaghsatemandetxt);
            this.groupBox1.Controls.Add(this.tedadeaghsattxt);
            this.groupBox1.Controls.Add(this.label59);
            this.groupBox1.Controls.Add(this.idghestytxt);
            this.groupBox1.Controls.Add(this.label60);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.darsadsodtxt);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.namesahebeghesttxt);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Location = new System.Drawing.Point(9, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(495, 214);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "اطلاعات قسطی";
            // 
            // mablagheghestmtxt
            // 
            this.mablagheghestmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mablagheghestmtxt.Location = new System.Drawing.Point(260, 149);
            this.mablagheghestmtxt.Name = "mablagheghestmtxt";
            this.mablagheghestmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablagheghestmtxt.Size = new System.Drawing.Size(117, 20);
            this.mablagheghestmtxt.TabIndex = 9;
            this.mablagheghestmtxt.TextChanged += new System.EventHandler(this.mablagheghestmtxt_TextChanged);
            this.mablagheghestmtxt.Enter += new System.EventHandler(this.mablagheghestmtxt_Enter);
            this.mablagheghestmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablagheghestmtxt_KeyDown);
            // 
            // tarikhepardakhtmtxt
            // 
            this.tarikhepardakhtmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhepardakhtmtxt.Location = new System.Drawing.Point(260, 73);
            this.tarikhepardakhtmtxt.Mask = "9999/99/99";
            this.tarikhepardakhtmtxt.Name = "tarikhepardakhtmtxt";
            this.tarikhepardakhtmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhepardakhtmtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhepardakhtmtxt.TabIndex = 5;
            this.tarikhepardakhtmtxt.Enter += new System.EventHandler(this.tarikhepardakhtmtxt_Enter);
            // 
            // tedadeaghsatemandetxt
            // 
            this.tedadeaghsatemandetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tedadeaghsatemandetxt.Location = new System.Drawing.Point(19, 111);
            this.tedadeaghsatemandetxt.Name = "tedadeaghsatemandetxt";
            this.tedadeaghsatemandetxt.Size = new System.Drawing.Size(117, 20);
            this.tedadeaghsatemandetxt.TabIndex = 8;
            this.tedadeaghsatemandetxt.TextChanged += new System.EventHandler(this.tedadeaghsatepardakhtitxt_TextChanged);
            this.tedadeaghsatemandetxt.Enter += new System.EventHandler(this.tedadeaghsatemandetxt_Enter);
            this.tedadeaghsatemandetxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedadeaghsatepardakhtitxt_KeyDown);
            // 
            // tedadeaghsattxt
            // 
            this.tedadeaghsattxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tedadeaghsattxt.Location = new System.Drawing.Point(260, 111);
            this.tedadeaghsattxt.Name = "tedadeaghsattxt";
            this.tedadeaghsattxt.Size = new System.Drawing.Size(117, 20);
            this.tedadeaghsattxt.TabIndex = 7;
            this.tedadeaghsattxt.TextChanged += new System.EventHandler(this.tedadeaghsatmandetxt_TextChanged);
            this.tedadeaghsattxt.Enter += new System.EventHandler(this.tedadeaghsattxt_Enter);
            this.tedadeaghsattxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedadeaghsatmandetxt_KeyDown);
            // 
            // label59
            // 
            this.label59.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label59.ForeColor = System.Drawing.Color.Red;
            this.label59.Location = new System.Drawing.Point(243, 40);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(16, 23);
            this.label59.TabIndex = 169;
            this.label59.Text = "*";
            // 
            // idghestytxt
            // 
            this.idghestytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idghestytxt.Location = new System.Drawing.Point(260, 35);
            this.idghestytxt.Name = "idghestytxt";
            this.idghestytxt.Size = new System.Drawing.Size(117, 20);
            this.idghestytxt.TabIndex = 4;
            this.idghestytxt.TextChanged += new System.EventHandler(this.idghestytxt_TextChanged);
            this.idghestytxt.Enter += new System.EventHandler(this.idghestytxt_Enter);
            this.idghestytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idghestytxt_KeyDown);
            // 
            // label60
            // 
            this.label60.Location = new System.Drawing.Point(379, 37);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(62, 23);
            this.label60.TabIndex = 167;
            this.label60.Text = "کد قسطی:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(243, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 23);
            this.label3.TabIndex = 166;
            this.label3.Text = "*";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(376, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 23);
            this.label7.TabIndex = 165;
            this.label7.Text = "مبلغ پرداختی هر قسط:";
            // 
            // label43
            // 
            this.label43.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(2, 154);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(16, 23);
            this.label43.TabIndex = 164;
            this.label43.Text = "*";
            // 
            // darsadsodtxt
            // 
            this.darsadsodtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.darsadsodtxt.Location = new System.Drawing.Point(19, 149);
            this.darsadsodtxt.Name = "darsadsodtxt";
            this.darsadsodtxt.Size = new System.Drawing.Size(117, 20);
            this.darsadsodtxt.TabIndex = 10;
            this.darsadsodtxt.Enter += new System.EventHandler(this.darsadsodtxt_Enter);
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(136, 151);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(99, 23);
            this.label44.TabIndex = 162;
            this.label44.Text = "درصد سود قسطی:";
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label47.ForeColor = System.Drawing.Color.Red;
            this.label47.Location = new System.Drawing.Point(2, 115);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(16, 23);
            this.label47.TabIndex = 161;
            this.label47.Text = "*";
            // 
            // label48
            // 
            this.label48.Location = new System.Drawing.Point(127, 113);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(103, 23);
            this.label48.TabIndex = 160;
            this.label48.Text = "تعداد اقساط مانده:";
            // 
            // label49
            // 
            this.label49.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.Location = new System.Drawing.Point(243, 114);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(16, 23);
            this.label49.TabIndex = 159;
            this.label49.Text = "*";
            // 
            // label50
            // 
            this.label50.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.Red;
            this.label50.Location = new System.Drawing.Point(243, 78);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(16, 23);
            this.label50.TabIndex = 158;
            this.label50.Text = "*";
            // 
            // namesahebeghesttxt
            // 
            this.namesahebeghesttxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesahebeghesttxt.Location = new System.Drawing.Point(19, 73);
            this.namesahebeghesttxt.Name = "namesahebeghesttxt";
            this.namesahebeghesttxt.Size = new System.Drawing.Size(117, 20);
            this.namesahebeghesttxt.TabIndex = 6;
            this.namesahebeghesttxt.Enter += new System.EventHandler(this.namesahebeghesttxt_Enter);
            // 
            // label51
            // 
            this.label51.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label51.ForeColor = System.Drawing.Color.Red;
            this.label51.Location = new System.Drawing.Point(3, 76);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(16, 23);
            this.label51.TabIndex = 156;
            this.label51.Text = "*";
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(135, 76);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(85, 23);
            this.label52.TabIndex = 155;
            this.label52.Text = "نام قسط دهنده:";
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(380, 113);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(67, 23);
            this.label53.TabIndex = 154;
            this.label53.Text = "تعداد اقساط:";
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(373, 75);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(108, 23);
            this.label54.TabIndex = 153;
            this.label54.Text = "تاریخ پرداخت اقساط:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tarikhesabtecheckmtxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.idnoetaraconeshtxt);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(9, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(495, 69);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // tarikhesabtecheckmtxt
            // 
            this.tarikhesabtecheckmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhesabtecheckmtxt.Location = new System.Drawing.Point(19, 25);
            this.tarikhesabtecheckmtxt.Name = "tarikhesabtecheckmtxt";
            this.tarikhesabtecheckmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesabtecheckmtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhesabtecheckmtxt.TabIndex = 3;
            this.tarikhesabtecheckmtxt.Enter += new System.EventHandler(this.tarikhesabtecheckmtxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(2, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 193;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(143, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 23);
            this.label6.TabIndex = 192;
            this.label6.Text = ":تاریخ ثبت حواله";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(243, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 187;
            this.label1.Text = "*";
            // 
            // idnoetaraconeshtxt
            // 
            this.idnoetaraconeshtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoetaraconeshtxt.Location = new System.Drawing.Point(260, 25);
            this.idnoetaraconeshtxt.Name = "idnoetaraconeshtxt";
            this.idnoetaraconeshtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoetaraconeshtxt.Size = new System.Drawing.Size(117, 20);
            this.idnoetaraconeshtxt.TabIndex = 1;
            this.idnoetaraconeshtxt.Text = "3";
            this.idnoetaraconeshtxt.TextChanged += new System.EventHandler(this.idnoetaraconeshtxt_TextChanged);
            this.idnoetaraconeshtxt.Enter += new System.EventHandler(this.idnoetaraconeshtxt_Enter);
            this.idnoetaraconeshtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnoetaraconeshtxt_KeyDown);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(383, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 23);
            this.label2.TabIndex = 185;
            this.label2.Text = ":کد نوع تراکنش ";
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(263, 329);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 11;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 82;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(164, 329);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 12;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // frmAddGhesty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 373);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddGhesty";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن پرداخت قسط";
            this.Load += new System.EventHandler(this.frmAddGhesty_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox tarikhesabtecheckmtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox idnoetaraconeshtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.MaskedTextBox mablagheghestmtxt;
        private System.Windows.Forms.MaskedTextBox tarikhepardakhtmtxt;
        private System.Windows.Forms.TextBox tedadeaghsatemandetxt;
        private System.Windows.Forms.TextBox tedadeaghsattxt;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox idghestytxt;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox darsadsodtxt;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox namesahebeghesttxt;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
    }
}
﻿namespace main1.Taraconeshha
{
    partial class frmAddNaghd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tarikhesabtmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idnoetaraconeshtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mablaghenaghdmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.idnaghdytxt = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.pardakhtkonandetxt = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tarikhesabtmtxt);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.idnoetaraconeshtxt);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(10, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(495, 66);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // tarikhesabtmtxt
            // 
            this.tarikhesabtmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhesabtmtxt.Location = new System.Drawing.Point(23, 25);
            this.tarikhesabtmtxt.Name = "tarikhesabtmtxt";
            this.tarikhesabtmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesabtmtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhesabtmtxt.TabIndex = 3;
            this.tarikhesabtmtxt.Enter += new System.EventHandler(this.tarikhesabtmtxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(6, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 193;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(147, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 23);
            this.label6.TabIndex = 192;
            this.label6.Text = ":تاریخ ثبت حواله";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(247, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 187;
            this.label1.Text = "*";
            // 
            // idnoetaraconeshtxt
            // 
            this.idnoetaraconeshtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoetaraconeshtxt.Location = new System.Drawing.Point(264, 25);
            this.idnoetaraconeshtxt.Name = "idnoetaraconeshtxt";
            this.idnoetaraconeshtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoetaraconeshtxt.Size = new System.Drawing.Size(117, 20);
            this.idnoetaraconeshtxt.TabIndex = 1;
            this.idnoetaraconeshtxt.Text = "4";
            this.idnoetaraconeshtxt.TextChanged += new System.EventHandler(this.idnoetaraconeshtxt_TextChanged);
            this.idnoetaraconeshtxt.Enter += new System.EventHandler(this.idnoetaraconeshtxt_Enter);
            this.idnoetaraconeshtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnoetaraconeshtxt_KeyDown);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(387, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 23);
            this.label2.TabIndex = 185;
            this.label2.Text = ":کد نوع تراکنش ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mablaghenaghdmtxt);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.idnaghdytxt);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.label61);
            this.groupBox1.Controls.Add(this.pardakhtkonandetxt);
            this.groupBox1.Controls.Add(this.label62);
            this.groupBox1.Controls.Add(this.label63);
            this.groupBox1.Controls.Add(this.label64);
            this.groupBox1.Location = new System.Drawing.Point(10, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(494, 118);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "اطلاعات پرداخت نقدی";
            // 
            // mablaghenaghdmtxt
            // 
            this.mablaghenaghdmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mablaghenaghdmtxt.Location = new System.Drawing.Point(264, 68);
            this.mablaghenaghdmtxt.Name = "mablaghenaghdmtxt";
            this.mablaghenaghdmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghenaghdmtxt.Size = new System.Drawing.Size(117, 20);
            this.mablaghenaghdmtxt.TabIndex = 5;
            this.mablaghenaghdmtxt.TextChanged += new System.EventHandler(this.mablaghenaghdmtxt_TextChanged);
            this.mablaghenaghdmtxt.Enter += new System.EventHandler(this.mablaghenaghdmtxt_Enter);
            this.mablaghenaghdmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghenaghdmtxt_KeyDown);
            // 
            // label45
            // 
            this.label45.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label45.ForeColor = System.Drawing.Color.Red;
            this.label45.Location = new System.Drawing.Point(247, 38);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(16, 23);
            this.label45.TabIndex = 161;
            this.label45.Text = "*";
            // 
            // idnaghdytxt
            // 
            this.idnaghdytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnaghdytxt.Location = new System.Drawing.Point(264, 34);
            this.idnaghdytxt.Name = "idnaghdytxt";
            this.idnaghdytxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnaghdytxt.Size = new System.Drawing.Size(117, 20);
            this.idnaghdytxt.TabIndex = 4;
            this.idnaghdytxt.TextChanged += new System.EventHandler(this.idnaghdytxt_TextChanged);
            this.idnaghdytxt.Enter += new System.EventHandler(this.idnaghdytxt_Enter);
            this.idnaghdytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnaghdytxt_KeyDown);
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(382, 36);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(54, 23);
            this.label46.TabIndex = 159;
            this.label46.Text = "کد نقدی:";
            // 
            // label61
            // 
            this.label61.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label61.ForeColor = System.Drawing.Color.Red;
            this.label61.Location = new System.Drawing.Point(247, 73);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(16, 23);
            this.label61.TabIndex = 158;
            this.label61.Text = "*";
            // 
            // pardakhtkonandetxt
            // 
            this.pardakhtkonandetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pardakhtkonandetxt.Location = new System.Drawing.Point(23, 68);
            this.pardakhtkonandetxt.Name = "pardakhtkonandetxt";
            this.pardakhtkonandetxt.Size = new System.Drawing.Size(117, 20);
            this.pardakhtkonandetxt.TabIndex = 5;
            this.pardakhtkonandetxt.Enter += new System.EventHandler(this.pardakhtkonandetxt_Enter);
            // 
            // label62
            // 
            this.label62.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label62.ForeColor = System.Drawing.Color.Red;
            this.label62.Location = new System.Drawing.Point(7, 71);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(16, 23);
            this.label62.TabIndex = 156;
            this.label62.Text = "*";
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(134, 71);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(98, 23);
            this.label63.TabIndex = 155;
            this.label63.Text = "نام پرداخت کننده:";
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(379, 70);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(65, 23);
            this.label64.TabIndex = 154;
            this.label64.Text = "مبلغ نقدی:";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(162, 232);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 7;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(261, 232);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 6;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 83;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // frmAddNaghd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 275);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddNaghd";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن پرداخت نقدی";
            this.Load += new System.EventHandler(this.frmAddNaghd_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox tarikhesabtmtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox idnoetaraconeshtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox mablaghenaghdmtxt;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox idnaghdytxt;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox pardakhtkonandetxt;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
    }
}
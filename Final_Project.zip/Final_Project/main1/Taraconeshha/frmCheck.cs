﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Taraconeshha
{
    public partial class frmCheck : Form
    {
        public frmCheck()
        {
            InitializeComponent();
        }
        CheckData CData = new CheckData();
        CheckDB CDB = new CheckDB();
        //
        //
        //
        //
        //
        //

        private void tarikhsarresidtxt_Enter(object sender, EventArgs e)
        {
            tarikhsarresidmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhsarresidtxt_Leave(object sender, EventArgs e)
        {
            tarikhsarresidmtxt.BackColor = Color.White;
        }

        private void namesahebtxt_Enter(object sender, EventArgs e)
        {
            namesahebtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesahebtxt_Leave(object sender, EventArgs e)
        {
            namesahebtxt.BackColor = Color.White;
        }

        private void vaziyatepardakhtcmb_Leave(object sender, EventArgs e)
        {
            vaziyatepardakhtcmb.BackColor = Color.White;
        }

        private void vaziyatepardakhtcmb_Enter(object sender, EventArgs e)
        {
            vaziyatepardakhtcmb.BackColor = Color.FromArgb(255, 255, 192);
        }
        //
        //
        //
        private void darjbtn_Click(object sender, EventArgs e)
        {
           Taraconeshha. frmAddCheck  obj = new frmAddCheck   ();
            obj.ShowDialog();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = CData.CheckShow1 ();
            set_datagrid();
        }

        private void چاپToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }

        private void frmCheck_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = CData.CheckShow1 ();
            set_datagrid();
            tarikhsarresidrbtn .Checked = true;
            namesahebtxt .Enabled = false;
            vaziyatepardakhtcmb.Enabled = false;
            dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
            tarikhsarresidmtxt.Focus();
            tarikhsarresidmtxt.BackColor = Color.FromArgb(255, 255, 192);

        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد چک ";
            dataGridView1.Columns[1].HeaderText = " کد نوع تراکنش ";
            dataGridView1.Columns[2].HeaderText = " تاریخ ثبت چک ";
            dataGridView1.Columns[3].HeaderText = " تاریخ سررسید چک ";
            dataGridView1.Columns[4].HeaderText = " نام صاحب چک ";
            dataGridView1.Columns[5].HeaderText = " نام بانک ";
            dataGridView1.Columns[6].HeaderText = " شعبه بانک ";
            dataGridView1.Columns[7].HeaderText = " وضعیت پرداخت/وصول ";
            dataGridView1.Columns[8].HeaderText = " شماره سریال چک ";
            dataGridView1.Columns[9].HeaderText = " مبلغ چک ";
            dataGridView1.Columns[9].DefaultCellStyle.Format = "0,0";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 50;
            dataGridView1.Columns[2].Width = 140;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 100;
            dataGridView1.Columns[5].Width = 100;
            dataGridView1.Columns[6].Width = 100;
            dataGridView1.Columns[7].Width = 100;
            dataGridView1.Columns[8].Width = 120;
            dataGridView1.Columns[9].Width = 150;
        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
              Taraconeshha.frmAddCheck   obj = new frmAddCheck  ();
             if (dataGridView1.RowCount == 0)
             {
                 MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
             }
             else
             {
                 int k = dataGridView1.CurrentCell.RowIndex;
                 Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                 if (obj.ShowDialog() == DialogResult.OK) { }

                 dataGridView1.DataSource = true;
                 dataGridView1.DataSource = CData.CheckShow1 ();
                 set_datagrid();
                 dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
             }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {

                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDCheck = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    CData.CheckDelete1(IDCheck);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        dataGridView1.DataSource = CData.CheckShow1();
                        this.dataGridView1.Refresh();
                    }
                    dataGridView1.DataSource = CData.CheckShow1();
                    this.dataGridView1.Refresh();
                }
            }
        }

        private void tarikhsarresidrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                tarikhsarresidmtxt.Focus();
            }
            if (tarikhsarresidrbtn.Checked == true)
            {
                tarikhsarresidmtxt.Enabled = true;
                tarikhsarresidmtxt.Focus();
            }
            else
                tarikhsarresidmtxt.Enabled = false;
        }

        private void namesahebrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[4];
                namesahebtxt .Focus();
            }
            if (namesahebrbtn.Checked == true)
            {
                namesahebtxt.Enabled = true;
                namesahebtxt.Focus();
            }
            else
                namesahebtxt.Enabled = false;
        }

        private void vaziyatepardakhtrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                vaziyatepardakhtcmb.Focus();
            }
            if (vaziyatepardakhtrbtn.Checked == true)
            {
                vaziyatepardakhtcmb.Enabled = true;
                vaziyatepardakhtcmb.Focus();
            }
            else
                vaziyatepardakhtcmb.Enabled = false;

            
        }
        //
        //
        //

        private void tarikhsarresidmtxt_TextChanged(object sender, EventArgs e)
        {
            if (tarikhsarresidmtxt.Text == "    /  /")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = CData.CheckShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (tarikhsarresidrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tarikhsarresidrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                    DateTime  str =Convert .ToDateTime  (tarikhsarresidmtxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = CData.FilterTarikheSarReside1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tarikhsarresidrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        tarikhsarresidmtxt.Text = "";
                        tarikhsarresidmtxt.Focus();
                        tarikhsarresidmtxt.SelectAll();

                    }
                }
            }
        }

        private void namesahebtxt_TextChanged(object sender, EventArgs e)
        {
            if (namesahebtxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = CData.CheckShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (namesahebrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[4];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (namesahebrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[4];
                    string  str = namesahebtxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = CData.FilterNameCheckDahande1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (namesahebrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[4];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        namesahebtxt.Text = "";
                        namesahebtxt.Focus();
                        namesahebtxt.SelectAll();

                    }
                }
            }
        }

        private void vaziyatepardakhtcmb_TextChanged(object sender, EventArgs e)
        {
            if (vaziyatepardakhtcmb.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = CData.CheckShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (vaziyatepardakhtrbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (vaziyatepardakhtrbtn .Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                    string  str = vaziyatepardakhtcmb.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = CData.FilterVazeiyatePardakhtOrVosol1(str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (vaziyatepardakhtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        vaziyatepardakhtcmb.Text = "";
                        vaziyatepardakhtcmb.Focus();
                        vaziyatepardakhtcmb.SelectAll();

                    }
                }
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void printbtn_Click(object sender, EventArgs e)
        {

        }
        //
        //
        //
    }
}

﻿namespace main1.Taraconeshha
{
    partial class frmAddHavale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tarikhesabtehavalemtxt = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idnoetaraconeshtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vaziyatepardakhtcmb = new System.Windows.Forms.ComboBox();
            this.namebankcmb = new System.Windows.Forms.ComboBox();
            this.tarikhsarresidmtxt = new System.Windows.Forms.MaskedTextBox();
            this.shobetxt = new System.Windows.Forms.TextBox();
            this.mablaghehavalemtxt = new System.Windows.Forms.MaskedTextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.idhavaletxt = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.serialhavaletxt = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.namesahebtxt = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tarikhesabtehavalemtxt);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.idnoetaraconeshtxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(9, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(495, 68);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // tarikhesabtehavalemtxt
            // 
            this.tarikhesabtehavalemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhesabtehavalemtxt.Location = new System.Drawing.Point(21, 25);
            this.tarikhesabtehavalemtxt.Name = "tarikhesabtehavalemtxt";
            this.tarikhesabtehavalemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesabtehavalemtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhesabtehavalemtxt.TabIndex = 3;
            this.tarikhesabtehavalemtxt.Enter += new System.EventHandler(this.tarikhesabtecheckmtxt_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(4, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 23);
            this.label5.TabIndex = 193;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(145, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 23);
            this.label6.TabIndex = 192;
            this.label6.Text = ":تاریخ ثبت حواله";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(248, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 187;
            this.label1.Text = "*";
            // 
            // idnoetaraconeshtxt
            // 
            this.idnoetaraconeshtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoetaraconeshtxt.Location = new System.Drawing.Point(265, 25);
            this.idnoetaraconeshtxt.Name = "idnoetaraconeshtxt";
            this.idnoetaraconeshtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoetaraconeshtxt.Size = new System.Drawing.Size(117, 20);
            this.idnoetaraconeshtxt.TabIndex = 1;
            this.idnoetaraconeshtxt.Text = "2";
            this.idnoetaraconeshtxt.TextChanged += new System.EventHandler(this.idnoetaraconeshtxt_TextChanged);
            this.idnoetaraconeshtxt.Enter += new System.EventHandler(this.idnoetaraconeshtxt_Enter);
            this.idnoetaraconeshtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnoetaraconeshtxt_KeyDown);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(388, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 23);
            this.label2.TabIndex = 185;
            this.label2.Text = ":کد نوع تراکنش ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.vaziyatepardakhtcmb);
            this.groupBox2.Controls.Add(this.namebankcmb);
            this.groupBox2.Controls.Add(this.tarikhsarresidmtxt);
            this.groupBox2.Controls.Add(this.shobetxt);
            this.groupBox2.Controls.Add(this.mablaghehavalemtxt);
            this.groupBox2.Controls.Add(this.label55);
            this.groupBox2.Controls.Add(this.idhavaletxt);
            this.groupBox2.Controls.Add(this.label56);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.serialhavaletxt);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.namesahebtxt);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Location = new System.Drawing.Point(9, 98);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(493, 241);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "اطلاعات حواله";
            // 
            // vaziyatepardakhtcmb
            // 
            this.vaziyatepardakhtcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.vaziyatepardakhtcmb.FormattingEnabled = true;
            this.vaziyatepardakhtcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.vaziyatepardakhtcmb.Items.AddRange(new object[] {
            "پرداخت شده",
            "پرداخت نشده",
            "دریافت شده",
            "دریافت نشده"});
            this.vaziyatepardakhtcmb.Location = new System.Drawing.Point(262, 145);
            this.vaziyatepardakhtcmb.Name = "vaziyatepardakhtcmb";
            this.vaziyatepardakhtcmb.Size = new System.Drawing.Size(117, 21);
            this.vaziyatepardakhtcmb.TabIndex = 9;
            this.vaziyatepardakhtcmb.Enter += new System.EventHandler(this.vaziyatepardakhtcmb_Enter);
            // 
            // namebankcmb
            // 
            this.namebankcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namebankcmb.FormattingEnabled = true;
            this.namebankcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namebankcmb.Items.AddRange(new object[] {
            "سپه",
            "ملی",
            "تجارت",
            "کشاورزی",
            "ملت",
            "اقتصاد نوین",
            "پاسارگاد",
            "پارسیان",
            "قوامین",
            "صادرات",
            "رفاه کارگران",
            ""});
            this.namebankcmb.Location = new System.Drawing.Point(262, 108);
            this.namebankcmb.Name = "namebankcmb";
            this.namebankcmb.Size = new System.Drawing.Size(117, 21);
            this.namebankcmb.TabIndex = 7;
            this.namebankcmb.Enter += new System.EventHandler(this.namebankcmb_Enter);
            // 
            // tarikhsarresidmtxt
            // 
            this.tarikhsarresidmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhsarresidmtxt.Location = new System.Drawing.Point(262, 71);
            this.tarikhsarresidmtxt.Mask = "9999/99/99";
            this.tarikhsarresidmtxt.Name = "tarikhsarresidmtxt";
            this.tarikhsarresidmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhsarresidmtxt.Size = new System.Drawing.Size(117, 20);
            this.tarikhsarresidmtxt.TabIndex = 5;
            this.tarikhsarresidmtxt.Enter += new System.EventHandler(this.tarikhsarresidmtxt_Enter);
            // 
            // shobetxt
            // 
            this.shobetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shobetxt.Location = new System.Drawing.Point(21, 109);
            this.shobetxt.Name = "shobetxt";
            this.shobetxt.Size = new System.Drawing.Size(117, 20);
            this.shobetxt.TabIndex = 8;
            this.shobetxt.Enter += new System.EventHandler(this.shobetxt_Enter);
            // 
            // mablaghehavalemtxt
            // 
            this.mablaghehavalemtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mablaghehavalemtxt.Location = new System.Drawing.Point(262, 184);
            this.mablaghehavalemtxt.Name = "mablaghehavalemtxt";
            this.mablaghehavalemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghehavalemtxt.Size = new System.Drawing.Size(117, 20);
            this.mablaghehavalemtxt.TabIndex = 11;
            this.mablaghehavalemtxt.TextChanged += new System.EventHandler(this.mablaghehavalemtxt_TextChanged);
            this.mablaghehavalemtxt.Enter += new System.EventHandler(this.mablaghehavalemtxt_Enter);
            this.mablaghehavalemtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghehavalemtxt_KeyDown);
            // 
            // label55
            // 
            this.label55.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label55.ForeColor = System.Drawing.Color.Red;
            this.label55.Location = new System.Drawing.Point(245, 39);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(16, 23);
            this.label55.TabIndex = 184;
            this.label55.Text = "*";
            // 
            // idhavaletxt
            // 
            this.idhavaletxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhavaletxt.Location = new System.Drawing.Point(262, 34);
            this.idhavaletxt.Name = "idhavaletxt";
            this.idhavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhavaletxt.Size = new System.Drawing.Size(117, 20);
            this.idhavaletxt.TabIndex = 4;
            this.idhavaletxt.TextChanged += new System.EventHandler(this.idhavaletxt_TextChanged);
            this.idhavaletxt.Enter += new System.EventHandler(this.idhavaletxt_Enter);
            this.idhavaletxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idhavaletxt_KeyDown);
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(381, 36);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(51, 23);
            this.label56.TabIndex = 182;
            this.label56.Text = "کد حواله:";
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(245, 189);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(16, 23);
            this.label27.TabIndex = 179;
            this.label27.Text = "*";
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(378, 186);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 23);
            this.label28.TabIndex = 178;
            this.label28.Text = "مبلغ حواله:";
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(4, 151);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 23);
            this.label31.TabIndex = 177;
            this.label31.Text = "*";
            // 
            // serialhavaletxt
            // 
            this.serialhavaletxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.serialhavaletxt.Location = new System.Drawing.Point(21, 146);
            this.serialhavaletxt.Name = "serialhavaletxt";
            this.serialhavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.serialhavaletxt.Size = new System.Drawing.Size(117, 20);
            this.serialhavaletxt.TabIndex = 10;
            this.serialhavaletxt.TextChanged += new System.EventHandler(this.serialhavaletxt_TextChanged);
            this.serialhavaletxt.Enter += new System.EventHandler(this.serialhavaletxt_Enter);
            this.serialhavaletxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.serialhavaletxt_KeyDown);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(137, 149);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(110, 23);
            this.label32.TabIndex = 175;
            this.label32.Text = "شماره سریال حواله:";
            // 
            // label33
            // 
            this.label33.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.Red;
            this.label33.Location = new System.Drawing.Point(245, 151);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(16, 23);
            this.label33.TabIndex = 174;
            this.label33.Text = "*";
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(374, 148);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(117, 23);
            this.label34.TabIndex = 173;
            this.label34.Text = "وضعیت پرداخت/دریافت:";
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.Red;
            this.label35.Location = new System.Drawing.Point(4, 113);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(16, 23);
            this.label35.TabIndex = 172;
            this.label35.Text = "*";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(142, 111);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 23);
            this.label36.TabIndex = 171;
            this.label36.Text = "نام شعبه بانک:";
            // 
            // label37
            // 
            this.label37.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(245, 112);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(16, 23);
            this.label37.TabIndex = 170;
            this.label37.Text = "*";
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(245, 76);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(16, 23);
            this.label38.TabIndex = 169;
            this.label38.Text = "*";
            // 
            // namesahebtxt
            // 
            this.namesahebtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namesahebtxt.Location = new System.Drawing.Point(21, 71);
            this.namesahebtxt.Name = "namesahebtxt";
            this.namesahebtxt.Size = new System.Drawing.Size(117, 20);
            this.namesahebtxt.TabIndex = 6;
            this.namesahebtxt.Enter += new System.EventHandler(this.namesahebtxt_Enter);
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.Red;
            this.label39.Location = new System.Drawing.Point(5, 74);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(16, 23);
            this.label39.TabIndex = 167;
            this.label39.Text = "*";
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(142, 74);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(90, 23);
            this.label40.TabIndex = 166;
            this.label40.Text = "نام صاحب حواله:";
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(380, 111);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 23);
            this.label41.TabIndex = 165;
            this.label41.Text = "نام بانک:";
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(382, 73);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(77, 23);
            this.label42.TabIndex = 163;
            this.label42.Text = "تاریخ سررسید:";
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(163, 359);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 13;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(262, 359);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 12;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتToolStripMenuItem,
            this.انصرافToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 81;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // ثبتToolStripMenuItem
            // 
            this.ثبتToolStripMenuItem.Name = "ثبتToolStripMenuItem";
            this.ثبتToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ثبتToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.ثبتToolStripMenuItem.Text = "ثبت";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // frmAddHavale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 404);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddHavale";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم اضافه کردن حواله";
            this.Load += new System.EventHandler(this.frmAddHavale_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox tarikhesabtehavalemtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox idnoetaraconeshtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox shobetxt;
        private System.Windows.Forms.MaskedTextBox mablaghehavalemtxt;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox idhavaletxt;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox serialhavaletxt;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox namesahebtxt;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.MaskedTextBox tarikhsarresidmtxt;
        private System.Windows.Forms.ComboBox vaziyatepardakhtcmb;
        private System.Windows.Forms.ComboBox namebankcmb;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
    }
}
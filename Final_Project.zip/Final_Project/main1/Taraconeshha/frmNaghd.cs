﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;


namespace main1.Taraconeshha
{
    public partial class frmNaghd : Form
    {
        public frmNaghd()
        {
            InitializeComponent();
        }
        FilterNaghdData NData1 = new FilterNaghdData();
        NaghdData NData = new NaghdData();
        NaghdDB NDB = new NaghdDB();
        //
        //

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }

        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddNaghd obj = new frmAddNaghd ();
            obj.ShowDialog();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = NData.NaghdShow1 ();
            set_datagrid();
        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            frmAddNaghd obj = new frmAddNaghd ();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                if (obj.ShowDialog() == DialogResult.OK) { }

                dataGridView1.DataSource = true;
                dataGridView1.DataSource = NData.NaghdShow1 ();
                set_datagrid();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDNaghdy = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    NData.NaghdDelete1(IDNaghdy);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        dataGridView1.DataSource = NData.NaghdShow1();
                        this.dataGridView1.Refresh();
                    }
                    dataGridView1.DataSource = NData.NaghdShow1();
                    this.dataGridView1.Refresh();
                }
            }
        }

        private void printbtn_Click(object sender, EventArgs e)
        {

        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tarikhesabtrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                tarikhesabtemtxt .Focus();
            }
            if (tarikhesabtrbtn.Checked == true)
            {
                tarikhesabtemtxt.Enabled = true;
                tarikhesabtemtxt.Focus();
            }
            else
                tarikhesabtemtxt.Enabled = false;
        }

        private void pardakhtkonanderbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                pardakhtkonandetxt .Focus();
            }
            if (pardakhtkonanderbtn.Checked == true)
            {
                pardakhtkonandetxt.Enabled = true;
                pardakhtkonandetxt.Focus();
            }
            else
                pardakhtkonandetxt.Enabled = false;
        }

        private void tarikhesabtemtxt_Leave(object sender, EventArgs e)
        {
            tarikhesabtemtxt.BackColor = Color.White;
        }

        private void tarikhesabtemtxt_Enter(object sender, EventArgs e)
        {
            tarikhesabtemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void pardakhtkonandetxt_Leave(object sender, EventArgs e)
        {
            pardakhtkonandetxt.BackColor = Color.White;
        }

        private void pardakhtkonandetxt_Enter(object sender, EventArgs e)
        {
            pardakhtkonandetxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void frmNaghd_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = NData1.NaghdShow1 ();
            set_datagrid();
            tarikhesabtrbtn.Checked = true;
            pardakhtkonandetxt .Enabled = false;
            dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
            tarikhesabtemtxt .Focus();
        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد نقدی ";
            dataGridView1.Columns[1].HeaderText = " کد نوع تراکنش ";
            dataGridView1.Columns[2].HeaderText = " تاریخ ثبت  ";
            dataGridView1.Columns[3].HeaderText = " نام پرداخت کننده ";
            dataGridView1.Columns[4].HeaderText = " مبلغ پرداختی ";
            dataGridView1.Columns[4].DefaultCellStyle.Format = "0,0";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 50;
            dataGridView1.Columns[2].Width = 120;
            dataGridView1.Columns[3].Width = 108;
            dataGridView1.Columns[4].Width = 120;
        }
        private void tarikhesabtemtxt_TextChanged(object sender, EventArgs e)
        {
            if (tarikhesabtemtxt.Text == "    /  /")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = NData1.NaghdShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (tarikhesabtrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tarikhesabtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                    DateTime str = Convert.ToDateTime(tarikhesabtemtxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = NData.FilterTarikheSabt1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tarikhesabtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        tarikhesabtemtxt.Text = "";
                        tarikhesabtemtxt.Focus();
                        tarikhesabtemtxt.SelectAll();

                    }
                }
            }
        }

        private void pardakhtkonandetxt_TextChanged(object sender, EventArgs e)
        {
            if (pardakhtkonandetxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = NData1.NaghdShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (pardakhtkonanderbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (pardakhtkonanderbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                    string str = pardakhtkonandetxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = NData.FilterNamePardakhtKonande1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (pardakhtkonanderbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        pardakhtkonandetxt.Text = "";
                        pardakhtkonandetxt.Focus();
                        pardakhtkonandetxt.SelectAll();

                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.Taraconeshha
{
    public partial class frmAddCheck : Form
    {
        public frmAddCheck()
        {
            InitializeComponent();
        }
        CheckData CData = new CheckData();
        CheckDB CDB = new CheckDB();
        //
        //
        //
        int k3 = 0;
        private void idnoetaraconeshtxt_TextChanged(object sender, EventArgs e)
        {
            if (idnoetaraconeshtxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                idnoetaraconeshtxt.Text = Class1.convert_number (idnoetaraconeshtxt.Text.Replace(",", ""));
                idnoetaraconeshtxt.Select(idnoetaraconeshtxt.Text.Length, 0);
            }
        }

        private void idnoetaraconeshtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }
        //
        //
        //
        private void mablaghecheckmtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        int k = 0;
        private void mablaghecheckmtxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghecheckmtxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                mablaghecheckmtxt.Text = Class1.convert_str (mablaghecheckmtxt.Text.Replace(",", ""));
                mablaghecheckmtxt.Select(mablaghecheckmtxt.Text.Length, 0);
            }
        }
        //
        //
        //
        int k1 = 0;
        private void idchecktxt_TextChanged(object sender, EventArgs e)
        {
            if (idchecktxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idchecktxt.Text = Class1.convert_number(idchecktxt.Text.Replace(",", ""));
                idchecktxt.Select(idchecktxt.Text.Length, 0);
            }
        }

        private void idchecktxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        //
        //
        //
        private void serialechecktxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        int k2 = 0;
        private void serialechecktxt_TextChanged(object sender, EventArgs e)
        {
            if (serialechecktxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                serialechecktxt.Text = Class1.convert_number(serialechecktxt.Text.Replace(",", ""));
                serialechecktxt.Select(serialechecktxt.Text.Length, 0);
            }
        }
        //
        //
        //
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idchecktxt.Text != "" && idnoetaraconeshtxt.Text != "" && tarikhesabtecheckmtxt.Text != "" && tarikhsarresidmtxt.Text != "    /  /" && namesahebechecktxt.Text != "" && namebankcmb.Text != "" && nameshobetxt.Text != "" && vaziyatepardakhtcmb.Text != "" && serialechecktxt.Text != "" && mablaghecheckmtxt.Text != "")
            {
                CDB.IDCheck = Convert.ToInt32(idchecktxt.Text);
                CDB.FKNoeTaraconesh =Convert .ToInt32 (idnoetaraconeshtxt .Text);
                CDB.TarikheSabteCheck  = Convert.ToDateTime(tarikhesabtecheckmtxt .Text);
                CDB.TarikheSarResideCheck  =Convert .ToDateTime (tarikhsarresidmtxt  .Text);
                CDB.NameCheckDahande  = namesahebechecktxt .Text;
                CDB.NameBank  = namebankcmb .Text;
                CDB.ShobeBank = nameshobetxt .Text;
                CDB.VazeiyatePardakhtOrVosol = vaziyatepardakhtcmb.Text;
                CDB.ShomareSerialeCheck  = serialechecktxt .Text;
                CDB.MablagheCheck = Convert .ToInt64 (mablaghecheckmtxt .Text.Replace (",",""));
                if (Class1.virayesh != 0)
                {
                    if (CData.CheckSearch1(CDB.IDCheck) && Class1.virayesh != CDB.IDCheck)
                    {
                        MessageBox.Show(" کد چک تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        CData .CheckUpdate1 (CDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDCheck = Convert.ToInt32(idchecktxt.Text);                            
                        }
                        Close();
                        Class1.virayesh = 0;
                    }
                }
                else
                {
                    if (!CData .CheckSearch1 (CDB.IDCheck ))
                    {
                        CData.CheckInsert1 (CDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.IDCheck = Convert.ToInt32(idchecktxt .Text);                            
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد چک تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Hide();
            frmCheck chk = new frmCheck();
            chk.ShowDialog();
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //
        //
        //
        private void frmAddCheck_Load(object sender, EventArgs e)
        {
            namesahebechecktxt .Text = Class1.NameMoshtari;
            if (Class1.virayesh != 0)
            {
                CDB  = CData .CheckFind1 (Class1.virayesh);
                idchecktxt .Text = CDB.IDCheck .ToString();
                idnoetaraconeshtxt .Text = CDB.FKNoeTaraconesh.ToString ();
                string s =CDB.TarikheSabteCheck .ToString();
                tarikhesabtecheckmtxt.Text = Class1.Tarikh(s);
                string s1 =CDB.TarikheSarResideCheck.ToString () ;
                tarikhsarresidmtxt.Text = Class1.Tarikh(s1);
                namesahebechecktxt .Text = CDB.NameCheckDahande .ToString();
                namebankcmb .Text = CDB.NameBank ;
                nameshobetxt .Text = CDB.ShobeBank .ToString();
                vaziyatepardakhtcmb.Text = CDB.VazeiyatePardakhtOrVosol;
                serialechecktxt .Text = CDB.ShomareSerialeCheck ;
                mablaghecheckmtxt .Text =Class1 .convert_str ( CDB.MablagheCheck.ToString ());
            }
            else
            {
                tarikhesabtecheckmtxt.Text = Class1.TarikheJari + " " + Class1.SaateJari;
                int i1 = 0;
                int i2 = 1;
                DataTable dt = CData .CheckSearchID1 ();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idchecktxt .Text = "1";
                }
                else
                {
                    idchecktxt.Text = Convert.ToString(i2 + 1);
                }

            }
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void idnoetaraconeshtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoetaraconeshtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void tarikhesabtecheckmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhesabtecheckmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idchecktxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idchecktxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhsarresidmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhsarresidmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesahebechecktxt_Enter(object sender, EventArgs e)
        {
            set_color();
            namesahebechecktxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namebankcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            namebankcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void nameshobetxt_Enter(object sender, EventArgs e)
        {
            set_color();
            nameshobetxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void vaziyatepardakhtcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            vaziyatepardakhtcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void serialechecktxt_Enter(object sender, EventArgs e)
        {
            set_color();
            serialechecktxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void mablaghecheckmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            mablaghecheckmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void set_color()
        {
            idnoetaraconeshtxt.BackColor = Color.White;
            tarikhesabtecheckmtxt.BackColor = Color.White;
            idchecktxt.BackColor = Color.White;
            tarikhsarresidmtxt.BackColor = Color.White;
            namesahebechecktxt.BackColor = Color.White;
            namebankcmb.BackColor = Color.White;
            nameshobetxt.BackColor = Color.White;
            vaziyatepardakhtcmb.BackColor = Color.White;
            serialechecktxt.BackColor = Color.White;
            mablaghecheckmtxt.BackColor = Color.White;
        }

        //
        //
        //
    }
}

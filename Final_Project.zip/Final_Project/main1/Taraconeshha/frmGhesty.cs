﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
namespace main1.Taraconeshha
{
    public partial class frmGhesty : Form
    {
        public frmGhesty()
        {
            InitializeComponent();
        }
        GhestyData GSData = new GhestyData();
        GhestyDB GSDB = new GhestyDB();

        private void darjbtn_Click(object sender, EventArgs e)
        {
           Taraconeshha  . frmAddGhesty  obj = new frmAddGhesty   ();
            obj.ShowDialog();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = GSData.GhestyShow1 ();
            set_datagrid();
        }

        private void virayeshbtn_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmAddGhesty obj = new frmAddGhesty ();
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                int k = dataGridView1.CurrentCell.RowIndex;
                Class1.virayesh = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                if (obj.ShowDialog() == DialogResult.OK) { }

                dataGridView1.DataSource = true;
                dataGridView1.DataSource = GSData.GhestyShow1();
                set_datagrid();
                dataGridView1.CurrentCell = dataGridView1.Rows[k].Cells[1];
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("!سطری انتخاب نشده است", "", MessageBoxButtons.OK);
            }
            else
            {
                if (MessageBox.Show("آیا مایل به حذف این رکورد هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int IDGhesty = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                    GSData.GhestyDelete1(IDGhesty);
                    if (MessageBox.Show("حذف با موفقیت انجام شد", "", MessageBoxButtons.OK) == DialogResult.OK)
                    {
                        dataGridView1.DataSource = GSData.GhestyShow1();
                        this.dataGridView1.Refresh();
                    }
                    dataGridView1.DataSource = GSData.GhestyShow1();
                    this.dataGridView1.Refresh();
                }
            }
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد قسطی ";
            dataGridView1.Columns[1].HeaderText = " کد نوع تراکنش ";
            dataGridView1.Columns[2].HeaderText = " تاریخ ثبت قسطی ";
            dataGridView1.Columns[3].HeaderText = " نام صاحب قسطی ";
            dataGridView1.Columns[4].HeaderText = " تعداد اقساط ";
            dataGridView1.Columns[5].HeaderText = " تاریخ پرداخت اقساط  ";
            dataGridView1.Columns[6].HeaderText = " تعداد اقساط مانده  ";
            dataGridView1.Columns[7].HeaderText = "  مبلغ پرداختی هر قسط ";
            dataGridView1.Columns[8].HeaderText = " درصد سود   ";
            dataGridView1.Columns[7].DefaultCellStyle.Format = "0,0";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 50;
            dataGridView1.Columns[2].Width = 140;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 50;
            dataGridView1.Columns[5].Width = 100;
            dataGridView1.Columns[6].Width = 50;
            dataGridView1.Columns[7].Width = 120;
            dataGridView1.Columns[8].Width = 100;
        }
        private void tarikhesabteghestmtxt_Enter(object sender, EventArgs e)
        {
            tarikhesabteghestmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namesahebtxt_Enter(object sender, EventArgs e)
        {
            namesahebtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhesabteghestmtxt_Leave(object sender, EventArgs e)
        {
            tarikhesabteghestmtxt.BackColor = Color.White ;
        }

        private void namesahebtxt_Leave(object sender, EventArgs e)
        {
            namesahebtxt.BackColor = Color.White ;
        }

        private void tarikhepardakhtemtxt_Leave(object sender, EventArgs e)
        {
            tarikhepardakhtemtxt.BackColor = Color.White ;
        }

        private void tarikhepardakhtemtxt_Enter(object sender, EventArgs e)
        {
            tarikhepardakhtemtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhesabteghestmtxt_TextChanged(object sender, EventArgs e)
        {
            if (tarikhesabteghestmtxt.Text == "    /  /")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = GSData.GhestyShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (tarikhesabtrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tarikhesabtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                    DateTime  str =Convert .ToDateTime ( tarikhesabteghestmtxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = GSData.FilterTarikheSabteGhest1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tarikhesabtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        tarikhesabteghestmtxt.Text = "";
                        tarikhesabteghestmtxt.Focus();
                        tarikhesabteghestmtxt.SelectAll();

                    }
                }
            }
        }

        private void namesahebtxt_TextChanged(object sender, EventArgs e)
        {
            if (namesahebtxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = GSData.GhestyShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (namesahebrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (namesahebrbtn .Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                    string str = namesahebtxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = GSData.FilterNameDahandeGhest1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (namesahebrbtn .Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        namesahebtxt.Text = "";
                        namesahebtxt.Focus();
                        namesahebtxt.SelectAll();

                    }
                }
            }
        }

        private void tarikhepardakhtemtxt_TextChanged(object sender, EventArgs e)
        {
            if (tarikhepardakhtemtxt.Text == "    /  /")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = GSData.GhestyShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                virayeshbtn.Enabled = true;
                printbtn.Enabled = true;
                if (tarikhepardakhtrbtn.Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tarikhepardakhtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
                    DateTime  str = Convert .ToDateTime ( tarikhepardakhtemtxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = GSData.FilterTarikhePardakhteAghsat1(str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tarikhepardakhtrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[5];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            virayeshbtn.Enabled = false;
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            virayeshbtn.Enabled = true;
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        tarikhepardakhtemtxt.Text = "";
                        tarikhepardakhtemtxt.Focus();
                        tarikhepardakhtemtxt.SelectAll();

                    }
                }
            }
        }

        private void tarikhesabtrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                tarikhesabteghestmtxt .Focus();
            }
            if (tarikhesabtrbtn.Checked == true)
            {
                tarikhesabteghestmtxt.Enabled = true;
                tarikhesabteghestmtxt.Focus();
            }
            else
                tarikhesabteghestmtxt.Enabled = false;
        }

        private void namesahebrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[3];
                namesahebtxt .Focus();
            }
            if (namesahebrbtn.Checked == true)
            {
                namesahebtxt.Enabled = true;
                namesahebtxt.Focus();
            }
            else
                namesahebtxt.Enabled = false;
        }

        private void tarikhepardakhtrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[7];
                tarikhepardakhtemtxt .Focus();
            }
            if (tarikhepardakhtrbtn.Checked == true)
            {
                tarikhepardakhtemtxt.Enabled = true;
                tarikhepardakhtemtxt.Focus();
            }
            else
                tarikhepardakhtemtxt.Enabled = false;
        }

        private void frmGhesty_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = GSData.GhestyShow1 ();
            set_datagrid();
            tarikhesabtrbtn .Checked = true;
            namesahebtxt.Enabled = false;
            tarikhepardakhtemtxt .Enabled = false;
            dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
            tarikhesabteghestmtxt .Focus();
        }
    }
}

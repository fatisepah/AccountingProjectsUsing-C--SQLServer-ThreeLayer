﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace WindowsFormsApplication2.Bank
{
    public partial class bank : Form
    {
        public bank()
        {
            InitializeComponent();
        }
        BankData bd = new BankData();

        private void bank_Load(object sender, EventArgs e)
        {
           
            dataGridView1.DataSource = bd.get_data();
            
        }
      

        private void txt_name_bank_TextChanged(object sender, EventArgs e)
        {
            string name_bank = txt_name_bank.Text.Replace("ی", "ي");
            try
            {
                dataGridView1.DataSource = bd.Filter(name_bank);
                if (dataGridView1.RowCount.ToString() == "0")
                {
                    btn_edit.Enabled = false;
                }
                else
                {
                    btn_edit.Enabled = true;
                }
            }
            catch
            {
                MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                txt_name_bank.Text = "";
                txt_name_bank.Focus();
                txt_name_bank.SelectAll();
            }
        }

       
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        

    }
}

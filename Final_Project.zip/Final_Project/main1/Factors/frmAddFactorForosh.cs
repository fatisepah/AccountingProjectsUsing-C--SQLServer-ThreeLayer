﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using DAL;
using BLL;
namespace main1.Factors
{
    public partial class frmAddFactorForosh : Form
    {
        public frmAddFactorForosh()
        {
            InitializeComponent();
        }
        //
        FactorData FData = new FactorData();
        FactorDB FDB = new FactorDB();
        //
        RizFactorKharidForoshData  RFKFData = new RizFactorKharidForoshData ();
        RizFactorKharidForoshDB  RFKFDB = new RizFactorKharidForoshDB ();
        //
        SanadeHesabdariData SHData = new SanadeHesabdariData();
        SanadeHesabdariDB SHDB = new SanadeHesabdariDB();
        //
        MoshtariData MData = new MoshtariData();
        MoshtariDB MDB = new MoshtariDB();
        //
        KalayeKharidForoshData  KKFData = new KalayeKharidForoshData ();
        KalayeKharidForoshDB  KKFDB = new KalayeKharidForoshDB ();
        //
        SherkatData SData = new SherkatData();
        SherkatDB SDB = new SherkatDB();
        //

        private void frmFactorForosh_Load(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1 ();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala=Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKharidForosh = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (TedadeKala  >= 0 )
                {
                    namekala1cmb.Items.Add(item);
                    namekala2cmb.Items.Add(item);
                    namekala3cmb.Items.Add(item);
                    namekala4cmb.Items.Add(item);
                    namekala5cmb.Items.Add(item);
                    namekala6cmb.Items.Add(item);
                }

            }
            //
            //
            //
            tedadkala1nud.Enabled = false;
            tedadkala2nud.Enabled = false;
            tedadkala3nud.Enabled = false;
            tedadkala4nud.Enabled = false;
            tedadkala5nud.Enabled = false;
            tedadkala6nud.Enabled = false;
            //
            lblkarbar.Text = Class1.NameFamilyKarbar;
            tarikhmtxt.Text = Class1.TarikheJari;
            //
            naghdchb.Checked = true;
            ghestychb.Checked = false;
            checkchb.Checked = false;
            havalechb.Checked = false;
            idghestytxt.Enabled = false;
            pardakheghestybtn.Enabled = false;
            idchecktxt.Enabled = false;
            pardakhecheckbtn.Enabled = false;
            idhavaletxt.Enabled = false;
            pardakhtehavalebtn.Enabled = false;
            //


            if (Class1.virayeshF != 0 && Class1.virayeshRFForosh != 0)
            {
                RFKFDB = RFKFData.RizFactorKharidForoshFind1 (Class1.virayeshRFForosh);
                idkerayetxt.Text = RFKFDB.IDFactorKHF.ToString();
                namekala1cmb.Text = RFKFDB.NameKalayeKharidForosh1 ;
                tedadkala1nud.Value = RFKFDB.Tedade1;
                namekala2cmb.Text = RFKFDB.NameKalayeKharidForosh2 ;
                tedadkala2nud.Value = RFKFDB.Tedade2;
                namekala3cmb.Text = RFKFDB.NameKalayeKharidForosh3 ;
                tedadkala3nud.Value = RFKFDB.Tedade3;
                namekala4cmb.Text = RFKFDB.NameKalayeKharidForosh4 ;
                tedadkala4nud.Value = RFKFDB.Tedade4;
                namekala5cmb .Text  = RFKFDB.NameKalayeKharidForosh5 ;
                tedadkala5nud.Value = RFKFDB.Tedade5;
                namekala6cmb .Text  = RFKFDB.NameKalayeKharidForosh6 ;
                tedadkala6nud.Value = RFKFDB.Tedade6;
                idfactortxt.Text = RFKFDB.FKFactor.ToString();
                gheimatekoltxt.Text = Class1.convert_str(RFKFDB.GheimateKol.ToString());
                //
                FDB = FData.FactorFind1(Class1.virayeshF);
                idfactortxt.Text = FDB.IDFactor.ToString();
                idnoemoshtaritxt.Text = FDB.FKNoeMoshtari.ToString();
                namemoshtaricmb.Text = FDB.NameMoshtari.ToString();
                idsanadtxt.Text = FDB.FKSanadeHesabdari.ToString();
                idnaghdytxt.Text = FDB.FKNaghdy.ToString();
                idghestytxt.Text = FDB.FKGhesty.ToString();
                idchecktxt.Text = FDB.FKCheck.ToString();
                idhavaletxt.Text = FDB.FKHavale.ToString();
                lblkarbar.Text = FDB.NameKarbar;
                string s1 = FDB.TarikheFactor.ToString();
                tarikhmtxt.Text = Class1.Tarikh(s1);
                darsadetakhfiftxt.Text = FDB.DarsadeTakhfif;
                nameranandetxt.Text = FDB.NameRanande;
                dastmozdekargartxt.Text = Class1.convert_str(FDB.DastMozdeKargareBarbari.ToString());
                kerayehamltxt.Text = Class1.convert_str(FDB.KerayeHaml.ToString());
            }
            else
            {
                int i3 = 0, i5 = 0;
                int i4 = 1, i6 = 1;
                DataTable dt1 = FData.FactorSearchID1();
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    i3 = Convert.ToInt32(dt1.Rows[i][0].ToString());
                    if (i4 < i3)
                    {
                        i4 = i3;
                    }
                }
                if (dt1.Rows.Count == 0)
                {
                    idfactortxt.Text = "1";
                }
                else
                {
                    idfactortxt.Text = Convert.ToString(i4 + 1);
                }
                //
                DataTable dt2 = RFKFData.RizFactorKharidForoshSearchID1 ();
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    i5 = Convert.ToInt32(dt2.Rows[i][0].ToString());
                    if (i6 < i5)
                    {
                        i6 = i5;
                    }
                }
                if (dt2.Rows.Count == 0)
                {
                    idkerayetxt.Text = "1";
                }
                else
                {
                    idkerayetxt.Text = Convert.ToString(i6 + 1);
                }
            }
        }

        private void namekala1cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (namekala1cmb.SelectedIndex == -1)
                tedadkala1nud.Enabled = false;
            else
                tedadkala1nud.Enabled = true;
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = IDKalaKHF.ToString();
                if (NameKala == namekala1cmb.Text)
                {
                    namekala2cmb.Items.Remove(item);
                    namekala3cmb.Items.Remove(item);
                    namekala4cmb.Items.Remove(item);
                    namekala5cmb.Items.Remove(item);
                    namekala6cmb.Items.Remove(item);
                }
                if (namekala1cmb.Text == item.Text)
                {
                    tedadkala1nud.Minimum = 1;
                    tedadkala1nud.Maximum = TedadeKala;
                    gheimatkala1txt.Text = Class1.convert_str(GheimateKala).ToString();
                    break;
                }

            }
        }

        private void namekala2cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (namekala2cmb.SelectedIndex == -1)
                tedadkala2nud.Enabled = false;
            else
                tedadkala2nud.Enabled = true;
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = IDKalaKHF.ToString();
                if (NameKala == namekala2cmb.Text)
                {
                    namekala3cmb.Items.Remove(item);
                    namekala4cmb.Items.Remove(item);
                    namekala5cmb.Items.Remove(item);
                    namekala6cmb.Items.Remove(item);
                }
                if (namekala2cmb.Text == item.Text)
                {
                    tedadkala2nud.Minimum = 1;
                    tedadkala2nud.Maximum = TedadeKala;
                    gheimatkala2txt.Text = Class1.convert_str(GheimateKala).ToString();
                    break;
                }

            }
        }

        private void namekala3cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (namekala3cmb.SelectedIndex == -1)
                tedadkala3nud.Enabled = false;
            else
                tedadkala3nud.Enabled = true;
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = IDKalaKHF.ToString();
                if (NameKala == namekala3cmb.Text)
                {
                    namekala4cmb.Items.Remove(item);
                    namekala5cmb.Items.Remove(item);
                    namekala6cmb.Items.Remove(item);
                }
                if (namekala3cmb.Text == item.Text)
                {
                    tedadkala3nud.Minimum = 1;
                    tedadkala3nud.Maximum = TedadeKala;
                    gheimatkala3txt.Text = Class1.convert_str(GheimateKala).ToString();
                    break;
                }

            }
        }

        private void namekala4cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (namekala4cmb.SelectedIndex == -1)
                tedadkala4nud.Enabled = false;
            else
                tedadkala4nud.Enabled = true;
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = IDKalaKHF.ToString();
                if (NameKala == namekala4cmb.Text)
                {
                    namekala5cmb.Items.Remove(item);
                    namekala6cmb.Items.Remove(item);
                }
                if (namekala4cmb.Text == item.Text)
                {
                    tedadkala4nud.Minimum = 1;
                    tedadkala4nud.Maximum = TedadeKala;
                    gheimatkala4txt.Text = Class1.convert_str(GheimateKala).ToString();
                    break;
                }

            }
        }

        private void namekala5cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (namekala5cmb.SelectedIndex == -1)
                tedadkala5nud.Enabled = false;
            else
                tedadkala5nud.Enabled = true;
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = IDKalaKHF.ToString();
                if (NameKala == namekala5cmb.Text)
                {
                    namekala6cmb.Items.Remove(item);
                }
                if (namekala5cmb.Text == item.Text)
                {
                    tedadkala5nud.Minimum = 1;
                    tedadkala5nud.Maximum = TedadeKala;
                    gheimatkala5txt.Text = Class1.convert_str(GheimateKala).ToString();
                    break;
                }

            }
        }

        private void namekala6cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (namekala6cmb.SelectedIndex == -1)
                tedadkala6nud.Enabled = false;
            else
                tedadkala6nud.Enabled = true;
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                string GheimateKala = DT.Rows[i][12].ToString();

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = IDKalaKHF.ToString();

                if (namekala6cmb.Text == item.Text)
                {
                    tedadkala6nud.Minimum = 1;
                    tedadkala6nud.Maximum = TedadeKala;
                    gheimatkala6txt.Text = Class1.convert_str(GheimateKala).ToString();
                    break;
                }

            }
        }

        private void tedadkala1nud_ValueChanged(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1 ();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                long GheimateKala =Convert .ToInt64 ( DT.Rows[i][12].ToString());

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (namekala1cmb.Text == NameKala)
                {
                    tedadkala1nud.Minimum = 1;
                    tedadkala1nud.Maximum = TedadeKala;
                    gheimatkala1txt.Text = Class1.convert_str((GheimateKala * tedadkala1nud.Value).ToString());
                    break;
                }
            }
        }

        private void tedadkala2nud_ValueChanged(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                long GheimateKala = Convert.ToInt64(DT.Rows[i][12].ToString());

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (namekala2cmb.Text == NameKala)
                {
                    tedadkala2nud.Minimum = 1;
                    tedadkala2nud.Maximum = TedadeKala;
                    gheimatkala2txt.Text = Class1.convert_str((GheimateKala * tedadkala2nud.Value).ToString());
                    break;
                }
            }
        }

        private void tedadkala3nud_ValueChanged(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                long GheimateKala = Convert.ToInt64(DT.Rows[i][12].ToString());

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (namekala3cmb.Text == NameKala)
                {
                    tedadkala3nud.Minimum = 1;
                    tedadkala3nud.Maximum = TedadeKala;
                    gheimatkala3txt.Text = Class1.convert_str((GheimateKala * tedadkala3nud.Value).ToString());
                    break;
                }
            }
        }

        private void tedadkala4nud_ValueChanged(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                long GheimateKala = Convert.ToInt64(DT.Rows[i][12].ToString());

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (namekala4cmb.Text == NameKala)
                {
                    tedadkala4nud.Minimum = 1;
                    tedadkala4nud.Maximum = TedadeKala;
                    gheimatkala4txt.Text = Class1.convert_str((GheimateKala * tedadkala4nud.Value).ToString());
                    break;
                }
            }
        }

        private void tedadkala5nud_ValueChanged(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                long GheimateKala = Convert.ToInt64(DT.Rows[i][12].ToString());

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (namekala5cmb.Text == NameKala)
                {
                    tedadkala5nud.Minimum = 1;
                    tedadkala5nud.Maximum = TedadeKala;
                    gheimatkala5txt.Text = Class1.convert_str((GheimateKala * tedadkala5nud.Value).ToString());
                    break;
                }
            }
        }

        private void tedadkala6nud_ValueChanged(object sender, EventArgs e)
        {
            DataTable DT = KKFData.KalayeKharidForoshComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int TedadeKala = Convert.ToInt32(DT.Rows[i][7].ToString());
                int IDKalaKHF = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][3].ToString();
                long GheimateKala = Convert.ToInt64(DT.Rows[i][12].ToString());

                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (namekala6cmb.Text == NameKala)
                {
                    tedadkala6nud.Minimum = 1;
                    tedadkala6nud.Maximum = TedadeKala;
                    gheimatkala6txt.Text = Class1.convert_str((GheimateKala * tedadkala6nud.Value).ToString());
                    break;
                }
            }
        }
        //
        int k = 0;
        private void idfactortxt_TextChanged(object sender, EventArgs e)
        {
            if (idfactortxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                idfactortxt.Text = Class1.convert_number(idfactortxt.Text.Replace(",", ""));
                idfactortxt.Select(idfactortxt.Text.Length, 0);
            }
        }

        private void idfactortxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }
        //
        int k1 = 0;
        private void idkerayetxt_TextChanged(object sender, EventArgs e)
        {
            if (idkerayetxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idkerayetxt.Text = Class1.convert_number(idkerayetxt.Text.Replace(",", ""));
                idkerayetxt.Select(idkerayetxt.Text.Length, 0);
            }
        }

        private void idkerayetxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        //
        int k2 = 0;
        private void idnoemoshtaritxt_TextChanged(object sender, EventArgs e)
        {
            if (idnoemoshtaritxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                idnoemoshtaritxt.Text = Class1.convert_number(idnoemoshtaritxt.Text.Replace(",", ""));
                idnoemoshtaritxt.Select(idnoemoshtaritxt.Text.Length, 0);
            }
        }

        private void idnoemoshtaritxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        //
        int k3 = 0;
        private void idmoshtaritxt_TextChanged(object sender, EventArgs e)
        {
            if (idmoshtaritxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                idmoshtaritxt.Text = Class1.convert_number(idmoshtaritxt.Text.Replace(",", ""));
                idmoshtaritxt.Select(idmoshtaritxt.Text.Length, 0);
            }
        }

        private void idmoshtaritxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }
        //
        int k4 = 0;
        private void idsanadtxt_TextChanged(object sender, EventArgs e)
        {
            if (idsanadtxt.Text.Length != 0 && k4 == 1)
            {
                k4 = 0;
                idsanadtxt.Text = Class1.convert_number(idsanadtxt.Text.Replace(",", ""));
                idsanadtxt.Select(idsanadtxt.Text.Length, 0);
            }
        }

        private void idsanadtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k4 = 1;
        }
        //
        int k5 = 0;
        private void gheimatkala1txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala1txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            gheimatbatakhfiftxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimatkala1txt.Text.Length != 0 && k5 == 1)
            {
                k5 = 0;
                gheimatkala1txt.Text = Class1.convert_str(gheimatkala1txt.Text.Replace(",", ""));
                gheimatkala1txt.Select(gheimatkala1txt.Text.Length, 0);
            }
        }

        private void gheimatkala1txt_KeyDown(object sender, KeyEventArgs e)
        {
            k5 = 1;
        }
        //
        int k6 = 0;
        private void gheimatkala2txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala2txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            gheimatbatakhfiftxt.Text =Class1.convert_str( Convert.ToString(i1 + i2));
            if (gheimatkala2txt.Text.Length != 0 && k6 == 1)
            {
                k6 = 0;
                gheimatkala2txt.Text = Class1.convert_str(gheimatkala2txt.Text.Replace(",", ""));
                gheimatkala2txt.Select(gheimatkala2txt.Text.Length, 0);
            }
        }

        private void gheimatkala2txt_KeyDown(object sender, KeyEventArgs e)
        {
            k6 = 1;
        }
        //
        int k7 = 0;
        private void gheimatkala3txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala3txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            gheimatbatakhfiftxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimatkala3txt.Text.Length != 0 && k7 == 1)
            {
                k7 = 0;
                gheimatkala3txt.Text = Class1.convert_str(gheimatkala3txt.Text.Replace(",", ""));
                gheimatkala3txt.Select(gheimatkala3txt.Text.Length, 0);
            }
        }

        private void gheimatkala3txt_KeyDown(object sender, KeyEventArgs e)
        {
            k7 = 1;
        }
        //
        int k8 = 0;
        private void gheimatkala4txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala4txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            gheimatbatakhfiftxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimatkala4txt.Text.Length != 0 && k8 == 1)
            {
                k8 = 0;
                gheimatkala4txt.Text = Class1.convert_str(gheimatkala4txt.Text.Replace(",", ""));
                gheimatkala4txt.Select(gheimatkala4txt.Text.Length, 0);
            }
        }

        private void gheimatkala4txt_KeyDown(object sender, KeyEventArgs e)
        {
            k8 = 1;
        }
        //
        int k9 = 0;
        private void gheimatkala5txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala5txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            gheimatbatakhfiftxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimatkala5txt.Text.Length != 0 && k9 == 1)
            {
                k9 = 0;
                gheimatkala5txt.Text = Class1.convert_str(gheimatkala5txt.Text.Replace(",", ""));
                gheimatkala5txt.Select(gheimatkala5txt.Text.Length, 0);
            }
        }

        private void gheimatkala5txt_KeyDown(object sender, KeyEventArgs e)
        {
            k9 = 1;
        }
        //
        int k10 = 0;
        private void gheimatkala6txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala6txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            gheimatbatakhfiftxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimatkala6txt.Text.Length != 0 && k10 == 1)
            {
                k10 = 0;
                gheimatkala6txt.Text = Class1.convert_str(gheimatkala6txt.Text.Replace(",", ""));
                gheimatkala6txt.Select(gheimatkala6txt.Text.Length, 0);
            }
        }

        private void gheimatkala6txt_KeyDown(object sender, KeyEventArgs e)
        {
            k10 = 1;
        }
        //
        int k11 = 0;
        private void gheimatbatakhfiftxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatkala1txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatkala2txt.Text.Replace(",", ""));
            long i3 = Convert.ToInt64(gheimatkala3txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(gheimatkala4txt.Text.Replace(",", ""));
            long i5 = Convert.ToInt64(gheimatkala5txt.Text.Replace(",", ""));
            long i6 = Convert.ToInt64(gheimatkala5txt.Text.Replace(",", ""));
            int i8 = Convert.ToInt32(darsadetakhfiftxt.Text);
            if (i8 == 0)
                i8 = 100;
            gheimatbatakhfiftxt.Text = Class1.convert_str(Convert.ToString((i1 + i2 + i3 + i4 + i5 + i6)));
            long i7 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            long i9 = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
            long i10 = Convert.ToInt64(dastmozdekargartxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str((i7 + i9 + i10).ToString());
            //
            if (gheimatbatakhfiftxt.Text.Length != 0 && k11 == 1)
            {
                k11 = 0;
                gheimatbatakhfiftxt.Text = Class1.convert_str(gheimatbatakhfiftxt.Text.Replace(",", ""));
                gheimatbatakhfiftxt.Select(gheimatbatakhfiftxt.Text.Length, 0);
            }
        }

        private void gheimatbatakhfiftxt_KeyDown(object sender, KeyEventArgs e)
        {
            k11 = 1;
        }
        //
        int k12 = 0;
        private void kerayehamltxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str((i1 + i2).ToString());
            if (kerayehamltxt.Text.Length != 0 && k12 == 1)
            {
                k12 = 0;
                kerayehamltxt.Text = Class1.convert_str(kerayehamltxt.Text.Replace(",", ""));
                kerayehamltxt.Select(kerayehamltxt.Text.Length, 0);
            }
        }

        private void kerayehamltxt_KeyDown(object sender, KeyEventArgs e)
        {
            k12 = 1;
        }
        //
        int k13 = 0;
        private void dastmozdekargartxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(dastmozdekargartxt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str((i1 + i2).ToString());
            if (dastmozdekargartxt.Text.Length != 0 && k13 == 1)
            {
                k13 = 0;
                dastmozdekargartxt.Text = Class1.convert_str(dastmozdekargartxt.Text.Replace(",", ""));
                dastmozdekargartxt.Select(dastmozdekargartxt.Text.Length, 0);
            }
        }

        private void dastmozdekargartxt_KeyDown(object sender, KeyEventArgs e)
        {
            k13 = 1;
        }
        //
        int k14 = 0;
        private void gheimatekoltxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatbatakhfiftxt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
            long i3 = Convert.ToInt64(dastmozdekargartxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str((i1 + i2 + i3).ToString());
            if (gheimatekoltxt.Text.Length != 0 && k14 == 1)
            {
                k14 = 0;
                gheimatekoltxt.Text = Class1.convert_str(gheimatekoltxt.Text.Replace(",", ""));
                gheimatekoltxt.Select(gheimatekoltxt.Text.Length, 0);
            }
        }

        private void gheimatekoltxt_KeyDown(object sender, KeyEventArgs e)
        {
            k14 = 1;
        }
        //
        int k15 = 0;
        private void darsadetakhfiftxt_TextChanged(object sender, EventArgs e)
        {
            int i1 = Convert.ToInt32(gheimatbatakhfiftxt.Text.Replace(",", ""));
            if (darsadetakhfiftxt.Text == "")
                darsadetakhfiftxt.Text = "0";
            int i8 = Convert.ToInt32(darsadetakhfiftxt.Text);
            if (i8 == 0)
                i8 = 100;
            gheimatbatakhfiftxt.Text = Convert.ToString(i1);
            lbldarsad.Text = darsadetakhfiftxt.Text;
            if (darsadetakhfiftxt.Text.Length != 0 && k15 == 1)
            {
                k15 = 0;
                darsadetakhfiftxt.Text = Class1.convert_number(darsadetakhfiftxt.Text.Replace(",", ""));
                darsadetakhfiftxt.Select(darsadetakhfiftxt.Text.Length, 0);
            }
        }

        private void darsadetakhfiftxt_KeyDown(object sender, KeyEventArgs e)
        {
            k15 = 1;
        }
        //
        int k16 = 0;
        private void idnaghdytxt_TextChanged(object sender, EventArgs e)
        {
            if (idnaghdytxt.Text.Length != 0 && k16 == 1)
            {
                k16 = 0;
                idnaghdytxt.Text = Class1.convert_number (idnaghdytxt.Text.Replace(",", ""));
                idnaghdytxt.Select(idnaghdytxt.Text.Length, 0);
            }
        }

        private void idnaghdytxt_KeyDown(object sender, KeyEventArgs e)
        {
            k16 = 1;
        }
        //
        int k17 = 0;
        private void idghestytxt_TextChanged(object sender, EventArgs e)
        {
            if (idghestytxt.Text.Length != 0 && k17 == 1)
            {
                k17 = 0;
                idghestytxt.Text = Class1.convert_number(idghestytxt.Text.Replace(",", ""));
                idghestytxt.Select(idghestytxt.Text.Length, 0);
            }
        }

        private void idghestytxt_KeyDown(object sender, KeyEventArgs e)
        {
            k17 = 1;
        }
        //
        int k18 = 0;
        private void idchecktxt_TextChanged(object sender, EventArgs e)
        {
            if (idchecktxt.Text.Length != 0 && k18 == 1)
            {
                k18 = 0;
                idchecktxt.Text = Class1.convert_number(idchecktxt.Text.Replace(",", ""));
                idchecktxt.Select(idchecktxt.Text.Length, 0);
            }
        }

        private void idchecktxt_KeyDown(object sender, KeyEventArgs e)
        {
            k18 = 1;
        }
        //
        int k19 = 0;
        private void idhavaletxt_TextChanged(object sender, EventArgs e)
        {
            if (idhavaletxt.Text.Length != 0 && k19 == 1)
            {
                k19 = 0;
                idhavaletxt.Text = Class1.convert_number(idhavaletxt.Text.Replace(",", ""));
                idhavaletxt.Select(idhavaletxt.Text.Length, 0);
            }
        }

        private void idhavaletxt_KeyDown(object sender, KeyEventArgs e)
        {
            k19 = 1;
        }

        private void noemoshtaricmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (noemoshtaricmb.SelectedIndex == 0)
            {
                idnoemoshtaritxt.Text = "1";
                idmoshtaritxt.Text = "";
            }
            else
            {
                idnoemoshtaritxt.Text = "2";
                idmoshtaritxt.Text = "";
            }
            if (noemoshtaricmb.Text == "حقیقی")
            {
                namemoshtaricmb.Items.Clear();
                DataTable DT = MData.MoshtariComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {
                    int IDMoshtari = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameMoshtari = DT.Rows[i][5].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameMoshtari;
                    item.Value = IDMoshtari.ToString();

                    namemoshtaricmb.Items.Add(item);

                }
            }
            else if (noemoshtaricmb.Text == "حقوقی")
            {
                namemoshtaricmb.Items.Clear();
                DataTable DT = SData.SherkatComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {

                    int IDSherkat = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameSherkat = DT.Rows[i][5].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameSherkat;
                    item.Value = IDSherkat.ToString();

                    namemoshtaricmb.Items.Add(item);

                }
            }
        }

        private void namemoshtaricmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (noemoshtaricmb.Text == "حقیقی")
            {
                DataTable DT = MData.MoshtariComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {
                    int IDMoshtari = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameMoshtari = DT.Rows[i][5].ToString();


                    ListItem item = new ListItem();
                    item.Text = NameMoshtari;
                    item.Value = IDMoshtari.ToString();
                    if (namemoshtaricmb.Text == item.Text)
                    {
                        idmoshtaritxt.Text = IDMoshtari.ToString();
                        break;
                    }

                }
            }
            else if (noemoshtaricmb.Text == "حقوقی")
            {
                DataTable DT = SData.SherkatComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {

                    int IDSherkat = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameSherkat = DT.Rows[i][5].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameSherkat;
                    item.Value = IDSherkat.ToString();
                    if (namemoshtaricmb.Text == item.Text)
                    {
                        idmoshtaritxt.Text = IDSherkat.ToString();
                        break;
                    }

                }
            }
        }

        private void naghdchb_CheckedChanged(object sender, EventArgs e)
        {
            if (naghdchb.Checked == true)
            {
                idnaghdytxt.Enabled = true;
                pardakhenaghdybtn.Enabled = true;
            }
            else
            {
                idnaghdytxt.Enabled = false;
                pardakhenaghdybtn.Enabled = false;
            }
        }

        private void ghestychb_CheckedChanged(object sender, EventArgs e)
        {
            if (ghestychb.Checked == true)
            {
                idghestytxt.Enabled = true;
                pardakheghestybtn.Enabled = true;
            }
            else
            {
                idghestytxt.Enabled = false;
                pardakheghestybtn.Enabled = false;
            }
        }

        private void checkchb_CheckedChanged(object sender, EventArgs e)
        {
            if (checkchb.Checked == true)
            {
                idchecktxt.Enabled = true;
                pardakhecheckbtn.Enabled = true;
            }
            else
            {
                idchecktxt.Enabled = false;
                pardakhecheckbtn.Enabled = false;
            }
        }

        private void havalechb_CheckedChanged(object sender, EventArgs e)
        {
            if (havalechb.Checked == true)
            {
                idhavaletxt.Enabled = true;
                pardakhtehavalebtn.Enabled = true;
            }
            else
            {
                idhavaletxt.Enabled = false;
                pardakhtehavalebtn.Enabled = false;
            }
        }

        private void pardakhenaghdybtn_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmAddNaghd obj = new Taraconeshha.frmAddNaghd();
            obj.ShowDialog();
            idnaghdytxt.Text = Class1.IDNaghdy.ToString();
        }

        private void pardakheghestybtn_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmAddGhesty obj = new Taraconeshha.frmAddGhesty  ();
            obj.ShowDialog();
            idghestytxt.Text = Class1.IDGhesty.ToString();
        }

        private void pardakhecheckbtn_Click(object sender, EventArgs e)
        {
            Taraconeshha .frmAddCheck obj = new Taraconeshha.frmAddCheck  ();
            obj.ShowDialog();
            idchecktxt.Text = Class1.IDCheck.ToString();
        }

        private void pardakhtehavalebtn_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmAddHavale obj = new Taraconeshha.frmAddHavale();
            obj.ShowDialog();
            idhavaletxt.Text = Class1.IDHavale.ToString();
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
            Class1.NameMoshtari = "";
            Class1.IDCheck = 0;
            Class1.IDGhesty = 0;
            Class1.IDHavale = 0;
            Class1.IDNaghdy = 0;
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idfactortxt.Text != "" && idkerayetxt.Text != "" && tarikhmtxt.Text != "" && idnoemoshtaritxt.Text != "" && idmoshtaritxt.Text != "" && namemoshtaricmb.Text != "" && namekala1cmb.Text != "" && gheimatekoltxt.Text != "" && idnaghdytxt.Text != "")
            {
                //برای جدول فاکتور
                FDB.IDFactor = Convert.ToInt32(idfactortxt.Text);
                FDB.FKNoeFactor = Convert.ToInt32("2");
                FDB.FKNoeMoshtari = Convert.ToInt32(idnoemoshtaritxt.Text);
                FDB.FKMoshtari = Convert.ToInt32(idmoshtaritxt.Text);
                FDB.NameMoshtari = namemoshtaricmb.Text;
                FDB.FKSanadeHesabdari = 0;//Class1.IDSanad;
                FDB.FKNaghdy = Convert.ToInt32(idnaghdytxt.Text);
                FDB.FKGhesty = Convert.ToInt32(idghestytxt.Text);
                FDB.FKCheck = Convert.ToInt32(idchecktxt.Text);
                FDB.FKHavale = Convert.ToInt32(idhavaletxt.Text);
                FDB.NameKarbar = lblkarbar.Text;
                FDB.TarikheFactor = Convert.ToDateTime(tarikhmtxt.Text);
                FDB.DarsadeTakhfif = darsadetakhfiftxt.Text;
                FDB.NameRanande = nameranandetxt.Text;
                FDB.DastMozdeKargareBarbari = Convert.ToInt64(dastmozdekargartxt.Text.Replace(",", ""));
                FDB.KerayeHaml = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
                //برای جدول ریز فاکتور
                RFKFDB.IDFactorKHF = Convert.ToInt32(idkerayetxt.Text);
                RFKFDB.NameKalayeKharidForosh1  = namekala1cmb.Text;
                RFKFDB.Tedade1 = Convert.ToInt32(tedadkala1nud.Value);
                RFKFDB.NameKalayeKharidForosh2  = namekala2cmb.Text;
                RFKFDB.Tedade2 = Convert.ToInt32(tedadkala2nud.Value);
                RFKFDB.NameKalayeKharidForosh3  = namekala3cmb.Text;
                RFKFDB.Tedade3 = Convert.ToInt32(tedadkala3nud.Text);
                RFKFDB.NameKalayeKharidForosh4  = namekala4cmb.Text;
                RFKFDB.Tedade4 = Convert.ToInt32(tedadkala4nud.Text);
                RFKFDB.NameKalayeKharidForosh5 = namekala5cmb.Text;
                RFKFDB.Tedade5 = Convert.ToInt32(tedadkala5nud.Text);
                RFKFDB.NameKalayeKharidForosh6 = namekala6cmb.Text;
                RFKFDB.Tedade6 = Convert.ToInt32(tedadkala6nud.Text);
                RFKFDB.FKFactor = Convert.ToInt32(idfactortxt.Text);
                RFKFDB.GheimateKol = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
                ////برای جدول سند حسابداری
                //SHDB.IDSanad = Convert.ToInt32(idsanadtxt .Text);
                //HesabhaData HData = new HesabhaData();
                //DataTable DT = HData.HesabhaComboShow1();
                //for (int i = 0; i < DT.Rows.Count; i++)
                //{

                //  int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                //  string NameHesabTafzily = DT.Rows[i][7].ToString();
                //  if(NameHesabTafzily == "درآمد")
                //    SHDB.FKHesabeBedehkar  = Convert.ToInt32(IDHesab);

                //}
                //SHDB.FKHesabeBestankar  = Convert.ToInt32("");
                //SHDB.FKNoeSanad = Convert.ToInt32("2");
                //SHDB.NameKarbar = lblkarbar .Text;
                //SHDB.TarikheSanad = Convert.ToDateTime(tarikhmtxt.Text);
                //SHDB.SharheSanad = ;
                //SHDB.MablagheBedehkari  = Convert.ToInt32(gheimatekoltxt .Text);
                //SHDB.MablagheBestanKari = Convert.ToInt32(gheimatekoltxt.Text);

                //برای آپدیت کردن وضعیت کرایه و تعداد کرایه داده شده کالاها
                DataTable DT1 = KKFData.KalayeKharidForoshComboShow1 ();
                for (int i = 0; i < DT1.Rows.Count; i++)
                {
                    KKFDB.IDKalaKHF = Convert.ToInt32(DT1.Rows[i][0].ToString());
                    KKFDB.FKNoeKala = Convert.ToInt32(DT1.Rows[i][1].ToString());
                    KKFDB.FKGroupKala = Convert.ToInt32(DT1.Rows[i][2].ToString());
                    KKFDB.NameKala = DT1.Rows[i][3].ToString();
                    KKFDB.VahedeShomaresheAsli  = DT1.Rows[i][4].ToString();
                    KKFDB.VahedeShomaresheFare  = DT1.Rows[i][5].ToString();
                    KKFDB.HadeaghaleTedadeMojod = Convert.ToInt32(DT1.Rows[i][6].ToString());
                    KKFDB.TedadeKala = Convert.ToInt32(DT1.Rows[i][7].ToString());
                    KKFDB.Tozihat = DT1.Rows[i][8].ToString();
                    KKFDB.TarikheTolid  = Convert.ToDateTime(DT1.Rows[i][9].ToString());
                    KKFDB.TarikheEngheza  = Convert.ToDateTime(DT1.Rows[i][10].ToString());
                    KKFDB.GheimateKharid  = Convert.ToInt64(DT1.Rows[i][11].ToString());
                    KKFDB.GheimateForosh = Convert.ToInt64(DT1.Rows[i][12].ToString());
                    KKFDB.Garanty = DT1.Rows[i][13].ToString();
                    KKFDB.ModeleKala = DT1.Rows[i][14].ToString();
                    KKFDB.BarcodeKala = DT1.Rows[i][15].ToString();
                    KKFDB.NameSherkatTolidi = DT1.Rows[i][16].ToString();
                    //
                    int TedadeKala = Convert.ToInt32(DT1.Rows[i][7].ToString());
                    string NameKala = DT1.Rows[i][3].ToString();
                    if (namekala1cmb.Text == NameKala)
                    {
                        TedadeKala  = TedadeKala  - Convert.ToInt32(tedadkala1nud.Value);
                        KKFDB.TedadeKala = TedadeKala;
                        KKFData.KalayeKharidForoshUpdate1 (KKFDB);
                    }
                    if (namekala2cmb.Text == NameKala)
                    {
                        TedadeKala = TedadeKala - Convert.ToInt32(tedadkala2nud.Value);
                        KKFDB.TedadeKala = TedadeKala;
                        KKFData.KalayeKharidForoshUpdate1(KKFDB);
                    }
                    if (namekala3cmb.Text == NameKala)
                    {
                        TedadeKala = TedadeKala - Convert.ToInt32(tedadkala3nud.Value);
                        KKFDB.TedadeKala = TedadeKala;
                        KKFData.KalayeKharidForoshUpdate1(KKFDB);
                    }
                    if (namekala4cmb.Text == NameKala)
                    {
                        TedadeKala = TedadeKala - Convert.ToInt32(tedadkala4nud.Value);
                        KKFDB.TedadeKala = TedadeKala;
                        KKFData.KalayeKharidForoshUpdate1(KKFDB);
                    }
                    if (namekala5cmb.Text == NameKala)
                    {
                        TedadeKala = TedadeKala - Convert.ToInt32(tedadkala5nud.Value);
                        KKFDB.TedadeKala = TedadeKala;
                        KKFData.KalayeKharidForoshUpdate1(KKFDB);
                    }
                    if (namekala6cmb.Text == NameKala)
                    {
                        TedadeKala = TedadeKala - Convert.ToInt32(tedadkala6nud.Value);
                        KKFDB.TedadeKala = TedadeKala;
                        KKFData.KalayeKharidForoshUpdate1(KKFDB);
                    }
                }

                if (Class1.virayeshF != 0 && Class1.virayeshRFForosh  != 0)
                {
                    if (RFKFData.RizFactorKharidForoshSearch1 (RFKFDB.IDFactorKHF) && Class1.virayeshRFForosh  != RFKFDB.IDFactorKHF && FData.FactorSearch1(FDB.IDFactor) && Class1.virayeshF != FDB.IDFactor)
                    {
                        MessageBox.Show(" کد فاکتور تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        FData.FactorUpdate1(FDB);
                        RFKFData.RizFactorKharidForoshUpdate1 (RFKFDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                        }
                        Close();
                        Class1.virayeshRFK = 0;
                        Class1.virayeshF = 0;
                        Class1.IDSanad = 0;
                        Class1.NameMoshtari = "";
                        Class1.IDCheck = 0;
                        Class1.IDGhesty = 0;
                        Class1.IDHavale = 0;
                        Class1.IDNaghdy = 0;
                        Class1.IDSanad = 0;
                    }
                }
                else
                {
                    if (!RFKFData.RizFactorKharidForoshSearch1 (RFKFDB.IDFactorKHF) && !FData.FactorSearch1(FDB.IDFactor))
                    {
                        FData.FactorInsert1(FDB);
                        RFKFData.RizFactorKerayeInsert1(RFKFDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.virayeshRFK = 0;
                            Class1.virayeshF = 0;
                            Class1.IDSanad = 0;
                            Class1.NameMoshtari = "";
                            Class1.IDCheck = 0;
                            Class1.IDGhesty = 0;
                            Class1.IDHavale = 0;
                            Class1.IDNaghdy = 0;
                            Class1.IDSanad = 0;
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد فاکتور تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void namemoshtaricmb_TextChanged(object sender, EventArgs e)
        {
            Class1.NameMoshtari = namemoshtaricmb.Text;
        }
        //

    }
}

﻿namespace main1.Factors
{
    partial class frmAddFactorKharid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addhavalebtn = new System.Windows.Forms.Button();
            this.addcheckbtn = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.idnaghdytxt = new System.Windows.Forms.TextBox();
            this.nameranandetxt = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.tarikhesarresidehavalemtxt = new System.Windows.Forms.MaskedTextBox();
            this.idhavaletxt = new System.Windows.Forms.TextBox();
            this.seryalehavaletxt = new System.Windows.Forms.TextBox();
            this.shobehavaletxt = new System.Windows.Forms.TextBox();
            this.bankehavaletxt = new System.Windows.Forms.TextBox();
            this.mablaghehavaletxt = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.tarikhesarresidecheckmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idchecktxt = new System.Windows.Forms.TextBox();
            this.seryalechecktxt = new System.Windows.Forms.TextBox();
            this.shobechecktxt = new System.Windows.Forms.TextBox();
            this.bankchecktxt = new System.Windows.Forms.TextBox();
            this.mablaghechecktxt = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.mablaghepardakhtenaghdtxt = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.namemoshtaricmb = new System.Windows.Forms.ComboBox();
            this.idmoshtaritxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.idnoemoshtaritxt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.noemoshtaricmb = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tarikhmtxt = new System.Windows.Forms.MaskedTextBox();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.idfactortxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.idkharidtxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.darsadetakhfiftxt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.gheimateaghlam = new System.Windows.Forms.TextBox();
            this.mandetxt = new System.Windows.Forms.TextBox();
            this.takhfifenaghdiyekharidtxt = new System.Windows.Forms.TextBox();
            this.gheimatekoltxt = new System.Windows.Forms.TextBox();
            this.dastmozdekargartxt = new System.Windows.Forms.TextBox();
            this.kerayehamltxt = new System.Windows.Forms.TextBox();
            this.takhfiftxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.vahedkala6txt = new System.Windows.Forms.TextBox();
            this.vahedkala5txt = new System.Windows.Forms.TextBox();
            this.vahedkala4txt = new System.Windows.Forms.TextBox();
            this.vahedkala3txt = new System.Windows.Forms.TextBox();
            this.vahedkala2txt = new System.Windows.Forms.TextBox();
            this.vahedkala1txt = new System.Windows.Forms.TextBox();
            this.gheimateradif6txt = new System.Windows.Forms.TextBox();
            this.gheimateradif5txt = new System.Windows.Forms.TextBox();
            this.gheimateradif4txt = new System.Windows.Forms.TextBox();
            this.gheimateradif3txt = new System.Windows.Forms.TextBox();
            this.gheimateradif2txt = new System.Windows.Forms.TextBox();
            this.gheimateradif1txt = new System.Windows.Forms.TextBox();
            this.gheimatkala6txt = new System.Windows.Forms.TextBox();
            this.gheimatkala5txt = new System.Windows.Forms.TextBox();
            this.gheimatkala4txt = new System.Windows.Forms.TextBox();
            this.gheimatkala3txt = new System.Windows.Forms.TextBox();
            this.gheimatkala2txt = new System.Windows.Forms.TextBox();
            this.gheimatkala1txt = new System.Windows.Forms.TextBox();
            this.tedadkala6nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala5nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala4nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala3nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala2nud = new System.Windows.Forms.NumericUpDown();
            this.tedadkala1nud = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.rectangleShape3 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape20 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape21 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape22 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape23 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape72 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape71 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape70 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape63 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape56 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape25 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape24 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape11 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape69 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape68 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape67 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape66 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape65 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape64 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape10 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape62 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape61 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape60 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape59 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape58 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape9 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape57 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape55 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape54 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape53 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape52 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape51 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape50 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape49 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape48 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape47 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape46 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape45 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape44 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape43 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape42 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape41 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape40 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape39 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape38 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape10 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape11 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape12 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape13 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape14 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape15 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape16 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape17 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape18 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape19 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape4 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape5 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape6 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape26 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape27 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape28 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape29 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape30 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape31 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape32 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape33 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape34 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape35 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape36 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape37 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.rectangleShape7 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape8 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.addghestybtn = new System.Windows.Forms.Button();
            this.tarikhepardakhteghestmtxt = new System.Windows.Forms.MaskedTextBox();
            this.tedadeaghsattxt = new System.Windows.Forms.TextBox();
            this.tedademandeghestmtxt = new System.Windows.Forms.TextBox();
            this.darsadsoodghesttxt = new System.Windows.Forms.TextBox();
            this.mablagheghesttxt = new System.Windows.Forms.TextBox();
            this.mablaghekoleaghsattxt = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.idghestytxt = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.addnaghdbtn = new System.Windows.Forms.Button();
            this.sabtesanadbtn = new System.Windows.Forms.Button();
            this.id6txt = new System.Windows.Forms.TextBox();
            this.id5txt = new System.Windows.Forms.TextBox();
            this.id4txt = new System.Windows.Forms.TextBox();
            this.id3txt = new System.Windows.Forms.TextBox();
            this.id2txt = new System.Windows.Forms.TextBox();
            this.id1txt = new System.Windows.Forms.TextBox();
            this.barcode6txt = new System.Windows.Forms.TextBox();
            this.barcode5txt = new System.Windows.Forms.TextBox();
            this.barcode4txt = new System.Windows.Forms.TextBox();
            this.barcode3txt = new System.Windows.Forms.TextBox();
            this.barcode2txt = new System.Windows.Forms.TextBox();
            this.barcode1txt = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.namekala6cmb = new System.Windows.Forms.ComboBox();
            this.namekala5cmb = new System.Windows.Forms.ComboBox();
            this.namekala4cmb = new System.Windows.Forms.ComboBox();
            this.namekala3cmb = new System.Windows.Forms.ComboBox();
            this.namekala2cmb = new System.Windows.Forms.ComboBox();
            this.namekala1cmb = new System.Windows.Forms.ComboBox();
            this.lineShape73 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label66 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala6nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala5nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala4nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala3nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala2nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala1nud)).BeginInit();
            this.SuspendLayout();
            // 
            // addhavalebtn
            // 
            this.addhavalebtn.Location = new System.Drawing.Point(783, 595);
            this.addhavalebtn.Name = "addhavalebtn";
            this.addhavalebtn.Size = new System.Drawing.Size(26, 23);
            this.addhavalebtn.TabIndex = 367;
            this.addhavalebtn.Text = "+";
            this.addhavalebtn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.addhavalebtn.UseVisualStyleBackColor = true;
            this.addhavalebtn.Click += new System.EventHandler(this.addhavalebtn_Click);
            // 
            // addcheckbtn
            // 
            this.addcheckbtn.Location = new System.Drawing.Point(783, 542);
            this.addcheckbtn.Name = "addcheckbtn";
            this.addcheckbtn.Size = new System.Drawing.Size(26, 23);
            this.addcheckbtn.TabIndex = 366;
            this.addcheckbtn.Text = "+";
            this.addcheckbtn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.addcheckbtn.UseVisualStyleBackColor = true;
            this.addcheckbtn.Click += new System.EventHandler(this.addcheckbtn_Click);
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label55.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label55.ForeColor = System.Drawing.Color.Red;
            this.label55.Location = new System.Drawing.Point(528, 494);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(18, 15);
            this.label55.TabIndex = 364;
            this.label55.Text = "*";
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label54.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label54.ForeColor = System.Drawing.Color.Red;
            this.label54.Location = new System.Drawing.Point(635, 519);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(18, 15);
            this.label54.TabIndex = 363;
            this.label54.Text = "*";
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label53.Location = new System.Drawing.Point(702, 518);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(73, 19);
            this.label53.TabIndex = 362;
            this.label53.Text = ":کد نقدی";
            // 
            // idnaghdytxt
            // 
            this.idnaghdytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnaghdytxt.Location = new System.Drawing.Point(653, 514);
            this.idnaghdytxt.Multiline = true;
            this.idnaghdytxt.Name = "idnaghdytxt";
            this.idnaghdytxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnaghdytxt.Size = new System.Drawing.Size(43, 24);
            this.idnaghdytxt.TabIndex = 361;
            this.idnaghdytxt.Text = "0";
            this.idnaghdytxt.TextChanged += new System.EventHandler(this.idnaghdytxt_TextChanged);
            this.idnaghdytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnaghdytxt_KeyDown);
            // 
            // nameranandetxt
            // 
            this.nameranandetxt.Location = new System.Drawing.Point(594, 377);
            this.nameranandetxt.Name = "nameranandetxt";
            this.nameranandetxt.Size = new System.Drawing.Size(119, 20);
            this.nameranandetxt.TabIndex = 359;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label52.Location = new System.Drawing.Point(719, 378);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(57, 20);
            this.label52.TabIndex = 360;
            this.label52.Text = ":نام راننده";
            // 
            // tarikhesarresidehavalemtxt
            // 
            this.tarikhesarresidehavalemtxt.Location = new System.Drawing.Point(541, 623);
            this.tarikhesarresidehavalemtxt.Mask = "9999/99/99";
            this.tarikhesarresidehavalemtxt.Name = "tarikhesarresidehavalemtxt";
            this.tarikhesarresidehavalemtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesarresidehavalemtxt.Size = new System.Drawing.Size(112, 20);
            this.tarikhesarresidehavalemtxt.TabIndex = 358;
            // 
            // idhavaletxt
            // 
            this.idhavaletxt.Location = new System.Drawing.Point(654, 623);
            this.idhavaletxt.Multiline = true;
            this.idhavaletxt.Name = "idhavaletxt";
            this.idhavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhavaletxt.Size = new System.Drawing.Size(43, 20);
            this.idhavaletxt.TabIndex = 357;
            this.idhavaletxt.Text = "0";
            this.idhavaletxt.TextChanged += new System.EventHandler(this.idhavaletxt_TextChanged);
            this.idhavaletxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idhavaletxt_KeyDown);
            // 
            // seryalehavaletxt
            // 
            this.seryalehavaletxt.Location = new System.Drawing.Point(187, 623);
            this.seryalehavaletxt.Multiline = true;
            this.seryalehavaletxt.Name = "seryalehavaletxt";
            this.seryalehavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.seryalehavaletxt.Size = new System.Drawing.Size(124, 20);
            this.seryalehavaletxt.TabIndex = 356;
            // 
            // shobehavaletxt
            // 
            this.shobehavaletxt.Location = new System.Drawing.Point(312, 623);
            this.shobehavaletxt.Multiline = true;
            this.shobehavaletxt.Name = "shobehavaletxt";
            this.shobehavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.shobehavaletxt.Size = new System.Drawing.Size(118, 20);
            this.shobehavaletxt.TabIndex = 355;
            // 
            // bankehavaletxt
            // 
            this.bankehavaletxt.Location = new System.Drawing.Point(431, 623);
            this.bankehavaletxt.Multiline = true;
            this.bankehavaletxt.Name = "bankehavaletxt";
            this.bankehavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bankehavaletxt.Size = new System.Drawing.Size(109, 20);
            this.bankehavaletxt.TabIndex = 354;
            // 
            // mablaghehavaletxt
            // 
            this.mablaghehavaletxt.Location = new System.Drawing.Point(38, 623);
            this.mablaghehavaletxt.Multiline = true;
            this.mablaghehavaletxt.Name = "mablaghehavaletxt";
            this.mablaghehavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghehavaletxt.Size = new System.Drawing.Size(148, 20);
            this.mablaghehavaletxt.TabIndex = 353;
            this.mablaghehavaletxt.Text = "0";
            this.mablaghehavaletxt.TextChanged += new System.EventHandler(this.mablaghehavaletxt_TextChanged);
            this.mablaghehavaletxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghehavaletxt_KeyDown);
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label46.Location = new System.Drawing.Point(98, 598);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(36, 19);
            this.label46.TabIndex = 352;
            this.label46.Text = "مبلغ ";
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label47.Location = new System.Drawing.Point(214, 598);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(72, 19);
            this.label47.TabIndex = 351;
            this.label47.Text = "شماره سریال";
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label48.Location = new System.Drawing.Point(352, 598);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(36, 19);
            this.label48.TabIndex = 350;
            this.label48.Text = "شعبه";
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label49.Location = new System.Drawing.Point(470, 598);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(29, 19);
            this.label49.TabIndex = 349;
            this.label49.Text = "بانک";
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label50.Location = new System.Drawing.Point(559, 598);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(82, 19);
            this.label50.TabIndex = 348;
            this.label50.Text = "تاریخ سر رسید";
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label51.Location = new System.Drawing.Point(666, 598);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(22, 19);
            this.label51.TabIndex = 347;
            this.label51.Text = "کد";
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label43.Location = new System.Drawing.Point(700, 593);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(77, 19);
            this.label43.TabIndex = 346;
            this.label43.Text = ":حواله پرداختی";
            // 
            // tarikhesarresidecheckmtxt
            // 
            this.tarikhesarresidecheckmtxt.Location = new System.Drawing.Point(541, 570);
            this.tarikhesarresidecheckmtxt.Mask = "9999/99/99";
            this.tarikhesarresidecheckmtxt.Name = "tarikhesarresidecheckmtxt";
            this.tarikhesarresidecheckmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesarresidecheckmtxt.Size = new System.Drawing.Size(112, 20);
            this.tarikhesarresidecheckmtxt.TabIndex = 345;
            // 
            // idchecktxt
            // 
            this.idchecktxt.Location = new System.Drawing.Point(654, 570);
            this.idchecktxt.Multiline = true;
            this.idchecktxt.Name = "idchecktxt";
            this.idchecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idchecktxt.Size = new System.Drawing.Size(43, 20);
            this.idchecktxt.TabIndex = 344;
            this.idchecktxt.Text = "0";
            this.idchecktxt.TextChanged += new System.EventHandler(this.idchecktxt_TextChanged);
            this.idchecktxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idchecktxt_KeyDown);
            // 
            // seryalechecktxt
            // 
            this.seryalechecktxt.Location = new System.Drawing.Point(187, 570);
            this.seryalechecktxt.Multiline = true;
            this.seryalechecktxt.Name = "seryalechecktxt";
            this.seryalechecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.seryalechecktxt.Size = new System.Drawing.Size(124, 20);
            this.seryalechecktxt.TabIndex = 343;
            // 
            // shobechecktxt
            // 
            this.shobechecktxt.Location = new System.Drawing.Point(312, 570);
            this.shobechecktxt.Multiline = true;
            this.shobechecktxt.Name = "shobechecktxt";
            this.shobechecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.shobechecktxt.Size = new System.Drawing.Size(118, 20);
            this.shobechecktxt.TabIndex = 342;
            // 
            // bankchecktxt
            // 
            this.bankchecktxt.Location = new System.Drawing.Point(431, 570);
            this.bankchecktxt.Multiline = true;
            this.bankchecktxt.Name = "bankchecktxt";
            this.bankchecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bankchecktxt.Size = new System.Drawing.Size(109, 20);
            this.bankchecktxt.TabIndex = 341;
            // 
            // mablaghechecktxt
            // 
            this.mablaghechecktxt.Location = new System.Drawing.Point(38, 570);
            this.mablaghechecktxt.Multiline = true;
            this.mablaghechecktxt.Name = "mablaghechecktxt";
            this.mablaghechecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghechecktxt.Size = new System.Drawing.Size(148, 20);
            this.mablaghechecktxt.TabIndex = 340;
            this.mablaghechecktxt.Text = "0";
            this.mablaghechecktxt.TextChanged += new System.EventHandler(this.mablaghechecktxt_TextChanged);
            this.mablaghechecktxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghechecktxt_KeyDown);
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label42.Location = new System.Drawing.Point(98, 547);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(36, 19);
            this.label42.TabIndex = 339;
            this.label42.Text = "مبلغ ";
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label41.Location = new System.Drawing.Point(214, 547);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(72, 19);
            this.label41.TabIndex = 338;
            this.label41.Text = "شماره سریال";
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label40.Location = new System.Drawing.Point(352, 547);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(36, 19);
            this.label40.TabIndex = 337;
            this.label40.Text = "شعبه";
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label39.Location = new System.Drawing.Point(470, 547);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 19);
            this.label39.TabIndex = 336;
            this.label39.Text = "بانک";
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label38.Location = new System.Drawing.Point(559, 547);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(82, 19);
            this.label38.TabIndex = 335;
            this.label38.Text = "تاریخ سر رسید";
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label35.Location = new System.Drawing.Point(666, 547);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(22, 19);
            this.label35.TabIndex = 334;
            this.label35.Text = "کد";
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label34.Location = new System.Drawing.Point(702, 543);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(70, 19);
            this.label34.TabIndex = 333;
            this.label34.Text = ":چک پرداختی";
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Location = new System.Drawing.Point(695, 465);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(87, 21);
            this.label29.TabIndex = 332;
            this.label29.Text = "پرداخت هزینه";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label26.Location = new System.Drawing.Point(702, 493);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(73, 19);
            this.label26.TabIndex = 331;
            this.label26.Text = ":پرداخت نقدی";
            // 
            // mablaghepardakhtenaghdtxt
            // 
            this.mablaghepardakhtenaghdtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mablaghepardakhtenaghdtxt.Location = new System.Drawing.Point(547, 489);
            this.mablaghepardakhtenaghdtxt.Multiline = true;
            this.mablaghepardakhtenaghdtxt.Name = "mablaghepardakhtenaghdtxt";
            this.mablaghepardakhtenaghdtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghepardakhtenaghdtxt.Size = new System.Drawing.Size(149, 24);
            this.mablaghepardakhtenaghdtxt.TabIndex = 330;
            this.mablaghepardakhtenaghdtxt.Text = "0";
            this.mablaghepardakhtenaghdtxt.TextChanged += new System.EventHandler(this.mablaghepardakhtenaghdtxt_TextChanged);
            this.mablaghepardakhtenaghdtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghepardakhtenaghdtxt_KeyDown);
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label24.Location = new System.Drawing.Point(195, 517);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 19);
            this.label24.TabIndex = 329;
            this.label24.Text = ":مانده";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(463, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 15);
            this.label9.TabIndex = 327;
            this.label9.Text = "*";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(293, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 15);
            this.label5.TabIndex = 326;
            this.label5.Text = "*";
            // 
            // namemoshtaricmb
            // 
            this.namemoshtaricmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namemoshtaricmb.FormattingEnabled = true;
            this.namemoshtaricmb.Location = new System.Drawing.Point(243, 142);
            this.namemoshtaricmb.Name = "namemoshtaricmb";
            this.namemoshtaricmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namemoshtaricmb.Size = new System.Drawing.Size(201, 21);
            this.namemoshtaricmb.TabIndex = 237;
            this.namemoshtaricmb.SelectedIndexChanged += new System.EventHandler(this.namemoshtaricmb_SelectedIndexChanged);
            // 
            // idmoshtaritxt
            // 
            this.idmoshtaritxt.Location = new System.Drawing.Point(79, 142);
            this.idmoshtaritxt.Name = "idmoshtaritxt";
            this.idmoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idmoshtaritxt.Size = new System.Drawing.Size(163, 20);
            this.idmoshtaritxt.TabIndex = 238;
            this.idmoshtaritxt.TextChanged += new System.EventHandler(this.idmoshtaritxt_TextChanged);
            this.idmoshtaritxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idmoshtaritxt_KeyDown);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Location = new System.Drawing.Point(129, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 22);
            this.label12.TabIndex = 262;
            this.label12.Text = ":کد فروشنده";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(307, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 22);
            this.label7.TabIndex = 263;
            this.label7.Text = ":نام فروشنده";
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Location = new System.Drawing.Point(477, 117);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 22);
            this.label15.TabIndex = 257;
            this.label15.Text = ":کد نوع فروشنده";
            // 
            // idnoemoshtaritxt
            // 
            this.idnoemoshtaritxt.Location = new System.Drawing.Point(445, 142);
            this.idnoemoshtaritxt.Name = "idnoemoshtaritxt";
            this.idnoemoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoemoshtaritxt.Size = new System.Drawing.Size(143, 20);
            this.idnoemoshtaritxt.TabIndex = 236;
            this.idnoemoshtaritxt.TextChanged += new System.EventHandler(this.idnoemoshtaritxt_TextChanged);
            this.idnoemoshtaritxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnoemoshtaritxt_KeyDown);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label13.Location = new System.Drawing.Point(626, 116);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 22);
            this.label13.TabIndex = 259;
            this.label13.Text = ":نوع فروشنده";
            // 
            // noemoshtaricmb
            // 
            this.noemoshtaricmb.FormattingEnabled = true;
            this.noemoshtaricmb.Items.AddRange(new object[] {
            "حقیقی",
            "حقوقی"});
            this.noemoshtaricmb.Location = new System.Drawing.Point(589, 142);
            this.noemoshtaricmb.Name = "noemoshtaricmb";
            this.noemoshtaricmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.noemoshtaricmb.Size = new System.Drawing.Size(142, 21);
            this.noemoshtaricmb.TabIndex = 235;
            this.noemoshtaricmb.SelectedIndexChanged += new System.EventHandler(this.noemoshtaricmb_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(117, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 15);
            this.label8.TabIndex = 264;
            this.label8.Text = "*";
            // 
            // tarikhmtxt
            // 
            this.tarikhmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhmtxt.Location = new System.Drawing.Point(101, 72);
            this.tarikhmtxt.Name = "tarikhmtxt";
            this.tarikhmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhmtxt.TabIndex = 234;
            // 
            // lblkarbar
            // 
            this.lblkarbar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblkarbar.Location = new System.Drawing.Point(101, 46);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(116, 23);
            this.lblkarbar.TabIndex = 271;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(84, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 23);
            this.label2.TabIndex = 254;
            this.label2.Text = "*";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(227, 48);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 23);
            this.label25.TabIndex = 272;
            this.label25.Text = ":نام کاربر";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(226, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 23);
            this.label3.TabIndex = 252;
            this.label3.Text = ":تاریخ";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(510, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 23);
            this.label10.TabIndex = 261;
            this.label10.Text = "*";
            // 
            // idfactortxt
            // 
            this.idfactortxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idfactortxt.Location = new System.Drawing.Point(527, 49);
            this.idfactortxt.Name = "idfactortxt";
            this.idfactortxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idfactortxt.Size = new System.Drawing.Size(117, 20);
            this.idfactortxt.TabIndex = 232;
            this.idfactortxt.TextChanged += new System.EventHandler(this.idfactortxt_TextChanged);
            this.idfactortxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idfactortxt_KeyDown);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(651, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 23);
            this.label4.TabIndex = 251;
            this.label4.Text = ":کد فاکتور";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(651, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 23);
            this.label11.TabIndex = 258;
            this.label11.Text = ":کد فاکتور خرید";
            // 
            // idkharidtxt
            // 
            this.idkharidtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idkharidtxt.Location = new System.Drawing.Point(527, 71);
            this.idkharidtxt.Name = "idkharidtxt";
            this.idkharidtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idkharidtxt.Size = new System.Drawing.Size(117, 20);
            this.idkharidtxt.TabIndex = 233;
            this.idkharidtxt.TextChanged += new System.EventHandler(this.idkharidtxt_TextChanged);
            this.idkharidtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idkharidtxt_KeyDown);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(510, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 255;
            this.label1.Text = "*";
            // 
            // label23
            // 
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(276, 381);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 19);
            this.label23.TabIndex = 323;
            this.label23.Text = " (-)";
            // 
            // darsadetakhfiftxt
            // 
            this.darsadetakhfiftxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.darsadetakhfiftxt.Location = new System.Drawing.Point(243, 378);
            this.darsadetakhfiftxt.Multiline = true;
            this.darsadetakhfiftxt.Name = "darsadetakhfiftxt";
            this.darsadetakhfiftxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.darsadetakhfiftxt.Size = new System.Drawing.Size(32, 21);
            this.darsadetakhfiftxt.TabIndex = 320;
            this.darsadetakhfiftxt.Text = "0";
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(196, 461);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 20);
            this.label22.TabIndex = 319;
            this.label22.Text = ":قیمت کل";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label21.Location = new System.Drawing.Point(195, 493);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 19);
            this.label21.TabIndex = 318;
            this.label21.Text = ":تخفیف خرید نقدی";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(196, 436);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(90, 23);
            this.label18.TabIndex = 315;
            this.label18.Text = ":دستمزد کارگران ";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(197, 408);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 23);
            this.label17.TabIndex = 314;
            this.label17.Text = ":کرایه حمل";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(198, 380);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 20);
            this.label16.TabIndex = 313;
            this.label16.Text = ":تخفیف";
            // 
            // gheimateaghlam
            // 
            this.gheimateaghlam.Location = new System.Drawing.Point(37, 340);
            this.gheimateaghlam.Multiline = true;
            this.gheimateaghlam.Name = "gheimateaghlam";
            this.gheimateaghlam.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateaghlam.Size = new System.Drawing.Size(149, 34);
            this.gheimateaghlam.TabIndex = 312;
            this.gheimateaghlam.Text = "0";
            this.gheimateaghlam.TextChanged += new System.EventHandler(this.gheimateaghlam_TextChanged);
            this.gheimateaghlam.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateaghlam_KeyDown);
            // 
            // mandetxt
            // 
            this.mandetxt.Location = new System.Drawing.Point(37, 514);
            this.mandetxt.Multiline = true;
            this.mandetxt.Name = "mandetxt";
            this.mandetxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mandetxt.Size = new System.Drawing.Size(149, 24);
            this.mandetxt.TabIndex = 310;
            this.mandetxt.Text = "0";
            this.mandetxt.TextChanged += new System.EventHandler(this.mandetxt_TextChanged);
            this.mandetxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mandetxt_KeyDown);
            // 
            // takhfifenaghdiyekharidtxt
            // 
            this.takhfifenaghdiyekharidtxt.Location = new System.Drawing.Point(37, 486);
            this.takhfifenaghdiyekharidtxt.Multiline = true;
            this.takhfifenaghdiyekharidtxt.Name = "takhfifenaghdiyekharidtxt";
            this.takhfifenaghdiyekharidtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.takhfifenaghdiyekharidtxt.Size = new System.Drawing.Size(149, 24);
            this.takhfifenaghdiyekharidtxt.TabIndex = 309;
            this.takhfifenaghdiyekharidtxt.Text = "0";
            this.takhfifenaghdiyekharidtxt.TextChanged += new System.EventHandler(this.takhfifenaghdiyekharidtxt_TextChanged);
            this.takhfifenaghdiyekharidtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.takhfifenaghdiyekharidtxt_KeyDown);
            // 
            // gheimatekoltxt
            // 
            this.gheimatekoltxt.Location = new System.Drawing.Point(37, 459);
            this.gheimatekoltxt.Multiline = true;
            this.gheimatekoltxt.Name = "gheimatekoltxt";
            this.gheimatekoltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekoltxt.Size = new System.Drawing.Size(149, 24);
            this.gheimatekoltxt.TabIndex = 308;
            this.gheimatekoltxt.Text = "0";
            this.gheimatekoltxt.TextChanged += new System.EventHandler(this.gheimatekoltxt_TextChanged);
            this.gheimatekoltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatekoltxt_KeyDown);
            // 
            // dastmozdekargartxt
            // 
            this.dastmozdekargartxt.Location = new System.Drawing.Point(37, 431);
            this.dastmozdekargartxt.Multiline = true;
            this.dastmozdekargartxt.Name = "dastmozdekargartxt";
            this.dastmozdekargartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dastmozdekargartxt.Size = new System.Drawing.Size(149, 24);
            this.dastmozdekargartxt.TabIndex = 307;
            this.dastmozdekargartxt.Text = "0";
            this.dastmozdekargartxt.TextChanged += new System.EventHandler(this.dastmozdekargartxt_TextChanged);
            this.dastmozdekargartxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dastmozdekargartxt_KeyDown);
            // 
            // kerayehamltxt
            // 
            this.kerayehamltxt.Location = new System.Drawing.Point(37, 404);
            this.kerayehamltxt.Multiline = true;
            this.kerayehamltxt.Name = "kerayehamltxt";
            this.kerayehamltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.kerayehamltxt.Size = new System.Drawing.Size(149, 24);
            this.kerayehamltxt.TabIndex = 306;
            this.kerayehamltxt.Text = "0";
            this.kerayehamltxt.TextChanged += new System.EventHandler(this.kerayehamltxt_TextChanged);
            this.kerayehamltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.kerayehamltxt_KeyDown);
            // 
            // takhfiftxt
            // 
            this.takhfiftxt.Location = new System.Drawing.Point(37, 377);
            this.takhfiftxt.Multiline = true;
            this.takhfiftxt.Name = "takhfiftxt";
            this.takhfiftxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.takhfiftxt.Size = new System.Drawing.Size(149, 24);
            this.takhfiftxt.TabIndex = 305;
            this.takhfiftxt.Text = "0";
            this.takhfiftxt.TextChanged += new System.EventHandler(this.takhfiftxt_TextChanged);
            this.takhfiftxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.takhfiftxt_KeyDown);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label14.Location = new System.Drawing.Point(195, 344);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 23);
            this.label14.TabIndex = 304;
            this.label14.Text = ":جمع اقلام";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // vahedkala6txt
            // 
            this.vahedkala6txt.Location = new System.Drawing.Point(323, 316);
            this.vahedkala6txt.Multiline = true;
            this.vahedkala6txt.Name = "vahedkala6txt";
            this.vahedkala6txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala6txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala6txt.TabIndex = 291;
            // 
            // vahedkala5txt
            // 
            this.vahedkala5txt.Location = new System.Drawing.Point(323, 292);
            this.vahedkala5txt.Multiline = true;
            this.vahedkala5txt.Name = "vahedkala5txt";
            this.vahedkala5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala5txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala5txt.TabIndex = 290;
            // 
            // vahedkala4txt
            // 
            this.vahedkala4txt.Location = new System.Drawing.Point(323, 268);
            this.vahedkala4txt.Multiline = true;
            this.vahedkala4txt.Name = "vahedkala4txt";
            this.vahedkala4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala4txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala4txt.TabIndex = 289;
            // 
            // vahedkala3txt
            // 
            this.vahedkala3txt.Location = new System.Drawing.Point(323, 244);
            this.vahedkala3txt.Multiline = true;
            this.vahedkala3txt.Name = "vahedkala3txt";
            this.vahedkala3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala3txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala3txt.TabIndex = 288;
            // 
            // vahedkala2txt
            // 
            this.vahedkala2txt.Location = new System.Drawing.Point(323, 220);
            this.vahedkala2txt.Multiline = true;
            this.vahedkala2txt.Name = "vahedkala2txt";
            this.vahedkala2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala2txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala2txt.TabIndex = 287;
            // 
            // vahedkala1txt
            // 
            this.vahedkala1txt.Location = new System.Drawing.Point(323, 196);
            this.vahedkala1txt.Multiline = true;
            this.vahedkala1txt.Name = "vahedkala1txt";
            this.vahedkala1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.vahedkala1txt.Size = new System.Drawing.Size(65, 22);
            this.vahedkala1txt.TabIndex = 286;
            // 
            // gheimateradif6txt
            // 
            this.gheimateradif6txt.Location = new System.Drawing.Point(37, 316);
            this.gheimateradif6txt.Multiline = true;
            this.gheimateradif6txt.Name = "gheimateradif6txt";
            this.gheimateradif6txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif6txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif6txt.TabIndex = 285;
            this.gheimateradif6txt.Text = "0";
            this.gheimateradif6txt.TextChanged += new System.EventHandler(this.gheimateradif6txt_TextChanged);
            this.gheimateradif6txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateradif6txt_KeyDown);
            // 
            // gheimateradif5txt
            // 
            this.gheimateradif5txt.Location = new System.Drawing.Point(37, 292);
            this.gheimateradif5txt.Multiline = true;
            this.gheimateradif5txt.Name = "gheimateradif5txt";
            this.gheimateradif5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif5txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif5txt.TabIndex = 284;
            this.gheimateradif5txt.Text = "0";
            this.gheimateradif5txt.TextChanged += new System.EventHandler(this.gheimateradif5txt_TextChanged);
            this.gheimateradif5txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateradif5txt_KeyDown);
            // 
            // gheimateradif4txt
            // 
            this.gheimateradif4txt.Location = new System.Drawing.Point(37, 268);
            this.gheimateradif4txt.Multiline = true;
            this.gheimateradif4txt.Name = "gheimateradif4txt";
            this.gheimateradif4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif4txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif4txt.TabIndex = 283;
            this.gheimateradif4txt.Text = "0";
            this.gheimateradif4txt.TextChanged += new System.EventHandler(this.gheimateradif4txt_TextChanged);
            this.gheimateradif4txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateradif4txt_KeyDown);
            // 
            // gheimateradif3txt
            // 
            this.gheimateradif3txt.Location = new System.Drawing.Point(37, 244);
            this.gheimateradif3txt.Multiline = true;
            this.gheimateradif3txt.Name = "gheimateradif3txt";
            this.gheimateradif3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif3txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif3txt.TabIndex = 282;
            this.gheimateradif3txt.Text = "0";
            this.gheimateradif3txt.TextChanged += new System.EventHandler(this.gheimateradif3txt_TextChanged);
            this.gheimateradif3txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateradif3txt_KeyDown);
            // 
            // gheimateradif2txt
            // 
            this.gheimateradif2txt.Location = new System.Drawing.Point(37, 220);
            this.gheimateradif2txt.Multiline = true;
            this.gheimateradif2txt.Name = "gheimateradif2txt";
            this.gheimateradif2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif2txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif2txt.TabIndex = 281;
            this.gheimateradif2txt.Text = "0";
            this.gheimateradif2txt.TextChanged += new System.EventHandler(this.gheimateradif2txt_TextChanged);
            this.gheimateradif2txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateradif2txt_KeyDown);
            // 
            // gheimateradif1txt
            // 
            this.gheimateradif1txt.Location = new System.Drawing.Point(37, 196);
            this.gheimateradif1txt.Multiline = true;
            this.gheimateradif1txt.Name = "gheimateradif1txt";
            this.gheimateradif1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimateradif1txt.Size = new System.Drawing.Size(149, 22);
            this.gheimateradif1txt.TabIndex = 280;
            this.gheimateradif1txt.Text = "0";
            this.gheimateradif1txt.TextChanged += new System.EventHandler(this.gheimateradif1txt_TextChanged);
            this.gheimateradif1txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimateradif1txt_KeyDown);
            // 
            // gheimatkala6txt
            // 
            this.gheimatkala6txt.Location = new System.Drawing.Point(188, 316);
            this.gheimatkala6txt.Multiline = true;
            this.gheimatkala6txt.Name = "gheimatkala6txt";
            this.gheimatkala6txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala6txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala6txt.TabIndex = 270;
            this.gheimatkala6txt.Text = "0";
            this.gheimatkala6txt.TextChanged += new System.EventHandler(this.gheimatkala6txt_TextChanged);
            this.gheimatkala6txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala6txt_KeyDown);
            // 
            // gheimatkala5txt
            // 
            this.gheimatkala5txt.Location = new System.Drawing.Point(188, 292);
            this.gheimatkala5txt.Multiline = true;
            this.gheimatkala5txt.Name = "gheimatkala5txt";
            this.gheimatkala5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala5txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala5txt.TabIndex = 267;
            this.gheimatkala5txt.Text = "0";
            this.gheimatkala5txt.TextChanged += new System.EventHandler(this.gheimatkala5txt_TextChanged);
            this.gheimatkala5txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala5txt_KeyDown);
            // 
            // gheimatkala4txt
            // 
            this.gheimatkala4txt.Location = new System.Drawing.Point(188, 268);
            this.gheimatkala4txt.Multiline = true;
            this.gheimatkala4txt.Name = "gheimatkala4txt";
            this.gheimatkala4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala4txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala4txt.TabIndex = 253;
            this.gheimatkala4txt.Text = "0";
            this.gheimatkala4txt.TextChanged += new System.EventHandler(this.gheimatkala4txt_TextChanged);
            this.gheimatkala4txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala4txt_KeyDown);
            // 
            // gheimatkala3txt
            // 
            this.gheimatkala3txt.Location = new System.Drawing.Point(188, 244);
            this.gheimatkala3txt.Multiline = true;
            this.gheimatkala3txt.Name = "gheimatkala3txt";
            this.gheimatkala3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala3txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala3txt.TabIndex = 248;
            this.gheimatkala3txt.Text = "0";
            this.gheimatkala3txt.TextChanged += new System.EventHandler(this.gheimatkala3txt_TextChanged);
            this.gheimatkala3txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala3txt_KeyDown);
            // 
            // gheimatkala2txt
            // 
            this.gheimatkala2txt.Location = new System.Drawing.Point(188, 220);
            this.gheimatkala2txt.Multiline = true;
            this.gheimatkala2txt.Name = "gheimatkala2txt";
            this.gheimatkala2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala2txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala2txt.TabIndex = 245;
            this.gheimatkala2txt.Text = "0";
            this.gheimatkala2txt.TextChanged += new System.EventHandler(this.gheimatkala2txt_TextChanged);
            this.gheimatkala2txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala2txt_KeyDown);
            // 
            // gheimatkala1txt
            // 
            this.gheimatkala1txt.Location = new System.Drawing.Point(188, 196);
            this.gheimatkala1txt.Multiline = true;
            this.gheimatkala1txt.Name = "gheimatkala1txt";
            this.gheimatkala1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala1txt.Size = new System.Drawing.Size(132, 22);
            this.gheimatkala1txt.TabIndex = 242;
            this.gheimatkala1txt.Text = "0";
            this.gheimatkala1txt.TextChanged += new System.EventHandler(this.gheimatkala1txt_TextChanged);
            this.gheimatkala1txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala1txt_KeyDown);
            // 
            // tedadkala6nud
            // 
            this.tedadkala6nud.AutoSize = true;
            this.tedadkala6nud.Location = new System.Drawing.Point(391, 316);
            this.tedadkala6nud.Name = "tedadkala6nud";
            this.tedadkala6nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala6nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala6nud.TabIndex = 269;
            this.tedadkala6nud.ValueChanged += new System.EventHandler(this.tedadkala6nud_ValueChanged);
            // 
            // tedadkala5nud
            // 
            this.tedadkala5nud.AutoSize = true;
            this.tedadkala5nud.Location = new System.Drawing.Point(391, 292);
            this.tedadkala5nud.Name = "tedadkala5nud";
            this.tedadkala5nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala5nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala5nud.TabIndex = 266;
            this.tedadkala5nud.ValueChanged += new System.EventHandler(this.tedadkala5nud_ValueChanged);
            // 
            // tedadkala4nud
            // 
            this.tedadkala4nud.AutoSize = true;
            this.tedadkala4nud.Location = new System.Drawing.Point(391, 268);
            this.tedadkala4nud.Name = "tedadkala4nud";
            this.tedadkala4nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala4nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala4nud.TabIndex = 250;
            this.tedadkala4nud.ValueChanged += new System.EventHandler(this.tedadkala4nud_ValueChanged);
            // 
            // tedadkala3nud
            // 
            this.tedadkala3nud.AutoSize = true;
            this.tedadkala3nud.Location = new System.Drawing.Point(391, 244);
            this.tedadkala3nud.Name = "tedadkala3nud";
            this.tedadkala3nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala3nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala3nud.TabIndex = 247;
            this.tedadkala3nud.ValueChanged += new System.EventHandler(this.tedadkala3nud_ValueChanged);
            // 
            // tedadkala2nud
            // 
            this.tedadkala2nud.AutoSize = true;
            this.tedadkala2nud.Location = new System.Drawing.Point(391, 220);
            this.tedadkala2nud.Name = "tedadkala2nud";
            this.tedadkala2nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala2nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala2nud.TabIndex = 244;
            this.tedadkala2nud.ValueChanged += new System.EventHandler(this.tedadkala2nud_ValueChanged);
            // 
            // tedadkala1nud
            // 
            this.tedadkala1nud.AutoSize = true;
            this.tedadkala1nud.Location = new System.Drawing.Point(391, 197);
            this.tedadkala1nud.Name = "tedadkala1nud";
            this.tedadkala1nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala1nud.Size = new System.Drawing.Size(53, 20);
            this.tedadkala1nud.TabIndex = 241;
            this.tedadkala1nud.ValueChanged += new System.EventHandler(this.tedadkala1nud_ValueChanged);
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label37.Location = new System.Drawing.Point(61, 171);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(99, 23);
            this.label37.TabIndex = 279;
            this.label37.Text = "جمع ";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label36.Location = new System.Drawing.Point(203, 171);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(108, 23);
            this.label36.TabIndex = 278;
            this.label36.Text = "قیمت واحد";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label33.Location = new System.Drawing.Point(330, 171);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(54, 23);
            this.label33.TabIndex = 277;
            this.label33.Text = "واحد کالا";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label32.Location = new System.Drawing.Point(393, 171);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(50, 23);
            this.label32.TabIndex = 276;
            this.label32.Text = "تعداد";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label31.Location = new System.Drawing.Point(453, 172);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(98, 23);
            this.label31.TabIndex = 275;
            this.label31.Text = "نام کالا";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label6.Location = new System.Drawing.Point(741, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 23);
            this.label6.TabIndex = 273;
            this.label6.Text = "ردیف";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Big1;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(2, 3);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(31, 28);
            this.enserafbtn.TabIndex = 371;
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(101, 3);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 369;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // rectangleShape3
            // 
            this.rectangleShape3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape3.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape3.Location = new System.Drawing.Point(78, 111);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new System.Drawing.Size(653, 54);
            // 
            // lineShape20
            // 
            this.lineShape20.Name = "lineShape20";
            this.lineShape20.X1 = 79;
            this.lineShape20.X2 = 731;
            this.lineShape20.Y1 = 140;
            this.lineShape20.Y2 = 140;
            // 
            // lineShape21
            // 
            this.lineShape21.Name = "lineShape21";
            this.lineShape21.X1 = 588;
            this.lineShape21.X2 = 588;
            this.lineShape21.Y1 = 112;
            this.lineShape21.Y2 = 164;
            // 
            // lineShape22
            // 
            this.lineShape22.Name = "lineShape22";
            this.lineShape22.X1 = 444;
            this.lineShape22.X2 = 444;
            this.lineShape22.Y1 = 111;
            this.lineShape22.Y2 = 164;
            // 
            // lineShape23
            // 
            this.lineShape23.Name = "lineShape23";
            this.lineShape23.X1 = 242;
            this.lineShape23.X2 = 242;
            this.lineShape23.Y1 = 111;
            this.lineShape23.Y2 = 164;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape73,
            this.lineShape72,
            this.lineShape71,
            this.lineShape70,
            this.lineShape63,
            this.lineShape56,
            this.lineShape25,
            this.lineShape24,
            this.rectangleShape11,
            this.lineShape69,
            this.lineShape68,
            this.lineShape67,
            this.lineShape66,
            this.lineShape65,
            this.lineShape64,
            this.rectangleShape10,
            this.lineShape62,
            this.lineShape61,
            this.lineShape60,
            this.lineShape59,
            this.lineShape58,
            this.rectangleShape9,
            this.lineShape57,
            this.lineShape55,
            this.lineShape54,
            this.lineShape53,
            this.lineShape52,
            this.lineShape51,
            this.lineShape50,
            this.lineShape49,
            this.lineShape48,
            this.lineShape47,
            this.lineShape46,
            this.lineShape45,
            this.lineShape44,
            this.lineShape43,
            this.lineShape42,
            this.lineShape41,
            this.lineShape40,
            this.lineShape39,
            this.lineShape38,
            this.rectangleShape1,
            this.lineShape1,
            this.lineShape2,
            this.lineShape3,
            this.lineShape4,
            this.lineShape5,
            this.lineShape6,
            this.lineShape7,
            this.lineShape8,
            this.lineShape9,
            this.lineShape10,
            this.lineShape11,
            this.lineShape12,
            this.lineShape13,
            this.rectangleShape2,
            this.lineShape14,
            this.lineShape15,
            this.lineShape16,
            this.lineShape17,
            this.lineShape18,
            this.lineShape19,
            this.rectangleShape4,
            this.rectangleShape5,
            this.rectangleShape6,
            this.lineShape26,
            this.lineShape27,
            this.lineShape28,
            this.lineShape29,
            this.lineShape30,
            this.lineShape31,
            this.lineShape32,
            this.lineShape33,
            this.lineShape34,
            this.lineShape35,
            this.lineShape36,
            this.lineShape37,
            this.rectangleShape7,
            this.rectangleShape8,
            this.lineShape23,
            this.lineShape22,
            this.lineShape21,
            this.lineShape20,
            this.rectangleShape3});
            this.shapeContainer1.Size = new System.Drawing.Size(813, 745);
            this.shapeContainer1.TabIndex = 372;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape72
            // 
            this.lineShape72.Name = "lineShape72";
            this.lineShape72.X1 = 186;
            this.lineShape72.X2 = 186;
            this.lineShape72.Y1 = 648;
            this.lineShape72.Y2 = 696;
            // 
            // lineShape71
            // 
            this.lineShape71.Name = "lineShape71";
            this.lineShape71.X1 = 311;
            this.lineShape71.X2 = 311;
            this.lineShape71.Y1 = 648;
            this.lineShape71.Y2 = 696;
            // 
            // lineShape70
            // 
            this.lineShape70.Name = "lineShape70";
            this.lineShape70.X1 = 378;
            this.lineShape70.X2 = 378;
            this.lineShape70.Y1 = 647;
            this.lineShape70.Y2 = 695;
            // 
            // lineShape63
            // 
            this.lineShape63.Name = "lineShape63";
            this.lineShape63.X1 = 470;
            this.lineShape63.X2 = 470;
            this.lineShape63.Y1 = 647;
            this.lineShape63.Y2 = 696;
            // 
            // lineShape56
            // 
            this.lineShape56.Name = "lineShape56";
            this.lineShape56.X1 = 540;
            this.lineShape56.X2 = 540;
            this.lineShape56.Y1 = 648;
            this.lineShape56.Y2 = 696;
            // 
            // lineShape25
            // 
            this.lineShape25.Name = "lineShape25";
            this.lineShape25.X1 = 36;
            this.lineShape25.X2 = 697;
            this.lineShape25.Y1 = 673;
            this.lineShape25.Y2 = 673;
            // 
            // lineShape24
            // 
            this.lineShape24.Name = "lineShape24";
            this.lineShape24.X1 = 653;
            this.lineShape24.X2 = 653;
            this.lineShape24.Y1 = 648;
            this.lineShape24.Y2 = 696;
            // 
            // rectangleShape11
            // 
            this.rectangleShape11.Location = new System.Drawing.Point(37, 647);
            this.rectangleShape11.Name = "rectangleShape11";
            this.rectangleShape11.Size = new System.Drawing.Size(660, 49);
            // 
            // lineShape69
            // 
            this.lineShape69.Name = "lineShape69";
            this.lineShape69.X1 = 36;
            this.lineShape69.X2 = 697;
            this.lineShape69.Y1 = 621;
            this.lineShape69.Y2 = 621;
            // 
            // lineShape68
            // 
            this.lineShape68.Name = "lineShape68";
            this.lineShape68.X1 = 186;
            this.lineShape68.X2 = 186;
            this.lineShape68.Y1 = 594;
            this.lineShape68.Y2 = 644;
            // 
            // lineShape67
            // 
            this.lineShape67.Name = "lineShape67";
            this.lineShape67.X1 = 311;
            this.lineShape67.X2 = 311;
            this.lineShape67.Y1 = 594;
            this.lineShape67.Y2 = 644;
            // 
            // lineShape66
            // 
            this.lineShape66.Name = "lineShape66";
            this.lineShape66.X1 = 430;
            this.lineShape66.X2 = 430;
            this.lineShape66.Y1 = 595;
            this.lineShape66.Y2 = 644;
            // 
            // lineShape65
            // 
            this.lineShape65.Name = "lineShape65";
            this.lineShape65.X1 = 540;
            this.lineShape65.X2 = 540;
            this.lineShape65.Y1 = 596;
            this.lineShape65.Y2 = 644;
            // 
            // lineShape64
            // 
            this.lineShape64.Name = "lineShape64";
            this.lineShape64.X1 = 653;
            this.lineShape64.X2 = 653;
            this.lineShape64.Y1 = 596;
            this.lineShape64.Y2 = 644;
            // 
            // rectangleShape10
            // 
            this.rectangleShape10.Location = new System.Drawing.Point(37, 595);
            this.rectangleShape10.Name = "rectangleShape10";
            this.rectangleShape10.Size = new System.Drawing.Size(660, 49);
            // 
            // lineShape62
            // 
            this.lineShape62.Name = "lineShape62";
            this.lineShape62.X1 = 36;
            this.lineShape62.X2 = 697;
            this.lineShape62.Y1 = 569;
            this.lineShape62.Y2 = 569;
            // 
            // lineShape61
            // 
            this.lineShape61.Name = "lineShape61";
            this.lineShape61.X1 = 653;
            this.lineShape61.X2 = 653;
            this.lineShape61.Y1 = 544;
            this.lineShape61.Y2 = 592;
            // 
            // lineShape60
            // 
            this.lineShape60.Name = "lineShape60";
            this.lineShape60.X1 = 540;
            this.lineShape60.X2 = 540;
            this.lineShape60.Y1 = 544;
            this.lineShape60.Y2 = 592;
            // 
            // lineShape59
            // 
            this.lineShape59.Name = "lineShape59";
            this.lineShape59.X1 = 430;
            this.lineShape59.X2 = 430;
            this.lineShape59.Y1 = 543;
            this.lineShape59.Y2 = 592;
            // 
            // lineShape58
            // 
            this.lineShape58.Name = "lineShape58";
            this.lineShape58.X1 = 311;
            this.lineShape58.X2 = 311;
            this.lineShape58.Y1 = 542;
            this.lineShape58.Y2 = 592;
            // 
            // rectangleShape9
            // 
            this.rectangleShape9.Location = new System.Drawing.Point(37, 543);
            this.rectangleShape9.Name = "rectangleShape9";
            this.rectangleShape9.Size = new System.Drawing.Size(660, 49);
            // 
            // lineShape57
            // 
            this.lineShape57.Name = "lineShape57";
            this.lineShape57.X1 = 186;
            this.lineShape57.X2 = 186;
            this.lineShape57.Y1 = 542;
            this.lineShape57.Y2 = 592;
            // 
            // lineShape55
            // 
            this.lineShape55.Name = "lineShape55";
            this.lineShape55.X1 = 37;
            this.lineShape55.X2 = 186;
            this.lineShape55.Y1 = 512;
            this.lineShape55.Y2 = 512;
            // 
            // lineShape54
            // 
            this.lineShape54.Name = "lineShape54";
            this.lineShape54.X1 = 37;
            this.lineShape54.X2 = 186;
            this.lineShape54.Y1 = 485;
            this.lineShape54.Y2 = 485;
            // 
            // lineShape53
            // 
            this.lineShape53.Name = "lineShape53";
            this.lineShape53.X1 = 37;
            this.lineShape53.X2 = 186;
            this.lineShape53.Y1 = 456;
            this.lineShape53.Y2 = 456;
            // 
            // lineShape52
            // 
            this.lineShape52.Name = "lineShape52";
            this.lineShape52.X1 = 37;
            this.lineShape52.X2 = 186;
            this.lineShape52.Y1 = 429;
            this.lineShape52.Y2 = 429;
            // 
            // lineShape51
            // 
            this.lineShape51.Name = "lineShape51";
            this.lineShape51.X1 = 37;
            this.lineShape51.X2 = 186;
            this.lineShape51.Y1 = 402;
            this.lineShape51.Y2 = 402;
            // 
            // lineShape50
            // 
            this.lineShape50.Name = "lineShape50";
            this.lineShape50.X1 = 737;
            this.lineShape50.X2 = 737;
            this.lineShape50.Y1 = 170;
            this.lineShape50.Y2 = 337;
            // 
            // lineShape49
            // 
            this.lineShape49.Name = "lineShape49";
            this.lineShape49.X1 = 560;
            this.lineShape49.X2 = 560;
            this.lineShape49.Y1 = 171;
            this.lineShape49.Y2 = 339;
            // 
            // lineShape48
            // 
            this.lineShape48.Name = "lineShape48";
            this.lineShape48.X1 = 445;
            this.lineShape48.X2 = 445;
            this.lineShape48.Y1 = 170;
            this.lineShape48.Y2 = 338;
            // 
            // lineShape47
            // 
            this.lineShape47.Name = "lineShape47";
            this.lineShape47.X1 = 389;
            this.lineShape47.X2 = 389;
            this.lineShape47.Y1 = 170;
            this.lineShape47.Y2 = 337;
            // 
            // lineShape46
            // 
            this.lineShape46.Name = "lineShape46";
            this.lineShape46.X1 = 321;
            this.lineShape46.X2 = 321;
            this.lineShape46.Y1 = 170;
            this.lineShape46.Y2 = 338;
            // 
            // lineShape45
            // 
            this.lineShape45.Name = "lineShape45";
            this.lineShape45.X1 = 186;
            this.lineShape45.X2 = 186;
            this.lineShape45.Y1 = 170;
            this.lineShape45.Y2 = 373;
            // 
            // lineShape44
            // 
            this.lineShape44.Name = "lineShape44";
            this.lineShape44.X1 = 37;
            this.lineShape44.X2 = 776;
            this.lineShape44.Y1 = 338;
            this.lineShape44.Y2 = 338;
            // 
            // lineShape43
            // 
            this.lineShape43.Name = "lineShape43";
            this.lineShape43.X1 = 37;
            this.lineShape43.X2 = 776;
            this.lineShape43.Y1 = 314;
            this.lineShape43.Y2 = 314;
            // 
            // lineShape42
            // 
            this.lineShape42.Name = "lineShape42";
            this.lineShape42.X1 = 37;
            this.lineShape42.X2 = 776;
            this.lineShape42.Y1 = 290;
            this.lineShape42.Y2 = 290;
            // 
            // lineShape41
            // 
            this.lineShape41.Name = "lineShape41";
            this.lineShape41.X1 = 37;
            this.lineShape41.X2 = 776;
            this.lineShape41.Y1 = 266;
            this.lineShape41.Y2 = 266;
            // 
            // lineShape40
            // 
            this.lineShape40.Name = "lineShape40";
            this.lineShape40.X1 = 37;
            this.lineShape40.X2 = 776;
            this.lineShape40.Y1 = 242;
            this.lineShape40.Y2 = 242;
            // 
            // lineShape39
            // 
            this.lineShape39.Name = "lineShape39";
            this.lineShape39.X1 = 37;
            this.lineShape39.X2 = 776;
            this.lineShape39.Y1 = 218;
            this.lineShape39.Y2 = 218;
            // 
            // lineShape38
            // 
            this.lineShape38.Name = "lineShape38";
            this.lineShape38.X1 = 37;
            this.lineShape38.X2 = 776;
            this.lineShape38.Y1 = 195;
            this.lineShape38.Y2 = 195;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.BorderColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rectangleShape1.Location = new System.Drawing.Point(36, 170);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(741, 204);
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 37;
            this.lineShape1.X2 = 776;
            this.lineShape1.Y1 = 195;
            this.lineShape1.Y2 = 195;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 739;
            this.lineShape2.X2 = 739;
            this.lineShape2.Y1 = 170;
            this.lineShape2.Y2 = 337;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 591;
            this.lineShape3.X2 = 591;
            this.lineShape3.Y1 = 171;
            this.lineShape3.Y2 = 339;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 445;
            this.lineShape4.X2 = 445;
            this.lineShape4.Y1 = 170;
            this.lineShape4.Y2 = 338;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 389;
            this.lineShape5.X2 = 389;
            this.lineShape5.Y1 = 170;
            this.lineShape5.Y2 = 337;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 321;
            this.lineShape6.X2 = 321;
            this.lineShape6.Y1 = 170;
            this.lineShape6.Y2 = 338;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 186;
            this.lineShape7.X2 = 186;
            this.lineShape7.Y1 = 170;
            this.lineShape7.Y2 = 373;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 37;
            this.lineShape8.X2 = 776;
            this.lineShape8.Y1 = 218;
            this.lineShape8.Y2 = 218;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 37;
            this.lineShape9.X2 = 776;
            this.lineShape9.Y1 = 242;
            this.lineShape9.Y2 = 242;
            // 
            // lineShape10
            // 
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 37;
            this.lineShape10.X2 = 776;
            this.lineShape10.Y1 = 266;
            this.lineShape10.Y2 = 266;
            // 
            // lineShape11
            // 
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 37;
            this.lineShape11.X2 = 776;
            this.lineShape11.Y1 = 290;
            this.lineShape11.Y2 = 290;
            // 
            // lineShape12
            // 
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 37;
            this.lineShape12.X2 = 776;
            this.lineShape12.Y1 = 314;
            this.lineShape12.Y2 = 314;
            // 
            // lineShape13
            // 
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 37;
            this.lineShape13.X2 = 776;
            this.lineShape13.Y1 = 338;
            this.lineShape13.Y2 = 338;
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape2.Location = new System.Drawing.Point(36, 375);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(150, 165);
            // 
            // lineShape14
            // 
            this.lineShape14.Name = "lineShape14";
            this.lineShape14.X1 = 37;
            this.lineShape14.X2 = 186;
            this.lineShape14.Y1 = 402;
            this.lineShape14.Y2 = 402;
            // 
            // lineShape15
            // 
            this.lineShape15.Name = "lineShape15";
            this.lineShape15.X1 = 37;
            this.lineShape15.X2 = 186;
            this.lineShape15.Y1 = 429;
            this.lineShape15.Y2 = 429;
            // 
            // lineShape16
            // 
            this.lineShape16.Name = "lineShape16";
            this.lineShape16.X1 = 37;
            this.lineShape16.X2 = 186;
            this.lineShape16.Y1 = 456;
            this.lineShape16.Y2 = 456;
            // 
            // lineShape17
            // 
            this.lineShape17.Name = "lineShape17";
            this.lineShape17.X1 = 37;
            this.lineShape17.X2 = 186;
            this.lineShape17.Y1 = 484;
            this.lineShape17.Y2 = 484;
            // 
            // lineShape18
            // 
            this.lineShape18.Name = "lineShape18";
            this.lineShape18.X1 = 37;
            this.lineShape18.X2 = 186;
            this.lineShape18.Y1 = 512;
            this.lineShape18.Y2 = 512;
            // 
            // lineShape19
            // 
            this.lineShape19.Name = "lineShape19";
            this.lineShape19.X1 = 37;
            this.lineShape19.X2 = 186;
            this.lineShape19.Y1 = 540;
            this.lineShape19.Y2 = 540;
            // 
            // rectangleShape4
            // 
            this.rectangleShape4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape4.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape4.Location = new System.Drawing.Point(36, 541);
            this.rectangleShape4.Name = "rectangleShape4";
            this.rectangleShape4.Size = new System.Drawing.Size(745, 159);
            // 
            // rectangleShape5
            // 
            this.rectangleShape5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape5.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape5.Location = new System.Drawing.Point(36, 486);
            this.rectangleShape5.Name = "rectangleShape5";
            this.rectangleShape5.Size = new System.Drawing.Size(745, 54);
            // 
            // rectangleShape6
            // 
            this.rectangleShape6.Location = new System.Drawing.Point(37, 543);
            this.rectangleShape6.Name = "rectangleShape6";
            this.rectangleShape6.Size = new System.Drawing.Size(660, 49);
            // 
            // lineShape26
            // 
            this.lineShape26.Name = "lineShape26";
            this.lineShape26.X1 = 36;
            this.lineShape26.X2 = 697;
            this.lineShape26.Y1 = 569;
            this.lineShape26.Y2 = 569;
            // 
            // lineShape27
            // 
            this.lineShape27.Name = "lineShape27";
            this.lineShape27.X1 = 653;
            this.lineShape27.X2 = 653;
            this.lineShape27.Y1 = 544;
            this.lineShape27.Y2 = 592;
            // 
            // lineShape28
            // 
            this.lineShape28.Name = "lineShape28";
            this.lineShape28.X1 = 540;
            this.lineShape28.X2 = 540;
            this.lineShape28.Y1 = 544;
            this.lineShape28.Y2 = 592;
            // 
            // lineShape29
            // 
            this.lineShape29.Name = "lineShape29";
            this.lineShape29.X1 = 430;
            this.lineShape29.X2 = 430;
            this.lineShape29.Y1 = 543;
            this.lineShape29.Y2 = 592;
            // 
            // lineShape30
            // 
            this.lineShape30.Name = "lineShape30";
            this.lineShape30.X1 = 186;
            this.lineShape30.X2 = 186;
            this.lineShape30.Y1 = 542;
            this.lineShape30.Y2 = 592;
            // 
            // lineShape31
            // 
            this.lineShape31.Name = "lineShape31";
            this.lineShape31.X1 = 311;
            this.lineShape31.X2 = 311;
            this.lineShape31.Y1 = 542;
            this.lineShape31.Y2 = 592;
            // 
            // lineShape32
            // 
            this.lineShape32.Name = "lineShape32";
            this.lineShape32.X1 = 186;
            this.lineShape32.X2 = 186;
            this.lineShape32.Y1 = 594;
            this.lineShape32.Y2 = 644;
            // 
            // lineShape33
            // 
            this.lineShape33.Name = "lineShape33";
            this.lineShape33.X1 = 311;
            this.lineShape33.X2 = 311;
            this.lineShape33.Y1 = 594;
            this.lineShape33.Y2 = 644;
            // 
            // lineShape34
            // 
            this.lineShape34.Name = "lineShape34";
            this.lineShape34.X1 = 430;
            this.lineShape34.X2 = 430;
            this.lineShape34.Y1 = 595;
            this.lineShape34.Y2 = 644;
            // 
            // lineShape35
            // 
            this.lineShape35.Name = "lineShape35";
            this.lineShape35.X1 = 653;
            this.lineShape35.X2 = 653;
            this.lineShape35.Y1 = 596;
            this.lineShape35.Y2 = 644;
            // 
            // lineShape36
            // 
            this.lineShape36.Name = "lineShape36";
            this.lineShape36.X1 = 540;
            this.lineShape36.X2 = 540;
            this.lineShape36.Y1 = 596;
            this.lineShape36.Y2 = 644;
            // 
            // lineShape37
            // 
            this.lineShape37.Name = "lineShape37";
            this.lineShape37.X1 = 36;
            this.lineShape37.X2 = 697;
            this.lineShape37.Y1 = 621;
            this.lineShape37.Y2 = 621;
            // 
            // rectangleShape7
            // 
            this.rectangleShape7.Location = new System.Drawing.Point(37, 595);
            this.rectangleShape7.Name = "rectangleShape7";
            this.rectangleShape7.Size = new System.Drawing.Size(660, 49);
            // 
            // rectangleShape8
            // 
            this.rectangleShape8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape8.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape8.Location = new System.Drawing.Point(592, 375);
            this.rectangleShape8.Name = "rectangleShape8";
            this.rectangleShape8.Size = new System.Drawing.Size(185, 24);
            // 
            // addghestybtn
            // 
            this.addghestybtn.Location = new System.Drawing.Point(784, 646);
            this.addghestybtn.Name = "addghestybtn";
            this.addghestybtn.Size = new System.Drawing.Size(26, 23);
            this.addghestybtn.TabIndex = 407;
            this.addghestybtn.Text = "+";
            this.addghestybtn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.addghestybtn.UseVisualStyleBackColor = true;
            this.addghestybtn.Click += new System.EventHandler(this.addghestybtn_Click);
            // 
            // tarikhepardakhteghestmtxt
            // 
            this.tarikhepardakhteghestmtxt.Location = new System.Drawing.Point(541, 675);
            this.tarikhepardakhteghestmtxt.Mask = "9999/99/99";
            this.tarikhepardakhteghestmtxt.Name = "tarikhepardakhteghestmtxt";
            this.tarikhepardakhteghestmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhepardakhteghestmtxt.Size = new System.Drawing.Size(112, 20);
            this.tarikhepardakhteghestmtxt.TabIndex = 406;
            // 
            // tedadeaghsattxt
            // 
            this.tedadeaghsattxt.Location = new System.Drawing.Point(471, 675);
            this.tedadeaghsattxt.Multiline = true;
            this.tedadeaghsattxt.Name = "tedadeaghsattxt";
            this.tedadeaghsattxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadeaghsattxt.Size = new System.Drawing.Size(69, 20);
            this.tedadeaghsattxt.TabIndex = 405;
            this.tedadeaghsattxt.TextChanged += new System.EventHandler(this.tedadeaghsattxt_TextChanged);
            this.tedadeaghsattxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedadeaghsattxt_KeyDown);
            // 
            // tedademandeghestmtxt
            // 
            this.tedademandeghestmtxt.Location = new System.Drawing.Point(379, 675);
            this.tedademandeghestmtxt.Multiline = true;
            this.tedademandeghestmtxt.Name = "tedademandeghestmtxt";
            this.tedademandeghestmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedademandeghestmtxt.Size = new System.Drawing.Size(91, 20);
            this.tedademandeghestmtxt.TabIndex = 404;
            this.tedademandeghestmtxt.TextChanged += new System.EventHandler(this.tedademandeghestmtxt_TextChanged);
            this.tedademandeghestmtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tedademandeghestmtxt_KeyDown);
            // 
            // darsadsoodghesttxt
            // 
            this.darsadsoodghesttxt.Location = new System.Drawing.Point(312, 675);
            this.darsadsoodghesttxt.Multiline = true;
            this.darsadsoodghesttxt.Name = "darsadsoodghesttxt";
            this.darsadsoodghesttxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.darsadsoodghesttxt.Size = new System.Drawing.Size(66, 20);
            this.darsadsoodghesttxt.TabIndex = 403;
            this.darsadsoodghesttxt.Text = "0";
            this.darsadsoodghesttxt.TextChanged += new System.EventHandler(this.darsadsoodghesttxt_TextChanged);
            this.darsadsoodghesttxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.darsadsoodghesttxt_KeyDown);
            // 
            // mablagheghesttxt
            // 
            this.mablagheghesttxt.Location = new System.Drawing.Point(187, 675);
            this.mablagheghesttxt.Multiline = true;
            this.mablagheghesttxt.Name = "mablagheghesttxt";
            this.mablagheghesttxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablagheghesttxt.Size = new System.Drawing.Size(124, 20);
            this.mablagheghesttxt.TabIndex = 402;
            this.mablagheghesttxt.Text = "0";
            this.mablagheghesttxt.TextChanged += new System.EventHandler(this.mablagheghesttxt_TextChanged);
            this.mablagheghesttxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablagheghesttxt_KeyDown);
            // 
            // mablaghekoleaghsattxt
            // 
            this.mablaghekoleaghsattxt.Location = new System.Drawing.Point(38, 675);
            this.mablaghekoleaghsattxt.Multiline = true;
            this.mablaghekoleaghsattxt.Name = "mablaghekoleaghsattxt";
            this.mablaghekoleaghsattxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mablaghekoleaghsattxt.Size = new System.Drawing.Size(148, 20);
            this.mablaghekoleaghsattxt.TabIndex = 401;
            this.mablaghekoleaghsattxt.Text = "0";
            this.mablaghekoleaghsattxt.TextChanged += new System.EventHandler(this.mablaghekoleaghsattxt_TextChanged);
            this.mablaghekoleaghsattxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mablaghekoleaghsattxt_KeyDown);
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label65.Location = new System.Drawing.Point(91, 651);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(45, 19);
            this.label65.TabIndex = 400;
            this.label65.Text = "کل مبلغ";
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label64.Location = new System.Drawing.Point(218, 651);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(72, 19);
            this.label64.TabIndex = 399;
            this.label64.Text = "مبلغ هر قسط";
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label63.Location = new System.Drawing.Point(320, 651);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(56, 19);
            this.label63.TabIndex = 398;
            this.label63.Text = "درصد سود";
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label62.Location = new System.Drawing.Point(379, 651);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(90, 19);
            this.label62.TabIndex = 397;
            this.label62.Text = "تعداد اقساط مانده";
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label61.Location = new System.Drawing.Point(475, 651);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(63, 19);
            this.label61.TabIndex = 396;
            this.label61.Text = "تعداد اقساط";
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label60.Location = new System.Drawing.Point(550, 651);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(93, 19);
            this.label60.TabIndex = 395;
            this.label60.Text = "تاریخ پرداخت قسط";
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label59.Location = new System.Drawing.Point(698, 646);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(83, 19);
            this.label59.TabIndex = 394;
            this.label59.Text = ":پرداخت قسطی";
            // 
            // idghestytxt
            // 
            this.idghestytxt.Location = new System.Drawing.Point(654, 675);
            this.idghestytxt.Multiline = true;
            this.idghestytxt.Name = "idghestytxt";
            this.idghestytxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idghestytxt.Size = new System.Drawing.Size(43, 20);
            this.idghestytxt.TabIndex = 393;
            this.idghestytxt.Text = "0";
            this.idghestytxt.TextChanged += new System.EventHandler(this.idghestytxt_TextChanged);
            this.idghestytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idghestytxt_KeyDown);
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label58.Location = new System.Drawing.Point(666, 651);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(22, 19);
            this.label58.TabIndex = 392;
            this.label58.Text = "کد";
            // 
            // addnaghdbtn
            // 
            this.addnaghdbtn.Location = new System.Drawing.Point(784, 487);
            this.addnaghdbtn.Name = "addnaghdbtn";
            this.addnaghdbtn.Size = new System.Drawing.Size(26, 23);
            this.addnaghdbtn.TabIndex = 408;
            this.addnaghdbtn.Text = "+";
            this.addnaghdbtn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.addnaghdbtn.UseVisualStyleBackColor = true;
            this.addnaghdbtn.Click += new System.EventHandler(this.addnaghdbtn_Click);
            // 
            // sabtesanadbtn
            // 
            this.sabtesanadbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtesanadbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtesanadbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtesanadbtn.Location = new System.Drawing.Point(634, 706);
            this.sabtesanadbtn.Name = "sabtesanadbtn";
            this.sabtesanadbtn.Size = new System.Drawing.Size(148, 28);
            this.sabtesanadbtn.TabIndex = 514;
            this.sabtesanadbtn.Text = " ثبت در سند حسابداری";
            this.sabtesanadbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtesanadbtn.UseVisualStyleBackColor = true;
            this.sabtesanadbtn.Click += new System.EventHandler(this.sabtesanadbtn_Click);
            // 
            // id6txt
            // 
            this.id6txt.Location = new System.Drawing.Point(681, 316);
            this.id6txt.Multiline = true;
            this.id6txt.Name = "id6txt";
            this.id6txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id6txt.Size = new System.Drawing.Size(56, 22);
            this.id6txt.TabIndex = 538;
            this.id6txt.TextChanged += new System.EventHandler(this.id6txt_TextChanged);
            this.id6txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.id6txt_KeyDown);
            // 
            // id5txt
            // 
            this.id5txt.Location = new System.Drawing.Point(681, 292);
            this.id5txt.Multiline = true;
            this.id5txt.Name = "id5txt";
            this.id5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id5txt.Size = new System.Drawing.Size(56, 22);
            this.id5txt.TabIndex = 537;
            this.id5txt.TextChanged += new System.EventHandler(this.id5txt_TextChanged);
            this.id5txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.id5txt_KeyDown);
            // 
            // id4txt
            // 
            this.id4txt.Location = new System.Drawing.Point(681, 268);
            this.id4txt.Multiline = true;
            this.id4txt.Name = "id4txt";
            this.id4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id4txt.Size = new System.Drawing.Size(56, 22);
            this.id4txt.TabIndex = 536;
            this.id4txt.TextChanged += new System.EventHandler(this.id4txt_TextChanged);
            this.id4txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.id4txt_KeyDown);
            // 
            // id3txt
            // 
            this.id3txt.Location = new System.Drawing.Point(681, 244);
            this.id3txt.Multiline = true;
            this.id3txt.Name = "id3txt";
            this.id3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id3txt.Size = new System.Drawing.Size(56, 22);
            this.id3txt.TabIndex = 535;
            this.id3txt.TextChanged += new System.EventHandler(this.id3txt_TextChanged);
            this.id3txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.id3txt_KeyDown);
            // 
            // id2txt
            // 
            this.id2txt.Location = new System.Drawing.Point(681, 220);
            this.id2txt.Multiline = true;
            this.id2txt.Name = "id2txt";
            this.id2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id2txt.Size = new System.Drawing.Size(56, 22);
            this.id2txt.TabIndex = 534;
            this.id2txt.TextChanged += new System.EventHandler(this.id2txt_TextChanged);
            this.id2txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.id2txt_KeyDown);
            // 
            // id1txt
            // 
            this.id1txt.Location = new System.Drawing.Point(681, 196);
            this.id1txt.Multiline = true;
            this.id1txt.Name = "id1txt";
            this.id1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.id1txt.Size = new System.Drawing.Size(56, 22);
            this.id1txt.TabIndex = 533;
            this.id1txt.TextChanged += new System.EventHandler(this.id1txt_TextChanged);
            this.id1txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.id1txt_KeyDown);
            // 
            // barcode6txt
            // 
            this.barcode6txt.Location = new System.Drawing.Point(561, 316);
            this.barcode6txt.Multiline = true;
            this.barcode6txt.Name = "barcode6txt";
            this.barcode6txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode6txt.Size = new System.Drawing.Size(119, 22);
            this.barcode6txt.TabIndex = 532;
            // 
            // barcode5txt
            // 
            this.barcode5txt.Location = new System.Drawing.Point(561, 292);
            this.barcode5txt.Multiline = true;
            this.barcode5txt.Name = "barcode5txt";
            this.barcode5txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode5txt.Size = new System.Drawing.Size(119, 22);
            this.barcode5txt.TabIndex = 531;
            // 
            // barcode4txt
            // 
            this.barcode4txt.Location = new System.Drawing.Point(561, 268);
            this.barcode4txt.Multiline = true;
            this.barcode4txt.Name = "barcode4txt";
            this.barcode4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode4txt.Size = new System.Drawing.Size(119, 22);
            this.barcode4txt.TabIndex = 530;
            // 
            // barcode3txt
            // 
            this.barcode3txt.Location = new System.Drawing.Point(561, 244);
            this.barcode3txt.Multiline = true;
            this.barcode3txt.Name = "barcode3txt";
            this.barcode3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode3txt.Size = new System.Drawing.Size(119, 22);
            this.barcode3txt.TabIndex = 529;
            // 
            // barcode2txt
            // 
            this.barcode2txt.Location = new System.Drawing.Point(561, 220);
            this.barcode2txt.Multiline = true;
            this.barcode2txt.Name = "barcode2txt";
            this.barcode2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode2txt.Size = new System.Drawing.Size(119, 22);
            this.barcode2txt.TabIndex = 528;
            // 
            // barcode1txt
            // 
            this.barcode1txt.Location = new System.Drawing.Point(561, 196);
            this.barcode1txt.Multiline = true;
            this.barcode1txt.Name = "barcode1txt";
            this.barcode1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.barcode1txt.Size = new System.Drawing.Size(119, 22);
            this.barcode1txt.TabIndex = 527;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(739, 316);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox19.Size = new System.Drawing.Size(37, 22);
            this.textBox19.TabIndex = 526;
            this.textBox19.Text = "6";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(739, 292);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox20.Size = new System.Drawing.Size(37, 22);
            this.textBox20.TabIndex = 525;
            this.textBox20.Text = "5";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(739, 268);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox21.Size = new System.Drawing.Size(37, 22);
            this.textBox21.TabIndex = 524;
            this.textBox21.Text = "4";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(739, 244);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox22.Size = new System.Drawing.Size(37, 22);
            this.textBox22.TabIndex = 523;
            this.textBox22.Text = "3";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(739, 220);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox23.Size = new System.Drawing.Size(37, 22);
            this.textBox23.TabIndex = 522;
            this.textBox23.Text = "2";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(739, 196);
            this.textBox24.Multiline = true;
            this.textBox24.Name = "textBox24";
            this.textBox24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox24.Size = new System.Drawing.Size(37, 22);
            this.textBox24.TabIndex = 521;
            this.textBox24.Text = "1";
            // 
            // namekala6cmb
            // 
            this.namekala6cmb.FormattingEnabled = true;
            this.namekala6cmb.Items.AddRange(new object[] {
            ""});
            this.namekala6cmb.Location = new System.Drawing.Point(446, 316);
            this.namekala6cmb.Name = "namekala6cmb";
            this.namekala6cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala6cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala6cmb.TabIndex = 520;
            this.namekala6cmb.SelectedIndexChanged += new System.EventHandler(this.namekala6cmb_SelectedIndexChanged);
            // 
            // namekala5cmb
            // 
            this.namekala5cmb.FormattingEnabled = true;
            this.namekala5cmb.Items.AddRange(new object[] {
            ""});
            this.namekala5cmb.Location = new System.Drawing.Point(447, 292);
            this.namekala5cmb.Name = "namekala5cmb";
            this.namekala5cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala5cmb.Size = new System.Drawing.Size(113, 21);
            this.namekala5cmb.TabIndex = 519;
            this.namekala5cmb.SelectedIndexChanged += new System.EventHandler(this.namekala5cmb_SelectedIndexChanged);
            // 
            // namekala4cmb
            // 
            this.namekala4cmb.FormattingEnabled = true;
            this.namekala4cmb.Items.AddRange(new object[] {
            ""});
            this.namekala4cmb.Location = new System.Drawing.Point(446, 268);
            this.namekala4cmb.Name = "namekala4cmb";
            this.namekala4cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala4cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala4cmb.TabIndex = 518;
            this.namekala4cmb.SelectedIndexChanged += new System.EventHandler(this.namekala4cmb_SelectedIndexChanged);
            // 
            // namekala3cmb
            // 
            this.namekala3cmb.FormattingEnabled = true;
            this.namekala3cmb.Items.AddRange(new object[] {
            ""});
            this.namekala3cmb.Location = new System.Drawing.Point(446, 244);
            this.namekala3cmb.Name = "namekala3cmb";
            this.namekala3cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala3cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala3cmb.TabIndex = 517;
            this.namekala3cmb.SelectedIndexChanged += new System.EventHandler(this.namekala3cmb_SelectedIndexChanged);
            // 
            // namekala2cmb
            // 
            this.namekala2cmb.FormattingEnabled = true;
            this.namekala2cmb.Items.AddRange(new object[] {
            ""});
            this.namekala2cmb.Location = new System.Drawing.Point(446, 220);
            this.namekala2cmb.Name = "namekala2cmb";
            this.namekala2cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala2cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala2cmb.TabIndex = 516;
            this.namekala2cmb.SelectedIndexChanged += new System.EventHandler(this.namekala2cmb_SelectedIndexChanged);
            // 
            // namekala1cmb
            // 
            this.namekala1cmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namekala1cmb.FormattingEnabled = true;
            this.namekala1cmb.Items.AddRange(new object[] {
            ""});
            this.namekala1cmb.Location = new System.Drawing.Point(446, 196);
            this.namekala1cmb.Name = "namekala1cmb";
            this.namekala1cmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namekala1cmb.Size = new System.Drawing.Size(114, 21);
            this.namekala1cmb.TabIndex = 515;
            this.namekala1cmb.SelectedIndexChanged += new System.EventHandler(this.namekala1cmb_SelectedIndexChanged);
            // 
            // lineShape73
            // 
            this.lineShape73.Name = "lineShape73";
            this.lineShape73.X1 = 680;
            this.lineShape73.X2 = 680;
            this.lineShape73.Y1 = 170;
            this.lineShape73.Y2 = 338;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label66.Location = new System.Drawing.Point(693, 172);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(39, 23);
            this.label66.TabIndex = 540;
            this.label66.Text = "کد کالا";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label30.Location = new System.Drawing.Point(575, 172);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 23);
            this.label30.TabIndex = 539;
            this.label30.Text = "بارکد کالا";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmAddFactorKharid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(813, 745);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.id6txt);
            this.Controls.Add(this.id5txt);
            this.Controls.Add(this.id4txt);
            this.Controls.Add(this.id3txt);
            this.Controls.Add(this.id2txt);
            this.Controls.Add(this.id1txt);
            this.Controls.Add(this.barcode6txt);
            this.Controls.Add(this.barcode5txt);
            this.Controls.Add(this.barcode4txt);
            this.Controls.Add(this.barcode3txt);
            this.Controls.Add(this.barcode2txt);
            this.Controls.Add(this.barcode1txt);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.namekala6cmb);
            this.Controls.Add(this.namekala5cmb);
            this.Controls.Add(this.namekala4cmb);
            this.Controls.Add(this.namekala3cmb);
            this.Controls.Add(this.namekala2cmb);
            this.Controls.Add(this.namekala1cmb);
            this.Controls.Add(this.sabtesanadbtn);
            this.Controls.Add(this.addnaghdbtn);
            this.Controls.Add(this.addghestybtn);
            this.Controls.Add(this.tarikhepardakhteghestmtxt);
            this.Controls.Add(this.tedadeaghsattxt);
            this.Controls.Add(this.tedademandeghestmtxt);
            this.Controls.Add(this.darsadsoodghesttxt);
            this.Controls.Add(this.mablagheghesttxt);
            this.Controls.Add(this.mablaghekoleaghsattxt);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.idghestytxt);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.addhavalebtn);
            this.Controls.Add(this.addcheckbtn);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.idnaghdytxt);
            this.Controls.Add(this.nameranandetxt);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.tarikhesarresidehavalemtxt);
            this.Controls.Add(this.idhavaletxt);
            this.Controls.Add(this.seryalehavaletxt);
            this.Controls.Add(this.shobehavaletxt);
            this.Controls.Add(this.bankehavaletxt);
            this.Controls.Add(this.mablaghehavaletxt);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.tarikhesarresidecheckmtxt);
            this.Controls.Add(this.idchecktxt);
            this.Controls.Add(this.seryalechecktxt);
            this.Controls.Add(this.shobechecktxt);
            this.Controls.Add(this.bankchecktxt);
            this.Controls.Add(this.mablaghechecktxt);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.mablaghepardakhtenaghdtxt);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.namemoshtaricmb);
            this.Controls.Add(this.idmoshtaritxt);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.idnoemoshtaritxt);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.noemoshtaricmb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tarikhmtxt);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.idfactortxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.idkharidtxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.darsadetakhfiftxt);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.gheimateaghlam);
            this.Controls.Add(this.mandetxt);
            this.Controls.Add(this.takhfifenaghdiyekharidtxt);
            this.Controls.Add(this.gheimatekoltxt);
            this.Controls.Add(this.dastmozdekargartxt);
            this.Controls.Add(this.kerayehamltxt);
            this.Controls.Add(this.takhfiftxt);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.vahedkala6txt);
            this.Controls.Add(this.vahedkala5txt);
            this.Controls.Add(this.vahedkala4txt);
            this.Controls.Add(this.vahedkala3txt);
            this.Controls.Add(this.vahedkala2txt);
            this.Controls.Add(this.vahedkala1txt);
            this.Controls.Add(this.gheimateradif6txt);
            this.Controls.Add(this.gheimateradif5txt);
            this.Controls.Add(this.gheimateradif4txt);
            this.Controls.Add(this.gheimateradif3txt);
            this.Controls.Add(this.gheimateradif2txt);
            this.Controls.Add(this.gheimateradif1txt);
            this.Controls.Add(this.gheimatkala6txt);
            this.Controls.Add(this.gheimatkala5txt);
            this.Controls.Add(this.gheimatkala4txt);
            this.Controls.Add(this.gheimatkala3txt);
            this.Controls.Add(this.gheimatkala2txt);
            this.Controls.Add(this.gheimatkala1txt);
            this.Controls.Add(this.tedadkala6nud);
            this.Controls.Add(this.tedadkala5nud);
            this.Controls.Add(this.tedadkala4nud);
            this.Controls.Add(this.tedadkala3nud);
            this.Controls.Add(this.tedadkala2nud);
            this.Controls.Add(this.tedadkala1nud);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddFactorKharid";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم فاکتور خرید";
            this.Load += new System.EventHandler(this.frmAddFactorKharid_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala6nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala5nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala4nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala3nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala2nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala1nud)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Button addhavalebtn;
        private System.Windows.Forms.Button addcheckbtn;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox idnaghdytxt;
        private System.Windows.Forms.TextBox nameranandetxt;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.MaskedTextBox tarikhesarresidehavalemtxt;
        private System.Windows.Forms.TextBox idhavaletxt;
        private System.Windows.Forms.TextBox seryalehavaletxt;
        private System.Windows.Forms.TextBox shobehavaletxt;
        private System.Windows.Forms.TextBox bankehavaletxt;
        private System.Windows.Forms.TextBox mablaghehavaletxt;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.MaskedTextBox tarikhesarresidecheckmtxt;
        private System.Windows.Forms.TextBox idchecktxt;
        private System.Windows.Forms.TextBox seryalechecktxt;
        private System.Windows.Forms.TextBox shobechecktxt;
        private System.Windows.Forms.TextBox bankchecktxt;
        private System.Windows.Forms.TextBox mablaghechecktxt;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox mablaghepardakhtenaghdtxt;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox namemoshtaricmb;
        private System.Windows.Forms.TextBox idmoshtaritxt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox idnoemoshtaritxt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox noemoshtaricmb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox tarikhmtxt;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox idfactortxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox idkharidtxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox darsadetakhfiftxt;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox gheimateaghlam;
        private System.Windows.Forms.TextBox mandetxt;
        private System.Windows.Forms.TextBox takhfifenaghdiyekharidtxt;
        private System.Windows.Forms.TextBox gheimatekoltxt;
        private System.Windows.Forms.TextBox dastmozdekargartxt;
        private System.Windows.Forms.TextBox kerayehamltxt;
        private System.Windows.Forms.TextBox takhfiftxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox vahedkala6txt;
        private System.Windows.Forms.TextBox vahedkala5txt;
        private System.Windows.Forms.TextBox vahedkala4txt;
        private System.Windows.Forms.TextBox vahedkala3txt;
        private System.Windows.Forms.TextBox vahedkala2txt;
        private System.Windows.Forms.TextBox vahedkala1txt;
        private System.Windows.Forms.TextBox gheimateradif6txt;
        private System.Windows.Forms.TextBox gheimateradif5txt;
        private System.Windows.Forms.TextBox gheimateradif4txt;
        private System.Windows.Forms.TextBox gheimateradif3txt;
        private System.Windows.Forms.TextBox gheimateradif2txt;
        private System.Windows.Forms.TextBox gheimateradif1txt;
        private System.Windows.Forms.TextBox gheimatkala6txt;
        private System.Windows.Forms.TextBox gheimatkala5txt;
        private System.Windows.Forms.TextBox gheimatkala4txt;
        private System.Windows.Forms.TextBox gheimatkala3txt;
        private System.Windows.Forms.TextBox gheimatkala2txt;
        private System.Windows.Forms.TextBox gheimatkala1txt;
        private System.Windows.Forms.NumericUpDown tedadkala6nud;
        private System.Windows.Forms.NumericUpDown tedadkala5nud;
        private System.Windows.Forms.NumericUpDown tedadkala4nud;
        private System.Windows.Forms.NumericUpDown tedadkala3nud;
        private System.Windows.Forms.NumericUpDown tedadkala2nud;
        private System.Windows.Forms.NumericUpDown tedadkala1nud;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label6;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape20;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape21;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape22;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape23;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape11;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape12;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape13;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape14;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape15;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape16;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape17;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape18;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape19;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape26;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape27;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape28;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape29;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape30;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape31;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape32;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape33;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape34;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape35;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape36;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape37;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape7;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape50;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape49;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape48;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape47;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape46;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape45;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape44;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape43;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape42;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape41;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape40;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape39;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape38;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape62;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape61;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape60;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape59;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape58;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape57;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape55;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape54;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape53;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape52;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape51;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape69;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape68;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape67;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape66;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape65;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape64;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape72;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape71;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape70;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape63;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape56;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape25;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape24;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape11;
        private System.Windows.Forms.Button addghestybtn;
        private System.Windows.Forms.MaskedTextBox tarikhepardakhteghestmtxt;
        private System.Windows.Forms.TextBox tedadeaghsattxt;
        private System.Windows.Forms.TextBox tedademandeghestmtxt;
        private System.Windows.Forms.TextBox darsadsoodghesttxt;
        private System.Windows.Forms.TextBox mablagheghesttxt;
        private System.Windows.Forms.TextBox mablaghekoleaghsattxt;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox idghestytxt;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button addnaghdbtn;
        private System.Windows.Forms.Button sabtesanadbtn;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape73;
        private System.Windows.Forms.TextBox id6txt;
        private System.Windows.Forms.TextBox id5txt;
        private System.Windows.Forms.TextBox id4txt;
        private System.Windows.Forms.TextBox id3txt;
        private System.Windows.Forms.TextBox id2txt;
        private System.Windows.Forms.TextBox id1txt;
        private System.Windows.Forms.TextBox barcode6txt;
        private System.Windows.Forms.TextBox barcode5txt;
        private System.Windows.Forms.TextBox barcode4txt;
        private System.Windows.Forms.TextBox barcode3txt;
        private System.Windows.Forms.TextBox barcode2txt;
        private System.Windows.Forms.TextBox barcode1txt;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.ComboBox namekala6cmb;
        private System.Windows.Forms.ComboBox namekala5cmb;
        private System.Windows.Forms.ComboBox namekala4cmb;
        private System.Windows.Forms.ComboBox namekala3cmb;
        private System.Windows.Forms.ComboBox namekala2cmb;
        private System.Windows.Forms.ComboBox namekala1cmb;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label30;
    }
}
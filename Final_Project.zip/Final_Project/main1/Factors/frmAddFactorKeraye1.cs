﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using DAL;
using BLL;
namespace main1.Factors
{
    public partial class frmAddFactorKeraye1 : Form
    {
        public frmAddFactorKeraye1()
        {
            InitializeComponent();
        }
        FactorData FData = new FactorData();
        FactorDB FDB = new FactorDB();
        //
        RizFactorKerayeData RFKData = new RizFactorKerayeData();
        RizFactorKerayeDB RFKDB = new RizFactorKerayeDB();
        //
        SanadeHesabdariData SHData = new SanadeHesabdariData();
        SanadeHesabdariDB SHDB = new SanadeHesabdariDB();
        //
        MoshtariData MData = new MoshtariData();
        MoshtariDB MDB = new MoshtariDB();
        //
        KalayeKerayeData KKData = new KalayeKerayeData();
        KalayeKerayeDB KKDB = new KalayeKerayeDB();
        //
        SherkatData SData = new SherkatData();
        SherkatDB SDB = new SherkatDB();
        //
        NaghdData NData = new NaghdData();
        NaghdDB NDB = new NaghdDB();
        //
        CheckData CData = new CheckData();
        CheckDB CDB = new CheckDB();
        //
        HavaleData HVData = new HavaleData();
        HavaleDB HVDB = new HavaleDB();
        //
        GhestyData GSData = new GhestyData();
        GhestyDB GSDB = new GhestyDB();
        //
        long Radif1 = 0;
        long Radif2 = 0;
        long Radif3 = 0;
        long Radif4 = 0;
        long Radif5 = 0;
        long Radif6 = 0;
        int TeadadRozeKeraye = 1;
        //
        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmAddFactorKeraye1_Load(object sender, EventArgs e)
        {
            DataTable DT = KKData.KalayeKerayeReportShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameKala = DT.Rows[i][4].ToString();
                string VaziyateKeraye = DT.Rows[i][5].ToString();
                string GheimateKala = DT.Rows[i][8].ToString();
                ListItem item = new ListItem();
                item.Text = NameKala;
                item.Value = GheimateKala.ToString();
                if (VaziyateKeraye == "کرایه داده نشده")
                {
                    namekala1cmb.Items.Add(item);
                    namekala2cmb.Items.Add(item);
                    namekala3cmb.Items.Add(item);
                    namekala4cmb.Items.Add(item);
                    namekala5cmb.Items.Add(item);
                    namekala6cmb.Items.Add(item);
                }

            }
            //
            //
            //
            tedadkala1nud.Enabled = false;
            tedadkala2nud.Enabled = false;
            tedadkala3nud.Enabled = false;
            tedadkala4nud.Enabled = false;
            tedadkala5nud.Enabled = false;
            tedadkala6nud.Enabled = false;
            //
            lblkarbar.Text = Class1.NameFamilyKarbar;
            tarikhmtxt.Text = Class1.TarikheJari;

            if (Class1.virayeshF != 0 && Class1.virayeshRFK != 0)
            {
                RFKDB = RFKData.RizFactorKerayeFind1(Class1.virayeshRFK);
                idkerayetxt.Text = RFKDB.IDFactorKeraye.ToString();
                namekala1cmb.Text = RFKDB.NameKalayeKeraye1;
                tedadkala1nud.Value = RFKDB.Tedade1;
                namekala2cmb.Text = RFKDB.NameKalayeKeraye2;
                tedadkala2nud.Value = RFKDB.Tedade2;
                namekala3cmb.Text = RFKDB.NameKalayeKeraye3;
                tedadkala3nud.Value = RFKDB.Tedade3;
                namekala4cmb.Text = RFKDB.NameKalayeKeraye4;
                tedadkala4nud.Value = RFKDB.Tedade4;
                idfactortxt.Text = RFKDB.FKFactor.ToString();
                string s = RFKDB.TarikheBargashteKala.ToString();
                tarikhebargashtekalamtxt.Text = Class1.Tarikh(s);
                gheimatekoltxt.Text = Class1.convert_str(RFKDB.GheimateKoleKalaha.ToString());
                //
                FDB = FData.FactorFind1(Class1.virayeshF);
                idfactortxt.Text = FDB.IDFactor.ToString();
                idnoemoshtaritxt.Text = FDB.FKNoeMoshtari.ToString();
                namemoshtaricmb.Text = FDB.NameMoshtari.ToString();
                idnaghdytxt.Text = FDB.FKNaghdy.ToString();
                idghestytxt.Text = FDB.FKGhesty.ToString();
                idchecktxt.Text = FDB.FKCheck.ToString();
                idhavaletxt.Text = FDB.FKHavale.ToString();
                lblkarbar.Text = FDB.NameKarbar;
                string s1 = FDB.TarikheFactor.ToString();
                tarikhmtxt.Text = Class1.Tarikh(s1);
                darsadetakhfiftxt.Text = FDB.DarsadeTakhfif;
                nameranandetxt.Text = FDB.NameRanande;
                dastmozdekargartxt.Text = Class1.convert_str(FDB.DastMozdeKargareBarbari.ToString());
                kerayehamltxt.Text = Class1.convert_str(FDB.KerayeHaml.ToString());
            }
            else
            {
                int i1=0, i3 = 0, i5 = 0;
                int i2=0,i4 = 1, i6 = 1;
                DataTable dt1 = FData.FactorSearchID1();
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    i3 = Convert.ToInt32(dt1.Rows[i][0].ToString());
                    if (i4 < i3)
                    {
                        i4 = i3;
                    }
                }
                if (dt1.Rows.Count == 0)
                {
                    idfactortxt.Text = "1";
                }
                else
                {
                    idfactortxt.Text = Convert.ToString(i4 + 1);
                }
                //
                DataTable dt2 = RFKData.RizFactorKerayeSearchID1();
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    i5 = Convert.ToInt32(dt2.Rows[i][0].ToString());
                    if (i6 < i5)
                    {
                        i6 = i5;
                    }
                }
                if (dt2.Rows.Count == 0)
                {
                    idkerayetxt.Text = "1";
                }
                else
                {
                    idkerayetxt.Text = Convert.ToString(i6 + 1);
                }
                //
                DataTable dt3 = NData.NaghdSearchID1 ();
                for (int i = 0; i < dt3.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt3.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt3.Rows.Count == 0)
                {
                    idnaghdytxt .Text = "1";
                }
                else
                {
                    idnaghdytxt.Text = Convert.ToString(i2 + 1);
                }
            }
            //
        }

        private void noemoshtaricmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (noemoshtaricmb.SelectedIndex == 0)
            {
                idnoemoshtaritxt.Text = "1";
                idmoshtaritxt.Text = "";
            }
            else
            {
                idnoemoshtaritxt.Text = "2";
                idmoshtaritxt.Text = "";
            }
            if (noemoshtaricmb.Text == "حقیقی")
            {
                namemoshtaricmb.Items.Clear();
                DataTable DT = MData.MoshtariComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {
                    int IDMoshtari = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameMoshtari = DT.Rows[i][5].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameMoshtari;
                    item.Value = IDMoshtari.ToString();

                    namemoshtaricmb.Items.Add(item);

                }
            }
            else if (noemoshtaricmb.Text == "حقوقی")
            {
                namemoshtaricmb.Items.Clear();
                DataTable DT = SData.SherkatComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {

                    int IDSherkat = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameSherkat = DT.Rows[i][5].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameSherkat;
                    item.Value = IDSherkat.ToString();

                    namemoshtaricmb.Items.Add(item);

                }
            }
        }

        private void namemoshtaricmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (noemoshtaricmb.Text == "حقیقی")
            {
                DataTable DT = MData.MoshtariComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {
                    int IDMoshtari = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameMoshtari = DT.Rows[i][5].ToString();
                   

                    ListItem item = new ListItem();
                    item.Text = NameMoshtari;
                    item.Value = IDMoshtari.ToString();
                     if(namemoshtaricmb .Text == item.Text )
                     {
                         idmoshtaritxt.Text = IDMoshtari.ToString();
                         break;
                     }

                }
            }
            else if (noemoshtaricmb.Text == "حقوقی")
            {
                DataTable DT = SData.SherkatComboShow1();
                for (int i = 0; i < DT.Rows.Count; i++)
                {

                    int IDSherkat = Convert.ToInt32(DT.Rows[i][0].ToString());
                    int FKNoeMoshtari = Convert.ToInt32(DT.Rows[i][2].ToString());
                    string NameSherkat = DT.Rows[i][5].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameSherkat;
                    item.Value = IDSherkat.ToString();
                    if (namemoshtaricmb.Text == item.Text)
                    {
                        idmoshtaritxt.Text = IDSherkat.ToString();
                        break;
                    }

                }
        }
    }
        //
        //


        private void namekala1cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (namekala1cmb.SelectedIndex == 0 )
            //{
            //    tedadkala1nud.Enabled = false;
            //    long i = Convert.ToInt64(gheimateradif1txt.Text.Replace(",", ""));
            //    gheimateradif1txt.Text = "0";
            //    gheimateaghlam.Text = (Convert.ToInt64(gheimateaghlam.Text.Replace (",","")) - i).ToString();
            //    gheimatkala1txt.Text = "0";
            //    takhfiferoz1.Text = "0";
            //    tedadkala1nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //}
            //else
            //    tedadkala1nud.Enabled = true;
            //DataTable DT = KKData.KalayeKerayeReportShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int TedadeKala = Convert.ToInt32(DT.Rows[i][9].ToString());
            //    int TedadeKerayeDade = Convert.ToInt32(DT.Rows[i][10].ToString());
            //    int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameKala = DT.Rows[i][4].ToString();
            //    string VaziyateKeraye = DT.Rows[i][5].ToString();
            //    string GheimateKala = DT.Rows[i][8].ToString();
            //    int TedadeMojodFely = TedadeKala - TedadeKerayeDade;
            //    string BarcodeKala = DT.Rows[i][13].ToString();

            //    ListItem item = new ListItem();
            //    item.Text = NameKala;
            //    item.Value = IDKalaKeraye.ToString();


                
            //    if (namekala1cmb.Text == item.Text)
            //    {
            //        tedadkala1nud.Minimum = 1;
            //        tedadkala1nud.Maximum = TedadeMojodFely;
            //        tedadkala1nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //        gheimatkala1txt.Text = Class1.convert_str(GheimateKala).ToString();
            //        gheimateradif1txt.Text = Class1.convert_str((Convert.ToInt64(GheimateKala) * TeadadRozeKeraye).ToString());
            //        id1txt.Text = IDKalaKeraye.ToString();
            //        barcode1txt.Text = BarcodeKala;

            //        TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            //        Radif1 = Convert.ToInt64(GheimateKala) * TeadadRozeKeraye;
            //        if (TeadadRozeKeraye <= 10)
            //            takhfiferoz1.Text = "0";
            //        if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            //            takhfiferoz1.Text = Class1.convert_str(((Radif1 * 5) / 100).ToString());
            //        if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            //            takhfiferoz1.Text = Class1.convert_str(((Radif1 * 10) / 100).ToString()); 
            //        if (TeadadRozeKeraye > 50)
            //            takhfiferoz1.Text = Class1.convert_str(((Radif1 * 15) / 100).ToString());

            //        break;
            //    }

            //}
            namekala2cmb.Items.Remove(namekala1cmb.SelectedItem);
            namekala3cmb.Items.Remove(namekala1cmb.SelectedItem);
            namekala4cmb.Items.Remove(namekala1cmb.SelectedItem);
            namekala5cmb.Items.Remove(namekala1cmb.SelectedItem);
            namekala6cmb.Items.Remove(namekala1cmb.SelectedItem);
        }

        private void namekala2cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (namekala2cmb.SelectedIndex == 0)
            //{
            //    tedadkala2nud.Enabled = false;
            //    long i = Convert.ToInt64(gheimateradif2txt.Text.Replace (",",""));
            //    gheimateradif2txt.Text = "0";
            //    gheimateaghlam.Text = (Convert.ToInt64(gheimateaghlam.Text.Replace(",", "")) - i).ToString();
            //    gheimatkala2txt.Text = "0";
            //    takhfiferoz2.Text = "0";
            //    this.tedadkala2nud.Value = new decimal(new int[] {1, 0,0,0});
            //}
            //else
            //    tedadkala2nud.Enabled = true;
            ////
            //DataTable DT = KKData.KalayeKerayeReportShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int TedadeKala = Convert.ToInt32(DT.Rows[i][9].ToString());
            //    int TedadeKerayeDade = Convert.ToInt32(DT.Rows[i][10].ToString());
            //    int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameKala = DT.Rows[i][4].ToString();
            //    string VaziyateKeraye = DT.Rows[i][5].ToString();
            //    string GheimateKala = DT.Rows[i][8].ToString();
            //    int TedadeMojodFely = TedadeKala - TedadeKerayeDade;
            //    string BarcodeKala = DT.Rows[i][13].ToString();

            //    ListItem item = new ListItem();
            //    item.Text = NameKala;
            //    item.Value = IDKalaKeraye.ToString();
            //    if (NameKala == namekala1cmb.Text)
            //    {
            //        namekala2cmb.Items.Remove(item);
            //    }
            //    if (NameKala == namekala2cmb.Text)
            //    {
            //        namekala3cmb.Items.Remove(item);
            //        namekala4cmb.Items.Remove(item);
            //        namekala5cmb.Items.Remove(item);
            //        namekala6cmb.Items.Remove(item);
            //    }
            //    if (namekala2cmb.Text == item.Text)
            //    {
            //        tedadkala2nud.Minimum = 1;
            //        tedadkala2nud.Maximum = TedadeMojodFely;
            //        this.tedadkala2nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //        gheimatkala2txt.Text = Class1.convert_str(GheimateKala).ToString();
            //        gheimateradif2txt.Text = Class1.convert_str((Convert.ToInt64(GheimateKala) * Convert.ToInt32(tedadrozhayekerayetxt.Text)).ToString());
            //        id2txt.Text = IDKalaKeraye.ToString();
            //        barcode2txt.Text = BarcodeKala;

            //        TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            //        Radif2 = Convert.ToInt64(GheimateKala) * TeadadRozeKeraye;
            //        if (TeadadRozeKeraye <= 10)
            //            takhfiferoz2.Text = "0";
            //        if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            //            takhfiferoz2.Text = Class1.convert_str(((Radif2 * 5) / 100).ToString());
            //        if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            //            takhfiferoz2.Text = Class1.convert_str(((Radif2 * 10) / 100).ToString());
            //        if (TeadadRozeKeraye > 50)
            //            takhfiferoz2.Text = Class1.convert_str(((Radif2 * 15) / 100).ToString());

            //        break;
            //    }

            //}
            namekala1cmb.Items.Remove(namekala2cmb.SelectedItem);
            namekala3cmb.Items.Remove(namekala2cmb.SelectedItem);
            namekala4cmb.Items.Remove(namekala2cmb.SelectedItem);
            namekala5cmb.Items.Remove(namekala2cmb.SelectedItem);
            namekala6cmb.Items.Remove(namekala2cmb.SelectedItem); 
        }

        private void namekala3cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (namekala3cmb.SelectedIndex == 0)
            //{
            //    tedadkala3nud.Enabled = false;
            //    long i = Convert.ToInt64(gheimateradif3txt.Text.Replace(",", ""));
            //    gheimateradif3txt.Text = "0";
            //    gheimateaghlam.Text = (Convert.ToInt64(gheimateaghlam.Text.Replace(",", "")) - i).ToString();
            //    gheimatkala3txt.Text = "0";
            //    takhfiferoz3.Text = "0";
            //    tedadkala3nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //}
            //else
            //    tedadkala3nud.Enabled = true;
            ////
            //DataTable DT = KKData.KalayeKerayeReportShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int TedadeKala = Convert.ToInt32(DT.Rows[i][9].ToString());
            //    int TedadeKerayeDade = Convert.ToInt32(DT.Rows[i][10].ToString());
            //    int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameKala = DT.Rows[i][4].ToString();
            //    string VaziyateKeraye = DT.Rows[i][5].ToString();
            //    string GheimateKala = DT.Rows[i][8].ToString();
            //    int TedadeMojodFely = TedadeKala - TedadeKerayeDade;
            //    string BarcodeKala = DT.Rows[i][13].ToString();

            //    ListItem item = new ListItem();
            //    item.Text = NameKala;
            //    item.Value = IDKalaKeraye.ToString();
            //    if (NameKala == namekala3cmb.Text)
            //    {
            //        namekala4cmb.Items.Remove(item);
            //        namekala5cmb.Items.Remove(item);
            //        namekala6cmb.Items.Remove(item);
            //    }
            //    if (namekala3cmb.Text == item.Text)
            //    {
            //        tedadkala3nud.Minimum = 1;
            //        tedadkala3nud.Maximum = TedadeMojodFely;
            //        tedadkala3nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //        gheimatkala3txt.Text = Class1.convert_str(GheimateKala).ToString();
            //        gheimateradif3txt.Text = Class1.convert_str((Convert.ToInt64(GheimateKala) * Convert.ToInt32(tedadrozhayekerayetxt.Text)).ToString());
            //        id3txt.Text = IDKalaKeraye.ToString();
            //        barcode3txt.Text = BarcodeKala;

            //        TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            //        Radif3 = Convert.ToInt64(GheimateKala) * TeadadRozeKeraye;
            //        if (TeadadRozeKeraye <= 10)
            //            takhfiferoz3.Text = "0";
            //        if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            //            takhfiferoz3.Text = Class1.convert_str(((Radif3 * 5) / 100).ToString());
            //        if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            //            takhfiferoz3.Text = Class1.convert_str(((Radif3 * 10) / 100).ToString());
            //        if (TeadadRozeKeraye > 50)
            //            takhfiferoz3.Text = Class1.convert_str(((Radif3 * 15) / 100).ToString());

            //        break;
            //    }

            //}
            namekala1cmb.Items.Remove(namekala3cmb.SelectedItem);
            namekala2cmb.Items.Remove(namekala3cmb.SelectedItem);
            namekala4cmb.Items.Remove(namekala3cmb.SelectedItem);
            namekala5cmb.Items.Remove(namekala3cmb.SelectedItem);
            namekala6cmb.Items.Remove(namekala3cmb.SelectedItem);
        }

        private void namekala4cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (namekala4cmb.SelectedIndex == 0)
            //{
            //    tedadkala4nud.Enabled = false;
            //    long i = Convert.ToInt64(gheimateradif4txt.Text.Replace(",", ""));
            //    gheimateradif4txt.Text = "0";
            //    gheimateaghlam.Text = (Convert.ToInt64(gheimateaghlam.Text.Replace(",", "")) - i).ToString();
            //    gheimatkala4txt.Text = "0";
            //    takhfiferoz4.Text = "0";
            //    tedadkala4nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //}
            //else
            //    tedadkala4nud.Enabled = true;
            ////
            //DataTable DT = KKData.KalayeKerayeReportShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int TedadeKala = Convert.ToInt32(DT.Rows[i][9].ToString());
            //    int TedadeKerayeDade = Convert.ToInt32(DT.Rows[i][10].ToString());
            //    int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameKala = DT.Rows[i][4].ToString();
            //    string VaziyateKeraye = DT.Rows[i][5].ToString();
            //    string GheimateKala = DT.Rows[i][8].ToString();
            //    int TedadeMojodFely = TedadeKala - TedadeKerayeDade;
            //    string BarcodeKala = DT.Rows[i][13].ToString();

            //    ListItem item = new ListItem();
            //    item.Text = NameKala;
            //    item.Value = IDKalaKeraye.ToString();
            //    if (NameKala == namekala4cmb.Text)
            //    {
            //        namekala5cmb.Items.Remove(item);
            //        namekala6cmb.Items.Remove(item);
            //    }
            //    if (namekala4cmb.Text == item.Text)
            //    {
            //        tedadkala4nud.Minimum = 1;
            //        tedadkala4nud.Maximum = TedadeMojodFely;
            //        tedadkala4nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //        gheimatkala4txt.Text = Class1.convert_str(GheimateKala).ToString();
            //        gheimateradif4txt.Text = Class1.convert_str((Convert.ToInt64(GheimateKala) * Convert.ToInt32(tedadrozhayekerayetxt.Text)).ToString());
            //        id4txt.Text = IDKalaKeraye.ToString();
            //        barcode4txt.Text = BarcodeKala;

            //        TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            //        Radif4 = Convert.ToInt64(GheimateKala) * TeadadRozeKeraye;
            //        if (TeadadRozeKeraye <= 10)
            //            takhfiferoz4.Text = "0";
            //        if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            //            takhfiferoz4.Text = Class1.convert_str(((Radif4 * 5) / 100).ToString());
            //        if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            //            takhfiferoz4.Text = Class1.convert_str(((Radif4 * 10) / 100).ToString());
            //        if (TeadadRozeKeraye > 50)
            //            takhfiferoz4.Text = Class1.convert_str(((Radif4 * 15) / 100).ToString());

            //        break;
            //    }

            //}
            namekala1cmb.Items.Remove(namekala4cmb.SelectedItem);
            namekala2cmb.Items.Remove(namekala4cmb.SelectedItem);
            namekala3cmb.Items.Remove(namekala4cmb.SelectedItem);
            namekala5cmb.Items.Remove(namekala4cmb.SelectedItem);
            namekala6cmb.Items.Remove(namekala4cmb.SelectedItem);
        }

        private void namekala5cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (namekala5cmb.SelectedIndex == 0)
            //{
            //    tedadkala5nud.Enabled = false;
            //    long i = Convert.ToInt64(gheimateradif5txt.Text.Replace(",", ""));
            //    gheimateradif5txt.Text = "0";
            //    gheimateaghlam.Text = (Convert.ToInt64(gheimateaghlam.Text.Replace(",", "")) - i).ToString();
            //    gheimatkala5txt.Text = "0";
            //    takhfiferoz5.Text = "0";
            //    tedadkala5nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //}
            //else
            //    tedadkala5nud.Enabled = true;
            ////
            //DataTable DT = KKData.KalayeKerayeReportShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int TedadeKala = Convert.ToInt32(DT.Rows[i][9].ToString());
            //    int TedadeKerayeDade = Convert.ToInt32(DT.Rows[i][10].ToString());
            //    int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameKala = DT.Rows[i][4].ToString();
            //    string VaziyateKeraye = DT.Rows[i][5].ToString();
            //    string GheimateKala = DT.Rows[i][8].ToString();
            //    int TedadeMojodFely = TedadeKala - TedadeKerayeDade;
            //    string BarcodeKala = DT.Rows[i][13].ToString();

            //    ListItem item = new ListItem();
            //    item.Text = NameKala;
            //    item.Value = IDKalaKeraye.ToString();
            //    if (NameKala == namekala5cmb.Text)
            //    {
            //        namekala6cmb.Items.Remove(item);
            //    }
            //    if (namekala5cmb.Text == item.Text)
            //    {
            //        tedadkala5nud.Minimum = 1;
            //        tedadkala5nud.Maximum = TedadeMojodFely;
            //        tedadkala5nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //        gheimatkala5txt.Text = Class1.convert_str(GheimateKala).ToString();
            //        gheimateradif5txt.Text = Class1.convert_str((Convert.ToInt64(GheimateKala) * Convert.ToInt32(tedadrozhayekerayetxt.Text)).ToString());
            //        id5txt.Text = IDKalaKeraye.ToString();
            //        barcode5txt.Text = BarcodeKala;

            //        TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            //        Radif5= Convert.ToInt64(GheimateKala) * TeadadRozeKeraye;
            //        if (TeadadRozeKeraye <= 10)
            //            takhfiferoz5.Text = "0";
            //        if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            //            takhfiferoz5.Text = Class1.convert_str(((Radif5 * 5) / 100).ToString());
            //        if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            //            takhfiferoz5.Text = Class1.convert_str(((Radif5 * 10) / 100).ToString());
            //        if (TeadadRozeKeraye > 50)
            //            takhfiferoz5.Text = Class1.convert_str(((Radif5 * 15) / 100).ToString());

            //        break;
            //    }

            //}
            namekala1cmb.Items.Remove(namekala5cmb.SelectedItem);
            namekala2cmb.Items.Remove(namekala5cmb.SelectedItem);
            namekala3cmb.Items.Remove(namekala5cmb.SelectedItem);
            namekala4cmb.Items.Remove(namekala5cmb.SelectedItem);
            namekala6cmb.Items.Remove(namekala5cmb.SelectedItem);
        }

        private void namekala6cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (namekala6cmb.SelectedIndex == 0)
            //{
            //    tedadkala6nud.Enabled = false;
            //    long i = Convert.ToInt64(gheimateradif6txt.Text.Replace(",", ""));
            //    gheimateradif6txt.Text = "0";
            //    gheimateaghlam.Text = (Convert.ToInt64(gheimateaghlam.Text.Replace(",", "")) - i).ToString();
            //    gheimatkala6txt.Text = "0";
            //    takhfiferoz6.Text = "0";
            //    tedadkala6nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //}
            //else
            //    tedadkala6nud.Enabled = true;
            ////
            //DataTable DT = KKData.KalayeKerayeReportShow1();
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{
            //    int TedadeKala = Convert.ToInt32(DT.Rows[i][9].ToString());
            //    int TedadeKerayeDade = Convert.ToInt32(DT.Rows[i][10].ToString());
            //    int IDKalaKeraye = Convert.ToInt32(DT.Rows[i][0].ToString());
            //    string NameKala = DT.Rows[i][4].ToString();
            //    string VaziyateKeraye = DT.Rows[i][5].ToString();
            //    string GheimateKala = DT.Rows[i][8].ToString();
            //    int TedadeMojodFely = TedadeKala - TedadeKerayeDade;
            //    string BarcodeKala = DT.Rows[i][13].ToString();

            //    ListItem item = new ListItem();
            //    item.Text = NameKala;
            //    item.Value = IDKalaKeraye.ToString();

            //    if (namekala6cmb.Text == item.Text)
            //    {
            //        tedadkala6nud.Minimum = 1;
            //        tedadkala6nud.Maximum = TedadeMojodFely;
            //        tedadkala6nud.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //        gheimatkala6txt.Text = Class1.convert_str(GheimateKala).ToString();
            //        gheimateradif6txt.Text = Class1.convert_str((Convert.ToInt64(GheimateKala) * Convert.ToInt32(tedadrozhayekerayetxt.Text)).ToString());
            //        id6txt.Text = IDKalaKeraye.ToString();
            //        barcode6txt.Text = BarcodeKala;

            //        TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            //        Radif6= Convert.ToInt64(GheimateKala) * TeadadRozeKeraye;
            //        if (TeadadRozeKeraye <= 10)
            //            takhfiferoz6.Text = "0";
            //        if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            //            takhfiferoz6.Text = Class1.convert_str(((Radif6 * 5) / 100).ToString());
            //        if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            //            takhfiferoz6.Text = Class1.convert_str(((Radif6 * 10) / 100).ToString());
            //        if (TeadadRozeKeraye > 50)
            //            takhfiferoz6.Text = Class1.convert_str(((Radif6 * 15) / 100).ToString());

            //        break;
            //    }
            //    //

            //}
            namekala1cmb.Items.Remove(namekala6cmb.SelectedItem);
            namekala2cmb.Items.Remove(namekala6cmb.SelectedItem);
            namekala3cmb.Items.Remove(namekala6cmb.SelectedItem);
            namekala4cmb.Items.Remove(namekala6cmb.SelectedItem);
            namekala5cmb.Items.Remove(namekala6cmb.SelectedItem);
        }
        //
        //
        int k43 = 0;
        private void tedadrozhayekerayetxt_TextChanged(object sender, EventArgs e)
        {
            if (tedadrozhayekerayetxt.Text == "")
                tedadrozhayekerayetxt.Text = "1";
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);

            if (TeadadRozeKeraye <= 10)
            {
                takhfiferoz1 .Text = "0";
                takhfiferoz2.Text = "0";
                takhfiferoz3.Text = "0";
                takhfiferoz4.Text = "0";
                takhfiferoz5.Text = "0";
                takhfiferoz6.Text = "0";
            }
            else if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
            {
                takhfiferoz1.Text = Class1.convert_str(((Radif1 * 5) / 100).ToString());
                takhfiferoz2.Text = Class1.convert_str(((Radif2 * 5) / 100).ToString());
                takhfiferoz3.Text = Class1.convert_str(((Radif3 * 5) / 100).ToString());
                takhfiferoz4.Text = Class1.convert_str(((Radif4 * 5) / 100).ToString());
                takhfiferoz5.Text = Class1.convert_str(((Radif5 * 5) / 100).ToString());
                takhfiferoz6.Text = Class1.convert_str(((Radif6 * 5) / 100).ToString());
            }
            else if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
            {
                takhfiferoz1.Text = Class1.convert_str(((Radif1 * 10) / 100).ToString());
                takhfiferoz2.Text = Class1.convert_str(((Radif2 * 10) / 100).ToString());
                takhfiferoz3.Text = Class1.convert_str(((Radif3 * 10) / 100).ToString());
                takhfiferoz4.Text = Class1.convert_str(((Radif4 * 10) / 100).ToString());
                takhfiferoz5.Text = Class1.convert_str(((Radif5 * 10) / 100).ToString());
                takhfiferoz6.Text = Class1.convert_str(((Radif6 * 10) / 100).ToString());
            }
            else if (TeadadRozeKeraye > 50)
            {
                takhfiferoz1.Text = Class1.convert_str(((Radif1 * 15) / 100).ToString());
                takhfiferoz2.Text = Class1.convert_str(((Radif2 * 15) / 100).ToString());
                takhfiferoz3.Text = Class1.convert_str(((Radif3 * 15) / 100).ToString());
                takhfiferoz4.Text = Class1.convert_str(((Radif4 * 15) / 100).ToString());
                takhfiferoz5.Text = Class1.convert_str(((Radif5 * 15) / 100).ToString());
                takhfiferoz6.Text = Class1.convert_str(((Radif6 * 15) / 100).ToString());
            }
            if (tedadrozhayekerayetxt.Text.Length != 0 && k43 == 1)
            {
                k43 = 0;
                tedadrozhayekerayetxt.Text = Class1.convert_number(tedadrozhayekerayetxt.Text.Replace(",", ""));
                tedadrozhayekerayetxt.Select(tedadrozhayekerayetxt.Text.Length, 0);
            }
        }

        private void tedadrozhayekerayetxt_KeyDown(object sender, KeyEventArgs e)
        {
            k43 = 1;
        }
        //
        //

        int k1 = 0;
        private void idfactortxt_TextChanged(object sender, EventArgs e)
        {
            if (idfactortxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idfactortxt.Text = Class1.convert_number(idfactortxt.Text.Replace(",", ""));
                idfactortxt.Select(idfactortxt.Text.Length, 0);
            }
        }

        private void idfactortxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }
        //
        //
        int k2 = 0;
        private void idkerayetxt_TextChanged(object sender, EventArgs e)
        {
            if (idkerayetxt.Text.Length != 0 && k2 == 1)
            {
                k2 = 0;
                idkerayetxt.Text = Class1.convert_number(idkerayetxt.Text.Replace(",", ""));
                idkerayetxt.Select(idkerayetxt.Text.Length, 0);
            }
        }

        private void idkerayetxt_KeyDown(object sender, KeyEventArgs e)
        {
            k2 = 1;
        }
        //
        //
        int k3 = 0;
        private void idnoemoshtaritxt_TextChanged(object sender, EventArgs e)
        {
            if (idnoemoshtaritxt.Text.Length != 0 && k3 == 1)
            {
                k3 = 0;
                idnoemoshtaritxt.Text = Class1.convert_number(idnoemoshtaritxt.Text.Replace(",", ""));
                idnoemoshtaritxt.Select(idnoemoshtaritxt.Text.Length, 0);
            }
        }

        private void idnoemoshtaritxt_KeyDown(object sender, KeyEventArgs e)
        {
            k3 = 1;
        }
        //
        //
        int k4 = 0;
        private void idmoshtaritxt_TextChanged(object sender, EventArgs e)
        {
            if (idmoshtaritxt.Text.Length != 0 && k4 == 1)
            {
                k4 = 0;
                idmoshtaritxt.Text = Class1.convert_number(idmoshtaritxt.Text.Replace(",", ""));
                idmoshtaritxt.Select(idmoshtaritxt.Text.Length, 0);
            }
        }

        private void idmoshtaritxt_KeyDown(object sender, KeyEventArgs e)
        {
            k4 = 1;
        }
        //
        //
        int k5 = 0;
        private void id1txt_TextChanged(object sender, EventArgs e)
        {
            if (id1txt.Text.Length != 0 && k5 == 1)
            {
                k5 = 0;
                id1txt.Text = Class1.convert_number(id1txt.Text.Replace(",", ""));
                id1txt.Select(id1txt.Text.Length, 0);
            }
        }

        private void id1txt_KeyDown(object sender, KeyEventArgs e)
        {
            k5 = 1;
        }
        //
        //
        int k6 = 0;
        private void id2txt_TextChanged(object sender, EventArgs e)
        {
            if (id2txt.Text.Length != 0 && k6 == 1)
            {
                k6 = 0;
                id2txt.Text = Class1.convert_number(id2txt.Text.Replace(",", ""));
                id2txt.Select(id2txt.Text.Length, 0);
            }
        }

        private void id2txt_KeyDown(object sender, KeyEventArgs e)
        {
            k6 = 1;
        }
        //
        //
        int k7 = 0;
        private void id3txt_TextChanged(object sender, EventArgs e)
        {
            if (id3txt.Text.Length != 0 && k7 == 1)
            {
                k7 = 0;
                id3txt.Text = Class1.convert_number(id3txt.Text.Replace(",", ""));
                id3txt.Select(id3txt.Text.Length, 0);
            }
        }

        private void id3txt_KeyDown(object sender, KeyEventArgs e)
        {
            k7 = 1;
        }
        //
        //
        int k8 = 0;
        private void id4txt_TextChanged(object sender, EventArgs e)
        {
            if (id4txt.Text.Length != 0 && k8 == 1)
            {
                k8 = 0;
                id4txt.Text = Class1.convert_number(id4txt.Text.Replace(",", ""));
                id4txt.Select(id4txt.Text.Length, 0);
            }
        }

        private void id4txt_KeyDown(object sender, KeyEventArgs e)
        {
            k8 = 1;
        }
        //
        //
        int k9 = 0;
        private void id5txt_TextChanged(object sender, EventArgs e)
        {
            if (id5txt.Text.Length != 0 && k9 == 1)
            {
                k9 = 0;
                id5txt.Text = Class1.convert_number(id5txt.Text.Replace(",", ""));
                id5txt.Select(id5txt.Text.Length, 0);
            }
        }

        private void id5txt_KeyDown(object sender, KeyEventArgs e)
        {
            k9 = 1;
        }
        //
        //
        int k10 = 0;
        private void id6txt_TextChanged(object sender, EventArgs e)
        {
            if (id6txt.Text.Length != 0 && k10 == 1)
            {
                k10 = 0;
                id6txt.Text = Class1.convert_number(id6txt.Text.Replace(",", ""));
                id6txt.Select(id6txt.Text.Length, 0);
            }
        }

        private void id6txt_KeyDown(object sender, KeyEventArgs e)
        {
            k10 = 1;
        }
        //
        //
        int k11 = 0;
        private void gheimatkala1txt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatkala1txt.Text.Length != 0 && k11 == 1)
            {
                k11 = 0;
                gheimatkala1txt.Text = Class1.convert_str(gheimatkala1txt.Text.Replace(",", ""));
                gheimatkala1txt.Select(gheimatkala1txt.Text.Length, 0);
            }
        }

        private void gheimatkala1txt_KeyDown(object sender, KeyEventArgs e)
        {
            k11 = 1;
        }
        //
        //
        int k12 = 0;
        private void gheimatkala2txt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatkala2txt.Text.Length != 0 && k12 == 1)
            {
                k12 = 0;
                gheimatkala2txt.Text = Class1.convert_str(gheimatkala2txt.Text.Replace(",", ""));
                gheimatkala2txt.Select(gheimatkala2txt.Text.Length, 0);
            }
        }

        private void gheimatkala2txt_KeyDown(object sender, KeyEventArgs e)
        {
            k12 = 1;
        }
        //
        //
        int k13 = 0;
        private void gheimatkala3txt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatkala3txt.Text.Length != 0 && k13 == 1)
            {
                k13 = 0;
                gheimatkala3txt.Text = Class1.convert_str(gheimatkala3txt.Text.Replace(",", ""));
                gheimatkala3txt.Select(gheimatkala3txt.Text.Length, 0);
            }
        }

        private void gheimatkala3txt_KeyDown(object sender, KeyEventArgs e)
        {
            k13 = 1;
        }
        //
        //
        int k14 = 0;
        private void gheimatkala4txt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatkala4txt.Text.Length != 0 && k14 == 1)
            {
                k14 = 0;
                gheimatkala4txt.Text = Class1.convert_str(gheimatkala4txt.Text.Replace(",", ""));
                gheimatkala4txt.Select(gheimatkala4txt.Text.Length, 0);
            }
        }

        private void gheimatkala4txt_KeyDown(object sender, KeyEventArgs e)
        {
            k14 = 1;
        }
        //
        //
        int k15 = 0;
        private void gheimatkala5txt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatkala5txt.Text.Length != 0 && k15 == 1)
            {
                k15 = 0;
                gheimatkala5txt.Text = Class1.convert_str(gheimatkala5txt.Text.Replace(",", ""));
                gheimatkala5txt.Select(gheimatkala5txt.Text.Length, 0);
            }
        }

        private void gheimatkala5txt_KeyDown(object sender, KeyEventArgs e)
        {
            k15 = 1;
        }
        //
        //
        int k16 = 0;
        private void gheimatkala6txt_TextChanged(object sender, EventArgs e)
        {
            if (gheimatkala6txt.Text.Length != 0 && k16 == 1)
            {
                k16 = 0;
                gheimatkala6txt.Text = Class1.convert_str(gheimatkala6txt.Text.Replace(",", ""));
                gheimatkala6txt.Select(gheimatkala6txt.Text.Length, 0);
            }
        }

        private void gheimatkala6txt_KeyDown(object sender, KeyEventArgs e)
        {
            k16 = 1;
        }
        //
        //
        int k17 = 0;
        private void gheimateradif1txt_TextChanged(object sender, EventArgs e)
        {
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            long i3 = Convert.ToInt64(gheimateradif1txt.Text.Replace(",", ""));
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i2 + i3));
            if (gheimateradif1txt.Text.Length != 0 && k17 == 1)
            {
                k17 = 0;
                gheimateradif1txt.Text = Class1.convert_str(gheimateradif1txt.Text.Replace(",", ""));
                gheimateradif1txt.Select(gheimateradif1txt.Text.Length, 0);
            }
        }

        private void gheimateradif1txt_KeyDown(object sender, KeyEventArgs e)
        {
            k17 = 1;
        }
        //
        //
        int k18 = 0;
        private void gheimateradif2txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif2txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimateradif2txt.Text.Length != 0 && k18 == 1)
            {
                k18 = 0;
                gheimateradif2txt.Text = Class1.convert_str(gheimateradif2txt.Text.Replace(",", ""));
                gheimateradif2txt.Select(gheimateradif2txt.Text.Length, 0);
            }
        }

        private void gheimateradif2txt_KeyDown(object sender, KeyEventArgs e)
        {
            k18 = 1;
        }
        //
        //
        int k19 = 0;
        private void gheimateradif3txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif3txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimateradif3txt.Text.Length != 0 && k19 == 1)
            {
                k19 = 0;
                gheimateradif3txt.Text = Class1.convert_str(gheimateradif3txt.Text.Replace(",", ""));
                gheimateradif3txt.Select(gheimateradif3txt.Text.Length, 0);
            }
        }

        private void gheimateradif3txt_KeyDown(object sender, KeyEventArgs e)
        {
            k19 = 1;
        }
        //
        //
        int k20 = 0;
        private void gheimateradif4txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif4txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimateradif4txt.Text.Length != 0 && k20 == 1)
            {
                k20 = 0;
                gheimateradif4txt.Text = Class1.convert_str(gheimateradif4txt.Text.Replace(",", ""));
                gheimateradif4txt.Select(gheimateradif4txt.Text.Length, 0);
            }
        }

        private void gheimateradif4txt_KeyDown(object sender, KeyEventArgs e)
        {
            k20 = 1;
        }
        //
        //
        int k21 = 0;
        private void gheimateradif5txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif5txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimateradif5txt.Text.Length != 0 && k21 == 1)
            {
                k21 = 0;
                gheimateradif5txt.Text = Class1.convert_str(gheimateradif5txt.Text.Replace(",", ""));
                gheimateradif5txt.Select(gheimateradif5txt.Text.Length, 0);
            }
        }

        private void gheimateradif5txt_KeyDown(object sender, KeyEventArgs e)
        {
            k21 = 1;
        }
        //
        //
        int k22 = 0;
        private void gheimateradif6txt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif6txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (gheimateradif6txt.Text.Length != 0 && k22 == 1)
            {
                k22 = 0;
                gheimateradif6txt.Text = Class1.convert_str(gheimateradif6txt.Text.Replace(",", ""));
                gheimateradif6txt.Select(gheimateradif6txt.Text.Length, 0);
            }
        }

        private void gheimateradif6txt_KeyDown(object sender, KeyEventArgs e)
        {
            k22 = 1;
        }
        //
        //
        int k23 = 0;
        private void gheimateaghlam_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif1txt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(gheimateradif2txt.Text.Replace(",", ""));
            long i3 = Convert.ToInt64(gheimateradif3txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(gheimateradif4txt.Text.Replace(",", ""));
            long i5 = Convert.ToInt64(gheimateradif5txt.Text.Replace(",", ""));
            long i6 = Convert.ToInt64(gheimateradif6txt.Text.Replace(",", ""));
            long i7 = Convert.ToInt32(darsadetakhfiftxt.Text);
            long i8 = Convert.ToInt32(darsadmaliyattxt.Text);
            long i9 = Convert.ToInt32(darsadkarmozdtxt.Text);
            gheimateaghlam.Text = Class1.convert_str(Convert.ToString(i1 + i2 + i3 + i4 + i5 + i6));
            takhfiftxt.Text = Class1.convert_str(Convert.ToString((Convert.ToInt32(gheimateaghlam.Text.Replace(",", "")) * i7) / 100));
            maliyattxt .Text = Class1.convert_str(Convert.ToString((Convert.ToInt32(gheimateaghlam.Text.Replace(",", "")) * i8) / 100));
            karmozdtxt.Text = Class1.convert_str(Convert.ToString((Convert.ToInt32(gheimateaghlam.Text.Replace(",", "")) * i9) / 100));
            gheimatekoltxt.Text = gheimateaghlam.Text;

            if (gheimateaghlam.Text.Length != 0 && k23 == 1)
            {
                k23 = 0;
                gheimateaghlam.Text = Class1.convert_str(gheimateaghlam.Text.Replace(",", ""));
                gheimateaghlam.Select(gheimateaghlam.Text.Length, 0);
            }
        }

        private void gheimateaghlam_KeyDown(object sender, KeyEventArgs e)
        {
            k23 = 1;
        }
        //
        //
        int k24 = 0;
        private void takhfiftxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateaghlam .Text.Replace(",", ""));
            long i2 = Convert.ToInt64(darsadetakhfiftxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str(Convert.ToString(i1 - i2));
            if (takhfiftxt.Text.Length != 0 && k24 == 1)
            {
                k24 = 0;
                takhfiftxt.Text = Class1.convert_str(takhfiftxt.Text.Replace(",", ""));
                takhfiftxt.Select(takhfiftxt.Text.Length, 0);
            }
        }

        private void takhfiftxt_KeyDown(object sender, KeyEventArgs e)
        {
            k24 = 1;
        }
        //
        //
        int k25 = 0;
        private void kerayehamltxt_TextChanged(object sender, EventArgs e)
        {
            if (kerayehamltxt.Text == "")
                kerayehamltxt.Text = "0";
            long i1 = Convert.ToInt64(gheimatekoltxt .Text.Replace(",", ""));
            long i2 = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (kerayehamltxt.Text.Length != 0 && k25 == 1)
            {
                k25 = 0;
                kerayehamltxt.Text = Class1.convert_str(kerayehamltxt.Text.Replace(",", ""));
                kerayehamltxt.Select(kerayehamltxt.Text.Length, 0);
            }
        }

        private void kerayehamltxt_KeyDown(object sender, KeyEventArgs e)
        {
            k25 = 1;
        }
        //
        //
        int k26 = 0;
        private void dastmozdekargartxt_TextChanged(object sender, EventArgs e)
        {
            if (dastmozdekargartxt .Text == "")
                dastmozdekargartxt.Text = "0";
            long i1 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(dastmozdekargartxt .Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (dastmozdekargartxt.Text.Length != 0 && k26 == 1)
            {
                k26 = 0;
                dastmozdekargartxt.Text = Class1.convert_str(dastmozdekargartxt.Text.Replace(",", ""));
                dastmozdekargartxt.Select(dastmozdekargartxt.Text.Length, 0);
            }
        }

        private void dastmozdekargartxt_KeyDown(object sender, KeyEventArgs e)
        {
            k26 = 1;
        }
        //
        //
        int k27 = 0;
        private void maliyattxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(maliyattxt .Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (maliyattxt.Text.Length != 0 && k27 == 1)
            {
                k27 = 0;
                maliyattxt.Text = Class1.convert_str(maliyattxt.Text.Replace(",", ""));
                maliyattxt.Select(maliyattxt.Text.Length, 0);
            }
        }

        private void maliyattxt_KeyDown(object sender, KeyEventArgs e)
        {
            k27 = 1;
        }
        //
        //
        int k28 = 0;
        private void karmozdtxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(karmozdtxt .Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str(Convert.ToString(i1 + i2));
            if (karmozdtxt.Text.Length != 0 && k28 == 1)
            {
                k28 = 0;
                karmozdtxt.Text = Class1.convert_str(karmozdtxt.Text.Replace(",", ""));
                karmozdtxt.Select(karmozdtxt.Text.Length, 0);
            }
        }

        private void karmozdtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k28 = 1;
        }
        //
        //
        int k29 = 0;
        private void gheimatekoltxt_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            long i2 = Convert.ToInt64(darsadetakhfiftxt.Text.Replace(",", ""));
            long i3 = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(dastmozdekargartxt.Text.Replace(",", ""));
            long i5 = Convert.ToInt64(maliyattxt.Text.Replace(",", ""));
            long i6 = Convert.ToInt64(karmozdtxt.Text.Replace(",", ""));
            gheimatekoltxt.Text = Class1.convert_str(Convert.ToString(i1 - i2 + i3 + i4 + i5 + i6));
            long i7 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            long i8 = Convert.ToInt64(takhfifenaghdiyekharidtxt.Text.Replace(",", ""));
            mablaghepardakhtenaghdtxt.Text = Class1.convert_str(Convert.ToString(i7-i8));
            if (gheimatekoltxt.Text.Length != 0 && k29 == 1)
            {
                k29 = 0;
                gheimatekoltxt.Text = Class1.convert_str(gheimatekoltxt.Text.Replace(",", ""));
                gheimatekoltxt.Select(gheimatekoltxt.Text.Length, 0);
            }
        }

        private void gheimatekoltxt_KeyDown(object sender, KeyEventArgs e)
        {
            k29 = 1;
        }
        //
        //
        int k30 = 0;
        private void takhfifenaghdiyekharidtxt_TextChanged(object sender, EventArgs e)
        {
            if (takhfifenaghdiyekharidtxt.Text == "")
                takhfifenaghdiyekharidtxt.Text = "0";
            long i7 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            long i8 = Convert.ToInt64(takhfifenaghdiyekharidtxt .Text.Replace(",", ""));
            mablaghepardakhtenaghdtxt.Text = Class1.convert_str(Convert.ToString(i7 - i8));
            if (takhfifenaghdiyekharidtxt.Text.Length != 0 && k30 == 1)
            {
                k30 = 0;
                takhfifenaghdiyekharidtxt.Text = Class1.convert_str(takhfifenaghdiyekharidtxt.Text.Replace(",", ""));
                takhfifenaghdiyekharidtxt.Select(takhfifenaghdiyekharidtxt.Text.Length, 0);
            }
        }

        private void takhfifenaghdiyekharidtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k30 = 1;
        }
        //
        //
        int k31 = 0;
        private void mandetxt_TextChanged(object sender, EventArgs e)
        {
            if (mandetxt.Text == "")
                mandetxt.Text = "0";
            if (mandetxt.Text.Length != 0 && k31 == 1)
            {
                k31 = 0;
                mandetxt.Text = Class1.convert_str(mandetxt.Text.Replace(",", ""));
                mandetxt.Select(mandetxt.Text.Length, 0);
            }
        }

        private void mandetxt_KeyDown(object sender, KeyEventArgs e)
        {
            k31 = 1;
        }
        //
        //
        int k32 = 0;
        private void mablaghepardakhtenaghdtxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghepardakhtenaghdtxt.Text == "")
                mablaghepardakhtenaghdtxt.Text = "0";
            long i7 = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
            long i8 = Convert.ToInt64(mablaghepardakhtenaghdtxt.Text.Replace(",", ""));
            long i9 = Convert.ToInt64(takhfifenaghdiyekharidtxt .Text.Replace(",", ""));
            mandetxt.Text = Class1.convert_str(Convert.ToString(i7 - i8-i9));
            if (mablaghepardakhtenaghdtxt.Text.Length != 0 && k32 == 1)
            {
                k32 = 0;
                mablaghepardakhtenaghdtxt.Text = Class1.convert_str(mablaghepardakhtenaghdtxt.Text.Replace(",", ""));
                mablaghepardakhtenaghdtxt.Select(mablaghepardakhtenaghdtxt.Text.Length, 0);
            }
        }

        private void mablaghepardakhtenaghdtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k32 = 1;
        }
        //
        //
        int k33 = 0;
        private void mablaghechecktxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghechecktxt.Text.Length != 0 && k33 == 1)
            {
                k33 = 0;
                mablaghechecktxt.Text = Class1.convert_str(mablaghechecktxt.Text.Replace(",", ""));
                mablaghechecktxt.Select(mablaghechecktxt.Text.Length, 0);
            }
        }

        private void mablaghechecktxt_KeyDown(object sender, KeyEventArgs e)
        {
            k33 = 1;
        }
        //
        //
        int k34 = 0;
        private void mablaghehavaletxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghehavaletxt.Text.Length != 0 && k34 == 1)
            {
                k34 = 0;
                mablaghehavaletxt.Text = Class1.convert_str(mablaghehavaletxt.Text.Replace(",", ""));
                mablaghehavaletxt.Select(mablaghehavaletxt.Text.Length, 0);
            }
        }

        private void mablaghehavaletxt_KeyDown(object sender, KeyEventArgs e)
        {
            k34 = 1;
        }
        //
        //
        int k36 = 0;
        private void tedademandeghestmtxt_TextChanged_1(object sender, EventArgs e)
        {
            if (tedademandeghestmtxt.Text.Length != 0 && k36 == 1)
            {
                k36 = 0;
                tedademandeghestmtxt.Text = Class1.convert_number(tedademandeghestmtxt.Text.Replace(",", ""));
                tedademandeghestmtxt.Select(tedademandeghestmtxt.Text.Length, 0);
            }
        }

        private void tedademandeghestmtxt_KeyDown_1(object sender, KeyEventArgs e)
        {
            k36 = 1;
        }
        //
        //
        int k35 = 0;
        private void tedadeaghsattxt_TextChanged_1(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(mablaghekoleaghsattxt .Text.Replace(",", ""));
            int TedadeAghsat = Convert.ToInt32(tedadeaghsattxt.Text);
            mablagheghesttxt.Text = Class1 .convert_str ((i1 / TedadeAghsat).ToString());
            if (tedadeaghsattxt.Text.Length != 0 && k35 == 1)
            {
                k35 = 0;
                tedadeaghsattxt.Text = Class1.convert_number(tedadeaghsattxt.Text.Replace(",", ""));
                tedadeaghsattxt.Select(tedadeaghsattxt.Text.Length, 0);
            }
        }

        private void tedadeaghsattxt_KeyDown_1(object sender, KeyEventArgs e)
        {
            k35 = 1;
        }
        //
        //
        int k37 = 0;
        private void darsadsoodghesttxt_TextChanged_1(object sender, EventArgs e)
        {
            if (darsadsoodghesttxt.Text == "")
                darsadsoodghesttxt.Text = "0";
            //برای محاسبه درصد سود قسطی و تقسیم سود بین کل اقساط
            int TedadeAghsat = Convert.ToInt32(tedadeaghsattxt.Text);
            int i1 = Convert.ToInt32(darsadsoodghesttxt.Text);
            long i2 = Convert.ToInt64(mablaghekoleaghsattxt.Text.Replace(",", ""));
            long i3 = (i2*i1)/100;
            long i4 = i3 / TedadeAghsat;
            mablagheghesttxt.Text = Class1.convert_str(((i2 / TedadeAghsat)+i4).ToString());
            if (darsadsoodghesttxt.Text.Length != 0 && k37 == 1)
            {
                k37 = 0;
                darsadsoodghesttxt.Text = Class1.convert_number(darsadsoodghesttxt.Text.Replace(",", ""));
                darsadsoodghesttxt.Select(darsadsoodghesttxt.Text.Length, 0);
            }
        }

        private void darsadsoodghesttxt_KeyDown_1(object sender, KeyEventArgs e)
        {
            k37 = 1;
        }
        //
        //
        int k38 = 0;
        private void mablagheghesttxt_TextChanged_1(object sender, EventArgs e)
        {
            if (mablagheghesttxt.Text.Length != 0 && k38 == 1)
            {
                k38 = 0;
                mablagheghesttxt.Text = Class1.convert_str(mablagheghesttxt.Text.Replace(",", ""));
                mablagheghesttxt.Select(mablagheghesttxt.Text.Length, 0);
            }
        }

        private void mablagheghesttxt_KeyDown_1(object sender, KeyEventArgs e)
        {
            k38 = 1;
        }
        //
        //
        int k39 = 0;
        private void mablaghekoleaghsattxt_TextChanged(object sender, EventArgs e)
        {
            if (mablaghekoleaghsattxt.Text.Length != 0 && k39 == 1)
            {
                k39 = 0;
                mablaghekoleaghsattxt.Text = Class1.convert_str(mablaghekoleaghsattxt.Text.Replace(",", ""));
                mablaghekoleaghsattxt.Select(mablaghekoleaghsattxt.Text.Length, 0);
            }
        }

        private void mablaghekoleaghsattxt_KeyDown(object sender, KeyEventArgs e)
        {
            k39 = 1;
        }
        //
        //
        int k40 = 0;
        private void darsadetakhfiftxt_TextChanged(object sender, EventArgs e)
        {
            if (darsadetakhfiftxt.Text == "")
                darsadetakhfiftxt.Text = "0";
            long i1 = Convert.ToInt32(darsadetakhfiftxt.Text);
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            takhfiftxt.Text = Class1.convert_str(Convert.ToString((i1*i2)/100));
            if (darsadetakhfiftxt.Text.Length != 0 && k40 == 1)
            {
                k40 = 0;
                darsadetakhfiftxt.Text = Class1.convert_number(darsadetakhfiftxt.Text.Replace(",", ""));
                darsadetakhfiftxt.Select(darsadetakhfiftxt.Text.Length, 0);
            }
        }

        private void darsadetakhfiftxt_KeyDown(object sender, KeyEventArgs e)
        {
            k40 = 1;
        }
        //
        //
        int k41 = 0;
        private void darsadmaliyattxt_TextChanged(object sender, EventArgs e)
        {
            if (darsadmaliyattxt.Text == "")
                darsadmaliyattxt.Text = "0";
            long i1 = Convert.ToInt32(darsadmaliyattxt.Text);
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            maliyattxt.Text = Class1.convert_str(Convert.ToString((i1 * i2) / 100));
            if (darsadmaliyattxt.Text.Length != 0 && k41 == 1)
            {
                k41 = 0;
                darsadmaliyattxt.Text = Class1.convert_number(darsadmaliyattxt.Text.Replace(",", ""));
                darsadmaliyattxt.Select(darsadmaliyattxt.Text.Length, 0);
            }
        }

        private void darsadmaliyattxt_KeyDown(object sender, KeyEventArgs e)
        {
            k41 = 1;
        }
        //
        //
        int k42 = 0;
        private void darsadkarmozdtxt_TextChanged(object sender, EventArgs e)
        {
            if (darsadkarmozdtxt.Text == "")
                darsadkarmozdtxt.Text = "0";
            long i1 = Convert.ToInt32(darsadkarmozdtxt.Text);
            long i2 = Convert.ToInt64(gheimateaghlam.Text.Replace(",", ""));
            karmozdtxt.Text = Class1.convert_str(Convert.ToString((i1 * i2) / 100));
            if (darsadkarmozdtxt.Text.Length != 0 && k42 == 1)
            {
                k42 = 0;
                darsadkarmozdtxt.Text = Class1.convert_number(darsadkarmozdtxt.Text.Replace(",", ""));
                darsadkarmozdtxt.Select(darsadkarmozdtxt.Text.Length, 0);
            }
        }

        private void darsadkarmozdtxt_KeyDown(object sender, KeyEventArgs e)
        {
            k42 = 1;
        }
        //
        //

        private void tedadkala1nud_ValueChanged(object sender, EventArgs e)
        {
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            gheimateradif1txt.Text = Class1.convert_str((Convert.ToInt64(gheimatkala1txt.Text.Replace(",", "")) * tedadkala1nud.Value * TeadadRozeKeraye).ToString());
            Radif1 = (Convert.ToInt64(gheimatkala1txt.Text.Replace(",", "")) * Convert.ToInt32( tedadkala1nud.Value) * TeadadRozeKeraye);
            if (TeadadRozeKeraye <= 10)
                takhfiferoz1.Text = "0";
            if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
                takhfiferoz1.Text = Class1.convert_str(((Radif1 * 5) / 100).ToString());
            if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
                takhfiferoz1.Text = Class1.convert_str(((Radif1 * 10) / 100).ToString());
            if (TeadadRozeKeraye > 50)
                takhfiferoz1.Text = Class1.convert_str(((Radif1 * 15) / 100).ToString());
        }

        private void tedadkala2nud_ValueChanged(object sender, EventArgs e)
        {
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            gheimateradif2txt.Text = Class1.convert_str((Convert.ToInt64(gheimatkala2txt.Text.Replace(",", "")) * tedadkala2nud.Value * TeadadRozeKeraye).ToString());
            Radif2 = (Convert.ToInt64(gheimatkala2txt.Text.Replace(",", "")) * Convert.ToInt32(tedadkala2nud.Value) * TeadadRozeKeraye);
            if (TeadadRozeKeraye <= 10)
                takhfiferoz2.Text = "0";
            if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
                takhfiferoz2.Text = Class1.convert_str(((Radif2 * 5) / 100).ToString());
            if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
                takhfiferoz2.Text = Class1.convert_str(((Radif2 * 10) / 100).ToString());
            if (TeadadRozeKeraye > 50)
                takhfiferoz2.Text = Class1.convert_str(((Radif2 * 15) / 100).ToString());
        }

        private void tedadkala3nud_ValueChanged(object sender, EventArgs e)
        {
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            gheimateradif3txt.Text = Class1.convert_str((Convert.ToInt64(gheimatkala3txt.Text.Replace(",", "")) * tedadkala3nud.Value * TeadadRozeKeraye).ToString());
            Radif3 = (Convert.ToInt64(gheimatkala3txt.Text.Replace(",", "")) * Convert.ToInt32(tedadkala3nud.Value) * TeadadRozeKeraye);
            if (TeadadRozeKeraye <= 10)
                takhfiferoz3.Text = "0";
            if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
                takhfiferoz3.Text = Class1.convert_str(((Radif3 * 5) / 100).ToString());
            if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
                takhfiferoz3.Text = Class1.convert_str(((Radif3 * 10) / 100).ToString());
            if (TeadadRozeKeraye > 50)
                takhfiferoz3.Text = Class1.convert_str(((Radif3 * 15) / 100).ToString());
        }

        private void tedadkala4nud_ValueChanged(object sender, EventArgs e)
        {
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            gheimateradif4txt.Text = Class1.convert_str((Convert.ToInt64(gheimatkala4txt.Text.Replace(",", "")) * tedadkala4nud.Value * TeadadRozeKeraye).ToString());
            Radif4 = (Convert.ToInt64(gheimatkala4txt.Text.Replace(",", "")) * Convert.ToInt32(tedadkala4nud.Value) * TeadadRozeKeraye);
            if (TeadadRozeKeraye <= 10)
                takhfiferoz4.Text = "0";
            if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
                takhfiferoz4.Text = Class1.convert_str(((Radif4 * 5) / 100).ToString());
            if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
                takhfiferoz4.Text = Class1.convert_str(((Radif4 * 10) / 100).ToString());
            if (TeadadRozeKeraye > 50)
                takhfiferoz4.Text = Class1.convert_str(((Radif4 * 15) / 100).ToString());
        }

        private void tedadkala5nud_ValueChanged(object sender, EventArgs e)
        {
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            gheimateradif5txt.Text = Class1.convert_str((Convert.ToInt64(gheimatkala5txt.Text.Replace(",", "")) * tedadkala5nud.Value * TeadadRozeKeraye).ToString());
            Radif5 = (Convert.ToInt64(gheimatkala5txt.Text.Replace(",", "")) * Convert.ToInt32(tedadkala5nud.Value) * TeadadRozeKeraye);
            if (TeadadRozeKeraye <= 10)
                takhfiferoz5.Text = "0";
            if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
                takhfiferoz5.Text = Class1.convert_str(((Radif5 * 5) / 100).ToString());
            if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
                takhfiferoz5.Text = Class1.convert_str(((Radif5 * 10) / 100).ToString());
            if (TeadadRozeKeraye > 50)
                takhfiferoz5.Text = Class1.convert_str(((Radif5 * 15) / 100).ToString());
        }

        private void tedadkala6nud_ValueChanged(object sender, EventArgs e)
        {
            TeadadRozeKeraye = Convert.ToInt32(tedadrozhayekerayetxt.Text);
            gheimateradif6txt.Text = Class1.convert_str((Convert.ToInt64(gheimatkala6txt.Text.Replace(",", "")) * tedadkala6nud.Value * TeadadRozeKeraye).ToString());
            Radif6 = (Convert.ToInt64(gheimatkala6txt.Text.Replace(",", "")) * Convert.ToInt32(tedadkala6nud.Value) * TeadadRozeKeraye);
            if (TeadadRozeKeraye <= 10)
                takhfiferoz6.Text = "0";
            if (TeadadRozeKeraye > 10 && TeadadRozeKeraye <= 20)
                takhfiferoz6.Text = Class1.convert_str(((Radif6 * 5) / 100).ToString());
            if (TeadadRozeKeraye > 20 && TeadadRozeKeraye <= 50)
                takhfiferoz6.Text = Class1.convert_str(((Radif6 * 10) / 100).ToString());
            if (TeadadRozeKeraye > 50)
                takhfiferoz6.Text = Class1.convert_str(((Radif6 * 15) / 100).ToString());
        }

        private void takhfiferoz1_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif1txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(takhfiferoz1.Text.Replace(",", ""));
            gheimateradif1txt.Text = Class1.convert_str(Convert.ToString(i1 - i4));
        }

        private void addnaghdbtn_Click(object sender, EventArgs e)
        {
            if (idfactortxt.Text !="" && idnaghdytxt.Text != "" && tarikhmtxt .Text != "" && namemoshtaricmb .Text != "" && mablaghepardakhtenaghdtxt .Text != "")
            {
                NDB.IDNaghdy = Convert.ToInt32(idnaghdytxt.Text);
                NDB.FKNoeTaraconesh =4;
                NDB.FKFactor = Convert.ToInt32(idfactortxt.Text);
                NDB.TarikheSabteNaghdy = Convert.ToDateTime(tarikhmtxt .Text);
                NDB.NamePardakhtKonande = namemoshtaricmb .Text;
                NDB.MablagheNaghdy = Convert.ToInt64(mablaghepardakhtenaghdtxt.Text.Replace(",", ""));

                if (!NData.NaghdSearch1(NDB.IDNaghdy))
                {
                    NData.NaghdInsert1(NDB);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                        Class1.IDNaghdy = Convert.ToInt32(idnaghdytxt.Text);
                    }
                  
                }
                else
                {
                    MessageBox.Show("کد نقد تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addcheckbtn_Click(object sender, EventArgs e)
        {
            //
            int i1 = 0;
            int i2 = 0;
            DataTable dt1 = CData.CheckSearchID1 ();
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                i1 = Convert.ToInt32(dt1.Rows[i][0].ToString());
                if (i2 < i1)
                {
                    i2 = i1;
                }
            }
            if (dt1.Rows.Count == 0)
            {
                Class1.IDCheck  = 1;
            }
            else
            {
                Class1.IDCheck = i2 + 1;
            }
            //
            if (tarikhmtxt.Text != "" && tarikhesarresidecheckmtxt.Text != "    /  /" && namemoshtaricmb.Text != "" && bankchecktxt.Text != "" && shobechecktxt.Text != "" && seryalechecktxt.Text != "" && mablaghechecktxt.Text != "")
            {
                CDB.IDCheck = Class1.IDCheck;
                CDB.FKNoeTaraconesh = 1;
                CDB.FKFactor =Convert.ToInt32(idfactortxt .Text );
                CDB.TarikheSabteCheck = Convert.ToDateTime(tarikhmtxt.Text);
                CDB.TarikheSarResideCheck = Convert.ToDateTime(tarikhesarresidecheckmtxt .Text);
                CDB.NameCheckDahande = namemoshtaricmb.Text;
                CDB.NameBank = bankchecktxt.Text;
                CDB.ShobeBank = shobechecktxt.Text;
                CDB.VazeiyatePardakhtOrVosol = "وصول نشده";
                CDB.ShomareSerialeCheck = seryalechecktxt .Text;
                CDB.MablagheCheck = Convert.ToInt64(mablaghechecktxt.Text.Replace(",", ""));

                if (!CData.CheckSearch1(CDB.IDCheck))
                {
                    CData.CheckInsert1(CDB);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                       idchecktxt.Text= Class1.IDCheck.ToString ();
                    }
                 
                }
                else
                {
                    MessageBox.Show("کد چک تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addhavalebtn_Click(object sender, EventArgs e)
        {
            //
            int i1 = 0;
            int i2 = 0;
            DataTable dt1 = HVData.HavaleSearchID1 ();
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                i1 = Convert.ToInt32(dt1.Rows[i][0].ToString());
                if (i2 < i1)
                {
                    i2 = i1;
                }
            }
            if (dt1.Rows.Count == 0)
            {
                Class1.IDHavale  = 1;
            }
            else
            {
                Class1.IDHavale = i2 + 1;
            }
            //
            if (tarikhmtxt .Text != "" && tarikhesarresidehavalemtxt .Text != "    /  /" && namemoshtaricmb .Text != "" && bankehavaletxt .Text != "" && shobehavaletxt .Text != ""  && seryalehavaletxt .Text != "" && mablaghehavaletxt .Text != "")
            {
                HVDB.IDHavale = Class1.IDHavale ;
                HVDB.FKNoeTaraconesh = 2;
                HVDB.FKFactor = Convert.ToInt32(idfactortxt.Text);
                HVDB.TarikheSabteHavale = Convert.ToDateTime(tarikhmtxt .Text);
                HVDB.NameHavaleDahande = namemoshtaricmb .Text;
                HVDB.TarikheSarResideHavale = Convert.ToDateTime(tarikhesarresidehavalemtxt .Text);
                HVDB.NameBank = bankehavaletxt .Text;
                HVDB.ShobeBank = shobehavaletxt .Text;
                HVDB.VazeiyatePardakhtOrVosol = "وصول نشده";
                HVDB.ShomareSerialeHavale = seryalehavaletxt .Text;
                HVDB.MablagheHavale = Convert.ToInt64(mablaghehavaletxt .Text.Replace(",", ""));

                if (!HVData.HavaleSearch1(HVDB.IDHavale))
                {
                    HVData.HavaleInsert1(HVDB);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                        idhavaletxt.Text=Class1.IDHavale.ToString();
                    }
                  
                }
                else
                {
                    MessageBox.Show("کد حواله تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addghestybtn_Click(object sender, EventArgs e)
        {
            //
            int i1 = 0;
            int i2 = 0;
            DataTable dt1 = GSData.GhestySearchID1 ();
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                i1 = Convert.ToInt32(dt1.Rows[i][0].ToString());
                if (i2 < i1)
                {
                    i2 = i1;
                }
            }
            if (dt1.Rows.Count == 0)
            {
                Class1.IDGhesty = 1;
            }
            else
            {
                Class1.IDGhesty = i2 + 1;
            }
            //
            if (tarikhmtxt.Text != "" && tarikhepardakhteghestmtxt.Text != "    /  /" && namemoshtaricmb.Text != "" && tedadeaghsattxt.Text != "" && tedademandeghestmtxt.Text != "" && mablagheghesttxt.Text != "" && darsadsoodghesttxt.Text != "")
            {
                GSDB.IDGhesty = Class1.IDGhesty;
                GSDB.FKNoeTaraconesh = 3;
                GSDB.TarikheSabteGhesti = Convert.ToDateTime(tarikhmtxt.Text);
                GSDB.NameDahandeGhest = namemoshtaricmb.Text;
                GSDB.TedadeAghsat = Convert.ToInt32(tedadeaghsattxt.Text);
                GSDB.TarikhePardakhteAghsat = Convert.ToDateTime(tarikhepardakhteghestmtxt.Text);
                GSDB.TedadeAghsateMande = Convert.ToInt32(tedademandeghestmtxt.Text);
                GSDB.MablagheGhest = Convert.ToInt64(mablagheghesttxt.Text.Replace(",", ""));
                GSDB.DarsadeSodeGhest = darsadsoodghesttxt.Text;

                if (!GSData.GhestySearch1(GSDB.IDGhesty))
                {
                    GSData.GhestyInsert1(GSDB);
                    if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                        idghestytxt.Text =Class1.IDGhesty.ToString();
                    }
                 
                }
                else
                {
                    MessageBox.Show("کد قسط تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idfactortxt.Text != "" && idkerayetxt.Text != "" && tarikhmtxt.Text != "" && idnoemoshtaritxt.Text != "" && idmoshtaritxt.Text != "" && namemoshtaricmb.Text != "" && namekala1cmb.Text != "" && gheimatekoltxt.Text != "" && idnaghdytxt.Text != "" && tarikhebargashtekalamtxt.Text != "    /  /")
            {
                //برای جدول فاکتور
                FDB.IDFactor = Convert.ToInt32(idfactortxt.Text);
                FDB.FKNoeFactor = 3;
                FDB.FKNoeMoshtari = Convert.ToInt32(idnoemoshtaritxt.Text);
                FDB.FKMoshtari = Convert.ToInt32(idmoshtaritxt.Text);
                FDB.NameMoshtari = namemoshtaricmb.Text;
                FDB.FKSanadeHesabdari = 0;
                FDB.FKNaghdy = Convert.ToInt32(idnaghdytxt.Text);
                FDB.FKGhesty = Convert.ToInt32(idghestytxt.Text);
                FDB.FKCheck = Convert.ToInt32(idchecktxt.Text);
                FDB.FKHavale = Convert.ToInt32(idhavaletxt.Text);
                FDB.NameKarbar = lblkarbar.Text;
                FDB.TarikheFactor = Convert.ToDateTime(tarikhmtxt.Text);
                FDB.DarsadeTakhfif = darsadetakhfiftxt.Text;
                FDB.NameRanande = nameranandetxt.Text;
                FDB.DastMozdeKargareBarbari = Convert.ToInt64(dastmozdekargartxt.Text.Replace(",", ""));
                FDB.KerayeHaml = Convert.ToInt64(kerayehamltxt.Text.Replace(",", ""));
                //برای جدول ریز فاکتور
                RFKDB.IDFactorKeraye = Convert.ToInt32(idkerayetxt.Text);
                RFKDB.NameKalayeKeraye1 = namekala1cmb.Text;
                RFKDB.Tedade1 = Convert.ToInt32(tedadkala1nud.Value);
                RFKDB.NameKalayeKeraye2 = namekala2cmb.Text;
                RFKDB.Tedade2 = Convert.ToInt32(tedadkala2nud.Value);
                RFKDB.NameKalayeKeraye3 = namekala3cmb.Text;
                RFKDB.Tedade3 = Convert.ToInt32(tedadkala3nud.Text);
                RFKDB.NameKalayeKeraye4 = namekala4cmb.Text;
                RFKDB.Tedade4 = Convert.ToInt32(tedadkala4nud.Text);
                RFKDB.NameKalayeKeraye5 = namekala5cmb.Text;
                RFKDB.Tedade5 = Convert.ToInt32(tedadkala5nud.Text);
                RFKDB.NameKalayeKeraye6 = namekala6cmb.Text;
                RFKDB.Tedade6 = Convert.ToInt32(tedadkala6nud.Text);
                RFKDB.FKFactor = Convert.ToInt32(idfactortxt.Text);
                RFKDB.TarikheBargashteKala = Convert.ToDateTime(tarikhebargashtekalamtxt.Text);
                RFKDB.GheimateKoleKalaha = Convert.ToInt64(gheimatekoltxt.Text.Replace(",", ""));
                ////برای جدول سند حسابداری
                //SHDB.IDSanad = Convert.ToInt32(idsanadtxt .Text);
                //HesabhaData HData = new HesabhaData();
                //DataTable DT = HData.HesabhaComboShow1();
                //for (int i = 0; i < DT.Rows.Count; i++)
                //{

                //  int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                //  string NameHesabTafzily = DT.Rows[i][7].ToString();
                //  if(NameHesabTafzily == "درآمد")
                //    SHDB.FKHesabeBedehkar  = Convert.ToInt32(IDHesab);

                //}
                //SHDB.FKHesabeBestankar  = Convert.ToInt32("");
                //SHDB.FKNoeSanad = Convert.ToInt32("2");
                //SHDB.NameKarbar = lblkarbar .Text;
                //SHDB.TarikheSanad = Convert.ToDateTime(tarikhmtxt.Text);
                //SHDB.SharheSanad = ;
                //SHDB.MablagheBedehkari  = Convert.ToInt32(gheimatekoltxt .Text);
                //SHDB.MablagheBestanKari = Convert.ToInt32(gheimatekoltxt.Text);

                //برای آپدیت کردن وضعیت کرایه و تعداد کرایه داده شده کالاها
                DataTable DT1 = KKData.KalayeKerayeReportShow1();
                for (int i = 0; i < DT1.Rows.Count; i++)
                {
                    KKDB.IDKalaKeraye = Convert.ToInt32(DT1.Rows[i][0].ToString());
                    KKDB.FKNoeKala = Convert.ToInt32(DT1.Rows[i][1].ToString());
                    KKDB.FKGroupKala = Convert.ToInt32(DT1.Rows[i][2].ToString());
                    KKDB.NameKala = DT1.Rows[i][4].ToString();
                    KKDB.VaziyateKeraye = DT1.Rows[i][5].ToString();
                    KKDB.Tozihat = DT1.Rows[i][6].ToString();
                    KKDB.GheimateKharid = Convert.ToInt64(DT1.Rows[i][7].ToString());
                    KKDB.GheimateKeraye = Convert.ToInt64(DT1.Rows[i][8].ToString());
                    KKDB.TedadeKalayeMojod = Convert.ToInt32(DT1.Rows[i][9].ToString());
                    KKDB.Garanty = DT1.Rows[i][11].ToString();
                    KKDB.ModeleKala = DT1.Rows[i][12].ToString();
                    KKDB.BarcodeKala = DT1.Rows[i][13].ToString();
                    KKDB.NameSherkatTolidi = DT1.Rows[i][14].ToString();
                    //
                    int TedadeKala = Convert.ToInt32(DT1.Rows[i][9].ToString());
                    int TedadeKerayeDade = Convert.ToInt32(DT1.Rows[i][10].ToString());
                    string VaziyateKeraye = DT1.Rows[i][5].ToString();
                    string NameKala = DT1.Rows[i][4].ToString();
                    if (namekala1cmb.Text == NameKala)
                    {
                        TedadeKerayeDade = TedadeKerayeDade + Convert.ToInt32(tedadkala1nud.Value);
                        if (TedadeKerayeDade == TedadeKala)
                        {
                            KKDB.VaziyateKeraye = "کرایه داده شده";
                        }
                        KKDB.TedadeKerayeDadeShode = TedadeKerayeDade;
                        KKData.KalayeKerayeUpdate1(KKDB);
                    }
                    if (namekala2cmb.Text == NameKala)
                    {
                        TedadeKerayeDade = TedadeKerayeDade + Convert.ToInt32(tedadkala2nud.Value);
                        if (TedadeKerayeDade == TedadeKala)
                        {
                            KKDB.VaziyateKeraye = "کرایه داده شده";
                        }
                        KKDB.TedadeKerayeDadeShode = TedadeKerayeDade;
                        KKData.KalayeKerayeUpdate1(KKDB);
                    }
                    if (namekala3cmb.Text == NameKala)
                    {
                        TedadeKerayeDade = TedadeKerayeDade + Convert.ToInt32(tedadkala3nud.Value);
                        if (TedadeKerayeDade == TedadeKala)
                        {
                            KKDB.VaziyateKeraye = "کرایه داده شده";
                        }
                        KKDB.TedadeKerayeDadeShode = TedadeKerayeDade;
                        KKData.KalayeKerayeUpdate1(KKDB);
                    }
                    if (namekala4cmb.Text == NameKala)
                    {
                        TedadeKerayeDade = TedadeKerayeDade + Convert.ToInt32(tedadkala4nud.Value);
                        if (TedadeKerayeDade == TedadeKala)
                        {
                            KKDB.VaziyateKeraye = "کرایه داده شده";
                        }
                        KKDB.TedadeKerayeDadeShode = TedadeKerayeDade;
                        KKData.KalayeKerayeUpdate1(KKDB);
                    }
                    if (namekala5cmb.Text == NameKala)
                    {
                        TedadeKerayeDade = TedadeKerayeDade + Convert.ToInt32(tedadkala5nud.Value);
                        if (TedadeKerayeDade == TedadeKala)
                        {
                            KKDB.VaziyateKeraye = "کرایه داده شده";
                        }
                        KKDB.TedadeKerayeDadeShode = TedadeKerayeDade;
                        KKData.KalayeKerayeUpdate1(KKDB);
                    }
                    if (namekala6cmb.Text == NameKala)
                    {
                        TedadeKerayeDade = TedadeKerayeDade + Convert.ToInt32(tedadkala6nud.Value);
                        if (TedadeKerayeDade == TedadeKala)
                        {
                            KKDB.VaziyateKeraye = "کرایه داده شده";
                        }
                        KKDB.TedadeKerayeDadeShode = TedadeKerayeDade;
                        KKData.KalayeKerayeUpdate1(KKDB);
                    }
                }

                if (Class1.virayeshF != 0 && Class1.virayeshRFK != 0)
                {
                    if (RFKData.RizFactorKerayeSearch1(RFKDB.IDFactorKeraye) && Class1.virayeshRFK != RFKDB.IDFactorKeraye && FData.FactorSearch1(FDB.IDFactor) && Class1.virayeshF != FDB.IDFactor)
                    {
                        MessageBox.Show(" کد فاکتور تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        FData.FactorUpdate1(FDB);
                        RFKData.RizFactorKerayeUpdate1(RFKDB);
                        if (MessageBox.Show("ویرایش با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {

                            Class1.virayeshRFK = 0;
                            Class1.virayeshF = 0;
                            Class1.NameMoshtari = "";
                            Class1.IDCheck = 0;
                            Class1.IDGhesty = 0;
                            Class1.IDHavale = 0;
                            Class1.IDNaghdy = 0;
                            Class1.IDSanad = 0;
                        }
                        Close();
                    }
                }
                else
                {
                    if (!RFKData.RizFactorKerayeSearch1(RFKDB.IDFactorKeraye) && !FData.FactorSearch1(FDB.IDFactor))
                    {
                        FData.FactorInsert1(FDB);
                        RFKData.RizFactorKerayeInsert1(RFKDB);
                        if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                        {
                            Class1.virayeshRFK = 0;
                            Class1.virayeshF = 0;
                            Class1.NameMoshtari = "";
                            Class1.IDCheck = 0;
                            Class1.IDGhesty = 0;
                            Class1.IDHavale = 0;
                            Class1.IDNaghdy = 0;
                            Class1.IDSanad = 0;
                        }
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("کد فاکتور تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void takhfiferoz2_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif2txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(takhfiferoz2.Text.Replace(",", ""));
            gheimateradif2txt.Text = Class1.convert_str(Convert.ToString(i1 - i4));
        }

        private void takhfiferoz3_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif3txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(takhfiferoz3.Text.Replace(",", ""));
            gheimateradif3txt.Text = Class1.convert_str(Convert.ToString(i1 - i4));
        }

        private void takhfiferoz4_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif4txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(takhfiferoz4.Text.Replace(",", ""));
            gheimateradif4txt.Text = Class1.convert_str(Convert.ToString(i1 - i4));
        }

        private void takhfiferoz5_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif5txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(takhfiferoz5.Text.Replace(",", ""));
            gheimateradif5txt.Text = Class1.convert_str(Convert.ToString(i1 - i4));
        }

        private void takhfiferoz6_TextChanged(object sender, EventArgs e)
        {
            long i1 = Convert.ToInt64(gheimateradif6txt.Text.Replace(",", ""));
            long i4 = Convert.ToInt64(takhfiferoz6.Text.Replace(",", ""));
            gheimateradif6txt.Text = Class1.convert_str(Convert.ToString(i1 - i4));
        }

        private void sabtesanadbtn_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmAddSanadHesabdari obj = new SanadeHesabdari.frmAddSanadHesabdari();
            obj.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("قبل از انتخاب کالاها تعداد روزهای کرایه را مشخص کنید", "راهنمایی",MessageBoxButtons .OK, MessageBoxIcon.Information);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            string s = "                            :برای وارد کردن اطلاعات پرداخت قسطی\n\r" + "ابتدا کل مبلغ بعد تعداد اقساط و سپس درصد سود را وارد کنید";
            MessageBox.Show(s, "راهنمایی", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


    }
}

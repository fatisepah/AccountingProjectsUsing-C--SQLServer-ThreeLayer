﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
namespace main1.Factors
{
    public partial class frmFactorKeraye : Form
    {
        public frmFactorKeraye()
        {
            InitializeComponent();
        }
        RizFactorKerayeData RFKData = new RizFactorKerayeData();

        private void frmFactorKeraye1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = RFKData.RizFactorKerayeShow1();
           //  set_datagrid();

        }

        private void darjbtn_Click(object sender, EventArgs e)
        {

        }
    }
}

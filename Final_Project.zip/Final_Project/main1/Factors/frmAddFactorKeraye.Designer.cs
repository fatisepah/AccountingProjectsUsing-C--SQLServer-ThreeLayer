﻿namespace main1.Factors
{
    partial class frmAddFactorKeraye
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.idsanadtxt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.idkerayetxt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tarikhmtxt = new System.Windows.Forms.MaskedTextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.idfactortxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.namemoshtaricmb = new System.Windows.Forms.ComboBox();
            this.noemoshtaricmb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.idmoshtaritxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.idnoemoshtaritxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label46 = new System.Windows.Forms.Label();
            this.namekala4cmb = new System.Windows.Forms.ComboBox();
            this.gheimatkala4txt = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tedadkala4nud = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.namekala3cmb = new System.Windows.Forms.ComboBox();
            this.gheimatkala3txt = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tedadkala3nud = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.namekala2cmb = new System.Windows.Forms.ComboBox();
            this.gheimatkala2txt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tedadkala2nud = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.namekala1cmb = new System.Windows.Forms.ComboBox();
            this.gheimatkala1txt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tedadkala1nud = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.gheimatbatakhfiftxt = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.kerayehamltxt = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.dastmozdekargartxt = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.gheimatekoltxt = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label42 = new System.Windows.Forms.Label();
            this.lbldarsad = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.tarikhebargashtekalamtxt = new System.Windows.Forms.MaskedTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.darsadetakhfiftxt = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.nameranandetxt = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pardakhtehavalebtn = new System.Windows.Forms.Button();
            this.pardakhecheckbtn = new System.Windows.Forms.Button();
            this.pardakheghestybtn = new System.Windows.Forms.Button();
            this.pardakhenaghdybtn = new System.Windows.Forms.Button();
            this.idhavaletxt = new System.Windows.Forms.TextBox();
            this.idchecktxt = new System.Windows.Forms.TextBox();
            this.idghestytxt = new System.Windows.Forms.TextBox();
            this.idnaghdytxt = new System.Windows.Forms.TextBox();
            this.havalechb = new System.Windows.Forms.CheckBox();
            this.checkchb = new System.Windows.Forms.CheckBox();
            this.ghestychb = new System.Windows.Forms.CheckBox();
            this.naghdchb = new System.Windows.Forms.CheckBox();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.pishnamayeshbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala4nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala3nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala2nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala1nud)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.idsanadtxt);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.idkerayetxt);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.tarikhmtxt);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.idfactortxt);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(24, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(557, 87);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // idsanadtxt
            // 
            this.idsanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idsanadtxt.Location = new System.Drawing.Point(61, 19);
            this.idsanadtxt.Name = "idsanadtxt";
            this.idsanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idsanadtxt.Size = new System.Drawing.Size(116, 20);
            this.idsanadtxt.TabIndex = 8;
            this.idsanadtxt.TextChanged += new System.EventHandler(this.idsanadtxt_TextChanged);
            this.idsanadtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idsanadtxt_KeyDown);
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(43, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(16, 23);
            this.label22.TabIndex = 72;
            this.label22.Text = "*";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(304, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 23);
            this.label10.TabIndex = 73;
            this.label10.Text = "*";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(182, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 23);
            this.label23.TabIndex = 71;
            this.label23.Text = "کد سند حسابداری:";
            // 
            // idkerayetxt
            // 
            this.idkerayetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idkerayetxt.Location = new System.Drawing.Point(321, 50);
            this.idkerayetxt.Name = "idkerayetxt";
            this.idkerayetxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idkerayetxt.Size = new System.Drawing.Size(117, 20);
            this.idkerayetxt.TabIndex = 2;
            this.idkerayetxt.TextChanged += new System.EventHandler(this.idkerayetxt_TextChanged);
            this.idkerayetxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idkerayetxt_KeyDown);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(442, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 23);
            this.label11.TabIndex = 71;
            this.label11.Text = "کد فاکتور کرایه:";
            // 
            // tarikhmtxt
            // 
            this.tarikhmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhmtxt.Location = new System.Drawing.Point(61, 50);
            this.tarikhmtxt.Name = "tarikhmtxt";
            this.tarikhmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhmtxt.TabIndex = 3;
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(304, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(16, 23);
            this.label29.TabIndex = 68;
            this.label29.Text = "*";
            // 
            // idfactortxt
            // 
            this.idfactortxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idfactortxt.Location = new System.Drawing.Point(321, 19);
            this.idfactortxt.Name = "idfactortxt";
            this.idfactortxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idfactortxt.Size = new System.Drawing.Size(117, 20);
            this.idfactortxt.TabIndex = 1;
            this.idfactortxt.TextChanged += new System.EventHandler(this.idfactortxt_TextChanged);
            this.idfactortxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idfactortxt_KeyDown);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(44, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 23);
            this.label6.TabIndex = 22;
            this.label6.Text = "*";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(181, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 23);
            this.label17.TabIndex = 20;
            this.label17.Text = "تاریخ:";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(445, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 23);
            this.label19.TabIndex = 19;
            this.label19.Text = "کد فاکتور:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.namemoshtaricmb);
            this.groupBox2.Controls.Add(this.noemoshtaricmb);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.idmoshtaritxt);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.idnoemoshtaritxt);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(24, 120);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(557, 94);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "اطلاعات مشتری";
            // 
            // namemoshtaricmb
            // 
            this.namemoshtaricmb.FormattingEnabled = true;
            this.namemoshtaricmb.Location = new System.Drawing.Point(61, 54);
            this.namemoshtaricmb.Name = "namemoshtaricmb";
            this.namemoshtaricmb.Size = new System.Drawing.Size(116, 21);
            this.namemoshtaricmb.TabIndex = 6;
            this.namemoshtaricmb.SelectedIndexChanged += new System.EventHandler(this.namemoshtaricmb_SelectedIndexChanged);
            this.namemoshtaricmb.TextChanged += new System.EventHandler(this.namemoshtaricmb_TextChanged);
            // 
            // noemoshtaricmb
            // 
            this.noemoshtaricmb.FormattingEnabled = true;
            this.noemoshtaricmb.Items.AddRange(new object[] {
            "حقیقی",
            "حقوقی"});
            this.noemoshtaricmb.Location = new System.Drawing.Point(61, 21);
            this.noemoshtaricmb.Name = "noemoshtaricmb";
            this.noemoshtaricmb.Size = new System.Drawing.Size(116, 21);
            this.noemoshtaricmb.TabIndex = 4;
            this.noemoshtaricmb.SelectedIndexChanged += new System.EventHandler(this.noemoshtaricmb_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(304, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 23);
            this.label1.TabIndex = 81;
            this.label1.Text = "*";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(304, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 23);
            this.label2.TabIndex = 80;
            this.label2.Text = "*";
            // 
            // idmoshtaritxt
            // 
            this.idmoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idmoshtaritxt.Location = new System.Drawing.Point(321, 55);
            this.idmoshtaritxt.Name = "idmoshtaritxt";
            this.idmoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idmoshtaritxt.Size = new System.Drawing.Size(117, 20);
            this.idmoshtaritxt.TabIndex = 7;
            this.idmoshtaritxt.TextChanged += new System.EventHandler(this.idmoshtaritxt_TextChanged);
            this.idmoshtaritxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idmoshtaritxt_KeyDown);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(44, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 23);
            this.label3.TabIndex = 77;
            this.label3.Text = "*";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(180, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 23);
            this.label4.TabIndex = 76;
            this.label4.Text = "نام مشتری:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(442, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 23);
            this.label5.TabIndex = 75;
            this.label5.Text = "کد مشتری:";
            // 
            // idnoemoshtaritxt
            // 
            this.idnoemoshtaritxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoemoshtaritxt.Location = new System.Drawing.Point(321, 22);
            this.idnoemoshtaritxt.Name = "idnoemoshtaritxt";
            this.idnoemoshtaritxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoemoshtaritxt.Size = new System.Drawing.Size(117, 20);
            this.idnoemoshtaritxt.TabIndex = 5;
            this.idnoemoshtaritxt.TextChanged += new System.EventHandler(this.idnoemoshtaritxt_TextChanged);
            this.idnoemoshtaritxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnoemoshtaritxt_KeyDown);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(184, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 23);
            this.label8.TabIndex = 72;
            this.label8.Text = "نوع مشتری:";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(442, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 23);
            this.label9.TabIndex = 71;
            this.label9.Text = "کد نوع مشتری:";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(522, 11);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 23);
            this.label25.TabIndex = 84;
            this.label25.Text = ":نام کاربر";
            // 
            // lblkarbar
            // 
            this.lblkarbar.Location = new System.Drawing.Point(399, 11);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(124, 23);
            this.lblkarbar.TabIndex = 83;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.namekala4cmb);
            this.groupBox4.Controls.Add(this.gheimatkala4txt);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.tedadkala4nud);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.namekala3cmb);
            this.groupBox4.Controls.Add(this.gheimatkala3txt);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.tedadkala3nud);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.namekala2cmb);
            this.groupBox4.Controls.Add(this.gheimatkala2txt);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.tedadkala2nud);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.namekala1cmb);
            this.groupBox4.Controls.Add(this.gheimatkala1txt);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.tedadkala1nud);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Location = new System.Drawing.Point(24, 214);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox4.Size = new System.Drawing.Size(556, 176);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "لیست کالاها";
            // 
            // label46
            // 
            this.label46.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.Red;
            this.label46.Location = new System.Drawing.Point(356, 33);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(16, 23);
            this.label46.TabIndex = 117;
            this.label46.Text = "*";
            // 
            // namekala4cmb
            // 
            this.namekala4cmb.FormattingEnabled = true;
            this.namekala4cmb.Location = new System.Drawing.Point(373, 140);
            this.namekala4cmb.Name = "namekala4cmb";
            this.namekala4cmb.Size = new System.Drawing.Size(94, 21);
            this.namekala4cmb.TabIndex = 18;
            this.namekala4cmb.SelectedIndexChanged += new System.EventHandler(this.namekala4cmb_SelectedIndexChanged);
            // 
            // gheimatkala4txt
            // 
            this.gheimatkala4txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatkala4txt.Location = new System.Drawing.Point(21, 142);
            this.gheimatkala4txt.Name = "gheimatkala4txt";
            this.gheimatkala4txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala4txt.Size = new System.Drawing.Size(117, 20);
            this.gheimatkala4txt.TabIndex = 20;
            this.gheimatkala4txt.Text = "0";
            this.gheimatkala4txt.TextChanged += new System.EventHandler(this.gheimatkala4txt_TextChanged);
            this.gheimatkala4txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala4txt_KeyDown);
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(144, 143);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 23);
            this.label26.TabIndex = 103;
            this.label26.Text = "قیمت کالاها:";
            // 
            // tedadkala4nud
            // 
            this.tedadkala4nud.Location = new System.Drawing.Point(235, 141);
            this.tedadkala4nud.Name = "tedadkala4nud";
            this.tedadkala4nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala4nud.Size = new System.Drawing.Size(59, 20);
            this.tedadkala4nud.TabIndex = 19;
            this.tedadkala4nud.ValueChanged += new System.EventHandler(this.tedadkala4nud_ValueChanged);
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(293, 142);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(57, 23);
            this.label27.TabIndex = 101;
            this.label27.Text = "تعداد کالا:";
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(464, 143);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 23);
            this.label28.TabIndex = 100;
            this.label28.Text = "نام کالا:";
            // 
            // namekala3cmb
            // 
            this.namekala3cmb.FormattingEnabled = true;
            this.namekala3cmb.Location = new System.Drawing.Point(373, 104);
            this.namekala3cmb.Name = "namekala3cmb";
            this.namekala3cmb.Size = new System.Drawing.Size(94, 21);
            this.namekala3cmb.TabIndex = 15;
            this.namekala3cmb.SelectedIndexChanged += new System.EventHandler(this.namekala3cmb_SelectedIndexChanged);
            // 
            // gheimatkala3txt
            // 
            this.gheimatkala3txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatkala3txt.Location = new System.Drawing.Point(21, 106);
            this.gheimatkala3txt.Name = "gheimatkala3txt";
            this.gheimatkala3txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala3txt.Size = new System.Drawing.Size(117, 20);
            this.gheimatkala3txt.TabIndex = 17;
            this.gheimatkala3txt.Text = "0";
            this.gheimatkala3txt.TextChanged += new System.EventHandler(this.gheimatkala3txt_TextChanged);
            this.gheimatkala3txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala3txt_KeyDown);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(144, 107);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 23);
            this.label18.TabIndex = 97;
            this.label18.Text = "قیمت کالاها:";
            // 
            // tedadkala3nud
            // 
            this.tedadkala3nud.Location = new System.Drawing.Point(235, 105);
            this.tedadkala3nud.Name = "tedadkala3nud";
            this.tedadkala3nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala3nud.Size = new System.Drawing.Size(59, 20);
            this.tedadkala3nud.TabIndex = 16;
            this.tedadkala3nud.ValueChanged += new System.EventHandler(this.tedadkala3nud_ValueChanged);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(293, 106);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 23);
            this.label20.TabIndex = 95;
            this.label20.Text = "تعداد کالا:";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(464, 107);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 23);
            this.label21.TabIndex = 94;
            this.label21.Text = "نام کالا:";
            // 
            // namekala2cmb
            // 
            this.namekala2cmb.FormattingEnabled = true;
            this.namekala2cmb.Location = new System.Drawing.Point(373, 64);
            this.namekala2cmb.Name = "namekala2cmb";
            this.namekala2cmb.Size = new System.Drawing.Size(94, 21);
            this.namekala2cmb.TabIndex = 12;
            this.namekala2cmb.SelectedIndexChanged += new System.EventHandler(this.namekala2cmb_SelectedIndexChanged);
            // 
            // gheimatkala2txt
            // 
            this.gheimatkala2txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatkala2txt.Location = new System.Drawing.Point(21, 66);
            this.gheimatkala2txt.Name = "gheimatkala2txt";
            this.gheimatkala2txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala2txt.Size = new System.Drawing.Size(117, 20);
            this.gheimatkala2txt.TabIndex = 14;
            this.gheimatkala2txt.Text = "0";
            this.gheimatkala2txt.TextChanged += new System.EventHandler(this.gheimatkala2txt_TextChanged);
            this.gheimatkala2txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala2txt_KeyDown);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(144, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 23);
            this.label14.TabIndex = 91;
            this.label14.Text = "قیمت کالاها:";
            // 
            // tedadkala2nud
            // 
            this.tedadkala2nud.Location = new System.Drawing.Point(235, 65);
            this.tedadkala2nud.Name = "tedadkala2nud";
            this.tedadkala2nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala2nud.Size = new System.Drawing.Size(59, 20);
            this.tedadkala2nud.TabIndex = 13;
            this.tedadkala2nud.ValueChanged += new System.EventHandler(this.tedadkala2nud_ValueChanged);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(293, 66);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 23);
            this.label15.TabIndex = 89;
            this.label15.Text = "تعداد کالا:";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(464, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 23);
            this.label16.TabIndex = 88;
            this.label16.Text = "نام کالا:";
            // 
            // namekala1cmb
            // 
            this.namekala1cmb.FormattingEnabled = true;
            this.namekala1cmb.Location = new System.Drawing.Point(373, 28);
            this.namekala1cmb.Name = "namekala1cmb";
            this.namekala1cmb.Size = new System.Drawing.Size(94, 21);
            this.namekala1cmb.TabIndex = 9;
            this.namekala1cmb.SelectedIndexChanged += new System.EventHandler(this.namekala1cmb_SelectedIndexChanged);
            // 
            // gheimatkala1txt
            // 
            this.gheimatkala1txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatkala1txt.Location = new System.Drawing.Point(21, 30);
            this.gheimatkala1txt.Name = "gheimatkala1txt";
            this.gheimatkala1txt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatkala1txt.Size = new System.Drawing.Size(117, 20);
            this.gheimatkala1txt.TabIndex = 11;
            this.gheimatkala1txt.Text = "0";
            this.gheimatkala1txt.TextChanged += new System.EventHandler(this.gheimatkala1txt_TextChanged);
            this.gheimatkala1txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatkala1txt_KeyDown);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(144, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 23);
            this.label13.TabIndex = 85;
            this.label13.Text = "قیمت کالاها:";
            // 
            // tedadkala1nud
            // 
            this.tedadkala1nud.Location = new System.Drawing.Point(235, 29);
            this.tedadkala1nud.Name = "tedadkala1nud";
            this.tedadkala1nud.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tedadkala1nud.Size = new System.Drawing.Size(59, 20);
            this.tedadkala1nud.TabIndex = 10;
            this.tedadkala1nud.ValueChanged += new System.EventHandler(this.tedadkala1nud_ValueChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(293, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 23);
            this.label7.TabIndex = 83;
            this.label7.Text = "تعداد کالا:";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(464, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 23);
            this.label12.TabIndex = 81;
            this.label12.Text = "نام کالا:";
            // 
            // gheimatbatakhfiftxt
            // 
            this.gheimatbatakhfiftxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatbatakhfiftxt.Location = new System.Drawing.Point(21, 16);
            this.gheimatbatakhfiftxt.Name = "gheimatbatakhfiftxt";
            this.gheimatbatakhfiftxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatbatakhfiftxt.Size = new System.Drawing.Size(117, 20);
            this.gheimatbatakhfiftxt.TabIndex = 21;
            this.gheimatbatakhfiftxt.Text = "0";
            this.gheimatbatakhfiftxt.TextChanged += new System.EventHandler(this.gheimatbatakhfiftxt_TextChanged);
            this.gheimatbatakhfiftxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatbatakhfiftxt_KeyDown);
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(221, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(86, 23);
            this.label30.TabIndex = 105;
            this.label30.Text = "قیمت به احتساب";
            // 
            // kerayehamltxt
            // 
            this.kerayehamltxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.kerayehamltxt.Location = new System.Drawing.Point(21, 42);
            this.kerayehamltxt.Name = "kerayehamltxt";
            this.kerayehamltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.kerayehamltxt.Size = new System.Drawing.Size(117, 20);
            this.kerayehamltxt.TabIndex = 22;
            this.kerayehamltxt.Text = "0";
            this.kerayehamltxt.TextChanged += new System.EventHandler(this.kerayehamltxt_TextChanged);
            this.kerayehamltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.kerayehamltxt_KeyDown);
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(140, 43);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(66, 23);
            this.label31.TabIndex = 107;
            this.label31.Text = "کرایه حمل:";
            // 
            // dastmozdekargartxt
            // 
            this.dastmozdekargartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dastmozdekargartxt.Location = new System.Drawing.Point(21, 68);
            this.dastmozdekargartxt.Name = "dastmozdekargartxt";
            this.dastmozdekargartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dastmozdekargartxt.Size = new System.Drawing.Size(117, 20);
            this.dastmozdekargartxt.TabIndex = 23;
            this.dastmozdekargartxt.Text = "0";
            this.dastmozdekargartxt.TextChanged += new System.EventHandler(this.dastmozdekargartxt_TextChanged);
            this.dastmozdekargartxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dastmozdekargartxt_KeyDown);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(138, 69);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(92, 23);
            this.label32.TabIndex = 109;
            this.label32.Text = "دستمزد کارگران:";
            // 
            // gheimatekoltxt
            // 
            this.gheimatekoltxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gheimatekoltxt.Location = new System.Drawing.Point(21, 94);
            this.gheimatekoltxt.Name = "gheimatekoltxt";
            this.gheimatekoltxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gheimatekoltxt.Size = new System.Drawing.Size(117, 20);
            this.gheimatekoltxt.TabIndex = 24;
            this.gheimatekoltxt.Text = "0";
            this.gheimatekoltxt.TextChanged += new System.EventHandler(this.gheimatekoltxt_TextChanged);
            this.gheimatekoltxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gheimatekoltxt_KeyDown);
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(133, 95);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 23);
            this.label33.TabIndex = 111;
            this.label33.Text = "قیمت کل:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.lbldarsad);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.gheimatekoltxt);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.dastmozdekargartxt);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.kerayehamltxt);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.gheimatbatakhfiftxt);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Location = new System.Drawing.Point(24, 390);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox5.Size = new System.Drawing.Size(310, 125);
            this.groupBox5.TabIndex = 112;
            this.groupBox5.TabStop = false;
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(5, 98);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(16, 23);
            this.label42.TabIndex = 117;
            this.label42.Text = "*";
            // 
            // lbldarsad
            // 
            this.lbldarsad.Location = new System.Drawing.Point(195, 15);
            this.lbldarsad.Name = "lbldarsad";
            this.lbldarsad.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbldarsad.Size = new System.Drawing.Size(29, 19);
            this.lbldarsad.TabIndex = 113;
            this.lbldarsad.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(147, 17);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(52, 23);
            this.label41.TabIndex = 112;
            this.label41.Text = "٪ تخفیف:";
            // 
            // tarikhebargashtekalamtxt
            // 
            this.tarikhebargashtekalamtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhebargashtekalamtxt.Location = new System.Drawing.Point(24, 23);
            this.tarikhebargashtekalamtxt.Mask = "9999/99/99";
            this.tarikhebargashtekalamtxt.Name = "tarikhebargashtekalamtxt";
            this.tarikhebargashtekalamtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhebargashtekalamtxt.Size = new System.Drawing.Size(109, 20);
            this.tarikhebargashtekalamtxt.TabIndex = 25;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(8, 27);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(16, 23);
            this.label34.TabIndex = 172;
            this.label34.Text = "*";
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(129, 25);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(105, 23);
            this.label35.TabIndex = 171;
            this.label35.Text = "تاریخ برگشت کالاها:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.darsadetakhfiftxt);
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.nameranandetxt);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.tarikhebargashtekalamtxt);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Location = new System.Drawing.Point(340, 390);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox6.Size = new System.Drawing.Size(240, 125);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            // 
            // darsadetakhfiftxt
            // 
            this.darsadetakhfiftxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.darsadetakhfiftxt.Location = new System.Drawing.Point(24, 89);
            this.darsadetakhfiftxt.Name = "darsadetakhfiftxt";
            this.darsadetakhfiftxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.darsadetakhfiftxt.Size = new System.Drawing.Size(109, 20);
            this.darsadetakhfiftxt.TabIndex = 174;
            this.darsadetakhfiftxt.Text = "0";
            this.darsadetakhfiftxt.TextChanged += new System.EventHandler(this.darsadetakhfiftxt_TextChanged);
            this.darsadetakhfiftxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.darsadetakhfiftxt_KeyDown);
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(131, 91);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 23);
            this.label40.TabIndex = 175;
            this.label40.Text = "درصد تخفیف:";
            // 
            // nameranandetxt
            // 
            this.nameranandetxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameranandetxt.Location = new System.Drawing.Point(24, 56);
            this.nameranandetxt.Name = "nameranandetxt";
            this.nameranandetxt.Size = new System.Drawing.Size(109, 20);
            this.nameranandetxt.TabIndex = 26;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(129, 58);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 23);
            this.label24.TabIndex = 173;
            this.label24.Text = "نام راننده:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label43);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.label38);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Controls.Add(this.label36);
            this.groupBox7.Controls.Add(this.pardakhtehavalebtn);
            this.groupBox7.Controls.Add(this.pardakhecheckbtn);
            this.groupBox7.Controls.Add(this.pardakheghestybtn);
            this.groupBox7.Controls.Add(this.pardakhenaghdybtn);
            this.groupBox7.Controls.Add(this.idhavaletxt);
            this.groupBox7.Controls.Add(this.idchecktxt);
            this.groupBox7.Controls.Add(this.idghestytxt);
            this.groupBox7.Controls.Add(this.idnaghdytxt);
            this.groupBox7.Controls.Add(this.havalechb);
            this.groupBox7.Controls.Add(this.checkchb);
            this.groupBox7.Controls.Add(this.ghestychb);
            this.groupBox7.Controls.Add(this.naghdchb);
            this.groupBox7.Location = new System.Drawing.Point(24, 515);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox7.Size = new System.Drawing.Size(555, 161);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "پرداخت هزینه";
            // 
            // label43
            // 
            this.label43.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(213, 36);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(16, 23);
            this.label43.TabIndex = 123;
            this.label43.Text = "*";
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(288, 128);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(52, 18);
            this.label39.TabIndex = 122;
            this.label39.Text = "کد حواله:";
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(287, 97);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(48, 18);
            this.label38.TabIndex = 121;
            this.label38.Text = "کد چک:";
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(287, 65);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(66, 18);
            this.label37.TabIndex = 120;
            this.label37.Text = "کد قسطی:";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(287, 34);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(57, 18);
            this.label36.TabIndex = 119;
            this.label36.Text = "کد نقدی:";
            // 
            // pardakhtehavalebtn
            // 
            this.pardakhtehavalebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pardakhtehavalebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pardakhtehavalebtn.Location = new System.Drawing.Point(21, 122);
            this.pardakhtehavalebtn.Name = "pardakhtehavalebtn";
            this.pardakhtehavalebtn.Size = new System.Drawing.Size(107, 24);
            this.pardakhtehavalebtn.TabIndex = 38;
            this.pardakhtehavalebtn.Text = "پرداخت حواله";
            this.pardakhtehavalebtn.UseVisualStyleBackColor = true;
            this.pardakhtehavalebtn.Click += new System.EventHandler(this.pardakhtehavalebtn_Click);
            // 
            // pardakhecheckbtn
            // 
            this.pardakhecheckbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pardakhecheckbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pardakhecheckbtn.Location = new System.Drawing.Point(21, 91);
            this.pardakhecheckbtn.Name = "pardakhecheckbtn";
            this.pardakhecheckbtn.Size = new System.Drawing.Size(107, 24);
            this.pardakhecheckbtn.TabIndex = 35;
            this.pardakhecheckbtn.Text = "پرداخت چک";
            this.pardakhecheckbtn.UseVisualStyleBackColor = true;
            this.pardakhecheckbtn.Click += new System.EventHandler(this.pardakhecheckbtn_Click);
            // 
            // pardakheghestybtn
            // 
            this.pardakheghestybtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pardakheghestybtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pardakheghestybtn.Location = new System.Drawing.Point(21, 59);
            this.pardakheghestybtn.Name = "pardakheghestybtn";
            this.pardakheghestybtn.Size = new System.Drawing.Size(107, 24);
            this.pardakheghestybtn.TabIndex = 32;
            this.pardakheghestybtn.Text = "پرداخت قسطی";
            this.pardakheghestybtn.UseVisualStyleBackColor = true;
            this.pardakheghestybtn.Click += new System.EventHandler(this.pardakheghestybtn_Click);
            // 
            // pardakhenaghdybtn
            // 
            this.pardakhenaghdybtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pardakhenaghdybtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pardakhenaghdybtn.Location = new System.Drawing.Point(21, 28);
            this.pardakhenaghdybtn.Name = "pardakhenaghdybtn";
            this.pardakhenaghdybtn.Size = new System.Drawing.Size(107, 24);
            this.pardakhenaghdybtn.TabIndex = 29;
            this.pardakhenaghdybtn.Text = "پرداخت نقدی";
            this.pardakhenaghdybtn.UseVisualStyleBackColor = true;
            this.pardakhenaghdybtn.Click += new System.EventHandler(this.pardakhenaghdybtn_Click);
            // 
            // idhavaletxt
            // 
            this.idhavaletxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhavaletxt.Location = new System.Drawing.Point(231, 126);
            this.idhavaletxt.Name = "idhavaletxt";
            this.idhavaletxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhavaletxt.Size = new System.Drawing.Size(53, 20);
            this.idhavaletxt.TabIndex = 37;
            this.idhavaletxt.Text = "0";
            this.idhavaletxt.TextChanged += new System.EventHandler(this.idhavaletxt_TextChanged);
            this.idhavaletxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idhavaletxt_KeyDown);
            // 
            // idchecktxt
            // 
            this.idchecktxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idchecktxt.Location = new System.Drawing.Point(231, 95);
            this.idchecktxt.Name = "idchecktxt";
            this.idchecktxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idchecktxt.Size = new System.Drawing.Size(53, 20);
            this.idchecktxt.TabIndex = 34;
            this.idchecktxt.Text = "0";
            this.idchecktxt.TextChanged += new System.EventHandler(this.idchecktxt_TextChanged);
            this.idchecktxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idchecktxt_KeyDown);
            // 
            // idghestytxt
            // 
            this.idghestytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idghestytxt.Location = new System.Drawing.Point(231, 63);
            this.idghestytxt.Name = "idghestytxt";
            this.idghestytxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idghestytxt.Size = new System.Drawing.Size(53, 20);
            this.idghestytxt.TabIndex = 31;
            this.idghestytxt.Text = "0";
            this.idghestytxt.TextChanged += new System.EventHandler(this.idghestytxt_TextChanged);
            this.idghestytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idghestytxt_KeyDown);
            // 
            // idnaghdytxt
            // 
            this.idnaghdytxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnaghdytxt.Location = new System.Drawing.Point(231, 32);
            this.idnaghdytxt.Name = "idnaghdytxt";
            this.idnaghdytxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnaghdytxt.Size = new System.Drawing.Size(53, 20);
            this.idnaghdytxt.TabIndex = 28;
            this.idnaghdytxt.Text = "0";
            this.idnaghdytxt.TextChanged += new System.EventHandler(this.idnaghdytxt_TextChanged);
            this.idnaghdytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idnaghdytxt_KeyDown);
            // 
            // havalechb
            // 
            this.havalechb.AutoSize = true;
            this.havalechb.Location = new System.Drawing.Point(458, 127);
            this.havalechb.Name = "havalechb";
            this.havalechb.Size = new System.Drawing.Size(50, 17);
            this.havalechb.TabIndex = 36;
            this.havalechb.Text = "حواله";
            this.havalechb.UseVisualStyleBackColor = true;
            this.havalechb.CheckedChanged += new System.EventHandler(this.havalechb_CheckedChanged);
            // 
            // checkchb
            // 
            this.checkchb.AutoSize = true;
            this.checkchb.Location = new System.Drawing.Point(464, 96);
            this.checkchb.Name = "checkchb";
            this.checkchb.Size = new System.Drawing.Size(44, 17);
            this.checkchb.TabIndex = 33;
            this.checkchb.Text = "چک";
            this.checkchb.UseVisualStyleBackColor = true;
            this.checkchb.CheckedChanged += new System.EventHandler(this.checkchb_CheckedChanged);
            // 
            // ghestychb
            // 
            this.ghestychb.AutoSize = true;
            this.ghestychb.Location = new System.Drawing.Point(446, 64);
            this.ghestychb.Name = "ghestychb";
            this.ghestychb.Size = new System.Drawing.Size(62, 17);
            this.ghestychb.TabIndex = 30;
            this.ghestychb.Text = "قسطی";
            this.ghestychb.UseVisualStyleBackColor = true;
            this.ghestychb.CheckedChanged += new System.EventHandler(this.ghestychb_CheckedChanged);
            // 
            // naghdchb
            // 
            this.naghdchb.AutoSize = true;
            this.naghdchb.Location = new System.Drawing.Point(468, 33);
            this.naghdchb.Name = "naghdchb";
            this.naghdchb.Size = new System.Drawing.Size(41, 17);
            this.naghdchb.TabIndex = 27;
            this.naghdchb.Text = "نقد";
            this.naghdchb.UseVisualStyleBackColor = true;
            this.naghdchb.CheckedChanged += new System.EventHandler(this.naghdchb_CheckedChanged);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(149, 693);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 3;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(386, 693);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 1;
            this.sabtbtn.Text = "F2  ثبت";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // pishnamayeshbtn
            // 
            this.pishnamayeshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pishnamayeshbtn.Image = global::main1.Properties.Resources.print_16x16;
            this.pishnamayeshbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pishnamayeshbtn.Location = new System.Drawing.Point(248, 693);
            this.pishnamayeshbtn.Name = "pishnamayeshbtn";
            this.pishnamayeshbtn.Size = new System.Drawing.Size(129, 28);
            this.pishnamayeshbtn.TabIndex = 2;
            this.pishnamayeshbtn.Text = "پیش نمایش";
            this.pishnamayeshbtn.UseVisualStyleBackColor = true;
            // 
            // frmAddFactorKeraye
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(605, 736);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pishnamayeshbtn);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddFactorKeraye";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم فاکتور کرایه";
            this.Load += new System.EventHandler(this.frmFactorKeraye_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala4nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala3nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala2nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tedadkala1nud)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pishnamayeshbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox tarikhmtxt;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox idfactortxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox idkerayetxt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idmoshtaritxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox idnoemoshtaritxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox idsanadtxt;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox namemoshtaricmb;
        private System.Windows.Forms.ComboBox noemoshtaricmb;
        private System.Windows.Forms.ComboBox namekala4cmb;
        private System.Windows.Forms.TextBox gheimatkala4txt;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown tedadkala4nud;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox namekala3cmb;
        private System.Windows.Forms.TextBox gheimatkala3txt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown tedadkala3nud;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox namekala2cmb;
        private System.Windows.Forms.TextBox gheimatkala2txt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown tedadkala2nud;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox namekala1cmb;
        private System.Windows.Forms.TextBox gheimatkala1txt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown tedadkala1nud;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox gheimatbatakhfiftxt;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox kerayehamltxt;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox dastmozdekargartxt;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox gheimatekoltxt;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.MaskedTextBox tarikhebargashtekalamtxt;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox nameranandetxt;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button pardakhtehavalebtn;
        private System.Windows.Forms.Button pardakhecheckbtn;
        private System.Windows.Forms.Button pardakheghestybtn;
        private System.Windows.Forms.Button pardakhenaghdybtn;
        private System.Windows.Forms.TextBox idhavaletxt;
        private System.Windows.Forms.TextBox idchecktxt;
        private System.Windows.Forms.TextBox idghestytxt;
        private System.Windows.Forms.TextBox idnaghdytxt;
        private System.Windows.Forms.CheckBox havalechb;
        private System.Windows.Forms.CheckBox checkchb;
        private System.Windows.Forms.CheckBox ghestychb;
        private System.Windows.Forms.CheckBox naghdchb;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Label lbldarsad;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox darsadetakhfiftxt;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
    }
}
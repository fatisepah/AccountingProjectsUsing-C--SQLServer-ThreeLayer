﻿namespace main1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.namenoesanadtxt = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.idnoesanadtxt = new System.Windows.Forms.TextBox();
            this.idsanadtxt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tarikhesanadmtxt = new System.Windows.Forms.MaskedTextBox();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.noehesabbedehkarcmb = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.mbedehkarimtxt = new System.Windows.Forms.MaskedTextBox();
            this.namehesabbedehkarcmb = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idhesabbedehkartxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.sharhesanadtxt = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.noehesabbestankarcmb = new System.Windows.Forms.ComboBox();
            this.namehesabbestankarcmb = new System.Windows.Forms.ComboBox();
            this.idhesabbestankartxt = new System.Windows.Forms.TextBox();
            this.mbestankarmtxt = new System.Windows.Forms.MaskedTextBox();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(666, 275);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.Location = new System.Drawing.Point(14, 108);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(633, 117);
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 15;
            this.lineShape1.X2 = 646;
            this.lineShape1.Y1 = 134;
            this.lineShape1.Y2 = 134;
            // 
            // namenoesanadtxt
            // 
            this.namenoesanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namenoesanadtxt.Location = new System.Drawing.Point(433, 45);
            this.namenoesanadtxt.Name = "namenoesanadtxt";
            this.namenoesanadtxt.Size = new System.Drawing.Size(117, 20);
            this.namenoesanadtxt.TabIndex = 77;
            this.namenoesanadtxt.Text = "اسناد حسابداری مالی";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(416, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 15);
            this.label14.TabIndex = 84;
            this.label14.Text = "*";
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(416, 72);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(16, 15);
            this.label29.TabIndex = 80;
            this.label29.Text = "*";
            // 
            // idnoesanadtxt
            // 
            this.idnoesanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoesanadtxt.Location = new System.Drawing.Point(433, 22);
            this.idnoesanadtxt.Name = "idnoesanadtxt";
            this.idnoesanadtxt.ReadOnly = true;
            this.idnoesanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoesanadtxt.Size = new System.Drawing.Size(117, 20);
            this.idnoesanadtxt.TabIndex = 76;
            this.idnoesanadtxt.Text = "2";
            // 
            // idsanadtxt
            // 
            this.idsanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idsanadtxt.Location = new System.Drawing.Point(433, 68);
            this.idsanadtxt.Name = "idsanadtxt";
            this.idsanadtxt.ReadOnly = true;
            this.idsanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idsanadtxt.Size = new System.Drawing.Size(117, 20);
            this.idsanadtxt.TabIndex = 78;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(416, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 16);
            this.label15.TabIndex = 83;
            this.label15.Text = "*";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(558, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 23);
            this.label19.TabIndex = 79;
            this.label19.Text = ":کد سند";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(557, 47);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 23);
            this.label20.TabIndex = 82;
            this.label20.Text = ":نام نوع سند";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(558, 25);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 23);
            this.label21.TabIndex = 81;
            this.label21.Text = ":کد نوع سند";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(39, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 16);
            this.label6.TabIndex = 87;
            this.label6.Text = "*";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(180, 28);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 23);
            this.label23.TabIndex = 88;
            this.label23.Text = ":نام کاربر";
            // 
            // tarikhesanadmtxt
            // 
            this.tarikhesanadmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhesanadmtxt.Location = new System.Drawing.Point(56, 54);
            this.tarikhesanadmtxt.Name = "tarikhesanadmtxt";
            this.tarikhesanadmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesanadmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhesanadmtxt.TabIndex = 85;
            // 
            // lblkarbar
            // 
            this.lblkarbar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblkarbar.Location = new System.Drawing.Point(56, 26);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(116, 23);
            this.lblkarbar.TabIndex = 89;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(178, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 23);
            this.label17.TabIndex = 86;
            this.label17.Text = ":تاریخ سند";
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 15;
            this.lineShape2.X2 = 646;
            this.lineShape2.Y1 = 157;
            this.lineShape2.Y2 = 157;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 15;
            this.lineShape3.X2 = 646;
            this.lineShape3.Y1 = 180;
            this.lineShape3.Y2 = 180;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 531;
            this.lineShape4.X2 = 531;
            this.lineShape4.Y1 = 109;
            this.lineShape4.Y2 = 225;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 460;
            this.lineShape5.X2 = 460;
            this.lineShape5.Y1 = 109;
            this.lineShape5.Y2 = 180;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 146;
            this.lineShape6.X2 = 146;
            this.lineShape6.Y1 = 109;
            this.lineShape6.Y2 = 180;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 361;
            this.lineShape7.X2 = 361;
            this.lineShape7.Y1 = 109;
            this.lineShape7.Y2 = 179;
            // 
            // noehesabbedehkarcmb
            // 
            this.noehesabbedehkarcmb.FormattingEnabled = true;
            this.noehesabbedehkarcmb.Items.AddRange(new object[] {
            "دارایی",
            "بدهی",
            "سرمایه"});
            this.noehesabbedehkarcmb.Location = new System.Drawing.Point(363, 136);
            this.noehesabbedehkarcmb.Name = "noehesabbedehkarcmb";
            this.noehesabbedehkarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.noehesabbedehkarcmb.Size = new System.Drawing.Size(97, 21);
            this.noehesabbedehkarcmb.TabIndex = 91;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Location = new System.Drawing.Point(384, 113);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 99;
            this.label10.Text = "نوع حساب";
            // 
            // mbedehkarimtxt
            // 
            this.mbedehkarimtxt.Location = new System.Drawing.Point(16, 136);
            this.mbedehkarimtxt.Name = "mbedehkarimtxt";
            this.mbedehkarimtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mbedehkarimtxt.Size = new System.Drawing.Size(130, 20);
            this.mbedehkarimtxt.TabIndex = 93;
            // 
            // namehesabbedehkarcmb
            // 
            this.namehesabbedehkarcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namehesabbedehkarcmb.FormattingEnabled = true;
            this.namehesabbedehkarcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namehesabbedehkarcmb.Location = new System.Drawing.Point(147, 136);
            this.namehesabbedehkarcmb.Name = "namehesabbedehkarcmb";
            this.namehesabbedehkarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namehesabbedehkarcmb.Size = new System.Drawing.Size(214, 21);
            this.namehesabbedehkarcmb.TabIndex = 92;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(51, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 16);
            this.label5.TabIndex = 98;
            this.label5.Text = "*";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(67, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 19);
            this.label7.TabIndex = 97;
            this.label7.Text = "مبلغ";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(463, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 11);
            this.label1.TabIndex = 96;
            this.label1.Text = "*";
            // 
            // idhesabbedehkartxt
            // 
            this.idhesabbedehkartxt.Location = new System.Drawing.Point(462, 136);
            this.idhesabbedehkartxt.Name = "idhesabbedehkartxt";
            this.idhesabbedehkartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabbedehkartxt.Size = new System.Drawing.Size(69, 20);
            this.idhesabbedehkartxt.TabIndex = 90;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(224, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 95;
            this.label3.Text = "نام حساب";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(478, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 94;
            this.label4.Text = "کد حساب";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(548, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.TabIndex = 100;
            this.label2.Text = "حساب بدهکار";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(546, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 20);
            this.label8.TabIndex = 101;
            this.label8.Text = "حساب بستانکار";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(534, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 13);
            this.label16.TabIndex = 103;
            this.label16.Text = "*";
            // 
            // sharhesanadtxt
            // 
            this.sharhesanadtxt.Location = new System.Drawing.Point(17, 182);
            this.sharhesanadtxt.Multiline = true;
            this.sharhesanadtxt.Name = "sharhesanadtxt";
            this.sharhesanadtxt.Size = new System.Drawing.Size(514, 42);
            this.sharhesanadtxt.TabIndex = 104;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label18.Location = new System.Drawing.Point(548, 193);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 23);
            this.label18.TabIndex = 102;
            this.label18.Text = "شرح سند";
            // 
            // noehesabbestankarcmb
            // 
            this.noehesabbestankarcmb.FormattingEnabled = true;
            this.noehesabbestankarcmb.Items.AddRange(new object[] {
            "دارایی",
            "بدهی",
            "سرمایه"});
            this.noehesabbestankarcmb.Location = new System.Drawing.Point(362, 158);
            this.noehesabbestankarcmb.Name = "noehesabbestankarcmb";
            this.noehesabbestankarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.noehesabbestankarcmb.Size = new System.Drawing.Size(98, 21);
            this.noehesabbestankarcmb.TabIndex = 106;
            // 
            // namehesabbestankarcmb
            // 
            this.namehesabbestankarcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namehesabbestankarcmb.FormattingEnabled = true;
            this.namehesabbestankarcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namehesabbestankarcmb.Location = new System.Drawing.Point(147, 159);
            this.namehesabbestankarcmb.Name = "namehesabbestankarcmb";
            this.namehesabbestankarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namehesabbestankarcmb.Size = new System.Drawing.Size(214, 21);
            this.namehesabbestankarcmb.TabIndex = 107;
            // 
            // idhesabbestankartxt
            // 
            this.idhesabbestankartxt.Location = new System.Drawing.Point(461, 159);
            this.idhesabbestankartxt.Name = "idhesabbestankartxt";
            this.idhesabbestankartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabbestankartxt.Size = new System.Drawing.Size(70, 20);
            this.idhesabbestankartxt.TabIndex = 105;
            // 
            // mbestankarmtxt
            // 
            this.mbestankarmtxt.Location = new System.Drawing.Point(15, 159);
            this.mbestankarmtxt.Name = "mbestankarmtxt";
            this.mbestankarmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mbestankarmtxt.Size = new System.Drawing.Size(130, 20);
            this.mbestankarmtxt.TabIndex = 108;
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = ((System.Drawing.Image)(resources.GetObject("sabtbtn.Image")));
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(116, 235);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(83, 28);
            this.sabtbtn.TabIndex = 109;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.exit1;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(14, 235);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(96, 28);
            this.enserafbtn.TabIndex = 110;
            this.enserafbtn.Text = "ESC انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(666, 275);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.noehesabbestankarcmb);
            this.Controls.Add(this.namehesabbestankarcmb);
            this.Controls.Add(this.idhesabbestankartxt);
            this.Controls.Add(this.mbestankarmtxt);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.sharhesanadtxt);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.noehesabbedehkarcmb);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.mbedehkarimtxt);
            this.Controls.Add(this.namehesabbedehkarcmb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.idhesabbedehkartxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.tarikhesanadmtxt);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.namenoesanadtxt);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.idnoesanadtxt);
            this.Controls.Add(this.idsanadtxt);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.TextBox namenoesanadtxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox idnoesanadtxt;
        private System.Windows.Forms.TextBox idsanadtxt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.MaskedTextBox tarikhesanadmtxt;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.Label label17;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private System.Windows.Forms.ComboBox noehesabbedehkarcmb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MaskedTextBox mbedehkarimtxt;
        private System.Windows.Forms.ComboBox namehesabbedehkarcmb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox idhesabbedehkartxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox sharhesanadtxt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox noehesabbestankarcmb;
        private System.Windows.Forms.ComboBox namehesabbestankarcmb;
        private System.Windows.Forms.TextBox idhesabbestankartxt;
        private System.Windows.Forms.MaskedTextBox mbestankarmtxt;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.Button enserafbtn;
    }
}
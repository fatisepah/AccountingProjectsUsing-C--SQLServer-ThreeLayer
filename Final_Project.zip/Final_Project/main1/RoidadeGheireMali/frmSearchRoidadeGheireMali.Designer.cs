﻿namespace main1.RoidadeGheireMali
{
    partial class frmSearchRoidadeGheireMali
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSearchRoidadeGheireMali));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.sharheroidadtxt = new System.Windows.Forms.TextBox();
            this.sharhch = new System.Windows.Forms.CheckBox();
            this.tarikh2mtxt = new System.Windows.Forms.MaskedTextBox();
            this.tarikhch = new System.Windows.Forms.CheckBox();
            this.tarikh1mtxt = new System.Windows.Forms.MaskedTextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.printbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.بالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پایینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جستجوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchbtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.sharheroidadtxt);
            this.groupBox1.Controls.Add(this.sharhch);
            this.groupBox1.Controls.Add(this.tarikh2mtxt);
            this.groupBox1.Controls.Add(this.tarikhch);
            this.groupBox1.Controls.Add(this.tarikh1mtxt);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(13, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(487, 106);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "جستجو";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(147, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 23);
            this.label2.TabIndex = 99;
            this.label2.Text = "تا  تاریخ:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(280, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 23);
            this.label4.TabIndex = 98;
            this.label4.Text = "از تاریخ:";
            // 
            // sharheroidadtxt
            // 
            this.sharheroidadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sharheroidadtxt.Location = new System.Drawing.Point(65, 63);
            this.sharheroidadtxt.Multiline = true;
            this.sharheroidadtxt.Name = "sharheroidadtxt";
            this.sharheroidadtxt.Size = new System.Drawing.Size(251, 20);
            this.sharheroidadtxt.TabIndex = 5;
            this.sharheroidadtxt.TextChanged += new System.EventHandler(this.sharheroidadtxt_TextChanged);
            this.sharheroidadtxt.Enter += new System.EventHandler(this.sharheroidadtxt_Enter);
            // 
            // sharhch
            // 
            this.sharhch.AutoSize = true;
            this.sharhch.Location = new System.Drawing.Point(329, 63);
            this.sharhch.Name = "sharhch";
            this.sharhch.Size = new System.Drawing.Size(118, 17);
            this.sharhch.TabIndex = 4;
            this.sharhch.Text = "براساس شرح سند:";
            this.sharhch.UseVisualStyleBackColor = true;
            this.sharhch.CheckedChanged += new System.EventHandler(this.sharhch_CheckedChanged);
            // 
            // tarikh2mtxt
            // 
            this.tarikh2mtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikh2mtxt.Location = new System.Drawing.Point(65, 31);
            this.tarikh2mtxt.Mask = "9999/99/99";
            this.tarikh2mtxt.Name = "tarikh2mtxt";
            this.tarikh2mtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikh2mtxt.Size = new System.Drawing.Size(79, 20);
            this.tarikh2mtxt.TabIndex = 3;
            this.tarikh2mtxt.Enter += new System.EventHandler(this.tarikh2mtxt_Enter);
            // 
            // tarikhch
            // 
            this.tarikhch.AutoSize = true;
            this.tarikhch.Location = new System.Drawing.Point(326, 32);
            this.tarikhch.Name = "tarikhch";
            this.tarikhch.Size = new System.Drawing.Size(121, 17);
            this.tarikhch.TabIndex = 1;
            this.tarikhch.Text = "براساس تاریخ رویداد:";
            this.tarikhch.UseVisualStyleBackColor = true;
            this.tarikhch.CheckedChanged += new System.EventHandler(this.tarikhch_CheckedChanged);
            // 
            // tarikh1mtxt
            // 
            this.tarikh1mtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikh1mtxt.Location = new System.Drawing.Point(198, 31);
            this.tarikh1mtxt.Mask = "9999/99/99";
            this.tarikh1mtxt.Name = "tarikh1mtxt";
            this.tarikh1mtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikh1mtxt.Size = new System.Drawing.Size(79, 20);
            this.tarikh1mtxt.TabIndex = 2;
            this.tarikh1mtxt.Enter += new System.EventHandler(this.tarikh1mtxt_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 133);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(487, 202);
            this.dataGridView1.TabIndex = 49;
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(116, 354);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(90, 28);
            this.enserafbtn.TabIndex = 8;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // printbtn
            // 
            this.printbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printbtn.Image = ((System.Drawing.Image)(resources.GetObject("printbtn.Image")));
            this.printbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printbtn.Location = new System.Drawing.Point(212, 354);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(85, 28);
            this.printbtn.TabIndex = 7;
            this.printbtn.Text = "F7  چاپ";
            this.printbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.printbtn.UseVisualStyleBackColor = true;
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.انصرافToolStripMenuItem,
            this.بالاToolStripMenuItem,
            this.پایینToolStripMenuItem,
            this.جستجوToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 52;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.چاپToolStripMenuItem.Text = "چاپ";
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // بالاToolStripMenuItem
            // 
            this.بالاToolStripMenuItem.Name = "بالاToolStripMenuItem";
            this.بالاToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.Tab)));
            this.بالاToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
            this.بالاToolStripMenuItem.Text = "بالا";
            this.بالاToolStripMenuItem.Click += new System.EventHandler(this.بالاToolStripMenuItem_Click_1);
            // 
            // پایینToolStripMenuItem
            // 
            this.پایینToolStripMenuItem.Name = "پایینToolStripMenuItem";
            this.پایینToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.پایینToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.پایینToolStripMenuItem.Text = "پایین";
            this.پایینToolStripMenuItem.Click += new System.EventHandler(this.پایینToolStripMenuItem_Click_1);
            // 
            // جستجوToolStripMenuItem
            // 
            this.جستجوToolStripMenuItem.Name = "جستجوToolStripMenuItem";
            this.جستجوToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.جستجوToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.جستجوToolStripMenuItem.Text = "جستجو";
            // 
            // searchbtn
            // 
            this.searchbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.searchbtn.Image = global::main1.Properties.Resources.ButtonSearch;
            this.searchbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.searchbtn.Location = new System.Drawing.Point(303, 354);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(90, 28);
            this.searchbtn.TabIndex = 6;
            this.searchbtn.Text = "F5 جستجو";
            this.searchbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchbtn.UseVisualStyleBackColor = true;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // frmSearchRoidadeGheireMali
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 394);
            this.Controls.Add(this.searchbtn);
            this.Controls.Add(this.printbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmSearchRoidadeGheireMali";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم جستجوی اسناد غیر مالی";
            this.Load += new System.EventHandler(this.frmSearchRoidadeGheireMali_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox tarikh1mtxt;
        private System.Windows.Forms.CheckBox sharhch;
        private System.Windows.Forms.MaskedTextBox tarikh2mtxt;
        private System.Windows.Forms.CheckBox tarikhch;
        private System.Windows.Forms.TextBox sharheroidadtxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.Button printbtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem بالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پایینToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جستجوToolStripMenuItem;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;

namespace main1.RoidadeGheireMali
{
    public partial class frmSearchRoidadeGheireMali : Form
    {
        public frmSearchRoidadeGheireMali()
        {
            InitializeComponent();
        }
        RoidadeGheireMaliData obj = new RoidadeGheireMaliData();
        RoidadeGheireMaliDB DBR = new RoidadeGheireMaliDB();
        RoidadeGheireMaliData bd=new RoidadeGheireMaliData ();
        FilterData1 FData = new FilterData1();
        FilterRoidadeGheireMaliData FData1 = new FilterRoidadeGheireMaliData();
        
        private void sharheroidadtxt_TextChanged(object sender, EventArgs e)
        {
          string SharheRoidad = sharheroidadtxt.Text.Replace("ی", "ي");
          try
          {
              //براساس شرح سند

              dataGridView1.DataSource = FData1.Filter1(SharheRoidad);
              if (dataGridView1.RowCount.ToString() == "0")
              {
                  printbtn.Enabled = false;
              }
              else
              {
                  printbtn.Enabled = true;
              }

          }
          catch
          {
              MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
              sharheroidadtxt.Text = "";
              sharheroidadtxt.Focus();
              sharheroidadtxt.SelectAll();
          }

        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد سند ";
            dataGridView1.Columns[1].HeaderText = "کد نوع سند";
            dataGridView1.Columns[2].HeaderText = "نام کاربر";
            dataGridView1.Columns[3].HeaderText = "تاریخ سند";
            dataGridView1.Columns[4].HeaderText = "شرح سند";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width =55;
            dataGridView1.Columns[2].Width =95;
            dataGridView1.Columns[3].Width =70;
            dataGridView1.Columns[4].Width = 157;

        }
        private void frmSearchRoidadeGheireMali_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource= true;
            dataGridView1.DataSource = FData1.RoidadeGheireMaliShow1();
            set_datagrid();

            sharheroidadtxt.Enabled = false;
            tarikh1mtxt.Enabled = false;
            tarikh2mtxt.Enabled = false;
      
           
        }
        private void بالاToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }
        private void set_color()
        {
            tarikh1mtxt .BackColor = Color.White;
            tarikh2mtxt.BackColor = Color.White;
            sharheroidadtxt.BackColor = Color.White;

        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tarikh1mtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikh1mtxt.BackColor = Color.FromArgb(255, 255, 192);

        }

        private void tarikh2mtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikh2mtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void sharheroidadtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            sharheroidadtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tarikhch_CheckedChanged(object sender, EventArgs e)
        {

            if (tarikhch.Checked == true)
            {
                tarikh1mtxt.Enabled = true;
                tarikh2mtxt.Enabled = true;
                tarikh1mtxt.Focus();
            }
            else
            {
                tarikh1mtxt.Enabled = false;
                tarikh2mtxt.Enabled = false;
            }
          
        }

        private void sharhch_CheckedChanged(object sender, EventArgs e)
        {
            if (sharhch.Checked == true)
            {
                sharheroidadtxt.Enabled = true;
                sharheroidadtxt.Focus();
            }
            else
                sharheroidadtxt.Enabled = false;

        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            if ((sharhch.Checked == true) && (tarikhch.Checked == true))
            {

            }
            if ((sharhch.Checked == true) && (tarikhch.Checked == false))
            {
                string SharheRoidad = sharheroidadtxt.Text.Replace("ی", "ي");
                try
                {
                    //براساس شرح سند

                    dataGridView1.DataSource = FData.FilterNameHesabKol1(SharheRoidad);
                    if (dataGridView1.RowCount.ToString() == "0")
                    {
                        printbtn.Enabled = false;
                    }
                    else
                    {
                        printbtn.Enabled = true;
                    }

                }
                catch
                {
                    MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                    sharheroidadtxt.Text = "";
                    sharheroidadtxt.Focus();
                    sharheroidadtxt.SelectAll();
                }
            }
            if ((sharhch.Checked == false) && (tarikhch.Checked == true))
            {
                string s1, s2;
                int i1, i2, i3;
                s1 = tarikh1mtxt.Text;
                s1 = s1.Replace("/", "");
                s2 = tarikh2mtxt.Text;
                s2 = s2.Replace("/", "");
                i1 = Convert.ToInt32(s1);
                i2 = Convert.ToInt32(s2);
                //////////برای جستجوی سطر به سطر در گرید ویو
                DataTable dt = obj.RoidadeGheireMaliSearchTarikh1();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string TarikheRoidad =dt.Rows[i][3].ToString();
                    string s = TarikheRoidad.Substring (0,9);
                    s = s.Replace("/", "");
                    i3 = Convert.ToInt32(s);
                    if (i3 < i2 && i3 > i1)
                    {
                        dataGridView1.DataSource = dt.Rows [i];
                    }
                }

            }
            if ((sharhch.Checked == false) && (tarikhch.Checked == false))
            {

                dataGridView1.DataSource = FData.RoidadeGheireMaliShow1();
                set_datagrid();

            }
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            frmRoidadeGheireMaliReport obj = new frmRoidadeGheireMaliReport();
            obj.ShowDialog();
        }



    }
}

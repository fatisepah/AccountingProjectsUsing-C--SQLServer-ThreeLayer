﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;


namespace main1.RoidadeGheireMali
{
    public partial class frmRoidadeGheireMali : Form
    {
        public frmRoidadeGheireMali()
        {
            InitializeComponent();
        }
        public int virayesh = 0;
        RoidadeGheireMaliData objRoidad = new RoidadeGheireMaliData();
        RoidadeGheireMaliDB DBR = new RoidadeGheireMaliDB();
        private void sabtbtn_Click(object sender, EventArgs e)
        {

           
            if ( tarikhroidadmtxt.Text !="    /  /" && sharheroidadtxt.Text != "")
            {
                DBR.IDRoidad = Convert.ToInt16(idroidadtxt.Text);
                DBR.FKNoeSanad = Convert.ToInt16("1");
                DBR.NameKarbar = lblkarbar.Text;
                DBR.TarikheRoidad = Convert.ToDateTime(tarikhroidadmtxt.Text);
                DBR.SharheRoidad = sharheroidadtxt.Text;

                    if (!objRoidad.RoidadeGheireMaliSearch1(DBR.IDRoidad))
                     {
                       objRoidad.RoidadeGheireMaliInsert1(DBR);
                       if (MessageBox.Show("ثبت با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                          {
                            idroidadtxt.Text = "";
                            idnoesanadtxt.Text = "";
                            tarikhroidadmtxt.Text = "";
                            sharheroidadtxt.Text = "";
                          }
                     }
                   else
                     {
                       MessageBox.Show("شماره رویداد تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     }
 
                }
            
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void set_color()
        {
            idroidadtxt.BackColor = Color.White;
            idnoesanadtxt.BackColor = Color.White;
            tarikhroidadmtxt.BackColor = Color.White;
            noesanadtxt.BackColor = Color.White;
            sharheroidadtxt.BackColor = Color.White;
        }

        private void idroidadtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idroidadtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikhroidadmtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikhroidadmtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idnoesanadtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idnoesanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void noesanadtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            noesanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void sharheroidadtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            sharheroidadtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            frmSearchRoidadeGheireMali objf = new frmSearchRoidadeGheireMali();
            objf.Show();
        }

        private void ثبتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sabtbtn_Click(objRoidad,e);
        }

        private void جستجوToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSearchRoidadeGheireMali objf = new frmSearchRoidadeGheireMali();
            searchbtn_Click(objf, e);
        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmRoidadeGheireMali_Load(object sender, EventArgs e)
        {
            tarikhroidadmtxt .Text = Class1.TarikheJari + " " + Class1.SaateJari;
            lblkarbar .Text =Class1.NameFamilyKarbar; 
            //برای بدست آوردن بزرگترین کد رویداد ثبت شده و قرار دادن کد جدید در فرم
            int i1 = 0;
            int i2 = 1;
            DataTable dt = objRoidad.RoidadeGheireMaliSearchID1();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                    if (i2 < i1)
                    {
                        i2 = i1;
                    }
                }
                if (dt.Rows.Count == 0)
                {
                    idroidadtxt .Text = "1";
                }
                else
                {
                    idroidadtxt.Text = Convert.ToString(i2 + 1);
                }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }




    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;
using BLL;
using System.Web.UI.WebControls;

namespace main1.SanadeHesabdari
{
    public partial class frmSanadHesabdari : Form
    {
        public frmSanadHesabdari()
        {
            InitializeComponent();
        }
        FilterSanadeHesabdariData SHData1 = new FilterSanadeHesabdariData();
        SanadeHesabdariData SHData = new SanadeHesabdariData();
        SanadeHesabdariDB SHDB = new SanadeHesabdariDB();
        HesabhaData HData = new HesabhaData();
        HesabhaDB HDB = new HesabhaDB();
        //
        //
        //
        private void چاپToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void انصرافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void بالاToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == 0)
                dataGridView1.CurrentCell = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k - 1].Cells[1];
        }

        private void پایینToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int k = dataGridView1.CurrentCell.RowIndex;
            if (k == dataGridView1.RowCount - 1)
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
            else
                dataGridView1.CurrentCell = dataGridView1.Rows[k + 1].Cells[1];
        }
        private void set_datagrid()
        {
            dataGridView1.Columns[0].HeaderText = " کد سند ";
            dataGridView1.Columns[1].HeaderText = "کد دفتر روزنامه";
            dataGridView1.Columns[2].HeaderText = "تاریخ سند";
            dataGridView1.Columns[3].HeaderText = "نام کاربر";
            dataGridView1.Columns[4].HeaderText = "کد حساب بدهکار";
            dataGridView1.Columns[5].HeaderText = "نوع حساب بدهکار";
            dataGridView1.Columns[6].HeaderText = "نام حساب کل بدهکار";
            dataGridView1.Columns[7].HeaderText = "نام حساب معین بدهکار";
            dataGridView1.Columns[8].HeaderText = "نام حساب تفضیلی بدهکار";
            dataGridView1.Columns[9].HeaderText = "مبلغ بدهکاری";
            dataGridView1.Columns[10].HeaderText = "کد حساب بستانکار";
            dataGridView1.Columns[11].HeaderText = "نوع حساب بستانکار";
            dataGridView1.Columns[12].HeaderText = "نام حساب کل بستانکار";
            dataGridView1.Columns[13].HeaderText = "نام حساب معین بستانکار";
            dataGridView1.Columns[14].HeaderText = "نام حساب تفضیلی بستانکار";
            dataGridView1.Columns[15].HeaderText = "مبلغ بستانکاری";
            dataGridView1.Columns[16].HeaderText = "شرح سند";
            dataGridView1.Columns[15].DefaultCellStyle.Format = "0,0";
            dataGridView1.Columns[9].DefaultCellStyle.Format = "0,0";

            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].Width = 50;
            dataGridView1.Columns[2].Width = 100;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 50;
            dataGridView1.Columns[5].Width = 100;
            dataGridView1.Columns[6].Width = 100;
            dataGridView1.Columns[7].Width = 100;
            dataGridView1.Columns[8].Width = 100;
            dataGridView1.Columns[9].Width = 120;
            dataGridView1.Columns[10].Width = 50;
            dataGridView1.Columns[11].Width = 100;
            dataGridView1.Columns[12].Width = 100;
            dataGridView1.Columns[13].Width = 100;
            dataGridView1.Columns[14].Width = 100;
            dataGridView1.Columns[15].Width = 120;
            dataGridView1.Columns[16].Width = 157;

        }

        private void frmSanadHesabdari_Load(object sender, EventArgs e)
        {
            //برای قرار دادن نام حساب ها در کمبو باکس
            HData = new HesabhaData();
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {

                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();

                    ListItem item = new ListItem();
                    item.Text =NameHesabTafzily;
                    item.Value = IDHesab.ToString();

                    namebedehkarcmb.Items.Add(item);
                    namebestankarcmb.Items.Add(item);
                
            }
            namebedehkarcmb.SelectedIndex = 0;
            namebestankarcmb.SelectedIndex = 0;
            //
            //
            //
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = SHData1.SanadeHesabdariShow1();
            set_datagrid();

            bedehkarrbtn.Checked = true;
            idhesabbedehkartxt .Enabled = true ;
            namebedehkarcmb.Enabled = true;
            namebedehkarcmb.Focus();

            sharhesanadtxt.Enabled = false;
            idhesabbestankartxt.Enabled = false;
            namebestankarcmb.Enabled = false;
            tarikh1mtxt.Enabled = false;
            tarikh2mtxt.Enabled = false;
            noehesabcmb.Enabled = false;
        }
        private void set_color()
        {
            tarikh1mtxt.BackColor = Color.White;
            tarikh2mtxt.BackColor = Color.White;
            idhesabbedehkartxt .BackColor = Color.White;
            namebedehkarcmb.BackColor = Color.White;
            idhesabbestankartxt .BackColor = Color.White;
            namebestankarcmb.BackColor = Color.White;
            sharhesanadtxt.BackColor = Color.White;
            noehesabcmb.BackColor = Color.White;
        }

        private void idhesabbedehkartxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idhesabbedehkartxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namebedehkarcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            namebedehkarcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void idhesabbestankartxt_Enter(object sender, EventArgs e)
        {
            set_color();
            idhesabbestankartxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void namebestankarcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            namebestankarcmb.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikh1mtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikh1mtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void tarikh2mtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            tarikh2mtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void sharhesanadtxt_Enter(object sender, EventArgs e)
        {
            set_color();
            sharhesanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        }

        private void darjbtn_Click(object sender, EventArgs e)
        {
            frmAddSanadHesabdari obj = new frmAddSanadHesabdari();
            obj.ShowDialog();
            dataGridView1.DataSource = true;
            dataGridView1.DataSource = SHData.SanadeHesabdariShow1();
            set_datagrid();
        }

        private void noehesabcmb_Enter(object sender, EventArgs e)
        {
            set_color();
            noehesabcmb.BackColor = Color.FromArgb(255, 255, 192);
        }
        private void enserafbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bedehkarrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                idhesabbedehkartxt .Focus();
            }
            if (bedehkarrbtn.Checked == true)
            {
                idhesabbedehkartxt.Enabled = true;
                namebedehkarcmb.Enabled = true;
                label1.Enabled = true;
                namebestankarcmb.Focus();
            }
            else
            {
                idhesabbedehkartxt.Enabled = false;
                namebedehkarcmb.Enabled = false;
                label1.Enabled = false;
            }
        }

        private void bestankarrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[6];
               idhesabbestankartxt .Focus();
            }
            if(bestankarrbtn .Checked ==true )
            {
                idhesabbestankartxt.Enabled = true;
                namebestankarcmb.Enabled = true;
                label2.Enabled = true;
                namebestankarcmb.Focus();
            }
            else 
            {
                idhesabbestankartxt.Enabled = false;
                namebestankarcmb.Enabled = false;
                label2.Enabled = false;
            }
        }

        private void tarikhrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];
                tarikh1mtxt .Focus();
            }
            if(tarikhrbtn .Checked ==true )
            {
                tarikh1mtxt.Enabled = true ;
                tarikh2mtxt.Enabled = true;
                label3.Enabled = true;
                label4.Enabled = true;
                tarikh1mtxt.Focus();
            }
            else 
            {
                tarikh1mtxt.Enabled = false;
                tarikh2mtxt.Enabled = false;
                label3.Enabled = false;
                label4.Enabled = false;
            }
        }

        private void sharhrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[14];
                sharhesanadtxt.Focus();
            }
            if (sharhrbtn.Checked == true)
            {
                sharhesanadtxt.Enabled = true;
                sharhesanadtxt.Focus();
            }
            else
                sharhesanadtxt.Enabled = false;
        }

        private void noehesabrbtn_CheckedChanged(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount.ToString() != "0")
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                noehesabcmb .Focus();
            }
            if (noehesabrbtn.Checked == true)
            {
                noehesabcmb.Enabled = true;
                noehesabcmb.Focus();
            }
            else
                noehesabcmb.Enabled = false;
        }
        int k = 0;
        private void idhesabbedehkartxt_KeyDown(object sender, KeyEventArgs e)
        {
            k = 1;
        }

        private void idhesabbedehkartxt_TextChanged(object sender, EventArgs e)
        {
            if (idhesabbedehkartxt.Text.Length != 0 && k == 1)
            {
                k = 0;
                idhesabbedehkartxt.Text = Class1.convert_number(idhesabbedehkartxt.Text.Replace(",", ""));
                idhesabbedehkartxt.Select(idhesabbedehkartxt.Text.Length, 0);
            }
            //
            //
            if (idhesabbedehkartxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = SHData1.SanadeHesabdariShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                printbtn.Enabled = true;
                if (bedehkarrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (bedehkarrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                    int str = Convert .ToInt32 ( idhesabbedehkartxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = SHData1.FilterHBedehkar1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (bedehkarrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[1];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        idhesabbedehkartxt.Text = "";
                        idhesabbedehkartxt.Focus();
                        idhesabbedehkartxt.SelectAll();

                    }
                }
            }
        }
        int k1 = 0;
        private void idhesabbestankartxt_KeyDown(object sender, KeyEventArgs e)
        {
            k1 = 1;
        }

        private void idhesabbestankartxt_TextChanged(object sender, EventArgs e)
        {
            if (idhesabbestankartxt.Text.Length != 0 && k1 == 1)
            {
                k1 = 0;
                idhesabbestankartxt.Text = Class1.convert_number(idhesabbestankartxt.Text.Replace(",", ""));
                idhesabbestankartxt.Select(idhesabbestankartxt.Text.Length, 0);
            }
            //
            //
            if (idhesabbestankartxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = SHData1.SanadeHesabdariShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                printbtn.Enabled = true;
                if (bestankarrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[6];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (bestankarrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[6];
                    int str = Convert.ToInt32 (idhesabbestankartxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = SHData1.FilterHBestankar1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (bestankarrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[6];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        idhesabbestankartxt.Text = "";
                        idhesabbestankartxt.Focus();
                        idhesabbestankartxt.SelectAll();

                    }
                }
            }
        }

        private void tarikh1mtxt_TextChanged(object sender, EventArgs e)
        {
            if (tarikh1mtxt.Text == "    /  /")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = SHData1.SanadeHesabdariShow1 ();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                printbtn.Enabled = true;
                if (tarikhrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tarikhrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];
                    DateTime str = Convert.ToDateTime(tarikh1mtxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = SHData.FilterTarikh1(str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tarikhrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        tarikh1mtxt.Text = "";
                        tarikh1mtxt.Focus();
                        tarikh1mtxt.SelectAll();

                    }
                }
            }
        }

        private void tarikh2mtxt_TextChanged(object sender, EventArgs e)
        {
            if (tarikh2mtxt.Text == "    /  /")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = SHData.SanadeHesabdariShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                printbtn.Enabled = true;
                if (tarikhrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (tarikhrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];
                    DateTime str = Convert.ToDateTime(tarikh2mtxt.Text);  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = SHData.FilterTarikh1(str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (tarikhrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[13];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        tarikh2mtxt.Text = "";
                        tarikh2mtxt.Focus();
                        tarikh2mtxt.SelectAll();

                    }
                }
            }
        }

        private void sharhesanadtxt_TextChanged(object sender, EventArgs e)
        {
            if (sharhesanadtxt.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = SHData1.SanadeHesabdariShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                printbtn.Enabled = true;
                if (sharhrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[14];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (sharhrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[14];
                    string  str = sharhesanadtxt.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = SHData1.FilterSharheSanad1 (str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (sharhrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[14];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        sharhesanadtxt.Text = "";
                        sharhesanadtxt.Focus();
                        sharhesanadtxt.SelectAll();

                    }
                }
            }
        }

        private void noehesabcmb_TextChanged(object sender, EventArgs e)
        {
            if (noehesabcmb.Text == "")
            {
                dataGridView1.DataSource = true;
                dataGridView1.DataSource = SHData1.SanadeHesabdariShow1();
                set_datagrid();
                //فعال کردن دکمه ویرایش در صورت وجود سطرها در دیتا گرید
                printbtn.Enabled = true;
                if (noehesabrbtn .Checked == true) dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];

            }
            else
            {
                //برای بررسی خالی نبودن دیتا گرید و دکمه رادیویی انتخاب شده
                if (noehesabrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0")
                {
                    if (dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                    string  str =noehesabcmb.Text;  //.Replace("ی", "ي");

                    try
                    {
                        dataGridView1.DataSource = true;
                        dataGridView1.DataSource = HData.FilterNoeHesab1(str);
                        //انتخاب سطر اول سلول دوم در اینجا شرط بکار بردم چون اگر دیتا گرید خالی باشد سلول 2 انتخاب نشده و با خطا مواجه میشود
                        if (noehesabrbtn.Checked == true && dataGridView1.RowCount.ToString() != "0") dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[2];
                        if (dataGridView1.RowCount.ToString() == "0")
                        {
                            printbtn.Enabled = false;

                        }
                        else
                        {
                            printbtn.Enabled = true;

                        }
                    }

                    catch
                    {
                        MessageBox.Show("کاربر گرامی در ورود اطلاعات اشتباه کردید", "خطا", MessageBoxButtons.OK);
                        noehesabcmb.Text = "";
                        noehesabcmb.Focus();
                        noehesabcmb.SelectAll();

                    }
                }
            }
        }

        private void printbtn_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmSanadeHesabdariReport obj = new frmSanadeHesabdariReport();
            obj.ShowDialog();
        }

        private void namebedehkarcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            HData = new HesabhaData();
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {

                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();

                ListItem item = new ListItem();
                item.Text =NameHesabTafzily;
                item.Value = IDHesab.ToString();

                if (item.Text == namebedehkarcmb.Text)
                {
                    idhesabbedehkartxt.Text = IDHesab.ToString();
                }
            }
        }

        private void namebestankarcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            HData = new HesabhaData();
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {

                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();

                ListItem item = new ListItem();
                item.Text =NameHesabTafzily;
                item.Value = IDHesab.ToString();

                if (item.Text == namebestankarcmb .Text)
                {
                    idhesabbestankartxt.Text = IDHesab.ToString();
                }
            }
        }




    }
}

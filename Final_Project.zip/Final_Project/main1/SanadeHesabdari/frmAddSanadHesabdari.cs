﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DAL;
using BLL;
using System.Web.UI.WebControls;

namespace main1.SanadeHesabdari
{
    public partial class frmAddSanadHesabdari : Form
    {
        public frmAddSanadHesabdari()
        {
            InitializeComponent();
        }
        //
        HesabhaData HData;
        HesabhaDB  HDB = new HesabhaDB ();
        //سند حسابداری
        SanadeHesabdariData SHData = new SanadeHesabdariData();
        SanadeHesabdariDB SHDB = new SanadeHesabdariDB();
       // HesabhaData HData;
        //بدهکار
        DaftareKolData DKBedehkarData = new DaftareKolData();
        DaftareKolDB DKBedehkarDB = new DaftareKolDB();
        //بستانکار
        DaftareKolData DKBestankarData = new DaftareKolData();
        DaftareKolDB DKBestankarDB = new DaftareKolDB();
        //دفتر روزنامه
        DaftareRoznameData DRData = new DaftareRoznameData();
        DaftareRoznameDB DRDB = new DaftareRoznameDB();
        //سرمایه
        SarmayeData SARData = new SarmayeData();
        SarmayeDB SARDB = new SarmayeDB();
        //سود و زیان خدماتی
        SoodZiyaneKhadamatiData SZKData = new SoodZiyaneKhadamatiData();
        SoodZiyaneKhadamatiDB SZKDB = new SoodZiyaneKhadamatiDB();
        //سود و زیان بازرگانی
        SoodZiyaneBazarganiData SZBData = new SoodZiyaneBazarganiData();
        SoodZiyaneBazarganiDB SZBDB = new SoodZiyaneBazarganiDB();
        //ترازنامه
        TaraznameData TData = new TaraznameData();
        TaraznameDB TDB = new TaraznameDB();
        ////
        ////
        ////
        //private void idhesabbedehkartxt_KeyDown(object sender, KeyEventArgs e)
        //{
        //    k2 = 1;
        //}
        //int k2 = 0;
        //private void idhesabbedehkartxt_TextChanged(object sender, EventArgs e)
        //{
        //    if (idhesabbedehkartxt.Text.Length != 0 && k2 == 1)
        //    {
        //        k2 = 0;
        //        idhesabbedehkartxt.Text = Class1.convert_number(idhesabbedehkartxt.Text.Replace(",", ""));
        //        idhesabbedehkartxt.Select(idhesabbedehkartxt.Text.Length, 0);
        //    }
        //}
        ////
        ////
        ////
        //private void idhesabbestankartxt_KeyDown(object sender, KeyEventArgs e)
        //{
        //    k3 = 1;
        //}
        //int k3 = 0;
        //private void idhesabbestankartxt_TextChanged(object sender, EventArgs e)
        //{
        //    if (idhesabbestankartxt.Text.Length != 0 && k3 == 1)
        //    {
        //        k3 = 0;
        //        idhesabbestankartxt.Text = Class1.convert_number(idhesabbestankartxt.Text.Replace(",", ""));
        //        idhesabbestankartxt.Select(idhesabbestankartxt.Text.Length, 0);
        //    }
        //}


        ////
        ////
        ////
        //int k = 0;
        //private void mbestankarmtxt_KeyDown(object sender, KeyEventArgs e)
        //{
        //    k = 1;
        //}

        //private void mbestankarmtxt_TextChanged(object sender, EventArgs e)
        //{
        //    if (mbestankarmtxt.Text.Length != 0 && k == 1)
        //    {
        //        k = 0;
        //        mbestankarmtxt.Text = Class1.convert_str(mbestankarmtxt.Text.Replace(",", ""));
        //        mbestankarmtxt.Select(mbestankarmtxt.Text.Length, 0);
        //    }
        //}
        ////
        ////
        ////
        //int k1 = 0;
        //private void mbedehkarimtxt_KeyDown(object sender, KeyEventArgs e)
        //{
        //    k1 = 1;
        //}

        private void mbedehkarimtxt_TextChanged(object sender, EventArgs e)
        {
            mbestankarmtxt.Text = mbedehkarimtxt.Text;
        //    if (mbedehkarimtxt.Text.Length != 0 && k1 == 1)
        //    {
        //        k1 = 0;
        //        mbedehkarimtxt.Text = Class1.convert_str(mbedehkarimtxt.Text.Replace(",", ""));
        //        mbedehkarimtxt.Select(mbedehkarimtxt.Text.Length, 0);
        //    }
        }
        ////
        ////
        ////
        private void frmSanadHesabdari_Load(object sender, EventArgs e)
        {
            //
            //
            tarikhesanadmtxt.Text = Class1.TarikheJari +" "+Class1.SaateJari;
            lblkarbar.Text = Class1.NameFamilyKarbar;
            int i1 = 0;
            int i2 = 1;
            DataTable dt = SHData.SanadeHesabdariSearchID1();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                i1 = Convert.ToInt32(dt.Rows[i][0].ToString());
                if (i2 < i1)
                {
                    i2 = i1;
                }
            }
            if (dt.Rows.Count == 0)
            {
                idsanadtxt.Text = "1";
            }
            else
            {
                idsanadtxt.Text = Convert.ToString(i2 + 1);
            }
            //
            HData = new HesabhaData();
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {

                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();

                    ListItem item = new ListItem();
                    item.Text = NameHesabKol + " / " + NameHesabMoein + " / " + NameHesabTafzily;
                    item.Value = IDHesab.ToString();

                    namehesabbedehkarcmb.Items.Add(item);
                    namehesabbestankarcmb.Items.Add(item);
            }
            namehesabbedehkarcmb.SelectedIndex = 0;
            namehesabbestankarcmb.SelectedIndex = 0;

        }
        //private void enserafbtn_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //}
        ////
        ////
        ////
        //private void set_color()
        //{
        //    idsanadtxt .BackColor = Color.White;
        //    idnoesanadtxt.BackColor = Color.White;
        //    namenoesanadtxt .BackColor = Color.White;
        //    tarikhesanadmtxt .BackColor = Color.White;
        //    idhesabbedehkartxt .BackColor = Color.White;
        //    namehesabbedehkarcmb .BackColor = Color.White;
        //    mbedehkarimtxt .BackColor = Color.White;
        //    idhesabbestankartxt .BackColor = Color.White;
        //    namehesabbestankarcmb .BackColor = Color.White;
        //    mbestankarmtxt.BackColor = Color.White;
        //    sharhesanadtxt.BackColor = Color.White;
        //    noehesabbedehkarcmb .BackColor = Color.White;
        //    noehesabbestankarcmb .BackColor = Color.White;

        //}

        //private void idnoesanadtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    idnoesanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void namenoesanadtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    namenoesanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void idsanadtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    idsanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void tarikhesanadmtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    tarikhesanadmtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void idhesabbedehkartxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    idhesabbedehkartxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void namehesabbedehkarcmb_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    namehesabbedehkarcmb.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void mbedehkarimtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    mbedehkarimtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void idhesabbestankartxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    idhesabbestankartxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void namehesabbestankarcmb_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    namehesabbestankarcmb.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void mbestankarmtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    mbestankarmtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void noehesabbedehkarcmb_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    noehesabbedehkarcmb.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void noehesabbestankarcmb_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    noehesabbestankarcmb.BackColor = Color.FromArgb(255, 255, 192);
        //}

        //private void sharhesanadtxt_Enter(object sender, EventArgs e)
        //{
        //    set_color();
        //    sharhesanadtxt.BackColor = Color.FromArgb(255, 255, 192);
        //}
        //
        //
        //
        private void sabtbtn_Click(object sender, EventArgs e)
        {
            if (idsanadtxt.Text != "" && idhesabbedehkartxt.Text != "" && idhesabbestankartxt.Text != "" && idnoesanadtxt.Text != "" && tarikhesanadmtxt.Text != "" && sharhesanadtxt.Text != "" && mbestankarmtxt.Text != "" && mbestankarmtxt.Text != "")
            {

                SHDB.IDSanad = Convert.ToInt32(idsanadtxt.Text);
                SHDB.FKHesabeBedehkar = Convert.ToInt32(idhesabbedehkartxt.Text);
                SHDB.FKHesabeBestankar = Convert.ToInt32(idhesabbestankartxt.Text);
                SHDB.FKNoeSanad = Convert.ToInt32(idnoesanadtxt.Text);
                SHDB.NameKarbar = lblkarbar.Text;
                SHDB.TarikheSanad = Convert.ToDateTime(tarikhesanadmtxt.Text);
                SHDB.SharheSanad = sharhesanadtxt.Text;
                SHDB.MablagheBedehkari = Convert.ToInt64(mbestankarmtxt.Text.Replace(",", ""));
                SHDB.MablagheBestanKari = Convert.ToInt64(mbestankarmtxt.Text.Replace(",", ""));
                //
                DRDB.IDDaftareRozname = Convert.ToInt32(idsanadtxt .Text);
                DRDB.FKSanadeHesabdari = Convert.ToInt32(idsanadtxt.Text);



                if (!SHData.SanadeHesabdariSearch1(SHDB.IDSanad) && !DRData.DaftareRoznameSearch1(DRDB.IDDaftareRozname))
                {
                    SHData.SanadeHesabdariInsert1 (SHDB);
                    if (MessageBox.Show("ثبت در سند حسابداری با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {
                        Class1.IDSanad = Convert.ToInt32(idsanadtxt.Text);
                    }
                    DRData.DaftareRoznameInsert1 (DRDB);
                    if (MessageBox.Show("ثبت در دفتر روزنامه با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {

                    }


                    //////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //برای ثبت مانده حساب ،حساب بدهکار در دفتر کل////////////////////////////////////////////////////////////////////
                    DKBedehkarDB.IDDaftareKol = Convert.ToInt32(idhesabbedehkartxt.Text);
                    DKBedehkarDB.FKDaftareRozname = Convert.ToInt32(idsanadtxt.Text);
                    DKBedehkarDB.FKHesab = Convert.ToInt32(idhesabbedehkartxt.Text);

                    DataTable DT = new DataTable();
                    DT = DKBedehkarData.DaftareKolSearchID1();
                    int IDHesabBedehkar = 0;
                    long MandeBedehkar = 0;
                    long MandeBestankar = 0;
                    string NameHesab1;
                    string NameHesab2;
                    long Mande1= 0;
                    long Mande2= 0;
                    //برای پیدا کردن نام حساب بدهکار 
                    HDB = HData .HesabhaFind1 (Convert .ToInt32 (idhesabbedehkartxt.Text ));
                    NameHesab1 =HDB .NameHesabMoien  ;
                    //برای پیدا کردن نام حساب بستانکار
                    HDB = HData .HesabhaFind1 (Convert .ToInt32 (idhesabbestankartxt.Text ));
                    NameHesab2 =HDB .NameHesabMoien ;
                    //
                    for (int i = 0; i < DT.Rows.Count; i++)
                    {
                        IDHesabBedehkar = Convert.ToInt32(DT.Rows[i][2].ToString());
                        MandeBedehkar = Convert.ToInt64(DT.Rows[i][3].ToString());
                        MandeBestankar = Convert.ToInt64(DT.Rows[i][4].ToString());
                        
                        if (IDHesabBedehkar == Convert.ToInt32(idhesabbedehkartxt.Text))
                        {
                            if (MandeBedehkar == 0)
                            {
                                if (MandeBestankar == 0)
                                {
                                    DKBedehkarDB.MandeBedehkar = Convert.ToInt64(mbedehkarimtxt.Text.Replace(",", ""));
                                    Mande1 = DKBedehkarDB.MandeBedehkar;
                                }
                                else if (MandeBestankar > Convert.ToInt64(mbedehkarimtxt.Text.Replace(",", "")))
                                {
                                    DKBedehkarDB.MandeBestankar = MandeBestankar - Convert.ToInt64(mbedehkarimtxt.Text.Replace(",", ""));
                                    Mande1 = DKBedehkarDB.MandeBestankar;
                                }
                                else
                                {
                                    DKBedehkarDB.MandeBedehkar = Convert.ToInt64(mbedehkarimtxt.Text.Replace(",", "")) - MandeBestankar;
                                    Mande1 = DKBedehkarDB.MandeBedehkar;
                                }
                            }
                            else
                            {
                                DKBedehkarDB.MandeBedehkar = MandeBedehkar + Convert.ToInt64(mbedehkarimtxt.Text.Replace(",", ""));
                                Mande1 = DKBedehkarDB.MandeBedehkar;
                            }

                            break;
                        }
                    }
                    if (IDHesabBedehkar == Convert.ToInt32(idhesabbedehkartxt.Text))
                    {
                        DKBedehkarData.DaftareKolUpdate1(DKBedehkarDB);
                    }
                    else
                    {
                        DKBedehkarDB.MandeBedehkar = Convert.ToInt64(mbedehkarimtxt.Text.Replace(",", ""));
                        DKBedehkarDB.MandeBestankar = MandeBestankar;
                        DKBedehkarData.DaftareKolInsert1(DKBedehkarDB);
                    }
                    //برای گذاشتن مانده حساب در فیلدهای جدول سرمایه/////////////////////////////////////////////////////////
                    //
                    //
                    SarmayeDB SARDBfind = SARData.SarmayeFind1(1);
                    SARDB.IDSarmaye = SARDBfind.IDSarmaye;
                    SARDB.SarmayeAvalDore = SARDBfind.SarmayeAvalDore;
                    SARDB.SarmayeGozariyeMojadad = SARDBfind.SarmayeGozariyeMojadad;
                    SARDB.SoodeVizhe = SARDBfind.SoodeVizhe;
                    SARDB.Bardasht = SARDBfind.Bardasht;
                    SARDB.ZiyaneVizhe = SARDBfind.ZiyaneVizhe;
                    SARDB.AfzayeshDarSarmaye = SARDBfind.AfzayeshDarSarmaye;
                    SARDB.KaheshDarSarmaye = SARDBfind.KaheshDarSarmaye;
                    SARDB.SarmayePayanDore = SARDBfind.SarmayePayanDore;
                    //
                    //
                    //برای گذاشتن مانده حساب در فیلدهای جدول سود و زیان خدماتی//////////////////////////////////////////////
                    SoodZiyaneKhadamatiDB SZKDBfind = SZKData.SoodZiyaneKhadamatiFind1(1);
                    SZKDB.IDSoodZiyaneKhadamati = SZKDBfind.IDSoodZiyaneKhadamati;
                    SZKDB.DaramadeKhadamat = SZKDBfind.DaramadeKhadamat;
                    SZKDB.HazineEjare = SZKDBfind.HazineEjare;
                    SZKDB.HazineHoghogh = SZKDBfind.HazineHoghogh;
                    SZKDB.HazineAbBarghTel = SZKDBfind.HazineAbBarghTel;
                    SZKDB.HazineMotefareghe = SZKDBfind.HazineMotefareghe;
                    SZKDB.SUMHazineha = SZKDBfind.SUMHazineha;
                    SZKDB.SoodVaZiyanGhableKasreMaliyat = SZKDBfind.SoodVaZiyanGhableKasreMaliyat;
                    SZKDB.Maliyat25 = SZKDBfind.Maliyat25;
                    SZKDB.SoodYaZiyaneVizhe = SZKDBfind.SoodYaZiyaneVizhe;
                    //
                    //برای گذاشتن مانده حساب در فیلدهای جدول بازرگانی////////////////////////////////////////////////////////
                    SoodZiyaneBazarganiDB SZBDBfind = SZBData.SoodZiyaneBazarganiFind1(1);
                    SZBDB.IDSoodZiyaneBazargani = SZBDBfind.IDSoodZiyaneBazargani;
                    SZBDB.Forosh = SZBDBfind.Forosh;
                    SZBDB.BargashtAzForoshVaTakhfifat = SZBDBfind.BargashtAzForoshVaTakhfifat;
                    SZBDB.TakhfifateNaghdiyeForosh = SZBDBfind.TakhfifateNaghdiyeForosh;
                    SZBDB.ForosheKhales = SZBDBfind.ForosheKhales;
                    SZBDB.MojodiyeKalayeAvalDore = SZBDBfind.MojodiyeKalayeAvalDore;
                    SZBDB.KharidTeyeDore = SZBDBfind.KharidTeyeDore;
                    SZBDB.BargashtAzKharidVaTakhfifat = SZBDBfind.BargashtAzKharidVaTakhfifat;
                    SZBDB.TakhfifateNaghdiyeKharid = SZBDBfind.TakhfifateNaghdiyeKharid;
                    SZBDB.KharideKhales = SZBDBfind.KharideKhales;
                    SZBDB.HazineHamleKalaKharidi = SZBDBfind.HazineHamleKalaKharidi;
                    SZBDB.BahayeTamamShodeKalaKharidi = SZBDBfind.BahayeTamamShodeKalaKharidi;
                    SZBDB.MojodiyeKalayeAmadeForosh = SZBDBfind.MojodiyeKalayeAmadeForosh;
                    SZBDB.MojodieKalayePayanDore = SZBDBfind.MojodieKalayePayanDore;
                    SZBDB.BahayeTamamShodeKalaForosh = SZBDBfind.BahayeTamamShodeKalaForosh;
                    SZBDB.SoodeNaVizhe = SZBDBfind.SoodeNaVizhe;
                    SZBDB.HazineOmomiVaEdari = SZBDBfind.HazineOmomiVaEdari;
                    SZBDB.HazinehayeForosh = SZBDBfind.HazinehayeForosh;
                    SZBDB.SoodeKhales = SZBDBfind.SoodeKhales;
                    //
                    //برای گذاشتن مانده حساب در فیلدهای جدول ترازنامه///////////////////////////////////////////////////////
                    TaraznameDB TDBfind = TData.TaraznameFind1(1);
                    TDB.IDTarazname = TDBfind.IDTarazname;
                    TDB.VajheNaghd = TDBfind.VajheNaghd;
                    TDB.HesabhayeDaryaftani = TDBfind.HesabhayeDaryaftani;
                    TDB.AsnadeDaryaftaniyeKotahModat = TDBfind.AsnadeDaryaftaniyeKotahModat;
                    TDB.PishPardakhteBime_Hazine = TDBfind.PishPardakhteBime_Hazine;
                    TDB.SUMDaraeehayeJari = TDBfind.SUMDaraeehayeJari;
                    TDB.Zamin = TDBfind.Zamin;
                    TDB.Sakhteman = TDBfind.Sakhteman;
                    TDB.EstehlakeSakhteman = TDBfind.EstehlakeSakhteman;
                    TDB.ArzesheDaftariyeSakhteman = TDBfind.ArzesheDaftariyeSakhteman;
                    TDB.VasayeleNaghliye = TDBfind.VasayeleNaghliye;
                    TDB.EstehlakeVasayeleNaghliye = TDBfind.EstehlakeVasayeleNaghliye;
                    TDB.ArzesheDaftariyeVasayeleNaghliye = TDBfind.ArzesheDaftariyeVasayeleNaghliye;
                    TDB.SarGhofli = TDBfind.SarGhofli;
                    TDB.SUMDaraeehayeSabet = TDBfind.SUMDaraeehayeSabet;
                    TDB.SUMDaraeeha = TDBfind.SUMDaraeeha;
                    TDB.HesabhayePardakhtani = TDBfind.HesabhayePardakhtani;
                    TDB.AsnadePardakhtaniyeKotahModat = TDBfind.AsnadePardakhtaniyeKotahModat;
                    TDB.PishDaryafteDaramad = TDBfind.PishDaryafteDaramad;
                    TDB.MaliyatePardakhtani = TDBfind.MaliyatePardakhtani;
                    TDB.EzafeBardashteBanki = TDBfind.EzafeBardashteBanki;
                    TDB.SUMBedehihayeJari = TDBfind.SUMBedehihayeJari;
                    TDB.AsnadePardakhtaniyeBolandModat = TDBfind.AsnadePardakhtaniyeBolandModat;
                    TDB.OragheGharzePardakhtani = TDBfind.OragheGharzePardakhtani;
                    TDB.SUMBedehihayeBolandModat = TDBfind.SUMBedehihayeBolandModat;
                    TDB.SUMBedehiha = TDBfind.SUMBedehiha;
                    TDB.FKSarmaye = TDBfind.FKSarmaye;
                    TDB.SUMBedehihaVaSarmaye = TDBfind.SUMBedehihaVaSarmaye;
                    //
                    //
                    switch (NameHesab1 )
                    {
                        case "سرمایه":
                            SARDB .SarmayeAvalDore =Mande1 ;
                            break ;
                        case "سرمایه گذاری مجدد":
                            SARDB .SarmayeGozariyeMojadad = Mande1 ;
                            break ;
                        case "برداشت":
                            SARDB .Bardasht =Mande1 ;
                            break ;
                        case "صندوق":
                            TDB.VajheNaghd = Mande1;
                            break;
                        case "بانک":
                            TDB.VajheNaghd = Mande1+TDBfind .VajheNaghd;
                            break;
                        case "حسابهای دریافتنی":
                            TDB.HesabhayeDaryaftani = Mande1;
                            break;
                        case "اسناد دریافتنی کوتاه مدت":
                            TDB.AsnadeDaryaftaniyeKotahModat = Mande1;
                            break;
                        case "پیش پرداخت بیمه":
                            TDB.PishPardakhteBime_Hazine = Mande1;
                            break;
                        case "زمین":
                            TDB.Zamin = Mande1;
                            break;
                        case "اثاثه":
                            TDB.Zamin += Mande1;
                            break;
                        case "ساختمان":
                            TDB.Sakhteman = Mande1;
                            break;
                        case "وسایل نقلیه":
                            TDB.VasayeleNaghliye = Mande1;
                            break;
                        case "سرقفلی":
                            TDB.SarGhofli = Mande1;
                            break;
                        case "حسابهای پرداختنی":
                            TDB.HesabhayePardakhtani = Mande1;
                            break;
                        case "اسناد پرداختنی کوتاه مدت":
                            TDB.AsnadePardakhtaniyeKotahModat = Mande1;
                            break;
                        case "پیش دریافت درآمد":
                            TDB.PishDaryafteDaramad = Mande1;
                            break;
                        case "مالیات پرداختنی":
                            TDB.MaliyatePardakhtani = Mande1;
                            break;
                        case "اضافه برداشت بانکی":
                            TDB.EzafeBardashteBanki = Mande1;
                            break;
                        case "اسناد پرداختنی بلند مدت":
                            TDB.AsnadePardakhtaniyeBolandModat = Mande1;
                            break;
                        case "اوراق قرضه پرداختنی":
                            TDB.OragheGharzePardakhtani = Mande1;
                            break;
                        case "فروش":
                            SZBDB.Forosh = Mande1;
                            break;
                        case "برگشت از فروش و تخفیفات":
                            SZBDB.BargashtAzForoshVaTakhfifat = Mande1;
                            break;
                        case "تخفیفات نقدی فروش":
                            SZBDB.TakhfifateNaghdiyeForosh = Mande1 ;
                            break;
                        case "موجودی کالای اول دوره":
                            SZBDB.MojodiyeKalayeAvalDore = Mande1;
                            break;
                        case "خرید طی دوره":
                            SZBDB.KharidTeyeDore = Mande1;
                            break;
                        case "برگشت از خرید و تخفیفات":
                            SZBDB.BargashtAzKharidVaTakhfifat = Mande1;
                            break;
                        case "تخفیفات نقدی خرید":
                            SZBDB.TakhfifateNaghdiyeKharid = Mande1;
                            break;
                        case "هزینه حمل کالا":
                            SZBDB.HazineHamleKalaKharidi = Mande1;
                            break;
                        case "هزینه های فروش":
                            SZBDB.HazinehayeForosh = Mande1;
                            break;
                        case "هزینه اداری":
                            SZBDB.HazineOmomiVaEdari = Mande1;
                            break;
                        case "درآمد خدمات":
                            SZKDB.DaramadeKhadamat = Mande1;
                            break;
                        case "هزینه اجاره":
                            SZKDB.HazineEjare = Mande1;
                            break;
                        case "هزینه های متفرقه":
                            SZKDB.HazineMotefareghe = Mande1;
                            break;
                        case "هزینه حقوق":
                            SZKDB.HazineHoghogh = Mande1;
                            break;
                        case "هزینه قبوض":
                            SZKDB.HazineAbBarghTel = Mande1;
                            break;
                    }
                    //////////ثبت در جدول سرمایه///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    SARDB.SoodeVizhe = SZBDB.SoodeKhales;
                    SARDB.SarmayePayanDore = SARDB.SarmayeAvalDore + SARDB.SarmayeGozariyeMojadad + SARDB.SoodeVizhe - SARDB.Bardasht - SARDB.ZiyaneVizhe;
                    SARDB.AfzayeshDarSarmaye = SARDB.SarmayeGozariyeMojadad + SARDB.SoodeVizhe;
                    SARDB.KaheshDarSarmaye = SARDB.Bardasht + SARDB.ZiyaneVizhe;
                    SARData .SarmayeUpdate1 (SARDB );
                    //برای آپدیت جدول ترازنامه چون کلید خارجی از جدول سرمایه دارد
                    TDB.SUMBedehihaVaSarmaye =TDB.SUMBedehiha+SARDB.SarmayePayanDore;
                    TData.TaraznameUpdate1(TDB);
                    //
                    //
                    //////////ثبت در جدول سود و زیان خدماتی////////////////////////////////////////////////////////////////////////////////////////////////////////
                    SZKDB.SUMHazineha = SZKDB.HazineEjare + SZKDB.HazineHoghogh + SZKDB.HazineAbBarghTel + SZKDB.HazineMotefareghe;
                    SZKDB.SoodVaZiyanGhableKasreMaliyat = SZKDB.DaramadeKhadamat - SZKDB.SUMHazineha;
                    SZKDB.Maliyat25=SZKDB.SoodVaZiyanGhableKasreMaliyat-((SZKDB.SoodVaZiyanGhableKasreMaliyat*25)/100);
                    SZKDB.SoodYaZiyaneVizhe = SZKDB.SoodVaZiyanGhableKasreMaliyat - SZKDB.Maliyat25;
                    SZKData.SoodZiyaneKhadamatiUpdate1(SZKDB);

                    //
                    /////////ثبت در جدول بازرگانی /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    SZBDB.ForosheKhales=SZBDB.Forosh-(SZBDB.BargashtAzForoshVaTakhfifat+SZBDB.TakhfifateNaghdiyeForosh );
                    ///////////برای بدست آوردن مانده حساب خرید
                    DataTable DTKharid = new DataTable();
                    string NameHesabKharid;
                    int IDHesabKharid;
                    DTKharid = HData.HesabhaSearchID1();
                    for (int i = 0; i < DTKharid.Rows.Count;i++ )
                    {
                        NameHesabKharid=DTKharid.Rows[i][7].ToString();
                        IDHesabKharid=Convert.ToInt32 (DTKharid.Rows[i][0]);
                        if(NameHesabKharid =="خرید")
                        {
                            DaftareKolDB DaftareKolKaridDB = DKBedehkarData.DaftareKolFind1(IDHesabKharid);
                            long MandeBedehkarKharid = DaftareKolKaridDB.MandeBedehkar;
                            long MandeBestankarKharid = DaftareKolKaridDB.MandeBestankar;
                            if(MandeBedehkarKharid !=0)
                                 SZBDB.KharideKhales=DaftareKolKaridDB.MandeBedehkar +SZBDB.HazineHamleKalaKharidi-(SZBDB.BargashtAzKharidVaTakhfifat+SZBDB.TakhfifateNaghdiyeKharid );
                            else if(MandeBestankarKharid !=0)
                                SZBDB.KharideKhales = DaftareKolKaridDB.MandeBestankar + SZBDB.HazineHamleKalaKharidi - (SZBDB.BargashtAzKharidVaTakhfifat + SZBDB.TakhfifateNaghdiyeKharid);
                            break;
                        }
                    }
                    //////////
                    SZBDB.BahayeTamamShodeKalaForosh = SZBDB.MojodiyeKalayeAvalDore + SZBDB.KharideKhales - SZBDB.MojodieKalayePayanDore;
                    SZBDB.SoodeNaVizhe = SZBDB.ForosheKhales - SZBDB.BahayeTamamShodeKalaForosh;
                    SZBDB.SoodeKhales=SZBDB.SoodeNaVizhe-(SZBDB.HazinehayeForosh +SZBDB.HazineOmomiVaEdari+SZKDB.HazineEjare+SZKDB.HazineHoghogh+SZKDB.HazineAbBarghTel);
                    SZBData.SoodZiyaneBazarganiUpdate1(SZBDB);
                    ////
                    ///////////ثبت در جدول ترازنامه//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    TDB.SUMDaraeehayeJari = TDB.VajheNaghd + TDB.HesabhayeDaryaftani + TDB.AsnadeDaryaftaniyeKotahModat + TDB.PishPardakhteBime_Hazine;
                    TDB.ArzesheDaftariyeSakhteman = TDB.Sakhteman - TDB.EstehlakeSakhteman;
                    TDB.ArzesheDaftariyeVasayeleNaghliye = TDB.VasayeleNaghliye - TDB.EstehlakeVasayeleNaghliye;
                    TDB.SUMDaraeehayeSabet = TDB.Zamin + TDB.ArzesheDaftariyeSakhteman + TDB.ArzesheDaftariyeVasayeleNaghliye + TDB.SarGhofli;
                    TDB.SUMDaraeeha = TDB.SUMDaraeehayeJari + TDB.SUMDaraeehayeSabet;
                    TDB.SUMBedehihayeJari = TDB.HesabhayePardakhtani + TDB.AsnadePardakhtaniyeKotahModat + TDB.PishDaryafteDaramad + TDB.MaliyatePardakhtani + TDB.EzafeBardashteBanki;
                    TDB.SUMBedehihayeBolandModat = TDB.AsnadePardakhtaniyeBolandModat + TDB.OragheGharzePardakhtani;
                    TDB.SUMBedehiha = TDB.SUMBedehihayeJari + TDB.SUMBedehihayeBolandModat;
                    //////// بدست آوردن سرمایه برای استفاده در جدول ترازنامه                 
                    TDB.SUMBedehihaVaSarmaye = SARDB.SarmayePayanDore + TDB.SUMBedehiha;
                    TData.TaraznameUpdate1(TDB);
                    ////////
                    //
                   
                    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //برای ثبت مانده حساب، حساب بستانکار در دفتر کل////////////////////////////////////////////////////////////////////////////////////////////////////
                    DKBestankarDB.IDDaftareKol = Convert.ToInt32(idhesabbestankartxt.Text);
                    DKBestankarDB.FKDaftareRozname = Convert.ToInt32(idsanadtxt.Text);
                    DKBestankarDB.FKHesab = Convert.ToInt32(idhesabbestankartxt.Text);

                    DataTable DT1 = new DataTable();
                    DT1 = DKBestankarData.DaftareKolSearchID1();
                    int IDHesabBestankar = 0;
                    long MandeBedehkar1 = 0;
                    long MandeBestankar1 = 0;
                    for (int i = 0; i < DT1.Rows.Count; i++)
                    {
                        IDHesabBestankar = Convert.ToInt32(DT1.Rows[i][2].ToString());
                        MandeBedehkar1 = Convert.ToInt64(DT1.Rows[i][3].ToString());
                        MandeBestankar1 = Convert.ToInt64(DT1.Rows[i][4].ToString());
                        if (IDHesabBestankar == Convert.ToInt32(idhesabbestankartxt.Text))
                        {
                            if (MandeBedehkar1 == 0)
                            {
                                if (MandeBestankar1 == 0)
                                {
                                    DKBestankarDB.MandeBestankar = Convert.ToInt64(mbestankarmtxt.Text.Replace(",", ""));
                                    Mande2 = DKBestankarDB.MandeBestankar;
                                }
                                else
                                {
                                    DKBestankarDB.MandeBestankar = MandeBestankar1 + Convert.ToInt64(mbestankarmtxt.Text.Replace(",", ""));
                                    Mande2 = DKBestankarDB.MandeBestankar;
                                }
                            }
                            else if (MandeBedehkar1 > Convert.ToInt64(mbestankarmtxt.Text.Replace(",", "")))
                            {
                                DKBestankarDB.MandeBedehkar = MandeBedehkar1 - Convert.ToInt64(mbestankarmtxt.Text.Replace(",", ""));
                                Mande2 = DKBestankarDB.MandeBedehkar;
                            }
                            else
                            {
                                DKBestankarDB.MandeBestankar = Convert.ToInt64(mbestankarmtxt.Text.Replace(",", "")) - MandeBedehkar1;
                                Mande2 = DKBestankarDB.MandeBestankar;
                            }
                            break;
                        }

                    }
                    if (IDHesabBestankar == Convert.ToInt32(idhesabbestankartxt.Text))
                    {
                        DKBestankarData.DaftareKolUpdate1(DKBestankarDB);

                    }
                    else
                    {
                        DKBestankarDB.MandeBedehkar = MandeBedehkar1;
                        DKBestankarDB.MandeBestankar = Convert.ToInt64(mbestankarmtxt.Text.Replace(",", ""));
                        DKBestankarData.DaftareKolInsert1(DKBestankarDB);
                    }
                    ////برای گذاشتن مانده حساب در فیلدهای جدول سرمایه////////////////////////////////////////////////////////////
                    ////
                    //SarmayeDB SARDBfind1 = SARData.SarmayeFind1(1);
                    //SARDB.IDSarmaye = SARDBfind1.IDSarmaye;
                    //SARDB.SarmayeAvalDore = SARDBfind1.SarmayeAvalDore;
                    //SARDB.SarmayeGozariyeMojadad = SARDBfind1.SarmayeGozariyeMojadad;
                    //SARDB.SoodeVizhe = SARDBfind1.SoodeVizhe;
                    //SARDB.Bardasht = SARDBfind1.Bardasht;
                    //SARDB.ZiyaneVizhe = SARDBfind1.ZiyaneVizhe;
                    //SARDB.AfzayeshDarSarmaye = SARDBfind1.AfzayeshDarSarmaye;
                    //SARDB.KaheshDarSarmaye = SARDBfind1.KaheshDarSarmaye;
                    //SARDB.SarmayePayanDore = SARDBfind1.SarmayePayanDore;
                    ////
                    ////برای گذاشتن مانده حساب در فیلدهای جدول سود و زیان خدماتی////////////////////////////////////////////////
                    //SoodZiyaneKhadamatiDB SZKDBfind1 = SZKData.SoodZiyaneKhadamatiFind1(1);
                    //SZKDB.IDSoodZiyaneKhadamati = SZKDBfind1.IDSoodZiyaneKhadamati;
                    //SZKDB.DaramadeKhadamat = SZKDBfind1.DaramadeKhadamat;
                    //SZKDB.HazineEjare = SZKDBfind1.HazineEjare;
                    //SZKDB.HazineHoghogh = SZKDBfind1.HazineHoghogh;
                    //SZKDB.HazineAbBarghTel = SZKDBfind1.HazineAbBarghTel;
                    //SZKDB.HazineMotefareghe = SZKDBfind1.HazineMotefareghe;
                    //SZKDB.SUMHazineha = SZKDBfind1.SUMHazineha;
                    //SZKDB.SoodVaZiyanGhableKasreMaliyat = SZKDBfind1.SoodVaZiyanGhableKasreMaliyat;
                    //SZKDB.Maliyat25 = SZKDBfind1.Maliyat25;
                    //SZKDB.SoodYaZiyaneVizhe = SZKDBfind1.SoodYaZiyaneVizhe;
                    ////
                    ////برای گذاشتن مانده حساب در فیلدهای جدول بازرگانی/////////////////////////////////////////////////////////
                    //SoodZiyaneBazarganiDB SZBDBfind1 = SZBData.SoodZiyaneBazarganiFind1 (1);
                    //SZBDB.IDSoodZiyaneBazargani = SZBDBfind1.IDSoodZiyaneBazargani;
                    //SZBDB.Forosh = SZBDBfind1.Forosh;
                    //SZBDB.BargashtAzForoshVaTakhfifat = SZBDBfind1.BargashtAzForoshVaTakhfifat;
                    //SZBDB.TakhfifateNaghdiyeForosh = SZBDBfind1.TakhfifateNaghdiyeForosh;
                    //SZBDB.ForosheKhales = SZBDBfind1.ForosheKhales;
                    //SZBDB.MojodiyeKalayeAvalDore = SZBDBfind1.MojodiyeKalayeAvalDore;
                    //SZBDB.KharidTeyeDore = SZBDBfind1.KharidTeyeDore;
                    //SZBDB.BargashtAzKharidVaTakhfifat = SZBDBfind1.BargashtAzKharidVaTakhfifat;
                    //SZBDB.TakhfifateNaghdiyeKharid = SZBDBfind1.TakhfifateNaghdiyeKharid;
                    //SZBDB.KharideKhales = SZBDBfind1.KharideKhales;
                    //SZBDB.HazineHamleKalaKharidi = SZBDBfind1.HazineHamleKalaKharidi;
                    //SZBDB.BahayeTamamShodeKalaKharidi = SZBDBfind1.BahayeTamamShodeKalaKharidi;
                    //SZBDB.MojodiyeKalayeAmadeForosh = SZBDBfind1.MojodiyeKalayeAmadeForosh;
                    //SZBDB.MojodieKalayePayanDore = SZBDBfind1.MojodieKalayePayanDore;
                    //SZBDB.BahayeTamamShodeKalaForosh = SZBDBfind1.BahayeTamamShodeKalaForosh;
                    //SZBDB.SoodeNaVizhe = SZBDBfind1.SoodeNaVizhe;
                    //SZBDB.HazineOmomiVaEdari = SZBDBfind1.HazineOmomiVaEdari;
                    //SZBDB.HazinehayeForosh = SZBDBfind1.HazinehayeForosh;
                    //SZBDB.SoodeKhales = SZBDBfind1.SoodeKhales;
                    ////
                    ////برای گذاشتن مانده حساب در فیلدهای جدول ترازنامه//////////////////////////////////////////////////////////
                    //TaraznameDB TDBfind1 = TData.TaraznameFind1(1);
                    //TDB.IDTarazname = TDBfind1.IDTarazname;
                    //TDB.VajheNaghd = TDBfind1.VajheNaghd;
                    //TDB.HesabhayeDaryaftani = TDBfind1.HesabhayeDaryaftani;
                    //TDB.AsnadeDaryaftaniyeKotahModat = TDBfind1.AsnadeDaryaftaniyeKotahModat;
                    //TDB.PishPardakhteBime_Hazine = TDBfind1.PishPardakhteBime_Hazine;
                    //TDB.SUMDaraeehayeJari = TDBfind1.SUMDaraeehayeJari;
                    //TDB.Zamin = TDBfind1.Zamin;
                    //TDB.Sakhteman = TDBfind1.Sakhteman;
                    //TDB.EstehlakeSakhteman = TDBfind1.EstehlakeSakhteman;
                    //TDB.ArzesheDaftariyeSakhteman = TDBfind1.ArzesheDaftariyeSakhteman;
                    //TDB.VasayeleNaghliye = TDBfind1.VasayeleNaghliye;
                    //TDB.EstehlakeVasayeleNaghliye = TDBfind1.EstehlakeVasayeleNaghliye;
                    //TDB.ArzesheDaftariyeVasayeleNaghliye = TDBfind1.ArzesheDaftariyeVasayeleNaghliye;
                    //TDB.SarGhofli = TDBfind1.SarGhofli;
                    //TDB.SUMDaraeehayeSabet = TDBfind1.SUMDaraeehayeSabet;
                    //TDB.SUMDaraeeha = TDBfind1.SUMDaraeeha;
                    //TDB.HesabhayePardakhtani = TDBfind1.HesabhayePardakhtani;
                    //TDB.AsnadePardakhtaniyeKotahModat = TDBfind1.AsnadePardakhtaniyeKotahModat;
                    //TDB.PishDaryafteDaramad = TDBfind1.PishDaryafteDaramad;
                    //TDB.MaliyatePardakhtani = TDBfind1.MaliyatePardakhtani;
                    //TDB.EzafeBardashteBanki = TDBfind1.EzafeBardashteBanki;
                    //TDB.SUMBedehihayeJari = TDBfind1.SUMBedehihayeJari;
                    //TDB.AsnadePardakhtaniyeBolandModat = TDBfind1.AsnadePardakhtaniyeBolandModat;
                    //TDB.OragheGharzePardakhtani = TDBfind1.OragheGharzePardakhtani;
                    //TDB.SUMBedehihayeBolandModat = TDBfind1.SUMBedehihayeBolandModat;
                    //TDB.SUMBedehiha = TDBfind1.SUMBedehiha;
                    //TDB.FKSarmaye = TDBfind1.FKSarmaye;
                    //TDB.SUMBedehihaVaSarmaye = TDBfind1.SUMBedehihaVaSarmaye;
                    //
                    switch (NameHesab2)
                    {
                        case "سرمایه":
                            SARDB.SarmayeAvalDore = Mande2;
                            break;
                        case "سرمایه گذاری مجدد":
                            SARDB.SarmayeGozariyeMojadad = Mande2;
                            break;
                        case "برداشت":
                            SARDB.Bardasht = Mande2;
                            break;
                        case "صندوق":
                            TDB.VajheNaghd = Mande2;
                            break;
                        case "بانک":
                            TDB.VajheNaghd = Mande2 +TDB.VajheNaghd;
                            break;
                        case "حسابهای دریافتنی":
                            TDB.HesabhayeDaryaftani = Mande2;
                            break;
                        case "اسناد دریافتنی کوتاه مدت":
                            TDB.AsnadeDaryaftaniyeKotahModat = Mande2;
                            break;
                        case "پیش پرداخت بیمه":
                            TDB.PishPardakhteBime_Hazine = Mande2;
                            break;
                        case "اثاثه":
                            TDB.Zamin += Mande2;
                            break;
                        case "زمین":
                            TDB.Zamin = Mande2;
                            break;
                        case "ساختمان":
                            TDB.Sakhteman = Mande2;
                            break;
                        case "وسایل نقلیه":
                            TDB.VasayeleNaghliye = Mande2;
                            break;
                        case "سرقفلی":
                            TDB.SarGhofli = Mande2;
                            break;
                        case "حسابهای پرداختنی":
                            TDB.HesabhayePardakhtani = Mande2;
                            break;
                        case "اسناد پرداختنی کوتاه مدت":
                            TDB.AsnadePardakhtaniyeKotahModat = Mande2;
                            break;
                        case "پیش دریافت درآمد":
                            TDB.PishDaryafteDaramad = Mande2;
                            break;
                        case "مالیات پرداختنی":
                            TDB.MaliyatePardakhtani = Mande2;
                            break;
                        case "اضافه برداشت بانکی":
                            TDB.EzafeBardashteBanki = Mande2;
                            break;
                        case "اسناد پرداختنی بلند مدت":
                            TDB.AsnadePardakhtaniyeBolandModat = Mande2;
                            break;
                        case "اوراق قرضه پرداختنی":
                            TDB.OragheGharzePardakhtani = Mande2;
                            break;
                        case "فروش":
                            SZBDB.Forosh = Mande2;
                            break;
                        case "برگشت از فروش و تخفیفات":
                            SZBDB.BargashtAzForoshVaTakhfifat = Mande2;
                            break;
                        case "تخفیفات نقدی فروش":
                            SZBDB.TakhfifateNaghdiyeForosh = Mande2 ;
                            break;
                        case "موجودی کالای اول دوره":
                            SZBDB.MojodiyeKalayeAvalDore = Mande2;
                            break;
                        case "خرید طی دوره":
                            SZBDB.KharidTeyeDore = Mande2;
                            break;
                        case "برگشت از خرید و تخفیفات":
                            SZBDB.BargashtAzKharidVaTakhfifat = Mande2;
                            break;
                        case "تخفیفات نقدی خرید":
                            SZBDB.TakhfifateNaghdiyeKharid = Mande2;
                            break;
                        case "هزینه حمل کالا":
                            SZBDB.HazineHamleKalaKharidi = Mande2;
                            break;
                        case "هزینه های فروش":
                            SZBDB.HazinehayeForosh = Mande2;
                            break;
                        case "هزینه اداری":
                            SZBDB.HazineOmomiVaEdari = Mande2;
                            break;
                        case "درآمد خدمات":
                            SZKDB.DaramadeKhadamat = Mande2;
                            break;
                        case "هزینه اجاره":
                            SZKDB.HazineEjare = Mande2;
                            break;
                        case "هزینه های متفرقه":
                            SZKDB.HazineMotefareghe = Mande2;
                            break;
                        case "هزینه حقوق":
                            SZKDB.HazineHoghogh = Mande2;
                            break;
                        case "هزینه قبوض":
                            SZKDB.HazineAbBarghTel = Mande2;
                            break;
                    }
                    ////////////////ثبت در جدول سرمایه///////////////////////////////////////////////////////////////////////////
                    SARDB.SoodeVizhe = SZBDB.SoodeKhales;
                    SARDB.SarmayePayanDore = SARDB.SarmayeAvalDore + SARDB.SarmayeGozariyeMojadad + SARDB.SoodeVizhe - SARDB.Bardasht - SARDB.ZiyaneVizhe;
                    SARDB.AfzayeshDarSarmaye = SARDB.SarmayeGozariyeMojadad + SARDB.SoodeVizhe;
                    SARDB.KaheshDarSarmaye = SARDB.Bardasht + SARDB.ZiyaneVizhe;
                    SARData.SarmayeUpdate1(SARDB);
                    //برای آپدیت جدول ترازنامه چون کلید خارجی از جدول سرمایه دارد
                    TDB.SUMBedehihaVaSarmaye =TDB.SUMBedehiha+SARDB.SarmayePayanDore;
                    TData.TaraznameUpdate1(TDB);
                    //
                    /////////////ثبت در جدول سود و زیان خدماتی
                    SZKDB.SUMHazineha = SZKDB.HazineEjare + SZKDB.HazineHoghogh + SZKDB.HazineAbBarghTel + SZKDB.HazineMotefareghe;
                    SZKDB.SoodVaZiyanGhableKasreMaliyat = SZKDB.DaramadeKhadamat - SZKDB.SUMHazineha;
                    SZKDB.Maliyat25 = SZKDB.SoodVaZiyanGhableKasreMaliyat - ((SZKDB.SoodVaZiyanGhableKasreMaliyat * 25) / 100);
                    SZKDB.SoodYaZiyaneVizhe = SZKDB.SoodVaZiyanGhableKasreMaliyat - SZKDB.Maliyat25;
                    SZKData.SoodZiyaneKhadamatiUpdate1(SZKDB);
                    //
                    /////////ثبت در جدول بازرگانی /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    SZBDB.ForosheKhales = SZBDB.Forosh - (SZBDB.BargashtAzForoshVaTakhfifat + SZBDB.TakhfifateNaghdiyeForosh);
                    ///////////برای بدست آوردن مانده حساب خرید
                    DataTable DTKharid1 = new DataTable();
                    string NameHesabKharid1;
                    int IDHesabKharid1;
                    DTKharid1 = HData.HesabhaSearchID1();
                    for (int i = 0; i < DTKharid1.Rows.Count; i++)
                    {
                        NameHesabKharid1 = DTKharid1.Rows[i][7].ToString();
                        IDHesabKharid1 = Convert.ToInt32(DTKharid1.Rows[i][0]);
                        if (NameHesabKharid1 == "خرید")
                        {
                            DaftareKolDB DaftareKolKaridDB = DKBedehkarData.DaftareKolFind1(IDHesabKharid1);
                            long MandeBedehkarKharid = DaftareKolKaridDB.MandeBedehkar;
                            long MandeBestankarKharid = DaftareKolKaridDB.MandeBestankar;
                            if (MandeBedehkarKharid != 0)
                                SZBDB.KharideKhales = DaftareKolKaridDB.MandeBedehkar + SZBDB.HazineHamleKalaKharidi - (SZBDB.BargashtAzKharidVaTakhfifat + SZBDB.TakhfifateNaghdiyeKharid);
                            else if (MandeBestankarKharid != 0)
                                SZBDB.KharideKhales = DaftareKolKaridDB.MandeBestankar + SZBDB.HazineHamleKalaKharidi - (SZBDB.BargashtAzKharidVaTakhfifat + SZBDB.TakhfifateNaghdiyeKharid);
                            break;
                        }
                    }
                    //////////
                    SZBDB.BahayeTamamShodeKalaForosh = SZBDB.MojodiyeKalayeAvalDore + SZBDB.KharideKhales - SZBDB.MojodieKalayePayanDore;
                    SZBDB.SoodeNaVizhe = SZBDB.ForosheKhales - SZBDB.BahayeTamamShodeKalaForosh;
                    SZBDB.SoodeKhales = SZBDB.SoodeNaVizhe - (SZBDB.HazinehayeForosh + SZBDB.HazineOmomiVaEdari + SZKDB.HazineEjare + SZKDB.HazineHoghogh + SZKDB.HazineAbBarghTel);
                    SZBData.SoodZiyaneBazarganiUpdate1(SZBDB);
                    ////
                    ///////////ثبت در جدول ترازنامه///////////////////////////////////////////////////////////////////////////////
                    TDB.SUMDaraeehayeJari = TDB.VajheNaghd + TDB.HesabhayeDaryaftani + TDB.AsnadeDaryaftaniyeKotahModat + TDB.PishPardakhteBime_Hazine;
                    TDB.ArzesheDaftariyeSakhteman = TDB.Sakhteman - TDB.EstehlakeSakhteman;
                    TDB.ArzesheDaftariyeVasayeleNaghliye = TDB.VasayeleNaghliye - TDB.EstehlakeVasayeleNaghliye;
                    TDB.SUMDaraeehayeSabet = TDB.Zamin + TDB.ArzesheDaftariyeSakhteman + TDB.ArzesheDaftariyeVasayeleNaghliye + TDB.SarGhofli;
                    TDB.SUMDaraeeha = TDB.SUMDaraeehayeJari + TDB.SUMDaraeehayeSabet;
                    TDB.SUMBedehihayeJari = TDB.HesabhayePardakhtani + TDB.AsnadePardakhtaniyeKotahModat + TDB.PishDaryafteDaramad + TDB.MaliyatePardakhtani + TDB.EzafeBardashteBanki;
                    TDB.SUMBedehihayeBolandModat = TDB.AsnadePardakhtaniyeBolandModat + TDB.OragheGharzePardakhtani;
                    TDB.SUMBedehiha = TDB.SUMBedehihayeJari + TDB.SUMBedehihayeBolandModat;
                    //////// بدست آوردن سرمایه برای استفاده در جدول ترازنامه                 
                    TDB.SUMBedehihaVaSarmaye = SARDB.SarmayePayanDore + TDB.SUMBedehiha;
                    TData.TaraznameUpdate1(TDB);
                    ////////
                    //
                    //
                    if (MessageBox.Show("ثبت در دفتر کل و جداول سود و زیان و سرمایه و ترازنامه با موفقیت انجام شد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                    {

                    }
                   Close();
                }
                else
                {
                    MessageBox.Show("کد سند حسابداری تکراری است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            else
            {
                MessageBox.Show("داده های وارد شده، کافی نمی باشد", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            frmSanadHesabdari shb = new frmSanadHesabdari();
            shb.ShowDialog();

        }
        private void noehesabbedehkarcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            namehesabbedehkarcmb.Items.Clear();
            HData = new HesabhaData();
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {

                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();
                if (noehesabbedehkarcmb.Text == NoeHesab)
                {
                    ListItem item = new ListItem();
                    item.Text = NameHesabKol + " / " + NameHesabMoein + " / " + NameHesabTafzily;
                    item.Value = IDHesab.ToString();

                    namehesabbedehkarcmb.Items.Add(item);
                }
            }
            namehesabbedehkarcmb.SelectedIndex = 0;
        }

        private void namehesabbedehkarcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
                       DataTable DT = HData.HesabhaComboShow1();
                       for (int i = 0; i < DT.Rows.Count; i++)
                       {

                           int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                           string NameHesabKol = DT.Rows[i][3].ToString();
                           string NoeHesab = DT.Rows[i][1].ToString();
                           string NameHesabMoein = DT.Rows[i][5].ToString();
                           string NameHesabTafzily = DT.Rows[i][7].ToString();
 
                               ListItem  item = new ListItem ();
                               item.Text = NameHesabKol + " / " + NameHesabMoein + " / " + NameHesabTafzily;
                               item.Value = IDHesab.ToString();
                           if(namehesabbedehkarcmb .Text == item .Text )
                           {
                               idhesabbedehkartxt.Text = IDHesab.ToString();
                               break;
                           }
                           
                       }
        }


        private void namehesabbestankarcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {

                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();

                ListItem item = new ListItem();
                item.Text = NameHesabKol + " / " + NameHesabMoein + " / " + NameHesabTafzily;
                item.Value = IDHesab.ToString();
                if (namehesabbestankarcmb.Text == item.Text)
                {
                    idhesabbestankartxt.Text = IDHesab.ToString();
                    break;
                }

            }
        }

        private void noehesabbestankarcmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            namehesabbestankarcmb.Items.Clear();
            HData = new HesabhaData();
            DataTable DT = HData.HesabhaComboShow1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                int IDHesab = Convert.ToInt32(DT.Rows[i][0].ToString());
                string NameHesabKol = DT.Rows[i][3].ToString();
                string NoeHesab = DT.Rows[i][1].ToString();
                string NameHesabMoein = DT.Rows[i][5].ToString();
                string NameHesabTafzily = DT.Rows[i][7].ToString();
                if (noehesabbestankarcmb.Text == NoeHesab)
                {
                    ListItem item = new ListItem();
                    item.Text = NameHesabKol + " / " + NameHesabMoein + " / " + NameHesabTafzily;
                    item.Value = IDHesab.ToString();

                    namehesabbestankarcmb.Items.Add(item);
                }
            }
            namehesabbestankarcmb.SelectedIndex = 0;
        
        }

        private void enserafbtn_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void mbedehkarimtxt_TextChanged_1(object sender, EventArgs e)
        {
            mbestankarmtxt.Text = mbedehkarimtxt.Text;
        }

        private void ejadehesabejadidbtn_Click(object sender, EventArgs e)
        {
            Hesabha.frmAddHesabha obj = new Hesabha.frmAddHesabha();
            obj.ShowDialog();
        }





     

        

    }
}

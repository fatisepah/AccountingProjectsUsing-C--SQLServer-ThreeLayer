﻿namespace main1.SanadeHesabdari
{
    partial class frmAddSanadHesabdari
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.noehesabbedehkarcmb = new System.Windows.Forms.ComboBox();
            this.mbedehkarimtxt = new System.Windows.Forms.MaskedTextBox();
            this.namehesabbedehkarcmb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.idhesabbedehkartxt = new System.Windows.Forms.TextBox();
            this.namenoesanadtxt = new System.Windows.Forms.TextBox();
            this.tarikhesanadmtxt = new System.Windows.Forms.MaskedTextBox();
            this.idnoesanadtxt = new System.Windows.Forms.TextBox();
            this.idsanadtxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.noehesabbestankarcmb = new System.Windows.Forms.ComboBox();
            this.namehesabbestankarcmb = new System.Windows.Forms.ComboBox();
            this.idhesabbestankartxt = new System.Windows.Forms.TextBox();
            this.mbestankarmtxt = new System.Windows.Forms.MaskedTextBox();
            this.sharhesanadtxt = new System.Windows.Forms.TextBox();
            this.lblkarbar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ejadehesabejadidbtn = new System.Windows.Forms.Button();
            this.sabtbtn = new System.Windows.Forms.Button();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // noehesabbedehkarcmb
            // 
            this.noehesabbedehkarcmb.FormattingEnabled = true;
            this.noehesabbedehkarcmb.Items.AddRange(new object[] {
            "دارایی",
            "بدهی",
            "سرمایه"});
            this.noehesabbedehkarcmb.Location = new System.Drawing.Point(463, 163);
            this.noehesabbedehkarcmb.Name = "noehesabbedehkarcmb";
            this.noehesabbedehkarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.noehesabbedehkarcmb.Size = new System.Drawing.Size(91, 21);
            this.noehesabbedehkarcmb.TabIndex = 6;
            this.noehesabbedehkarcmb.SelectedIndexChanged += new System.EventHandler(this.noehesabbedehkarcmb_SelectedIndexChanged);
            // 
            // mbedehkarimtxt
            // 
            this.mbedehkarimtxt.Location = new System.Drawing.Point(21, 163);
            this.mbedehkarimtxt.Name = "mbedehkarimtxt";
            this.mbedehkarimtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mbedehkarimtxt.Size = new System.Drawing.Size(131, 20);
            this.mbedehkarimtxt.TabIndex = 8;
            this.mbedehkarimtxt.TextChanged += new System.EventHandler(this.mbedehkarimtxt_TextChanged_1);
            // 
            // namehesabbedehkarcmb
            // 
            this.namehesabbedehkarcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namehesabbedehkarcmb.FormattingEnabled = true;
            this.namehesabbedehkarcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namehesabbedehkarcmb.Location = new System.Drawing.Point(153, 163);
            this.namehesabbedehkarcmb.Name = "namehesabbedehkarcmb";
            this.namehesabbedehkarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namehesabbedehkarcmb.Size = new System.Drawing.Size(308, 21);
            this.namehesabbedehkarcmb.TabIndex = 7;
            this.namehesabbedehkarcmb.SelectedIndexChanged += new System.EventHandler(this.namehesabbedehkarcmb_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(3, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 15);
            this.label1.TabIndex = 75;
            this.label1.Text = "*";
            // 
            // idhesabbedehkartxt
            // 
            this.idhesabbedehkartxt.Location = new System.Drawing.Point(556, 163);
            this.idhesabbedehkartxt.Name = "idhesabbedehkartxt";
            this.idhesabbedehkartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabbedehkartxt.Size = new System.Drawing.Size(70, 20);
            this.idhesabbedehkartxt.TabIndex = 5;
            // 
            // namenoesanadtxt
            // 
            this.namenoesanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.namenoesanadtxt.Location = new System.Drawing.Point(497, 56);
            this.namenoesanadtxt.Name = "namenoesanadtxt";
            this.namenoesanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namenoesanadtxt.Size = new System.Drawing.Size(117, 20);
            this.namenoesanadtxt.TabIndex = 2;
            this.namenoesanadtxt.Text = "اسناد حسابداری مالی";
            // 
            // tarikhesanadmtxt
            // 
            this.tarikhesanadmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikhesanadmtxt.Location = new System.Drawing.Point(64, 65);
            this.tarikhesanadmtxt.Name = "tarikhesanadmtxt";
            this.tarikhesanadmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikhesanadmtxt.Size = new System.Drawing.Size(116, 20);
            this.tarikhesanadmtxt.TabIndex = 4;
            // 
            // idnoesanadtxt
            // 
            this.idnoesanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idnoesanadtxt.Location = new System.Drawing.Point(497, 32);
            this.idnoesanadtxt.Name = "idnoesanadtxt";
            this.idnoesanadtxt.ReadOnly = true;
            this.idnoesanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idnoesanadtxt.Size = new System.Drawing.Size(117, 20);
            this.idnoesanadtxt.TabIndex = 1;
            this.idnoesanadtxt.Text = "2";
            // 
            // idsanadtxt
            // 
            this.idsanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idsanadtxt.Location = new System.Drawing.Point(497, 80);
            this.idsanadtxt.Name = "idsanadtxt";
            this.idsanadtxt.ReadOnly = true;
            this.idsanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idsanadtxt.Size = new System.Drawing.Size(117, 20);
            this.idsanadtxt.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(47, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 16);
            this.label6.TabIndex = 22;
            this.label6.Text = "*";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(195, 43);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 23);
            this.label23.TabIndex = 38;
            this.label23.Text = ":نام کاربر";
            // 
            // noehesabbestankarcmb
            // 
            this.noehesabbestankarcmb.FormattingEnabled = true;
            this.noehesabbestankarcmb.Items.AddRange(new object[] {
            "دارایی",
            "بدهی",
            "سرمایه"});
            this.noehesabbestankarcmb.Location = new System.Drawing.Point(463, 186);
            this.noehesabbestankarcmb.Name = "noehesabbestankarcmb";
            this.noehesabbestankarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.noehesabbestankarcmb.Size = new System.Drawing.Size(90, 21);
            this.noehesabbestankarcmb.TabIndex = 10;
            this.noehesabbestankarcmb.SelectedIndexChanged += new System.EventHandler(this.noehesabbestankarcmb_SelectedIndexChanged);
            // 
            // namehesabbestankarcmb
            // 
            this.namehesabbestankarcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namehesabbestankarcmb.FormattingEnabled = true;
            this.namehesabbestankarcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namehesabbestankarcmb.Location = new System.Drawing.Point(153, 186);
            this.namehesabbestankarcmb.Name = "namehesabbestankarcmb";
            this.namehesabbestankarcmb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.namehesabbestankarcmb.Size = new System.Drawing.Size(308, 21);
            this.namehesabbestankarcmb.TabIndex = 11;
            this.namehesabbestankarcmb.SelectedIndexChanged += new System.EventHandler(this.namehesabbestankarcmb_SelectedIndexChanged);
            // 
            // idhesabbestankartxt
            // 
            this.idhesabbestankartxt.Location = new System.Drawing.Point(556, 186);
            this.idhesabbestankartxt.Name = "idhesabbestankartxt";
            this.idhesabbestankartxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.idhesabbestankartxt.Size = new System.Drawing.Size(70, 20);
            this.idhesabbestankartxt.TabIndex = 9;
            // 
            // mbestankarmtxt
            // 
            this.mbestankarmtxt.Location = new System.Drawing.Point(21, 186);
            this.mbestankarmtxt.Name = "mbestankarmtxt";
            this.mbestankarmtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mbestankarmtxt.Size = new System.Drawing.Size(130, 20);
            this.mbestankarmtxt.TabIndex = 12;
            // 
            // sharhesanadtxt
            // 
            this.sharhesanadtxt.Location = new System.Drawing.Point(21, 209);
            this.sharhesanadtxt.Multiline = true;
            this.sharhesanadtxt.Name = "sharhesanadtxt";
            this.sharhesanadtxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sharhesanadtxt.Size = new System.Drawing.Size(605, 42);
            this.sharhesanadtxt.TabIndex = 13;
            // 
            // lblkarbar
            // 
            this.lblkarbar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblkarbar.Location = new System.Drawing.Point(64, 39);
            this.lblkarbar.Name = "lblkarbar";
            this.lblkarbar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblkarbar.Size = new System.Drawing.Size(116, 23);
            this.lblkarbar.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(620, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 23);
            this.label2.TabIndex = 100;
            this.label2.Text = ":کد سند";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(619, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 23);
            this.label11.TabIndex = 102;
            this.label11.Text = ":نام نوع سند";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(620, 35);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 23);
            this.label12.TabIndex = 101;
            this.label12.Text = ":کد نوع سند";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(478, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 15);
            this.label16.TabIndex = 105;
            this.label16.Text = "*";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(478, 82);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(16, 15);
            this.label22.TabIndex = 103;
            this.label22.Text = "*";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(478, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(16, 16);
            this.label24.TabIndex = 104;
            this.label24.Text = "*";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(195, 67);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 23);
            this.label17.TabIndex = 106;
            this.label17.Text = ":تاریخ سند";
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.Location = new System.Drawing.Point(20, 135);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(693, 117);
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 627;
            this.lineShape4.X2 = 627;
            this.lineShape4.Y1 = 136;
            this.lineShape4.Y2 = 252;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 21;
            this.lineShape1.X2 = 712;
            this.lineShape1.Y1 = 161;
            this.lineShape1.Y2 = 161;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 21;
            this.lineShape2.X2 = 712;
            this.lineShape2.Y1 = 184;
            this.lineShape2.Y2 = 184;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 21;
            this.lineShape3.X2 = 712;
            this.lineShape3.Y1 = 207;
            this.lineShape3.Y2 = 207;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 554;
            this.lineShape5.X2 = 554;
            this.lineShape5.Y1 = 136;
            this.lineShape5.Y2 = 207;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 461;
            this.lineShape7.X2 = 461;
            this.lineShape7.Y1 = 136;
            this.lineShape7.Y2 = 206;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 152;
            this.lineShape6.X2 = 152;
            this.lineShape6.Y1 = 136;
            this.lineShape6.Y2 = 207;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape6,
            this.lineShape7,
            this.lineShape5,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.lineShape4,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(735, 307);
            this.shapeContainer1.TabIndex = 107;
            this.shapeContainer1.TabStop = false;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Location = new System.Drawing.Point(633, 219);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 23);
            this.label15.TabIndex = 116;
            this.label15.Text = "شرح سند";
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label19.Location = new System.Drawing.Point(633, 186);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 20);
            this.label19.TabIndex = 115;
            this.label19.Text = "حساب بستانکار";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label20.Location = new System.Drawing.Point(635, 163);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 20);
            this.label20.TabIndex = 114;
            this.label20.Text = "حساب بدهکار";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label21.Location = new System.Drawing.Point(481, 139);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 20);
            this.label21.TabIndex = 113;
            this.label21.Text = "نوع حساب";
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label25.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(55, 142);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(16, 16);
            this.label25.TabIndex = 112;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label26.Location = new System.Drawing.Point(71, 140);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(31, 19);
            this.label26.TabIndex = 111;
            this.label26.Text = "مبلغ";
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label27.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(556, 142);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(16, 11);
            this.label27.TabIndex = 110;
            this.label27.Text = "*";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label28.Location = new System.Drawing.Point(279, 140);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 20);
            this.label28.TabIndex = 109;
            this.label28.Text = "نام حساب";
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label29.Location = new System.Drawing.Point(571, 139);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(52, 20);
            this.label29.TabIndex = 108;
            this.label29.Text = "کد حساب";
            // 
            // ejadehesabejadidbtn
            // 
            this.ejadehesabejadidbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ejadehesabejadidbtn.Image = global::main1.Properties.Resources.plus;
            this.ejadehesabejadidbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ejadehesabejadidbtn.Location = new System.Drawing.Point(600, 267);
            this.ejadehesabejadidbtn.Name = "ejadehesabejadidbtn";
            this.ejadehesabejadidbtn.Size = new System.Drawing.Size(114, 28);
            this.ejadehesabejadidbtn.TabIndex = 16;
            this.ejadehesabejadidbtn.Text = "ایجاد حساب جدید";
            this.ejadehesabejadidbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ejadehesabejadidbtn.UseVisualStyleBackColor = true;
            this.ejadehesabejadidbtn.Click += new System.EventHandler(this.ejadehesabejadidbtn_Click);
            // 
            // sabtbtn
            // 
            this.sabtbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sabtbtn.Image = global::main1.Properties.Resources.save_16x16;
            this.sabtbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sabtbtn.Location = new System.Drawing.Point(122, 267);
            this.sabtbtn.Name = "sabtbtn";
            this.sabtbtn.Size = new System.Drawing.Size(95, 28);
            this.sabtbtn.TabIndex = 14;
            this.sabtbtn.Text = "F2 ثبت ";
            this.sabtbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sabtbtn.UseVisualStyleBackColor = true;
            this.sabtbtn.Click += new System.EventHandler(this.sabtbtn_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(20, 267);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(96, 28);
            this.enserafbtn.TabIndex = 15;
            this.enserafbtn.Text = "ESC انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // frmAddSanadHesabdari
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(735, 307);
            this.Controls.Add(this.ejadehesabejadidbtn);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.namenoesanadtxt);
            this.Controls.Add(this.noehesabbedehkarcmb);
            this.Controls.Add(this.tarikhesanadmtxt);
            this.Controls.Add(this.noehesabbestankarcmb);
            this.Controls.Add(this.mbedehkarimtxt);
            this.Controls.Add(this.idnoesanadtxt);
            this.Controls.Add(this.sabtbtn);
            this.Controls.Add(this.idsanadtxt);
            this.Controls.Add(this.namehesabbedehkarcmb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.namehesabbestankarcmb);
            this.Controls.Add(this.sharhesanadtxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.idhesabbedehkartxt);
            this.Controls.Add(this.idhesabbestankartxt);
            this.Controls.Add(this.lblkarbar);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.mbestankarmtxt);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAddSanadHesabdari";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم ثبت سند حسابداری";
            this.Load += new System.EventHandler(this.frmSanadHesabdari_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox tarikhesanadmtxt;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox idsanadtxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox idhesabbedehkartxt;
        private System.Windows.Forms.ComboBox namehesabbedehkarcmb;
        private System.Windows.Forms.MaskedTextBox mbedehkarimtxt;
        private System.Windows.Forms.MaskedTextBox mbestankarmtxt;
        private System.Windows.Forms.TextBox sharhesanadtxt;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.TextBox idnoesanadtxt;
        private System.Windows.Forms.ComboBox namehesabbestankarcmb;
        private System.Windows.Forms.TextBox idhesabbestankartxt;
        private System.Windows.Forms.Label lblkarbar;
        private System.Windows.Forms.TextBox namenoesanadtxt;
        private System.Windows.Forms.Button sabtbtn;
        private System.Windows.Forms.ComboBox noehesabbedehkarcmb;
        private System.Windows.Forms.ComboBox noehesabbestankarcmb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label17;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button ejadehesabejadidbtn;
    }
}
﻿namespace main1.SanadeHesabdari
{
    partial class frmSanadHesabdari
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSanadHesabdari));
            this.بالاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.پایینToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printbtn = new System.Windows.Forms.Button();
            this.انصرافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enserafbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.noehesabrbtn = new System.Windows.Forms.RadioButton();
            this.noehesabcmb = new System.Windows.Forms.ComboBox();
            this.tarikh2mtxt = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tarikh1mtxt = new System.Windows.Forms.MaskedTextBox();
            this.idhesabbestankartxt = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.idhesabbedehkartxt = new System.Windows.Forms.MaskedTextBox();
            this.namebestankarcmb = new System.Windows.Forms.ComboBox();
            this.sharhesanadtxt = new System.Windows.Forms.TextBox();
            this.sharhrbtn = new System.Windows.Forms.RadioButton();
            this.namebedehkarcmb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tarikhrbtn = new System.Windows.Forms.RadioButton();
            this.bestankarrbtn = new System.Windows.Forms.RadioButton();
            this.bedehkarrbtn = new System.Windows.Forms.RadioButton();
            this.چاپToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.darjbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // بالاToolStripMenuItem
            // 
            this.بالاToolStripMenuItem.Name = "بالاToolStripMenuItem";
            this.بالاToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.Tab)));
            this.بالاToolStripMenuItem.Size = new System.Drawing.Size(34, 20);
            this.بالاToolStripMenuItem.Text = "بالا";
            this.بالاToolStripMenuItem.Click += new System.EventHandler(this.بالاToolStripMenuItem_Click);
            // 
            // پایینToolStripMenuItem
            // 
            this.پایینToolStripMenuItem.Name = "پایینToolStripMenuItem";
            this.پایینToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.پایینToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.پایینToolStripMenuItem.Text = "پایین";
            this.پایینToolStripMenuItem.Click += new System.EventHandler(this.پایینToolStripMenuItem_Click);
            // 
            // printbtn
            // 
            this.printbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printbtn.Image = ((System.Drawing.Image)(resources.GetObject("printbtn.Image")));
            this.printbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printbtn.Location = new System.Drawing.Point(215, 482);
            this.printbtn.Name = "printbtn";
            this.printbtn.Size = new System.Drawing.Size(85, 28);
            this.printbtn.TabIndex = 15;
            this.printbtn.Text = "F7  چاپ";
            this.printbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.printbtn.UseVisualStyleBackColor = true;
            this.printbtn.Click += new System.EventHandler(this.printbtn_Click);
            // 
            // انصرافToolStripMenuItem
            // 
            this.انصرافToolStripMenuItem.Name = "انصرافToolStripMenuItem";
            this.انصرافToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F9;
            this.انصرافToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.انصرافToolStripMenuItem.Text = "انصراف";
            this.انصرافToolStripMenuItem.Click += new System.EventHandler(this.انصرافToolStripMenuItem_Click);
            // 
            // enserafbtn
            // 
            this.enserafbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enserafbtn.Image = global::main1.Properties.Resources.Cancel_Min;
            this.enserafbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.enserafbtn.Location = new System.Drawing.Point(126, 482);
            this.enserafbtn.Name = "enserafbtn";
            this.enserafbtn.Size = new System.Drawing.Size(85, 28);
            this.enserafbtn.TabIndex = 16;
            this.enserafbtn.Text = "F9 انصراف ";
            this.enserafbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enserafbtn.UseVisualStyleBackColor = true;
            this.enserafbtn.Click += new System.EventHandler(this.enserafbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.noehesabrbtn);
            this.groupBox1.Controls.Add(this.noehesabcmb);
            this.groupBox1.Controls.Add(this.tarikh2mtxt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tarikh1mtxt);
            this.groupBox1.Controls.Add(this.idhesabbestankartxt);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.idhesabbedehkartxt);
            this.groupBox1.Controls.Add(this.namebestankarcmb);
            this.groupBox1.Controls.Add(this.sharhesanadtxt);
            this.groupBox1.Controls.Add(this.sharhrbtn);
            this.groupBox1.Controls.Add(this.namebedehkarcmb);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tarikhrbtn);
            this.groupBox1.Controls.Add(this.bestankarrbtn);
            this.groupBox1.Controls.Add(this.bedehkarrbtn);
            this.groupBox1.Location = new System.Drawing.Point(12, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(489, 199);
            this.groupBox1.TabIndex = 60;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "جستجو";
            // 
            // noehesabrbtn
            // 
            this.noehesabrbtn.AutoSize = true;
            this.noehesabrbtn.Location = new System.Drawing.Point(337, 165);
            this.noehesabrbtn.Name = "noehesabrbtn";
            this.noehesabrbtn.Size = new System.Drawing.Size(119, 17);
            this.noehesabrbtn.TabIndex = 12;
            this.noehesabrbtn.TabStop = true;
            this.noehesabrbtn.Text = "براساس نوع حساب:";
            this.noehesabrbtn.UseVisualStyleBackColor = true;
            this.noehesabrbtn.CheckedChanged += new System.EventHandler(this.noehesabrbtn_CheckedChanged);
            // 
            // noehesabcmb
            // 
            this.noehesabcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.noehesabcmb.FormattingEnabled = true;
            this.noehesabcmb.Items.AddRange(new object[] {
            "دارایی",
            "بدهی",
            "سرمایه"});
            this.noehesabcmb.Location = new System.Drawing.Point(176, 164);
            this.noehesabcmb.Name = "noehesabcmb";
            this.noehesabcmb.Size = new System.Drawing.Size(116, 21);
            this.noehesabcmb.TabIndex = 13;
            this.noehesabcmb.TextChanged += new System.EventHandler(this.noehesabcmb_TextChanged);
            this.noehesabcmb.Enter += new System.EventHandler(this.noehesabcmb_Enter);
            // 
            // tarikh2mtxt
            // 
            this.tarikh2mtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikh2mtxt.Location = new System.Drawing.Point(79, 98);
            this.tarikh2mtxt.Mask = "9999/99/99";
            this.tarikh2mtxt.Name = "tarikh2mtxt";
            this.tarikh2mtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikh2mtxt.Size = new System.Drawing.Size(79, 20);
            this.tarikh2mtxt.TabIndex = 9;
            this.tarikh2mtxt.TextChanged += new System.EventHandler(this.tarikh2mtxt_TextChanged);
            this.tarikh2mtxt.Enter += new System.EventHandler(this.tarikh2mtxt_Enter);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(160, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 23);
            this.label3.TabIndex = 97;
            this.label3.Text = "تا  تاریخ:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(297, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 23);
            this.label4.TabIndex = 96;
            this.label4.Text = "از تاریخ:";
            // 
            // tarikh1mtxt
            // 
            this.tarikh1mtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tarikh1mtxt.Location = new System.Drawing.Point(213, 98);
            this.tarikh1mtxt.Mask = "9999/99/99";
            this.tarikh1mtxt.Name = "tarikh1mtxt";
            this.tarikh1mtxt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tarikh1mtxt.Size = new System.Drawing.Size(79, 20);
            this.tarikh1mtxt.TabIndex = 8;
            this.tarikh1mtxt.TextChanged += new System.EventHandler(this.tarikh1mtxt_TextChanged);
            this.tarikh1mtxt.Enter += new System.EventHandler(this.tarikh1mtxt_Enter);
            // 
            // idhesabbestankartxt
            // 
            this.idhesabbestankartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhesabbestankartxt.Location = new System.Drawing.Point(243, 64);
            this.idhesabbestankartxt.Name = "idhesabbestankartxt";
            this.idhesabbestankartxt.Size = new System.Drawing.Size(49, 20);
            this.idhesabbestankartxt.TabIndex = 6;
            this.idhesabbestankartxt.TextChanged += new System.EventHandler(this.idhesabbestankartxt_TextChanged);
            this.idhesabbestankartxt.Enter += new System.EventHandler(this.idhesabbestankartxt_Enter);
            this.idhesabbestankartxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idhesabbestankartxt_KeyDown);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(131, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 23);
            this.label2.TabIndex = 92;
            this.label2.Text = "نام حساب بستانکار:";
            // 
            // idhesabbedehkartxt
            // 
            this.idhesabbedehkartxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.idhesabbedehkartxt.Location = new System.Drawing.Point(243, 30);
            this.idhesabbedehkartxt.Name = "idhesabbedehkartxt";
            this.idhesabbedehkartxt.Size = new System.Drawing.Size(49, 20);
            this.idhesabbedehkartxt.TabIndex = 3;
            this.idhesabbedehkartxt.TextChanged += new System.EventHandler(this.idhesabbedehkartxt_TextChanged);
            this.idhesabbedehkartxt.Enter += new System.EventHandler(this.idhesabbedehkartxt_Enter);
            this.idhesabbedehkartxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.idhesabbedehkartxt_KeyDown);
            // 
            // namebestankarcmb
            // 
            this.namebestankarcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namebestankarcmb.FormattingEnabled = true;
            this.namebestankarcmb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.namebestankarcmb.Location = new System.Drawing.Point(15, 63);
            this.namebestankarcmb.Name = "namebestankarcmb";
            this.namebestankarcmb.Size = new System.Drawing.Size(116, 21);
            this.namebestankarcmb.TabIndex = 5;
            this.namebestankarcmb.SelectedIndexChanged += new System.EventHandler(this.namebestankarcmb_SelectedIndexChanged);
            this.namebestankarcmb.Enter += new System.EventHandler(this.namebestankarcmb_Enter);
            // 
            // sharhesanadtxt
            // 
            this.sharhesanadtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sharhesanadtxt.Location = new System.Drawing.Point(176, 132);
            this.sharhesanadtxt.Name = "sharhesanadtxt";
            this.sharhesanadtxt.Size = new System.Drawing.Size(116, 20);
            this.sharhesanadtxt.TabIndex = 11;
            this.sharhesanadtxt.TextChanged += new System.EventHandler(this.sharhesanadtxt_TextChanged);
            this.sharhesanadtxt.Enter += new System.EventHandler(this.sharhesanadtxt_Enter);
            // 
            // sharhrbtn
            // 
            this.sharhrbtn.AutoSize = true;
            this.sharhrbtn.Location = new System.Drawing.Point(339, 132);
            this.sharhrbtn.Name = "sharhrbtn";
            this.sharhrbtn.Size = new System.Drawing.Size(117, 17);
            this.sharhrbtn.TabIndex = 10;
            this.sharhrbtn.TabStop = true;
            this.sharhrbtn.Text = "براساس شرح سند:";
            this.sharhrbtn.UseVisualStyleBackColor = true;
            this.sharhrbtn.CheckedChanged += new System.EventHandler(this.sharhrbtn_CheckedChanged);
            // 
            // namebedehkarcmb
            // 
            this.namebedehkarcmb.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.namebedehkarcmb.FormattingEnabled = true;
            this.namebedehkarcmb.Location = new System.Drawing.Point(15, 29);
            this.namebedehkarcmb.Name = "namebedehkarcmb";
            this.namebedehkarcmb.Size = new System.Drawing.Size(116, 21);
            this.namebedehkarcmb.TabIndex = 2;
            this.namebedehkarcmb.SelectedIndexChanged += new System.EventHandler(this.namebedehkarcmb_SelectedIndexChanged);
            this.namebedehkarcmb.Enter += new System.EventHandler(this.namebedehkarcmb_Enter);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(128, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 23);
            this.label1.TabIndex = 90;
            this.label1.Text = "نام حساب بدهکار:";
            // 
            // tarikhrbtn
            // 
            this.tarikhrbtn.AutoSize = true;
            this.tarikhrbtn.Location = new System.Drawing.Point(341, 98);
            this.tarikhrbtn.Name = "tarikhrbtn";
            this.tarikhrbtn.Size = new System.Drawing.Size(115, 17);
            this.tarikhrbtn.TabIndex = 7;
            this.tarikhrbtn.TabStop = true;
            this.tarikhrbtn.Text = "براساس تاریخ سند:";
            this.tarikhrbtn.UseVisualStyleBackColor = true;
            this.tarikhrbtn.CheckedChanged += new System.EventHandler(this.tarikhrbtn_CheckedChanged);
            // 
            // bestankarrbtn
            // 
            this.bestankarrbtn.AutoSize = true;
            this.bestankarrbtn.Location = new System.Drawing.Point(300, 64);
            this.bestankarrbtn.Name = "bestankarrbtn";
            this.bestankarrbtn.Size = new System.Drawing.Size(156, 17);
            this.bestankarrbtn.TabIndex = 4;
            this.bestankarrbtn.TabStop = true;
            this.bestankarrbtn.Text = "براساس کد حساب بستانکار:";
            this.bestankarrbtn.UseVisualStyleBackColor = true;
            this.bestankarrbtn.CheckedChanged += new System.EventHandler(this.bestankarrbtn_CheckedChanged);
            // 
            // bedehkarrbtn
            // 
            this.bedehkarrbtn.AutoSize = true;
            this.bedehkarrbtn.Location = new System.Drawing.Point(308, 30);
            this.bedehkarrbtn.Name = "bedehkarrbtn";
            this.bedehkarrbtn.Size = new System.Drawing.Size(148, 17);
            this.bedehkarrbtn.TabIndex = 1;
            this.bedehkarrbtn.TabStop = true;
            this.bedehkarrbtn.Text = "براساس کد حساب بدهکار:";
            this.bedehkarrbtn.UseVisualStyleBackColor = true;
            this.bedehkarrbtn.CheckedChanged += new System.EventHandler(this.bedehkarrbtn_CheckedChanged);
            // 
            // چاپToolStripMenuItem
            // 
            this.چاپToolStripMenuItem.Name = "چاپToolStripMenuItem";
            this.چاپToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F7;
            this.چاپToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.چاپToolStripMenuItem.Text = "چاپ";
            this.چاپToolStripMenuItem.Click += new System.EventHandler(this.چاپToolStripMenuItem_Click);
            // 
            // darjbtn
            // 
            this.darjbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.darjbtn.Image = global::main1.Properties.Resources.ButtonNew;
            this.darjbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.darjbtn.Location = new System.Drawing.Point(305, 482);
            this.darjbtn.Name = "darjbtn";
            this.darjbtn.Size = new System.Drawing.Size(83, 28);
            this.darjbtn.TabIndex = 14;
            this.darjbtn.Text = "F2  درج ";
            this.darjbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.darjbtn.UseVisualStyleBackColor = true;
            this.darjbtn.Click += new System.EventHandler(this.darjbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.چاپToolStripMenuItem,
            this.انصرافToolStripMenuItem,
            this.بالاToolStripMenuItem,
            this.پایینToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(513, 24);
            this.menuStrip1.TabIndex = 67;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 222);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.Size = new System.Drawing.Size(489, 243);
            this.dataGridView1.TabIndex = 66;
            // 
            // frmSanadHesabdari
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(513, 529);
            this.Controls.Add(this.printbtn);
            this.Controls.Add(this.enserafbtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.darjbtn);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmSanadHesabdari";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فرم سند حسابداری";
            this.Load += new System.EventHandler(this.frmSanadHesabdari_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem بالاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem پایینToolStripMenuItem;
        private System.Windows.Forms.Button printbtn;
        private System.Windows.Forms.ToolStripMenuItem انصرافToolStripMenuItem;
        private System.Windows.Forms.Button enserafbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripMenuItem چاپToolStripMenuItem;
        private System.Windows.Forms.Button darjbtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MaskedTextBox idhesabbedehkartxt;
        private System.Windows.Forms.ComboBox namebestankarcmb;
        private System.Windows.Forms.TextBox sharhesanadtxt;
        private System.Windows.Forms.RadioButton sharhrbtn;
        private System.Windows.Forms.ComboBox namebedehkarcmb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton tarikhrbtn;
        private System.Windows.Forms.RadioButton bestankarrbtn;
        private System.Windows.Forms.RadioButton bedehkarrbtn;
        private System.Windows.Forms.MaskedTextBox idhesabbestankartxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox tarikh2mtxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox tarikh1mtxt;
        private System.Windows.Forms.RadioButton noehesabrbtn;
        private System.Windows.Forms.ComboBox noehesabcmb;

    }
}
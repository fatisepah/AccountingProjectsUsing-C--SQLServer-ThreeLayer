﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using DAL;
using BLL;

namespace main1.SanadeHesabdari
{
    public partial class frmTarazeAzmayeshiReport : Form
    {
        public frmTarazeAzmayeshiReport()
        {
            InitializeComponent();
        }
        private void frmTarazeAzmayeshiReport_Load(object sender, EventArgs e)
        {
            ReportDocument RD = new ReportDocument();
            RD.FileName = "TarazeAzmayeshi.rpt";
            DaftareKolData DKData = new DaftareKolData();
            RD.SetDataSource(DKData.DaftareKolComboShow1());
            crystalReportViewer1.ReportSource = RD;
            crystalReportViewer1.Show();
        }


    }
}

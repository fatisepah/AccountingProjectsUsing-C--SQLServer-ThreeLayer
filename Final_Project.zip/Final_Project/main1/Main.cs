﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using DAL;
using BLL;
using System.Diagnostics;
using System.IO;
namespace main1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        SanadeHesabdariData SHData = new SanadeHesabdariData();
        //
        CheckData CData = new CheckData();
        CheckDB CDB = new CheckDB();
        //
        KalayeKharidForoshData KKHFData = new KalayeKharidForoshData();
        KalayeKharidForoshDB KKHFDB = new KalayeKharidForoshDB();
        //
        FactorData FData = new FactorData();
        FactorDB FDB = new FactorDB();
        //
        RizFactorKerayeData RFKData = new RizFactorKerayeData();
        RizFactorKerayeDB RFKDB = new RizFactorKerayeDB();
        private void Main_Load(object sender, EventArgs e)
        {

            timer1.Enabled = true;
            date dd = new date();
            date1 dd1 = new date1();
            lbldate.Text = dd.print() ;
            lbldate1.Text = dd1.print();
            //
            loginkarbarrib.Enabled = true;
            logoutkarbarrib.Enabled = true;
            exitrib.Enabled = true;
            shutdownrib.Enabled = true;
            rebootrib.Enabled = true;
            logoffrib.Enabled = true;
            //
            kalakerayerib.Enabled = false;
            kalakharidforoshrib.Enabled = false;
            moshtaririb.Enabled = false;
            hesabbankirib.Enabled = false;
            karbarrib.Enabled = false;
            sanadhesabdaririb.Enabled = false;
            roidadegheiremalirib.Enabled = false;
            hesabrib.Enabled = false;
            groupkalarib.Enabled = false;
            checkrib.Enabled = false;
            havalerib.Enabled = false;
            ghestyrib.Enabled = false;
            naghdrib.Enabled = false;
            //
            factorkharidrib.Enabled = false;
            factorforoshrib.Enabled = false;
            factorkerayerib.Enabled = false;
            //
            taraznamerib.Enabled = false;
            tarazazmayeshirib.Enabled = false;
            soratsarmayerib.Enabled = false;
            sorathoghoghsahebrib.Enabled = false;
            soratsodziyanrib.Enabled = false;
            mandekolrib.Enabled = false;
            dafatreroznamerib.Enabled = false;
            //
            mashinhesabrib.Enabled = false;
            //
            rahnamarib.Enabled = false;
            darbarerib.Enabled = false;

            //برای چک کردن تاریخ سر رسید چکهای دریافتی و پرداختی
            DataTable DT = new DataTable();
            DT = CData.CheckSearchID1();
            for (int i = 0; i < DT.Rows.Count; i++)
            {
                string TarikheSarResid = DT.Rows[i][3].ToString();
                string NameSahebeCheck = DT.Rows[i][4].ToString();
                string VazeiyatePardakht = DT.Rows[i][7].ToString();
                string Mablagh = DT.Rows[i][9].ToString();
                Mablagh = Class1.convert_str(Mablagh);
                TarikheSarResid = Class1.Tarikh(TarikheSarResid);
                TarikheSarResid = TarikheSarResid.Substring(0, 10);
                int TarikheSarResid1 = Convert.ToInt32(TarikheSarResid.Replace("/", ""));
                int TarikheJari1 = Convert.ToInt32(Class1.TarikheJari.Replace("/", ""));
                if (TarikheSarResid1 <= TarikheJari1)
                {
                    if (VazeiyatePardakht == "پرداخت نشده")
                    {
                        checkpardakhtilbl.Text += "تاریخ چک آقای/شرکت" + " " + NameSahebeCheck + " " + "به مبلغ" + " " + Mablagh + " " + "سررسیده است\r\n";
                    }
                    if (VazeiyatePardakht == "دریافت نشده")
                    {
                        checkdaryaftilbl.Text += "تاریخ چک آقای/شرکت" + " " + NameSahebeCheck + " " + "به مبلغ" + " " + Mablagh + " " + "سررسیده است\r\n";
                    }

                }
            }
            //
            DataTable DT1 = new DataTable();
            DT1 = KKHFData.KalayeKharidForoshSearchID1();
            for (int i = 0; i < DT1.Rows.Count; i++)
            {
                string NameKala = DT1.Rows[i][3].ToString();
                int HadeaghaleTedad = Convert.ToInt32(DT1.Rows[i][6]);
                int TedadKala = Convert.ToInt32(DT1.Rows[i][7]);
                if (TedadKala <= HadeaghaleTedad)
                {
                    lblkalasefareshi .Text = " موجودی کالای " + " " + NameKala + ", " + "به حداقل رسیده است\r\n";
                }
            }
            DataTable DT2 = new DataTable();
            DataTable DT3 = new DataTable();
            DT2 = FData.FactorSearchID1();
            DT3 = RFKData.RizFactorKerayeSearchID1();

            for (int i = 0; i < DT2.Rows.Count; i++)
            {
                int IDFactor = Convert.ToInt32(DT2.Rows[i][0]);
                string NameMoshtari = DT2.Rows[i][4].ToString();

                for (int i1 = 0; i1 < DT3.Rows.Count; i1++)
                {
                    int FKFactor = Convert.ToInt32(DT3.Rows[i1][9]);
                    string TarikheBargasht = DT3.Rows[i1][10].ToString();
                    string s = Class1.Tarikh(TarikheBargasht);
                    int TarikheBargasht1 = Convert.ToInt32(s.Replace("/", ""));
                    int TarikheJari1 = Convert.ToInt32(Class1.TarikheJari.Replace("/", ""));
                    if (FKFactor == IDFactor && TarikheBargasht1 <= TarikheJari1)
                    {
                        lblkalakeraye.Text = " زمان برگشت کالاهای کرایه داده شده به آقای/خانم/شرکت " + " " + NameMoshtari + " " + "سر رسیده است\r\n";
                    }
                }
            }
        }
        public string Miladi2Shasi(DateTime date)
        {
            PersianCalendar pc=new PersianCalendar ();
            StringBuilder sb=new StringBuilder ();
            sb.Append (pc.GetYear (date ).ToString ("0000"));
            lblsalemali.Text=sb.ToString ();
            sb.Append ("/");
            sb.Append (pc.GetMonth (date ).ToString ("00"));
            sb.Append ("/");
            sb.Append(pc.GetDayOfMonth (date ).ToString ("00"));
            return sb.ToString ();
        }

        public string Miladi2Shasi1(DateTime date1)
        {
            PersianCalendar pc = new PersianCalendar();
            StringBuilder sbtarikh = new StringBuilder();        
            sbtarikh .Append(pc.GetHour(date1).ToString("00"));
            sbtarikh.Append(":");
            sbtarikh.Append(pc.GetMinute(date1).ToString("00"));
            sbtarikh.Append(":");
            sbtarikh.Append(pc.GetSecond(date1).ToString("00"));
            return sbtarikh.ToString();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            KalayeKeraye.frmGroupKala obj = new KalayeKeraye.frmGroupKala();
            obj.ShowDialog ();
        }



        private void sanadhesabdaririb_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmSanadHesabdari obj = new SanadeHesabdari.frmSanadHesabdari();
            obj.ShowDialog();
        }

        private void roidadegheiremalirib_Click(object sender, EventArgs e)
        {
            RoidadeGheireMali.frmRoidadeGheireMali obj = new RoidadeGheireMali.frmRoidadeGheireMali();
            obj.ShowDialog();
        }

        private void karbarrib_Click(object sender, EventArgs e)
        {
            Karbar.frmKarbar obj = new Karbar.frmKarbar();
            obj.ShowDialog();
        }

        private void hesabbankirib_Click(object sender, EventArgs e)
        {
            HesabBanki.frmHesabBanki obj = new HesabBanki.frmHesabBanki();
            obj.ShowDialog();
        }

        private void moshtaririb_Click(object sender, EventArgs e)
        {
            Moshtari.frmMoshtarian obj = new Moshtari.frmMoshtarian();
            obj.ShowDialog();
        }

        private void kalakharidforoshrib_Click(object sender, EventArgs e)
        {
            KalayeKharidForosh.frmKalayeKharidForosh obj = new KalayeKharidForosh.frmKalayeKharidForosh();
            obj.ShowDialog();
        }

        private void kalakerayerib_Click(object sender, EventArgs e)
        {
            KalayeKeraye.frmKalayeKeraye obj = new KalayeKeraye.frmKalayeKeraye();
            obj.ShowDialog();
        }

        private void groupkalarib_Click(object sender, EventArgs e)
        {
            KalayeKeraye.frmGroupKala obj = new KalayeKeraye.frmGroupKala();
            obj.ShowDialog();
        }

        private void exitrib_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مایل به خروج از برنامه هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void shutdownrib_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا مایل به خاموش کردن سیستم هستید؟", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Shutdown
                System.Diagnostics.Process.Start("ShutDown", "/s");
            }

        }

        private void logoutkarbarrib_Click(object sender, EventArgs e)
        {
            loginkarbarrib.Enabled = true;
            logoutkarbarrib.Enabled = true;
            exitrib.Enabled = true;
            shutdownrib.Enabled = true;
            rebootrib.Enabled = true;
            logoffrib.Enabled = true;
            //
            kalakerayerib.Enabled = false;
            kalakharidforoshrib.Enabled = false;
            moshtaririb.Enabled = false;
            hesabbankirib.Enabled = false;
            karbarrib.Enabled = false;
            sanadhesabdaririb.Enabled = false;
            roidadegheiremalirib.Enabled = false;
            hesabrib.Enabled = false;
            groupkalarib.Enabled = false;
            checkrib.Enabled = false;
            havalerib.Enabled = false;
            ghestyrib.Enabled = false;
            naghdrib.Enabled = false;
            //
            factorkharidrib.Enabled = false;
            factorforoshrib.Enabled = false;
            factorkerayerib.Enabled = false;
            //
            taraznamerib.Enabled = false;
            tarazazmayeshirib.Enabled = false;
            soratsarmayerib.Enabled = false;
            sorathoghoghsahebrib.Enabled = false;
            soratsodziyanrib.Enabled = false;
            mandekolrib.Enabled = false;
            dafatreroznamerib.Enabled = false;
            //
            mashinhesabrib.Enabled = false;
            //
            rahnamarib.Enabled = false;
            darbarerib.Enabled = false;
            Class1.NameFamilyKarbar = "";
            lblkarbar.Text = "";
            MessageBox.Show(".کاربر محترم نام کاربری و رمز عبور خود را وارد کنید", "", MessageBoxButtons.OK);
        }

        private void restartrib_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("سیستم هستید؟ Reboot آیا مایل به ", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start("ShutDown", "/r");
            }
        }
      
        private void logoffrib_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("سیستم هستید؟ LogOff آیا مایل به ", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start("ShutDown", "/l");
            }
        }

        private void mashinhesabrib_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc");
        }

        private void loginkarbarrib_Click_1(object sender, EventArgs e)
        {
            Login obj = new Login();
            if (obj.ShowDialog() == DialogResult.OK)
            {
            }
            if(Class1.SemateKarbar=="مدیر")
                karbarrib.Enabled = true;
            else
                karbarrib.Enabled = false;

            lblkarbar.Text = Class1.NameFamilyKarbar;
            kalakerayerib.Enabled = true;
            kalakharidforoshrib.Enabled = true;
            moshtaririb.Enabled = true;
            hesabbankirib.Enabled = true;
            sanadhesabdaririb.Enabled = true;
            roidadegheiremalirib.Enabled = true;
            hesabrib.Enabled = true;
            groupkalarib.Enabled = true;
            checkrib.Enabled = true;
            havalerib.Enabled = true;
            ghestyrib.Enabled = true;
            naghdrib.Enabled = true;
            //
            factorkharidrib.Enabled = true;
            factorforoshrib.Enabled = true;
            factorkerayerib.Enabled = true;
            //
            taraznamerib.Enabled = true;
            tarazazmayeshirib.Enabled = true;
            soratsarmayerib.Enabled = true;
            sorathoghoghsahebrib.Enabled = true;
            soratsodziyanrib.Enabled = true;
            mandekolrib.Enabled = true;
            dafatreroznamerib.Enabled = true;
            //
            mashinhesabrib.Enabled = true;
            //
            rahnamarib.Enabled = true;
            darbarerib.Enabled = true;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            //lbldate.Text = Miladi2Shasi(DateTime.Now);
            lbltime.Text = Miladi2Shasi1(DateTime.Now);
            Class1.SaateJari = Miladi2Shasi1(DateTime.Now);
            Class1.TarikheJari = Miladi2Shasi(DateTime.Now);
        }

        private void hesabrib_Click(object sender, EventArgs e)
        {
            Hesabha.frmHesabha obj = new Hesabha.frmHesabha();
            obj.ShowDialog();
        }

        private void checkrib_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmCheck obj = new Taraconeshha.frmCheck();
            obj.ShowDialog();
        }

        private void havalerib_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmHavale obj = new Taraconeshha.frmHavale();
            obj.ShowDialog();
        }

        private void ghestyrib_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmGhesty obj = new Taraconeshha.frmGhesty();
            obj.ShowDialog();
        }

        private void naghdrib_Click(object sender, EventArgs e)
        {
            Taraconeshha.frmNaghd obj = new Taraconeshha.frmNaghd();
            obj.ShowDialog();
        }

        private void tarazazmayeshirib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmTarazeAzmayeshiReport obj = new SanadeHesabdari.frmTarazeAzmayeshiReport();
            obj.ShowDialog();
        }

        private void dafatreroznamerib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmDaftareRoznameReport obj = new SanadeHesabdari.frmDaftareRoznameReport();
            obj.ShowDialog();
        }

        private void factorkerayerib_Click(object sender, EventArgs e)
        {
            Factors .frmAddFactorKeraye1 obj = new Factors.frmAddFactorKeraye1 ();
            obj.ShowDialog();
        }

        private void factorkharidrib_Click(object sender, EventArgs e)
        {
            Factors.frmAddFactorKharid obj = new Factors.frmAddFactorKharid();
            obj.ShowDialog();
        }

        private void factorforoshrib_Click(object sender, EventArgs e)
        {
            Factors.frmAddFactorForosh1  obj = new Factors.frmAddFactorForosh1 ();
            obj.ShowDialog();
        }

        private void taraznamerib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.Tarazname obj = new SanadeHesabdari.Tarazname();
            obj.ShowDialog();
        }

        private void sorathoghoghsahebrib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmSorateSoodVaZiyaneBazargani obj = new SanadeHesabdari.frmSorateSoodVaZiyaneBazargani ();
            obj.ShowDialog();
        }

        private void soratsodziyanrib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmSorateSoodVaZiyaneKhadamati  obj = new SanadeHesabdari.frmSorateSoodVaZiyaneKhadamati ();
            obj.ShowDialog();
        }

        private void mandekolrib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmTarazeAzmayeshiReport obj = new SanadeHesabdari.frmTarazeAzmayeshiReport();
            obj.ShowDialog();
        }

        private void checkpardakhtchb_CheckedChanged(object sender, EventArgs e)
        {
            if(checkpardakhtchb.Checked == true )
                checkpardakhtGB.Visible = true;
            else
                checkpardakhtGB.Visible = false;

        }

        private void checkvosolchb_CheckedChanged(object sender, EventArgs e)
        {
            if (checkvosolchb.Checked == true)
                checkvosolGB.Visible = true;
            else
                checkvosolGB.Visible = false ;

        }

        private void kalakerayechb_CheckedChanged(object sender, EventArgs e)
        {
            if (kalakerayechb.Checked == true)
                kalakerayeGB.Visible = true;
            else
                kalakerayeGB.Visible = false ;

        }

        private void hadeaghalekalachb_CheckedChanged(object sender, EventArgs e)
        {
            if (hadeaghalekalachb.Checked == true)
                hadeaghalekalaGB.Visible = true;
            else
                hadeaghalekalaGB.Visible = false ;

        }

        private void ribbonButton20_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.System) + Path.DirectorySeparatorChar + "osk.exe");

        }

        private void ribbonButton21_Click(object sender, EventArgs e)
        {
            frmMandeHesab obj = new frmMandeHesab();
            obj.ShowDialog();
        }

        private void soratsarmayerib_Click(object sender, EventArgs e)
        {
            SanadeHesabdari.frmSarmaye obj = new SanadeHesabdari.frmSarmaye();
            obj.ShowDialog();
        }



        
    }
}

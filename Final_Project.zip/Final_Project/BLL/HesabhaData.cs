﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class HesabhaData:HesabhaManagment1
    {
       DataView dw = new DataView();
       public DataTable  HesabhaComboShow1()
       {
           return HesabhaComboShow2();
       }

       public DataView HesabhaShow1()
       {
           return HesabhaShow2();
       }
       public DataTable  HesabhaReportShow1()
       {
           return HesabhaReportShow2();
       }
       public DataView FilterNoeHesab1(string NoeHesab)
       {
           dw.RowFilter = FilterKol2(NoeHesab);
           return dw;
       }
       public DataView FilterKol1(string NameHesabKol)
       {
           dw.RowFilter = FilterKol2(NameHesabKol);
           return dw;
       }
       public DataView FilterMoien1(string NameHesabMoien)
       {
           dw.RowFilter = FilterMoien2(NameHesabMoien);
           return dw;
       }
       public DataView FilterTafzily1(string NameHesabTafzily)
       {
           dw.RowFilter = FilterTafzily2(NameHesabTafzily);
           return dw;
       }
       public void HesabhaInsert1(HesabhaDB bd)
        {
            HesabhaInsert2(bd);
        }
       public void HesabhaDelete1(int IDHesab)
        {
            HesabhaDelete2(IDHesab);
        }
       public void HesabhaUpdate1(HesabhaDB bd)
       {
           HesabhaUpdate2(bd);
       }
       public Boolean HesabhaSearch1(int IDHesab)
       {
           return HesabhaSearch2(IDHesab);
       }
       public DataTable HesabhaSearchID1()
       {
           return HesabhaSearchID2();
       }
       public HesabhaDB  HesabhaFind1(int IDHesab)
       {
           DataRow dr = HesabhaFind2(IDHesab);
           HesabhaDB bd = new HesabhaDB ();
           bd.IDHesab= Convert.ToInt32(dr[0].ToString());
           bd.NoeHesab = dr[1].ToString();
           bd.CodeHesabeKol  = Convert.ToInt32(dr[2].ToString());
           bd.NameHesabKol  = dr[3].ToString();
           bd.CodeHesabeMoien  = Convert.ToInt32(dr[4].ToString());
           bd.NameHesabMoien  = dr[5].ToString();
           bd.CodeHesabeTafzily = Convert.ToInt32(dr[6].ToString());
           bd.NameHesabTafzily = dr[7].ToString();
           return bd;
       }
    }
}

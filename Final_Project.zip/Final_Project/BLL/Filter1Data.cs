﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class Filter1Data : BankManagement
    {
        DataView dw = new DataView();
        
        public DataView get_data()
        {
            dw = show_data();
            return dw;
        }
    
        public DataView Filter(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
       
        public DataView FilterNoeHesab1(string NoeHesab)
        {
            dw.RowFilter = FilterNoeHesab2(NoeHesab);
            return dw;
        }
        public DataView FilterMoien1(string NameHesabMoien)
        {
            dw.RowFilter = FilterMoien2(NameHesabMoien);
            return dw;
        }
        public DataView FilterTafzily1(string NameHesabTafzily)
        {
            dw.RowFilter = FilterTafzily2(NameHesabTafzily);
            return dw;
        }
     
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class KalayeKerayeData:KalayeKerayeManagment 
    {
        DataView dw = new DataView();

        public DataView KalayeKerayeShow1()
        {
            return KalayeKerayeShow2();
        }
        public DataTable  KalayeKerayeReportShow1()
        {
            return KalayeKerayeReportShow2();
        }
       //
       ///////////////////////////////////////فیلترها
       //
        public DataView FilterFKGroupKala1(int FKGroupKala)
        {
            dw.RowFilter = FilterFKGroupKala2(FKGroupKala);
            return dw;
        }
        public DataView FilterNameKala1(string NameKala)
        {
            dw.RowFilter = FilterNameKala2(NameKala);
            return dw;
        }
        public DataView FilterVaziyateKeraye1(string VaziyateKeraye)
        {
            dw.RowFilter = FilterVaziyateKeraye2(VaziyateKeraye);
            return dw;
        }
        public DataView FilterNSherkat1(string NameSherkatTolidi)
        {
            dw.RowFilter = FilterNSherkat2(NameSherkatTolidi);
            return dw;
        }

       //
       //////////////////////////////////
       //
       //
        public void KalayeKerayeInsert1(KalayeKerayeDB bd)
        {
            KalayeKerayeInsert2(bd);
        }
        public void KalayeKerayeDelete1(int IDKalaKeraye)
        {
            KalayeKerayeDelete2(IDKalaKeraye);
        }
        public void KalayeKerayeUpdate1(KalayeKerayeDB bd)
        {
            KalayeKerayeUpdate2(bd);
        }
        public Boolean KalayeKerayeSearch1(int IDKalaKeraye)
        {
            return KalayeKerayeSearch2(IDKalaKeraye);
        }
        public DataTable KalayeKerayeSearchID1()
        {
            return KalayeKerayeSearchID2();
        }
        public KalayeKerayeDB KalayeKerayeFind1(int IDKalaKeraye)
        {
            DataRow dr = KalayeKerayeFind2(IDKalaKeraye);
            KalayeKerayeDB bd = new KalayeKerayeDB();
            bd.IDKalaKeraye  = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeKala  = Convert.ToInt32(dr[1].ToString());
            bd.FKGroupKala  =Convert.ToInt32( dr[2].ToString());
            bd.NameKala  = dr[3].ToString();
            bd.VaziyateKeraye = dr[4].ToString();
            bd.Tozihat  = dr[5].ToString();
            bd.GheimateKharid  = Convert.ToInt64(dr[6].ToString());
            bd.GheimateKeraye  = Convert.ToInt64(dr[7].ToString());
            bd.TedadeKalayeMojod = Convert.ToInt32(dr[8].ToString());
            bd.TedadeKerayeDadeShode = Convert.ToInt32(dr[9].ToString());
            bd.Garanty = dr[10].ToString();
            bd.ModeleKala = dr[11].ToString();
            bd.BarcodeKala = dr[12].ToString();
            bd.NameSherkatTolidi = dr[13].ToString();

            return bd;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterNaghdData: FilterNaghdManagment
    {
        DataView dw = new DataView();
        
        public DataView NaghdShow1()
        {
            dw = show_data();
            return dw;
        }



        public DataView FilterTarikheSabt1(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
       public DataView FilterNamePardakhtKonande1(DateTime  TarikheSanad)
        {
            dw.RowFilter = FilterTarikh2(TarikheSanad);
            return dw;
        }
        public DataView FilterFKFactor1(int FKHesabeBedehkar)
        {
            dw.RowFilter = FilterHBedehkar2(FKHesabeBedehkar);
            return dw;
        }
       

       
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.SqlClient;
namespace BLL
{
   public class FactorData:FactorManagment 
    {
        DataView dw = new DataView();
        public DataTable FactorComboShow1()
        {
            return FactorComboShow2();
        }

        public DataView FactorShow1()
        {
            return FactorShow2();
        }


        //فیلترها
        public DataView FilterNameMoshtari1(string NameMoshtari)
        {
            dw.RowFilter = FilterNameMoshtari2(NameMoshtari);
            return dw;
        }
        public DataView FilterNameRanande1(string NameRanande)
        {
            dw.RowFilter = FilterNameRanande2(NameRanande);
            return dw;
        }
        public DataView FilterKerayeHaml1(long KerayeHaml)
        {
            dw.RowFilter = FilterKerayeHaml2(KerayeHaml);
            return dw;
        }
        public DataView FilterTarikheFactor1(DateTime TarikheFactor)
        {
            dw.RowFilter = FilterTarikheFactor2(TarikheFactor);
            return dw;
        }
        public DataView FilterNameKarbar1(string NameKarbar)
        {
            dw.RowFilter = FilterNameKarbar2(NameKarbar);
            return dw;
        }
        //
        //
        //
        public void FactorInsert1(FactorDB bd)
        {
            FactorInsert2(bd);
        }
        public void FactorDelete1(int IDFactor)
        {
            FactorDelete2(IDFactor);
        }
        public void FactorUpdate1(FactorDB bd)
        {
            FactorUpdate2(bd);
        }
        public Boolean FactorSearch1(int IDFactor)
        {
            return FactorSearch2(IDFactor);
        }
        public DataTable FactorSearchID1()
        {
            return FactorSearchID2();
        }
        public FactorDB FactorFind1(int IDFactor)
        {
            DataRow dr = FactorFind2(IDFactor);
            FactorDB bd = new FactorDB();
            bd.IDFactor  = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeFactor  = Convert.ToInt32(dr[1].ToString());
            bd.FKNoeMoshtari  = Convert.ToInt32(dr[2].ToString());
            bd.FKMoshtari = Convert.ToInt32(dr[3].ToString());
            bd.NameMoshtari  = dr[4].ToString();
            bd.FKSanadeHesabdari =Convert.ToInt32( dr[5].ToString());
            bd.NameKarbar  = dr[6].ToString();
            bd.TarikheFactor =Convert.ToDateTime( dr[7].ToString());
            bd.DarsadeTakhfif = dr[8].ToString();
            bd.NameRanande  = dr[9].ToString();
            bd.DastMozdeKargareBarbari = Convert.ToInt64(dr[10].ToString());
            bd.KerayeHaml = Convert.ToInt64(dr[11].ToString());
            return bd;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterSanadeHesabdariData: FilterSanadeHesabdariManagment
    {
        DataView dw = new DataView();
        
        public DataView SanadeHesabdariShow1()
        {
            dw = show_data();
            return dw;
        }



        public DataView FilterSharheSanad1(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
       public DataView FilterTarikh1(DateTime  TarikheSanad)
        {
            dw.RowFilter = FilterTarikh2(TarikheSanad);
            return dw;
        }
        public DataView FilterHBedehkar1(int FKHesabeBedehkar)
        {
            dw.RowFilter = FilterHBedehkar2(FKHesabeBedehkar);
            return dw;
        }
        public DataView FilterHBestankar1(int FKHesabeBestankar)
        {
            dw.RowFilter = FilterHBestankar2(FKHesabeBestankar);
            return dw;
        }
               

       
       
    }
}

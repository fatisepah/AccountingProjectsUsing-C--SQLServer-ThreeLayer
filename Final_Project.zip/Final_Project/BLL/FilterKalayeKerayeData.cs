﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterKalayeKerayeData: FilterKalayeKerayeManagment
    {
        DataView dw = new DataView();
        
        public DataView KalayeKerayeShow1()
        {
            dw = show_data();
            return dw;
        }



        public DataView FilterFKGroupKala1(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
        public DataView FilterNameKala1(string barangh)
        {
            dw.RowFilter = Filter1(barangh);
            return dw;
        }
        public DataView FilterVaziyateKeraye1(string VaziyateKeraye)
        {
            dw.RowFilter = FilterVaziyateKeraye2(VaziyateKeraye);
            return dw;
        }
        public DataView FilterNSherkat1(string NameSherkatTolidi)
        {
            dw.RowFilter = FilterNSherkat2(NameSherkatTolidi);
            return dw;
        }

       
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BLL
{
   public  class GhestyData:GhestyManagment 
    {
        DataView dw = new DataView();
        public DataTable GhestyComboShow1()
        {
            return GhestyComboShow2();
        }

        public DataView GhestyShow1()
        {
            return GhestyShow2();
        }


        //فیلترها
        public DataView FilterTarikheSabteGhest1(DateTime TarikheSabteGhest)
        {
            dw.RowFilter = FilterTarikheSabteGhesti2(TarikheSabteGhest);
            return dw;
        }
        public DataView FilterNameDahandeGhest1(string NameDahandeGhest)
        {
            dw.RowFilter = FilterNameDahandeGhest2(NameDahandeGhest);
            return dw;
        }
        public DataView FilterTarikhePardakhteAghsat1(DateTime  TarikhePardakhteAghsat)
        {
            dw.RowFilter = FilterTarikhePardakhteAghsat2(TarikhePardakhteAghsat);
            return dw;
        }
        public DataView FilterFKFactor1(int FKFactor)
        {
            dw.RowFilter = FilterFKFactor2(FKFactor);
            return dw;
        }
       //
       //

        public void GhestyInsert1(GhestyDB bd)
        {
            GhestyInsert2(bd);
        }
        public void GhestyDelete1(int IDGhesty)
        {
            GhestyDelete2(IDGhesty);
        }
        public void GhestyUpdate1(GhestyDB bd)
        {
            GhestyUpdate2(bd);
        }
        public Boolean GhestySearch1(int IDGhesty)
        {
            return GhestySearch2(IDGhesty);
        }
        public DataTable GhestySearchID1()
        {
            return GhestySearchID2();
        }
        public GhestyDB GhestyFind1(int IDGhesty)
        {
            DataRow dr = GhestyFind2(IDGhesty);
            GhestyDB bd = new GhestyDB();
            bd.IDGhesty = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeTaraconesh = Convert.ToInt32(dr[1].ToString());
            bd.TarikheSabteGhesti  = Convert.ToDateTime(dr[2].ToString());
            bd.NameDahandeGhest = dr[3].ToString();
            bd.TedadeAghsat  = Convert.ToInt32 (dr[4].ToString());
            bd.TarikhePardakhteAghsat  = Convert.ToDateTime(dr[5].ToString());
            bd.TedadeAghsateMande  =Convert.ToInt32( dr[6].ToString());
            bd.MablagheGhest  = Convert .ToInt64 (dr[6].ToString());
            bd.DarsadeSodeGhest = dr[7].ToString();
            return bd;
        }
    }
}

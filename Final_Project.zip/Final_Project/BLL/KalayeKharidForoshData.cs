﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
   public  class KalayeKharidForoshData:KalayeKharidForoshManagment 
    {
        DataView dw = new DataView();

        public DataView KalayeKharidForoshShow1()
        {
            return KalayeKharidForoshShow2();
        }
        public DataTable  KalayeKharidForoshComboShow1()
        {
            return KalayeKharidForoshComboShow2();
        }
        //
        ///////////////////////////////////////فیلترها
        //
        public DataView FilterFKGroupKala1(int FKGroupKala)
        {
            dw.RowFilter = FilterFKGroupKala2(FKGroupKala);
            return dw;
        }
        public DataView FilterNameKala1(string NameKala)
        {
            dw.RowFilter = FilterNameKala2(NameKala);
            return dw;
        }
        public DataView FilterNSherkat1(string NameSherkatTolidi)
        {
            dw.RowFilter = FilterNSherkat2(NameSherkatTolidi);
            return dw;
        }

        //
        //////////////////////////////////
        //
        //
        public void KalayeKharidForoshInsert1(KalayeKharidForoshDB bd)
        {
            KalayeKharidForoshInsert2(bd);
        }
        public void KalayeKharidForoshDelete1(int IDKalaKHF)
        {
            KalayeKharidForoshDelete2(IDKalaKHF);
        }
        public void KalayeKharidForoshUpdate1(KalayeKharidForoshDB bd)
        {
            KalayeKharidForoshUpdate2(bd);
        }
        public Boolean KalayeKharidForoshSearch1(int IDKalaKHF)
        {
            return KalayeKharidForoshSearch2(IDKalaKHF);
        }
        public DataTable KalayeKharidForoshSearchID1()
        {
            return KalayeKharidForoshSearchID2();
        }
        public KalayeKharidForoshDB KalayeKharidForoshFind1(int IDKalaKHF)
        {
            DataRow dr = KalayeKharidForoshFind2(IDKalaKHF);
            KalayeKharidForoshDB bd = new KalayeKharidForoshDB();
            bd.IDKalaKHF = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeKala = Convert.ToInt32(dr[1].ToString());
            bd.FKGroupKala = Convert.ToInt32(dr[2].ToString());
            bd.NameKala  =dr[3].ToString();
            bd.VahedeShomaresheAsli  = dr[4].ToString();
            bd.VahedeShomaresheFare = dr[5].ToString();
            bd.HadeaghaleTedadeMojod = Convert.ToInt32(dr[6].ToString());
            bd.TedadeKala = Convert.ToInt32(dr[7].ToString());
            bd.Tozihat = dr[8].ToString();
            bd.TarikheTolid = Convert.ToDateTime(dr[9].ToString());
            bd.TarikheEngheza = Convert.ToDateTime(dr[10].ToString());
            bd.GheimateKharid  = Convert.ToInt64(dr[11].ToString());
            bd.GheimateForosh  = Convert.ToInt64(dr[12].ToString());
            bd.Garanty = dr[13].ToString();
            bd.ModeleKala = dr[14].ToString();
            bd.BarcodeKala = dr[15].ToString();
            bd.NameSherkatTolidi = dr[16].ToString();

            return bd;
        }
    }
}

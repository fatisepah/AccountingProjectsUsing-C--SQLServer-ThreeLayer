﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.SqlClient;
namespace BLL
{
   public  class TaraznameData:TaraznameManagment 
    {
        DataView dw = new DataView();
        public DataView TaraznameShow1()
        {
            return TaraznameShow2();
        }
        public void TaraznameInsert1(TaraznameDB bd)
        {
            TaraznameInsert2(bd);
        }

        public void TaraznameUpdate1(TaraznameDB bd)
        {
            TaraznameUpdate2(bd);
        }
        public Boolean TaraznameSearch1(int IDTarazname)
        {
            return TaraznameSearch2(IDTarazname);
        }
        public TaraznameDB TaraznameFind1(int IDTarazname)
        {
            DataRow dr = TaraznameFind2(IDTarazname);
            TaraznameDB bd = new TaraznameDB();
            bd.IDTarazname = Convert.ToInt32(dr[0].ToString());
            bd.VajheNaghd = Convert.ToInt64(dr[1].ToString());
            bd.HesabhayeDaryaftani  = Convert.ToInt64(dr[2].ToString());
            bd.AsnadeDaryaftaniyeKotahModat = Convert.ToInt64(dr[3].ToString());
            bd.PishPardakhteBime_Hazine = Convert.ToInt64(dr[4].ToString());
            bd.SUMDaraeehayeJari = Convert.ToInt64(dr[5].ToString());
            bd.Zamin = Convert.ToInt64(dr[6].ToString());
            bd.Sakhteman = Convert.ToInt64(dr[7].ToString());
            bd.EstehlakeSakhteman  = Convert.ToInt64(dr[8].ToString());
            bd.ArzesheDaftariyeSakhteman  = Convert.ToInt64(dr[9].ToString());
            bd.VasayeleNaghliye  = Convert.ToInt64(dr[10].ToString());
            bd.EstehlakeVasayeleNaghliye  = Convert.ToInt64(dr[11].ToString());
            bd.ArzesheDaftariyeVasayeleNaghliye  = Convert.ToInt64(dr[12].ToString());
            bd.SarGhofli  = Convert.ToInt64(dr[13].ToString());
            bd.SUMDaraeehayeSabet  = Convert.ToInt64(dr[14].ToString());
            bd.SUMDaraeeha  = Convert.ToInt64(dr[15].ToString());
            bd.HesabhayePardakhtani  = Convert.ToInt64(dr[16].ToString());
            bd.AsnadePardakhtaniyeKotahModat  = Convert.ToInt64(dr[17].ToString());
            bd.PishDaryafteDaramad  = Convert.ToInt64(dr[18].ToString());
            bd.MaliyatePardakhtani  = Convert.ToInt64(dr[19].ToString());
            bd.EzafeBardashteBanki  = Convert.ToInt64(dr[20].ToString());
            bd.SUMBedehihayeJari  = Convert.ToInt64(dr[21].ToString());
            bd.AsnadePardakhtaniyeBolandModat  = Convert.ToInt64(dr[22].ToString());
            bd.OragheGharzePardakhtani  = Convert.ToInt64(dr[23].ToString());
            bd.SUMBedehihayeBolandModat  = Convert.ToInt64(dr[24].ToString());
            bd.SUMBedehiha  = Convert.ToInt64(dr[25].ToString());
            bd.FKSarmaye  = Convert.ToInt32(dr[26].ToString());
            bd.SUMBedehihaVaSarmaye  = Convert.ToInt64(dr[27].ToString());
            return bd;
        }
        public DataTable TaraznameSearchID1()
        {
            return TaraznameSearchID2();
        }
    }
}

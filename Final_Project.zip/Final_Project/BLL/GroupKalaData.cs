﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class GroupKalaData:GroupKalaManagment 
    {
        DataView dw = new DataView();
        public DataView GroupKalaShow1()
        {
            return GroupKalaShow2();
        }
        public DataTable  GroupKalaComboShow1()
        {
            return GroupKalaComboShow2();
        }
        public void GroupKalaInsert1(GroupKalaDB bd)
        {
            GroupKalaInsert2(bd);
        }
        public void GroupKalaUpdate1(GroupKalaDB bd)
        {
            GroupKalaUpdate2(bd);
        }
        public void GroupKalaDelete1(int IDGroupKala)
        {
            GroupKalaDelete2(IDGroupKala);
        }

        public Boolean GroupKalaSearch1(int IDGroupKala)
        {
            return GroupKalaSearch2(IDGroupKala);
        }
        public Boolean GroupKalaSearchName1(string  NameGroup)
        {
            return GroupKalaSearchName2(NameGroup);
        }
        public DataTable GroupKalaSearchID1()
        {
            return GroupKalaSearchID2();
        }
        public GroupKalaDB GroupKalaFind1(int IDGroupKala)
        {
            DataRow dr = GroupKalaFind2(IDGroupKala);
            GroupKalaDB bd = new GroupKalaDB();
            bd.IDGroupKala = Convert.ToInt32(dr[0].ToString());
            bd.NameGroup  = dr[1].ToString();
            return bd;
        }
        public GroupKalaDB GroupKalaFindName1(string NameGroup)
        {
            DataRow dr = GroupKalaFindName2 (NameGroup);
            GroupKalaDB bd = new GroupKalaDB();
            bd.IDGroupKala = Convert.ToInt32(dr[0].ToString());
            bd.NameGroup = dr[1].ToString();
            return bd;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterRoidadeGheireMaliData: FilterRoidadeGheireMaliManagment
    {
        DataView dw = new DataView();
        
        public DataView RoidadeGheireMaliShow1()
        {
            dw = show_data();
            return dw;
        }



        public DataView Filter1(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
       
               

       
       
    }
}

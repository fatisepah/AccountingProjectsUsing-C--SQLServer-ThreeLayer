﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BLL
{
   public  class RizFactorKharidForoshData:RizFactorKharidForoshManagment 
    {
        DataView dw = new DataView();
        public DataTable RizFactorKharidForoshComboShow1()
        {
            return RizFactorKharidForoshComboShow2();
        }

        public DataView RizFactorKharidForoshShow1()
        {
            return RizFactorKharidForoshShow2();
        }


        //فیلترها

        //
        public DataView FilterNameKalayeKharidForosh11(string NameKalayeKharidForosh1)
        {
            dw.RowFilter = FilterNameKalayeKharidForosh12(NameKalayeKharidForosh1);
            return dw;
        }
        public DataView FilterNameKalayeKharidForosh21(string NameKalayeKharidForosh2)
        {
            dw.RowFilter = FilterNameKalayeKharidForosh22(NameKalayeKharidForosh2);
            return dw;
        }
        public DataView FilterNameKalayeKharidForosh31(string NameKalayeKharidForosh3)
        {
            dw.RowFilter = FilterNameKalayeKharidForosh32(NameKalayeKharidForosh3);
            return dw;
        }
        public DataView FilterNameKalayeKharidForosh41(string NameKalayeKharidForosh4)
        {
            dw.RowFilter = FilterNameKalayeKharidForosh42(NameKalayeKharidForosh4);
            return dw;
        }
        //
        //
        //
        public void RizFactorKerayeInsert1(RizFactorKharidForoshDB bd)
        {
            RizFactorKharidForoshInsert2(bd);
        }
        public void RizFactorKharidForoshDelete1(int IDFactorKHF)
        {
            RizFactorKharidForoshDelete2(IDFactorKHF);
        }
        public void RizFactorKharidForoshUpdate1(RizFactorKharidForoshDB bd)
        {
            RizFactorKharidForoshUpdate2(bd);
        }
        public Boolean RizFactorKharidForoshSearch1(int IDFactorKHF)
        {
            return RizFactorKharidForoshSearch2(IDFactorKHF);
        }
        public DataTable RizFactorKharidForoshSearchID1()
        {
            return RizFactorKharidForoshSearchID2();
        }
        public RizFactorKharidForoshDB RizFactorKharidForoshFind1(int IDFactorKHF)
        {
            DataRow dr = RizFactorKharidForoshFind2(IDFactorKHF);
            RizFactorKharidForoshDB bd = new RizFactorKharidForoshDB();
            bd.IDFactorKHF = Convert.ToInt32(dr[0].ToString());
            bd.NameKalayeKharidForosh1  = dr[1].ToString();
            bd.Tedade1 = Convert.ToInt32(dr[2].ToString());
            bd.NameKalayeKharidForosh2  = dr[3].ToString();
            bd.Tedade2 = Convert.ToInt32(dr[4].ToString());
            bd.NameKalayeKharidForosh3  = dr[5].ToString();
            bd.Tedade3 = Convert.ToInt32(dr[6].ToString());
            bd.NameKalayeKharidForosh4  = dr[7].ToString();
            bd.Tedade4 = Convert.ToInt32(dr[8].ToString());
            bd.NameKalayeKharidForosh5  = dr[9].ToString();
            bd.Tedade5 = Convert.ToInt32(dr[10].ToString());
            bd.NameKalayeKharidForosh6  = dr[11].ToString();
            bd.Tedade6 = Convert.ToInt32(dr[12].ToString());
            bd.FKFactor = Convert.ToInt32(dr[13].ToString());
            bd.GheimateKol = Convert.ToInt64(dr[14].ToString());
            return bd;
        }
    }
}

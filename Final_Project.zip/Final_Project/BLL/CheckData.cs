﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
using System.Globalization;

namespace BLL
{
    public class CheckData:CheckManagment
    {

        DataView dw = new DataView();
        public DataTable CheckComboShow1()
        {
            return CheckComboShow2();
        }

        public DataView CheckShow1()
        {
            return CheckShow2();
        }


        //فیلترها
        public DataView FilterTarikheSarReside1(DateTime  TarikheSarResideCheck)
        {
            dw.RowFilter = FilterTarikheSarReside2(TarikheSarResideCheck);
            return dw;
        }
        public DataView FilterNameCheckDahande1(string NameCheckDahande)
        {
            dw.RowFilter = FilterNameCheckDahande2(NameCheckDahande);
            return dw;
        }
        public DataView FilterVazeiyatePardakhtOrVosol1(string VazeiyatePardakhtOrVosol)
        {
            dw.RowFilter = FilterVazeiyatePardakhtOrVosol2(VazeiyatePardakhtOrVosol);
            return dw;
        }
        public DataView FilterFKFactor1(int FKFactor)
        {
            dw.RowFilter = FilterFKFactor2(FKFactor);
            return dw;
        }
        //
        //
        //
        public void CheckInsert1(CheckDB bd)
        {
            CheckInsert2(bd);
        }
        public void CheckDelete1(int IDCheck)
        {
            CheckDelete2(IDCheck);
        }
        public void CheckUpdate1(CheckDB bd)
        {
            CheckUpdate2(bd);
        }
        public Boolean CheckSearch1(int IDCheck)
        {
            return CheckSearch2(IDCheck);
        }
        public DataTable CheckSearchID1()
        {
            return CheckSearchID2();
        }
        public CheckDB CheckFind1(int IDCheck)
        {
            DataRow dr = CheckFind2(IDCheck);
            CheckDB bd = new CheckDB();
            bd.IDCheck = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeTaraconesh = Convert.ToInt32(dr[1].ToString());
            bd.TarikheSabteCheck = Convert.ToDateTime(dr[2].ToString());
            bd.TarikheSarResideCheck = Convert.ToDateTime (dr[3].ToString());
            bd.NameCheckDahande = dr[4].ToString();
            bd.NameBank = dr[5].ToString();
            bd.ShobeBank = dr[6].ToString();
            bd.VazeiyatePardakhtOrVosol = dr[7].ToString();
            bd.ShomareSerialeCheck = dr[8].ToString();
            bd.MablagheCheck =Convert.ToInt64( dr[9].ToString());
            return bd;
        }

    }
}

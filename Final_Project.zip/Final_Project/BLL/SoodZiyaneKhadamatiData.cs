﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.SqlClient;
namespace BLL
{
  public class SoodZiyaneKhadamatiData:SoodZiyaneKhadamatiManagment 
    {
        DataView dw = new DataView();
        public DataView SoodZiyaneKhadamatiShow1()
        {
            return SoodZiyaneKhadamatiShow2();
        }
        public void SoodZiyaneKhadamatiInsert1(SoodZiyaneKhadamatiDB bd)
        {
            SoodZiyaneKhadamatiInsert2(bd);
        }

        public void SoodZiyaneKhadamatiUpdate1(SoodZiyaneKhadamatiDB bd)
        {
            SoodZiyaneKhadamatiUpdate2(bd);
        }
        public Boolean SoodZiyaneKhadamatiSearch1(int IDSoodZiyaneKhadamati)
        {
            return SoodZiyaneKhadamatiSearch2(IDSoodZiyaneKhadamati);
        }
        public SoodZiyaneKhadamatiDB SoodZiyaneKhadamatiFind1(int IDSoodZiyaneKhadamati)
        {
            DataRow dr = SoodZiyaneKhadamatiFind2(IDSoodZiyaneKhadamati);
            SoodZiyaneKhadamatiDB bd = new SoodZiyaneKhadamatiDB();
            bd.IDSoodZiyaneKhadamati = Convert.ToInt32(dr[0].ToString());
            bd.DaramadeKhadamat = Convert.ToInt64(dr[1].ToString());
            bd.HazineEjare = Convert.ToInt64(dr[2].ToString());
            bd.HazineHoghogh = Convert.ToInt64(dr[3].ToString());
            bd.HazineAbBarghTel = Convert.ToInt64(dr[4].ToString());
            bd.HazineMotefareghe = Convert.ToInt64(dr[5].ToString());
            bd.SUMHazineha = Convert.ToInt64(dr[6].ToString());
            bd.SoodVaZiyanGhableKasreMaliyat = Convert.ToInt64(dr[7].ToString());
            bd.Maliyat25 = Convert.ToInt64(dr[8].ToString());
            bd.SoodYaZiyaneVizhe = Convert.ToInt64(dr[9].ToString());
            return bd;
        }
        public DataTable SoodZiyaneKhadamatiSearchID1()
        {
            return SoodZiyaneKhadamatiSearchID2();
        }
    }
}

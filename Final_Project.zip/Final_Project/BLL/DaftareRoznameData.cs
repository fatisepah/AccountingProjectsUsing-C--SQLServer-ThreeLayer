﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BLL
{
   public  class DaftareRoznameData:DaftareRoznameManagment 
    {
        DataView dw = new DataView();
        public DataTable DaftareRoznameComboShow1()
        {
            return DaftareRoznameComboShow2();
        }

        public DataView DaftareRoznameShow1()
        {
            return DaftareRoznameShow2();
        }
        public DataView FilterIDDaftareRozname1(int IDDaftareRozname)
        {
            dw.RowFilter = FilterIDDaftareRozname2(IDDaftareRozname);
            return dw;
        }

        public void DaftareRoznameInsert1(DaftareRoznameDB bd)
        {
            DaftareRoznameInsert2(bd);
        }
        public void DaftareRoznameDelete1(int IDDaftareRozname)
        {
            DaftareRoznameDelete2(IDDaftareRozname);
        }
        public void DaftareRoznameUpdate1(DaftareRoznameDB bd)
        {
            DaftareRoznameUpdate2(bd);
        }
        public Boolean DaftareRoznameSearch1(int IDDaftareRozname)
        {
            return DaftareRoznameSearch2(IDDaftareRozname);
        }
        public DataTable DaftareRoznameSearchID1()
        {
            return DaftareRoznameSearchID2();
        }
        public DaftareRoznameDB DaftareRoznameFind1(int IDDaftareRozname)
        {
            DataRow dr = DaftareRoznameFind2(IDDaftareRozname);
            DaftareRoznameDB bd = new DaftareRoznameDB();
            bd.IDDaftareRozname = Convert.ToInt32(dr[0].ToString());
            bd.FKSanadeHesabdari = Convert.ToInt32(dr[1].ToString());

            return bd;
        }

    }
}

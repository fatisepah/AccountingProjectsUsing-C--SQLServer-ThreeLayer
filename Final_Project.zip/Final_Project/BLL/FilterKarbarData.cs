﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterKarbarData: FilterKarbarManagment
    {
        DataView dw = new DataView();
        
        public DataView KarbarShow1()
        {
            dw = show_data();
            return dw;
        }



        public DataView FilterUserKarbar1(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
        public DataView FilterNameKarbar1(string barangh)
        {
            dw.RowFilter = Filter1(barangh);
            return dw;
        }
               

       
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterhaData : FilterhaManagement
    {
        DataView dw = new DataView();
      
        public DataView get_data()
        {
            dw = show_data();
            return dw;
        }
      
        public DataView Filter(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
        public DataView Filter2_NameHesabMoein(string NameHesabMoein)
        {
            dw.RowFilter = Filter39(NameHesabMoein);
            return dw;
        }

        public DataView Filter2_NameHesabTafzily(string NameHesabTafzily)
        {
            dw.RowFilter = Filter30_39(NameHesabTafzily);
            return dw;
        }
        public DataView FilterNoeHesab1(string NoeHesab)
        {
            dw.RowFilter = FilterNoeHesab2(NoeHesab);
            return dw;
        }
      
        
       
    }
}

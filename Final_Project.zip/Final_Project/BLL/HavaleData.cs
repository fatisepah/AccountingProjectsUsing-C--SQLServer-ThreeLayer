﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class HavaleData:HavaleManagment 
    {
        DataView dw = new DataView();
        public DataTable HavaleComboShow1()
        {
            return HavaleComboShow2();
        }

        public DataView HavaleShow1()
        {
            return HavaleShow2();
        }


        //فیلترها
        public DataView FilterTarikheSarReside1(DateTime TarikheSarResideHavale)
        {
            dw.RowFilter = FilterTarikheSarReside2(TarikheSarResideHavale);
            return dw;
        }
        public DataView FilterNameHavaleDahande1(string NameHavaleDahande)
        {
            dw.RowFilter = FilterNameHavaleDahande2(NameHavaleDahande);
            return dw;
        }
        public DataView FilterVazeiyatePardakhtOrVosol1(string VazeiyatePardakhtOrVosol)
        {
            dw.RowFilter = FilterVazeiyatePardakhtOrVosol2(VazeiyatePardakhtOrVosol);
            return dw;
        }
        public DataView FilterFKFactor1(int FKFactor)
        {
            dw.RowFilter = FilterFKFactor2(FKFactor);
            return dw;
        }
       //
       //
        public void HavaleInsert1(HavaleDB bd)
        {
            HavaleInsert2(bd);
        }
        public void HavaleDelete1(int IDHavale)
        {
            HavaleDelete2(IDHavale);
        }
        public void HavaleUpdate1(HavaleDB bd)
        {
            HavaleUpdate2(bd);
        }
        public Boolean HavaleSearch1(int IDHavale)
        {
            return HavaleSearch2(IDHavale);
        }
        public DataTable HavaleSearchID1()
        {
            return HavaleSearchID2();
        }
        public HavaleDB HavaleFind1(int IDHavale)
        {
            DataRow dr = HavaleFind2(IDHavale);
            HavaleDB bd = new HavaleDB();
            bd.IDHavale = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeTaraconesh = Convert.ToInt32(dr[1].ToString());
            bd.TarikheSabteHavale = Convert.ToDateTime(dr[2].ToString());
            bd.NameHavaleDahande = dr[3].ToString();
            bd.TarikheSarResideHavale = Convert.ToDateTime(dr[4].ToString());
            bd.NameBank = dr[5].ToString();
            bd.ShobeBank = dr[6].ToString();
            bd.VazeiyatePardakhtOrVosol = dr[6].ToString();
            bd.ShomareSerialeHavale = dr[7].ToString();
            bd.MablagheHavale = Convert.ToInt64(dr[8].ToString());
            return bd;
        }
    }
}

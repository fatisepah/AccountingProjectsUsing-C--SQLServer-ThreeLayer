﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class FilterData1 : FilterManagment1 
    {
        DataView dw = new DataView();
        public DataView HesabhaShow1()
        {
            return HesabhaShow2();
        }

        public DataView RoidadeGheireMaliShow1()
        {
            return RoidadeGheireMaliShow2();
        }
        public DataView FilterSharheRoidad1(string SharheRoidad)
        {
            dw.RowFilter = FilterNameHesabKol2(SharheRoidad);
            return dw;
        }
        public DataView FilterNameHesabKol1(string NameHesabKol)
        {
            dw.RowFilter = FilterNameHesabKol2(NameHesabKol);
            return dw;
        }

        public DataView Filter_NameHesabKol(string NameHesabKol)
        {
            dw.RowFilter = Filter30(NameHesabKol);
            return dw;
        }
        public DataView Filter2_NameHesabMoein(string NameHesabMoein)
        {
            dw.RowFilter = Filter39(NameHesabMoein);
            return dw;
        }

        public DataView Filter2_NameHesabTafzily(string NameHesabTafzily)
        {
            dw.RowFilter = Filter30_39(NameHesabTafzily);
            return dw;
        }
      
    }
}

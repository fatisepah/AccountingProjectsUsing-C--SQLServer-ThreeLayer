﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public class RoidadeGheireMaliData:RoidadeGheireMaliManagment
    {
       DataView dw = new DataView();

       public DataView RoidadeGheireMaliShow1()
        {
            return RoidadeGheireMaliShow2();
        }
       public void RoidadeGheireMaliInsert1(RoidadeGheireMaliDB bd)
        {
            RoidadeGheireMaliInsert2(bd);
        }
       public DataView Filter1(string SharheRoidad)
       {
           dw.RowFilter = Filter2(SharheRoidad);
           return dw;
       }
       public Boolean RoidadeGheireMaliSearch1(int IDRoidad)
       {
           return RoidadeGheireMaliSearch2(IDRoidad);
       }

       public DataTable  RoidadeGheireMaliSearchTarikh1()
       {
           return RoidadeGheireMaliSearchTarikh2();
       }
       public DataTable RoidadeGheireMaliSearchID1()
       {
           return RoidadeGheireMaliSearchID2();
       }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BLL
{
   public  class DaftareKolData:DaftareKolManagment 
    {
        DataView dw = new DataView();
        public DataTable DaftareKolComboShow1()
        {
            return DaftareKolComboShow2();
        }

        public DataView DaftareKolShow1()
        {
            return DaftareKolShow2();
        }
       //
       //
       //
        public DataView FilterIDDaftareKol1(int IDDaftareKol)
        {
            dw.RowFilter = FilterIDDaftareKol2(IDDaftareKol);
            return dw;
        }
        public DataView FilterMandeBedehkar1(long MandeBedehkar)
        {
            dw.RowFilter = FilterMandeBedehkar2(MandeBedehkar);
            return dw;
        }
        public DataView FilterMandeBestankar1(long MandeBestankar)
        {
            dw.RowFilter = FilterMandeBestankar2(MandeBestankar);
            return dw;
        }
       //
       //
        public void DaftareKolInsert1(DaftareKolDB bd)
        {
            DaftareKolInsert2(bd);
        }
        public void DaftareKolDelete1(int IDDaftareKol)
        {
            DaftareKolDelete2(IDDaftareKol);
        }
        public void DaftareKolUpdate1(DaftareKolDB bd)
        {
            DaftareKolUpdate2(bd);
        }
        public Boolean DaftareKolSearch1(int IDDaftareKol)
        {
            return DaftareKolSearch2(IDDaftareKol);
        }
        public Boolean DaftareKolSearchHesab1(int FKHesab)
        {
            return DaftareKolSearchHesab2(FKHesab);
        }
        public DataTable DaftareKolSearchID1()
        {
            return DaftareKolSearchID2();
        }
        public DaftareKolDB DaftareKolFind1(int IDDaftareKol)
        {
            DataRow dr = DaftareKolFind2(IDDaftareKol);
            DaftareKolDB bd = new DaftareKolDB();
            bd.IDDaftareKol = Convert.ToInt32(dr[0].ToString());
            bd.FKDaftareRozname = Convert.ToInt32(dr[1].ToString());
            bd.MandeBedehkar = Convert.ToInt64(dr[2].ToString());
            bd.MandeBestankar = Convert.ToInt64(dr[3].ToString());
            return bd;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
    public class FilterHesabBankiData: FilterHesabBankiManageMent
    {
        DataView dw = new DataView();
        
        public DataView HesabBankiShow1()
        {
            dw = show_data();
            return dw;
        }



        public DataView FilterNBank1(string nam_bank)
        {
            dw.RowFilter = Filter_kala(nam_bank);
            return dw;
        }
        public DataView FilterSHHesab1(string barangh)
        {
            dw.RowFilter = Filter1(barangh);
            return dw;
        }
       
       
    }
}

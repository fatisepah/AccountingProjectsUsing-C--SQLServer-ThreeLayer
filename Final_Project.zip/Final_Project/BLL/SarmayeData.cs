﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.SqlClient;
namespace BLL
{
   public  class SarmayeData:SarmayeManagment 
    {
        DataView dw = new DataView();
        public DataView SarmayeShow1()
        {
            return SarmayeShow2();
        }
        public void SarmayeInsert1(SarmayeDB bd)
        {
            SarmayeInsert2(bd);
        }

        public void SarmayeUpdate1(SarmayeDB bd)
        {
            SarmayeUpdate2(bd);
        }
        public Boolean SarmayeSearch1(int IDSarmaye)
        {
            return SarmayeSearch2(IDSarmaye);
        }
        public SarmayeDB SarmayeFind1(int IDSarmaye)
        {
            DataRow dr = SarmayeFind2(IDSarmaye);
            SarmayeDB bd = new SarmayeDB();
            bd.IDSarmaye = Convert.ToInt32(dr[0].ToString());
            bd.SarmayeAvalDore  = Convert.ToInt64(dr[1].ToString());
            bd.SarmayeGozariyeMojadad  = Convert.ToInt64(dr[2].ToString());
            bd.SoodeVizhe = Convert.ToInt64(dr[3].ToString());
            bd.Bardasht = Convert.ToInt64(dr[4].ToString());
            bd.ZiyaneVizhe = Convert.ToInt64(dr[5].ToString());
            bd.AfzayeshDarSarmaye = Convert.ToInt64(dr[6].ToString());
            bd.KaheshDarSarmaye = Convert.ToInt64(dr[7].ToString());
            bd.SarmayePayanDore  = Convert.ToInt64(dr[8].ToString());
            return bd;
        }
        public DataTable SarmayeSearchID1()
        {
            return SarmayeSearchID2();
        }
    }
}

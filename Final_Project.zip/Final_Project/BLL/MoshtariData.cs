﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class MoshtariData:MoshtariManagment
    {
        DataView dw = new DataView();
        public DataView MoshtariShow1()
        {
            return MoshtariShow2();
        }
        public DataTable MoshtariComboShow1()
        {
            return MoshtariComboShow2();
        }
        public void MoshtariInsert1(MoshtariDB bd)
        {
            MoshtariInsert2(bd);
        }
        public void MoshtariDelete1(int IDMoshtari)
        {
            MoshtariDelete2(IDMoshtari);
        }
        public void MoshtariUpdate1(MoshtariDB bd)
        {
            MoshtariUpdate2(bd);
        }
        public Boolean MoshtariSearch1(int IDMoshtari)
        {
            return MoshtariSearch2(IDMoshtari);
        }
        public MoshtariDB MoshtariFind1(int IDMoshtari)
        {
            DataRow dr = MoshtariFind2(IDMoshtari);
            MoshtariDB bd = new MoshtariDB();
            bd.IDMoshtari = Convert.ToInt32(dr[0].ToString());
            bd.FKHesabBanki  = Convert.ToInt32(dr[1].ToString());
            bd.FKNoeMoshtari = Convert.ToInt32(dr[2].ToString());
            bd.NameKarbar = dr[3].ToString();
            bd.NameMoshtari = dr[4].ToString();
            bd.Mobile  = dr[5].ToString();
            bd.AddressKhane  = dr[6].ToString();
            bd.AddressKar = dr[7].ToString();
            bd.Email  = dr[8].ToString();
            return bd;
        }
        public DataTable MoshtariSearchID1()
        {
            return MoshtariSearchID2();
        }
        public DataView FilterNMoshtari1(string NameMoshtari)
        {
            dw.RowFilter = FilterNMoshtari2(NameMoshtari);
            return dw;
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.SqlClient;
namespace BLL
{
   public  class SoodZiyaneBazarganiData:SoodZiyaneBazarganiManagment 
    {
        DataView dw = new DataView();
        public DataView SoodZiyaneBazarganiShow1()
        {
            return SoodZiyaneBazarganiShow2();
        }
        public void SoodZiyaneBazarganiInsert1(SoodZiyaneBazarganiDB bd)
        {
            SoodZiyaneBazarganiInsert2(bd);
        }

        public void SoodZiyaneBazarganiUpdate1(SoodZiyaneBazarganiDB bd)
        {
            SoodZiyaneBazarganiUpdate2(bd);
        }
        public Boolean SoodZiyaneBazarganiSearch1(int IDSoodZiyaneBazargani)
        {
            return SoodZiyaneBazarganiSearch2(IDSoodZiyaneBazargani);
        }
        public SoodZiyaneBazarganiDB SoodZiyaneBazarganiFind1(int IDSoodZiyaneBazargani)
        {
            DataRow dr = SoodZiyaneBazarganiFind2(IDSoodZiyaneBazargani);
            SoodZiyaneBazarganiDB bd = new SoodZiyaneBazarganiDB();
            bd.IDSoodZiyaneBazargani = Convert.ToInt32(dr[0].ToString());
            bd.Forosh = Convert.ToInt64(dr[1].ToString());
            bd.BargashtAzForoshVaTakhfifat = Convert.ToInt64(dr[2].ToString());
            bd.TakhfifateNaghdiyeForosh = Convert.ToInt64(dr[3].ToString());
            bd.ForosheKhales = Convert.ToInt64(dr[4].ToString());
            bd.MojodiyeKalayeAvalDore = Convert.ToInt64(dr[5].ToString());
            bd.KharidTeyeDore = Convert.ToInt64(dr[6].ToString());
            bd.BargashtAzKharidVaTakhfifat = Convert.ToInt64(dr[7].ToString());
            bd.TakhfifateNaghdiyeKharid = Convert.ToInt64(dr[8].ToString());
            bd.KharideKhales = Convert.ToInt64(dr[9].ToString());
            bd.HazineHamleKalaKharidi = Convert.ToInt64(dr[10].ToString());
            bd.BahayeTamamShodeKalaKharidi = Convert.ToInt64(dr[11].ToString());
            bd.MojodiyeKalayeAmadeForosh = Convert.ToInt64(dr[12].ToString());
            bd.MojodieKalayePayanDore = Convert.ToInt64(dr[13].ToString());
            bd.BahayeTamamShodeKalaForosh = Convert.ToInt64(dr[14].ToString());
            bd.SoodeNaVizhe = Convert.ToInt64(dr[15].ToString());
            bd.HazineOmomiVaEdari = Convert.ToInt64(dr[16].ToString());
            bd.HazinehayeForosh = Convert.ToInt64(dr[17].ToString());
            bd.SoodeKhales = Convert.ToInt64(dr[18].ToString());
            return bd;
        }
        public DataTable SoodZiyaneBazarganiSearchID1()
        {
            return SoodZiyaneBazarganiSearchID2();
        }
    }
}

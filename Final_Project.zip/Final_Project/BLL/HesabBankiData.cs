﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public class HesabBankiData:HesabBankiManagment 
    {
       DataView dw = new DataView();
       public DataView  HesabBankiShow1()
        {
            return HesabBankiShow2();
        }
       public DataTable  HesabBankiReportShow1()
       {
           return HesabBankiReportShow2();
       }
       public void HesabBankiInsert1(HesabBankiDB bd)
        {
            HesabBankiInsert2(bd);
        }
       public void HesabBankiUpdate1(HesabBankiDB bd)
       {
           HesabBankiUpdate2(bd);
       }
       public void HesabBankiDelete1(int IDHesabBanki)
        {
            HesabBankiDelete2(IDHesabBanki);
        }

       public Boolean HesabBankiSearch1(int IDHesabBanki)
       {
           return HesabBankiSearch2(IDHesabBanki);
       }
       public DataTable  HesabBankiSearchID1()
       {
           return HesabBankiSearchID2();
       }
       public HesabBankiDB HesabBankiFind1(int IDHesabBanki)
       {
           DataRow dr = HesabBankiFind2(IDHesabBanki);
           HesabBankiDB bd = new HesabBankiDB();
           bd.IDHesabBanki = Convert.ToInt32(dr[0].ToString());
           bd.NameBank = dr[1].ToString();
           bd.ShobeBank = dr[2].ToString();
           bd.ShomareHesab  = dr[3].ToString();
           bd.ShomareKart = dr[4].ToString();
           bd.MablagheMojodi =Convert.ToInt32( dr[5].ToString()); 
           return bd;
       }
       public DataView FilterNBank1(string NameBank)
       {
           dw.RowFilter = FilterNBank2(NameBank);
           return dw;
       }
       public DataView FilterSHHesab1(string ShomareHesab)
       {
           dw.RowFilter = FilterSHHesab2(ShomareHesab);
           return dw;
       }
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BLL
{
   public class RizFactorKerayeData:RizFactorKerayeManagment 
    {
        DataView dw = new DataView();
        public DataTable RizFactorKerayeComboShow1()
        {
            return RizFactorKerayeComboShow2();
        }

        public DataView RizFactorKerayeShow1()
        {
            return RizFactorKerayeShow2();
        }


        //فیلترها
        public DataView FilterTarikheBargashteKala1(DateTime TarikheBargashteKala)
        {
            dw.RowFilter = FilterTarikheBargashteKala2(TarikheBargashteKala);
            return dw;
        }
       //
        public DataView FilterNameKalayeKeraye11(string NameKalayeKeraye1)
        {
            dw.RowFilter = FilterNameKalayeKeraye12(NameKalayeKeraye1);
            return dw;
        }
        public DataView FilterNameKalayeKeraye21(string NameKalayeKeraye2)
        {
            dw.RowFilter = FilterNameKalayeKeraye22(NameKalayeKeraye2);
            return dw;
        }
        public DataView FilterNameKalayeKeraye31(string NameKalayeKeraye3)
        {
            dw.RowFilter = FilterNameKalayeKeraye32(NameKalayeKeraye3);
            return dw;
        }
        public DataView FilterNameKalayeKeraye41(string NameKalayeKeraye4)
        {
            dw.RowFilter = FilterNameKalayeKeraye42(NameKalayeKeraye4);
            return dw;
        }
        //
        //
        //
        public void RizFactorKerayeInsert1(RizFactorKerayeDB bd)
        {
            RizFactorKerayeInsert2(bd);
        }
        public void RizFactorKerayeDelete1(int IDFactorKeraye)
        {
            RizFactorKerayeDelete2(IDFactorKeraye);
        }
        public void RizFactorKerayeUpdate1(RizFactorKerayeDB bd)
        {
            RizFactorKerayeUpdate2(bd);
        }
        public Boolean RizFactorKerayeSearch1(int IDFactorKeraye)
        {
            return RizFactorKerayeSearch2(IDFactorKeraye);
        }
        public DataTable RizFactorKerayeSearchID1()
        {
            return RizFactorKerayeSearchID2();
        }
        public RizFactorKerayeDB RizFactorKerayeFind1(int IDFactorKeraye)
        {
            DataRow dr = RizFactorKerayeFind2(IDFactorKeraye);
            RizFactorKerayeDB bd = new RizFactorKerayeDB();
            bd.IDFactorKeraye = Convert.ToInt32(dr[0].ToString());
            bd.NameKalayeKeraye1  = dr[1].ToString();
            bd.Tedade1  = Convert.ToInt32 (dr[2].ToString());
            bd.NameKalayeKeraye2  = dr[3].ToString();
            bd.Tedade2 = Convert.ToInt32(dr[4].ToString());
            bd.NameKalayeKeraye3  = dr[5].ToString();
            bd.Tedade3 = Convert.ToInt32(dr[6].ToString());
            bd.NameKalayeKeraye4  = dr[7].ToString();
            bd.Tedade4 = Convert.ToInt32(dr[8].ToString());
            bd.FKFactor = Convert.ToInt32(dr[9].ToString());
            bd.TarikheBargashteKala = Convert.ToDateTime(dr[12].ToString());
            bd.GheimateKoleKalaha = Convert.ToInt64(dr[13].ToString());
            return bd;
        }
    }
}

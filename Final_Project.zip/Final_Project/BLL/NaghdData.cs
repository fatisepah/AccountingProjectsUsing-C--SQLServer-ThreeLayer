﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class NaghdData:NaghdManagment 
    {
        DataView dw = new DataView();
        public DataTable NaghdComboShow1()
        {
            return NaghdComboShow2();
        }

        public DataView NaghdShow1()
        {
            return NaghdShow2();
        }


        //فیلترها
        public DataView FilterTarikheSabt1(DateTime TarikheSabteNaghdy)
        {
            dw.RowFilter = FilterTarikheSabt2(TarikheSabteNaghdy);
            return dw;
        }
        public DataView FilterNamePardakhtKonande1(string NamePardakhtKonande)
        {
            dw.RowFilter = FilterNamePardakhtKonande2(NamePardakhtKonande);
            return dw;
        }
        public DataView FilterFKFactor1(int FKFactor)
        {
            dw.RowFilter = FilterFKFactor2(FKFactor);
            return dw;
        }
       //
       //
        public void NaghdInsert1(NaghdDB bd)
        {
            NaghdInsert2(bd);
        }
        public void NaghdDelete1(int IDNaghdy)
        {
            NaghdDelete2(IDNaghdy);
        }
        public void NaghdUpdate1(NaghdDB bd)
        {
            NaghdUpdate2(bd);
        }
        public Boolean NaghdSearch1(int IDNaghdy)
        {
            return NaghdSearch2(IDNaghdy);
        }
        public DataTable NaghdSearchID1()
        {
            return NaghdSearchID2();
        }
        public NaghdDB NaghdFind1(int IDNaghdy)
        {
            DataRow dr = NaghdFind2(IDNaghdy);
            NaghdDB bd = new NaghdDB();
            bd.IDNaghdy = Convert.ToInt32(dr[0].ToString());
            bd.FKNoeTaraconesh = Convert.ToInt32(dr[1].ToString());
            bd.TarikheSabteNaghdy = Convert.ToDateTime(dr[2].ToString());
            bd.NamePardakhtKonande = dr[3].ToString();
            bd.MablagheNaghdy = Convert.ToInt64(dr[4].ToString());
            return bd;
        }
    }
}

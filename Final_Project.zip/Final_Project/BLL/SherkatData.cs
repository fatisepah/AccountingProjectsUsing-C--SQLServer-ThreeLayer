﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace BLL
{
   public  class SherkatData:SherkatManagment 
    {
       DataView dw = new DataView();
       public DataView SherkatShow1()
       {
           return SherkatShow2();
       }
       public DataTable SherkatComboShow1()
       {
           return SherkatComboShow2();
       }
       public void SherkatInsert1(SherkatDB bd)
        {
            SherkatInsert2(bd);
        }
       public void SherkatDelete1(int IDSherkat)
        {
            SherkatDelete2(IDSherkat);
        }
       public void SherkatUpdate1(SherkatDB bd)
        {
            SherkatUpdate2(bd);
        }
       public Boolean SherkatSearch1(int IDSherkat)
        {
            return SherkatSearch2(IDSherkat);
        }
       public SherkatDB SherkatFind1(int IDSherkat)
        {
            DataRow dr = SherkatFind2(IDSherkat);
            SherkatDB bd = new SherkatDB();
            bd.IDSherkat = Convert.ToInt32(dr[0].ToString());
            bd.FKHesabBanki = Convert.ToInt32(dr[1].ToString());
            bd.FKNoeMoshtari = Convert.ToInt32(dr[2].ToString());
            bd.NameKarbar = dr[3].ToString();
            bd.NameSherkat = dr[4].ToString();
            bd.AddressSherkat = dr[5].ToString();
            bd.TelSherkat = dr[6].ToString();
            bd.Email = dr[7].ToString();
            bd. Fax= dr[8].ToString();
            return bd;
        }
       public DataTable SherkatSearchID1()
       {
           return SherkatSearchID2();
       }
       public DataView FilterNSherkat1(string NameSherkat)
       {
           dw.RowFilter = FilterNSherkat2(NameSherkat);
           return dw;
       }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DAL;
namespace BLL
{
   public  class SanadeHesabdariData:SanadeHesabdariManagment 
    {
        DataView dw = new DataView();
        public DataView SanadeHesabdariShow1()
        {
            return SanadeHesabdariShow2();
        }
        public DataTable  SanadeHesabdariReportShow1()
        {
            return SanadeHesabdariReportShow2();
        }
        public void SanadeHesabdariInsert1(SanadeHesabdariDB bd)
        {
            SanadeHesabdariInsert2(bd);
        }
        public void SanadeHesabdariUpdate1(SanadeHesabdariDB bd)
        {
            SanadeHesabdariUpdate2(bd);
        }
        public void SanadeHesabdariDelete1(int IDSanad)
        {
            SanadeHesabdariDelete2(IDSanad);
        }

        public Boolean SanadeHesabdariSearch1(int IDSanad)
        {
            return SanadeHesabdariSearch2(IDSanad);
        }
        public DataTable SanadeHesabdariSearchID1()
        {
            return SanadeHesabdariSearchID2();
        }
        public SanadeHesabdariDB SanadeHesabdariFind1(int IDSanad)
        {
            DataRow dr = SanadeHesabdariFind2(IDSanad);
            SanadeHesabdariDB bd = new SanadeHesabdariDB();
            bd.IDSanad = Convert.ToInt32(dr[0].ToString());
            bd.FKHesabeBedehkar = Convert.ToInt32(dr[1].ToString());
            bd.FKHesabeBestankar = Convert.ToInt32(dr[2].ToString());
            bd.FKNoeSanad = Convert.ToInt32(dr[3].ToString());
            bd.NameKarbar = dr[4].ToString();
            bd.TarikheSanad = Convert.ToDateTime (dr[5].ToString());
            bd.SharheSanad = dr[6].ToString();
            bd.MablagheBedehkari  = Convert.ToInt64(dr[7].ToString());
            bd.MablagheBestanKari  = Convert.ToInt64(dr[8].ToString());
            return bd;
        }
        public DataView FilterSharheSanad1(string SharheSanad)
        {
            dw.RowFilter = FilterSharheSanad2(SharheSanad);
            return dw;
        }
        public DataView FilterTarikh1(DateTime  TarikheSanad)
        {
            dw.RowFilter = FilterTarikh2(TarikheSanad);
            return dw;
        }
        public DataView FilterHBedehkar1(int FKHesabeBedehkar)
        {
            dw.RowFilter = FilterHBedehkar2(FKHesabeBedehkar);
            return dw;
        }
        public DataView FilterHBestankar1(int FKHesabeBestankar)
        {
            dw.RowFilter = FilterHBestankar2(FKHesabeBestankar);
            return dw;
        }
    }
}
